//
//  AppDelegate.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/16.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit
import IQKeyboardManagerSwift
import RxSwift
@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    let disposeBag = DisposeBag()

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        self.window = UIWindow(frame: UIScreen.main.bounds)
        self.window?.backgroundColor = UIColor.black
        
        
//        if !UserDefaults.standard.bool(forKey: "noFirstLaunch") {
//            UserDefaults.standard.set(true, forKey: "noFirstLaunch")
//            UserDefaults.standard.synchronize()
//
//            let featureVC = NewFeatureViewController()
//            featureVC.imageNameList = ["引导页_1", "引导页_2", "引导页_3", "引导页_4"]
//            featureVC.completed = {[weak self] in
//                let mainVC = MainViewController()
//                self?.window?.rootViewController = mainVC
//            }
//            self.window?.rootViewController = featureVC
//        }else{
//            if UserInfoManager.shared.isLogined {
                let mainVC = MainViewController()
                self.window?.rootViewController = mainVC
//            }else{
//                let loginVC = LoginViewController()
//                let loginNav = BaseNavigationController(rootViewController: loginVC)
//                self.window?.rootViewController = loginNav
//            }
//        }
        
        
        self.window?.makeKeyAndVisible()
        
        setupIQKeyboardManager()
        setupSVProgressHUD()
        registerWXChat()
        addUpdate()
        return true
    }
    
    func setupIQKeyboardManager() {
        IQKeyboardManager.shared.enable = true
        IQKeyboardManager.shared.shouldResignOnTouchOutside = true
        IQKeyboardManager.shared.enableAutoToolbar = false
    }
    
    func setupSVProgressHUD() {
        SVProgressHUD.setMinimumDismissTimeInterval(1.5)
        SVProgressHUD.setMaximumDismissTimeInterval(2.0)
        SVProgressHUD.setDefaultStyle(SVProgressHUDStyle.dark)
        SVProgressHUD.setDefaultMaskType(SVProgressHUDMaskType.clear)
        SVProgressHUD.setMinimumSize(CGSize(width: 80, height: 80))
    }
    //向微信注册
    func registerWXChat() {
        let isSuc = WXApi.registerApp(kWechat_AppKey)
//        let isSuc = WXApi.registerApp(kWechat_AppKey, universalLink: "CBIT")
        print(isSuc)
    }
    func application(_ app: UIApplication, open url: URL, options: [UIApplication.OpenURLOptionsKey: Any] = [:]) -> Bool {
        print(url)
        if url.host == nil {
            return true
        }
        
//        if url.host == "auctionDetail" {
//            let urlComponents = NSURLComponents(string: url.absoluteString)
//            var dic = [String: String]()
//            urlComponents?.queryItems?.enumerated().forEach({ (index, item) in
//                dic[item.name] = item.value
//            })
//            if let auctionId = dic["auctionId"]?.toInt() {
//                let vc = AuctionDetailViewController()
//                vc.auctionId = auctionId
//                UtilUser.getNavigationController()?.pushViewController(vc, animated: true)
//            }
//            return true
//        }
        if url.host == "safepay" {//支付宝
            //跳转支付宝钱包进行支付，处理支付结果
            AlipaySDK.defaultService()?.processOrder(withPaymentResult: url, standbyCallback: { (resultDic) in
                print("application_result=\(resultDic)")
                let resultStatus = (resultDic?["resultStatus"] as? String) ?? ""
                NotificationCenter.default.post(name: NSNotification.Name.alipayResult, object: nil, userInfo: ["resultStatus" : resultStatus])
            })
            return true
        }else if url.host == "pay" {//微信支付
            return WXApi.handleOpen(url, delegate: self)
        }
        return true
    }
    //添加更新提示
    func addUpdate() {
        noHUDprovider.rx.request(APITarget.getBySource)
            .map(BaseResponse<AppVersionModel>.self)
            .subscribe(onSuccess: { (res) in
                if let model = res.data {
                    let version = model.versionCoded ?? "1.0"
                    guard model.type == 1 else {
                        return
                    }
                    let isForce = model.state == 1
                    let desc = model.updateTip
                    let a = currentAppVersion.compare(version, options: String.CompareOptions.numeric)
                    if a != .orderedAscending {//>=
                        return
                    }
                    let alertVC = UIAlertController(title: "版本更新\(version)", message: desc, preferredStyle: UIAlertController.Style.alert)
                    if !isForce {
                        let cancelAction = UIAlertAction(title: "取消", style: .cancel) {(action) in

                        }
                        alertVC.addAction(cancelAction)
                    }
                    let okAction = UIAlertAction(title: "下载更新", style: .default) {[weak self](action) in
                        if let iosUrl = model.downloadUrl {
                            if let updateUrl = URL(string: iosUrl) {
                                if UIApplication.shared.canOpenURL(updateUrl) {
                                    UIApplication.shared.open(updateUrl, options: [:], completionHandler: nil)
                                }
                            }
                        }
                    }
                    alertVC.addAction(okAction)
                    let vc = self.window?.rootViewController
                    vc?.present(alertVC, animated: true, completion: nil)
                }
            }, onError: { (error) in
                
            })
            .disposed(by: disposeBag)
    }
    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
}

extension AppDelegate: WXApiDelegate {
    func onResp(_ resp: BaseResp) {
        //支付返回结果，实际支付结果需要去微信服务器端查询
        print(resp)
        if resp.isKind(of: PayResp.self) {
            NotificationCenter.default.post(name: NSNotification.Name.wechatPayResult, object: nil, userInfo: ["errCode" : NSNumber(value: resp.errCode)])
        }
    }
    func onReq(_ req: BaseReq) {
        print(req)
    }
}
