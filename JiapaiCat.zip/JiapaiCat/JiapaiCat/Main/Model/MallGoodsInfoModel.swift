//
//  MallGoodsInfoModel.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2020/1/13.
//  Copyright © 2020 刘文利. All rights reserved.
//

import UIKit
/*

     "applyed": false,
     "assessPrice": 8000.00,
     "boutique": 2,
     "categoryId": 1,
     "categoryName": "工艺品",
     "channelId": "",
     "clicked": false,
     "content": "",
     "costPrice": 5800.00,
     "createBy": "admin",
     "createTime": "2019-11-29 15:19:49",
     "deleted": 0,
     "desc": "desc",
     "description": "Apple iPhone 11 (A2223) 128GB 颜色可选",
     "deviceCode": "",
     "deviceType": "",
     "eendTime": "",
     "endTime": null,
     "goodsDetail": "",
     "goodsId": 179,
     "goodsName": "Apple iPhone 11 (A2223) 128GB 颜色可选",
     "goodsSubType": null,
     "goodsType": 1,
     "headImage": "[\"https://images.fmallnet.com/81f4a385971442be81dd5a0587534371\",\"https://images.fmallnet.com/f2d1a83784374d6d8a5b1050955e684f\",\"https://images.fmallnet.com/e9d9acfc00134ea8b74d172f1fe6921e\"]",
     "integral": 8000.00,
     "inventory": 3,
     "logo": "https://images.fmallnet.com/4e7aee2860cc4901bc1cfa30a881dfe6",
     "orderField": "",
     "page": {
         "currentResult": 0,
         "entityOrField": false,
         "pageNumber": 1,
         "pageSize": 10,
         "pageStr": "",
         "totalPage": 0,
         "totalResult": 0
     },
     "params": null,
     "price": 2000.00,
     "priceType": 2,
     "remark": "",
     "searchValue": "",
     "soldNum": 2,
     "sort": 99999,
     "sstartTime": "",
     "startTime": null,
     "status": 2,
     "supplier": "JD",
     "supplierId": 4,
     "updateBy": "cyz2019",
     "updateTime": "2019-12-27 10:50:40",
     "upperTime": null,
     "url5": "",
     "url6": "",
     "url7": "",
     "url8": "",
     "url9": ""
 }
 */
class MallGoodsInfoModel: Codable {
    var applyed: Bool = false
    var assessPrice: Double!
    var boutique: Int!
    var categoryId: Int!
    var categoryName: String!
    var content: String!
    var costPrice: Double!
    var createTime: String!
    var description: String!
    var goodsId: Int!
    var goodsName: String!
    var goodsType: Int!
    var headImage: String!
    var integral: Double!
    var inventory: Int!
    var logo: String!
    var price: Double!
    var priceType: Int!
    var status: Int!
    var goodsDetail: String?
}
