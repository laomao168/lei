//
//  OrderStatisticsModel.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/27.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit
/*
 {
     "waitReceivingGoods": 0,
     "waitDeliverGoods": 0,
     "waitPay": 0
 }
 */
class OrderStatisticsModel: NSObject, Codable {
    var waitReceivingGoods: Int = 0
    var waitDeliverGoods: Int = 0
    var waitPay: Int = 0
}
