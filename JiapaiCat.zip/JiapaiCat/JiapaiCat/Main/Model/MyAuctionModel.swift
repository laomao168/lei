//
//  MyAuctionModel.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/24.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit
/*

     "addPriceRuleId": 43,
     "applyed": false,
     "assessPrice": 3.00,
     "auctionId": 9242,
     "brokerage": 2.00,
     "categoryId": 1016,
     "categoryName": "",
     "channelId": "",
     "clicked": false,
     "costPrice": 1.00,
     "createBy": "cyz2019",
     "createTime": "2019-12-26 16:40:29",
     "deleted": 0,
     "desc": "desc",
     "deviceCode": "",
     "deviceType": "",
     "displayArea": 1,
     "endEndTime": "",
     "endStartPrice": null,
     "endStartTime": "",
     "endTime": "2019-12-27 16:55:00",
     "endTimes": 563580,
     "fatherCategoryId": null,
     "goodsDetail": "<p><span></span></p>\n<p></p>\n<p><img src=\"https://images.oneauct.com/faf0923935534c96834469c111e09031\"></p>\n<p><span></span><br></p>",
     "goodsId": 1369,
     "goodsName": "新手体验活动 首次充值用户活动 全额退款 老用户禁止参与体验",
     "headImage": "[\"https://images.oneauct.com/5a6a10b202d14f5c8a3590bf1672c1aa\"]",
     "list": [],
     "logo": "https://images.oneauct.com/cd2a923cf6384cc2ad8563ff9e403361",
     "mailingUserId": null,
     "mallGoodsId": null,
     "markupNum": 30,
     "markupPrice": 20.00,
     "maxProtectPrice": 10000.00,
     "openRobot": 1,
     "openRobotPrecent": 1,
     "orderField": "",
     "page": {
         "currentResult": 0,
         "entityOrField": false,
         "pageNumber": 1,
         "pageSize": 10,
         "pageStr": "",
         "totalPage": 0,
         "totalResult": 0
     },
     "params": null,
     "passTitle": "",
     "platformGoodsId": null,
     "protectPrice": 5.00,
     "remark": "",
     "robotPrecent": 60,
     "searchValue": "",
     "sort": null,
     "source": 2,
     "startEndTime": "",
     "startPrice": 520.00,
     "startStartPrice": null,
     "startStartTime": "",
     "startTime": "2019-12-27 16:45:00",
     "startTimes": -36420,
     "status": 3,
     "supplier": "其他",
     "supplierId": 8,
     "topPrice": 1120.00,
     "transactionPrice": null,
     "type": null,
     "updateBy": "",
     "updateTime": "2019-12-26 16:40:30",
     "userId": null,
     "username": "",
     "viewCount": 352
 }
 */
class MyAuctionModel: NSObject, Codable {
     var auctionId: Int!
     var categoryName: String?
     var startTime: String?
     var startTimes: Int?
     var endTime: String?
     var endTimes: Int?
     var topPrice: Double?
     var startPrice: Double?
     var viewCount: Int!
     var goodsId: Int?
     var goodsName: String?
     var logo: String?
     var markupNum: Int? //出价次数
     var status: Int! //2:即将开始，3:已开始
    var createTime: String?
}
