//
//  RechargeWechatModel.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/26.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit
/*
 {
   "nonceStr" : "3bf55bbad370a8fcad1d09b005e278c2",
   "partnerId" : "1566772371",
   "timeStamp" : "1578641470",
   "package" : "Sign=WXPay",
   "appId" : "wx10eb27bde7ae5089",
   "prepayId" : "wx101531104719421652d610751164524100",
   "sign" : "CADD8BEBD4D16CF58B76924CEF9EC480"
 }
 */

class RechargeWechatModel: NSObject, Codable {
    var appId: String!
    var partnerId: String!
    var nonceStr: String!
    var prepayId: String!
    var sign: String!
    var timeStamp: String!
    var package: String!
}
class RechargeAlipayModel: NSObject, Codable {
    var order: String?
}
