//
//  AreaModel.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/25.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit
/*
    "areaname": "上城区",
    "id": 330102,
    "parentid": 330100,
    "shortname": "上城"
}*/
open class AreaModel: NSObject, Codable {
    var areaname: String!
    var id: Int!
    public init(areaname: String, id: Int) {
        self.areaname = areaname
        self.id = id
        super.init()
    }
}
