//
//  RankingListModel.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/23.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit
/*

     " ": "https://wx.qlogo.cn/mmopen/vi_32/6bpibPuroOAFqcsAfRvzvozASbZqg6bQVpwfWvYZjBS0wszK8Hgf8uAyIqefXYaJkibsviaBubgrRApGodhiaUqCEA/132",
     "num": 3,
     "totalPrice": 30.00,
     "userName": "临漳小伙子"
 },
 */
class RankingListModel: NSObject, Codable {
    var avatar: String?
    var num: Int!
    var totalPrice: Double!
    var userName: String?
}
