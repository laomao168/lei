//
//  MallPayOrder.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2020/1/13.
//  Copyright © 2020 刘文利. All rights reserved.
//

import UIKit

class MallPayOrderModel: NSObject, Codable {
    var mallGoodsInfo: MallGoodsInfoModel?
    var memberAddress: AddressModel?
}
