//
//  UserInfoModel.swift
//  CBIT
//
//  Created by 刘文利 on 2019/8/22.
//  Copyright © 2019 网泰信息. All rights reserved.
//

import UIKit
/*

     "accountDetailType": null,
     "amount": null,
     "applyed": false,
     "avatar": "https://wx.qlogo.cn/mmopen/vi_32/h93CmZT6q0ebribd7lKHYzpvbvJX22HoZ22ibohYmQdTz57kYmLRO5wxvHuHZx6EUnOZk92IiaUbfBicKmmE2wOwZw/132",
     "backDeposit": null,
     "beginTime": "",
     "birthday": null,
     "blacklist": 0,
     "channelId": "",
     "chargeMoney": null,
     "clicked": false,
     "createBy": "",
     "createIp": "",
     "createTime": "2019-12-15 13:09:01",
     "deleted": 0,
     "desc": "desc",
     "deviceCode": "",
     "deviceType": "",
     "directNum": null,
     "endTime": null,
     "failMoney": null,
     "fanNums": null,
     "gender": 0,
     "indirectNum": null,
     "integralAmount": null,
     "integralDetailType": null,
     "invitationCode": "G42409",
     "isEarnings": null,
     "isSendMsg": null,
     "lastLoginIp": "",
     "lastLoginTime": "2019-12-15 13:09:02",
     "lockAmount": null,
     "money": null,
     "newPeople": null,
     "nickname": "刘文利",
     "openid": "oQr774gSfT1zHXztfxkVl3_KFAGU",
     "orderField": "",
     "orderMoney": null,
     "outWithdraw": null,
     "overTime": "",
     "page": {
         "currentResult": 0,
         "entityOrField": false,
         "pageNumber": 1,
         "pageSize": 10,
         "pageStr": "",
         "totalPage": 0,
         "totalResult": 0
     },
     "params": null,
     "parentId": 0,
     "parentIdList": [],
     "parentInvitationCode": "",
     "parentNickname": "",
     "parentTime": null,
     "partnerIncome": null,
     "password": "",
     "payPassword": "719b1195cc10607e3857913927b88d63c76995142d786c4e",
     "phone": "13396717793",
     "positMoney": null,
     "qrcodeUrl": "https://images.oneauct.com/25e3f8ab58934070bb1c09e8db871d5c",
     "remark": "",
     "searchValue": "",
     "secondInviterId": null,
     "sjnickname": "",
     "smsCode": "",
     "startTime": null,
     "status": 0,
     "token": "",
     "totalIncome": null,
     "tradeType": null,
     "type": 0,
     "unionid": "",
     "updateBy": "1614",
     "updateTime": null,
     "userId": 1614,
     "username": "刘文利",
     "verifyCode": ""
 }
 */
class UserInfoModel: NSObject, Codable, NSCoding {
    var avatar: String?
    var invitationCode: String?
    var parentId: Int?
    var payPassword: String?
    var phone: String?
    var qrcodeUrl: String?
    var token: String?
    var userId: Int?
    var username: String?
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(self.avatar, forKey: "avatar")
        aCoder.encode(self.userId, forKey: "userId")
        aCoder.encode(self.username, forKey: "username")
        aCoder.encode(self.token, forKey: "token")
        aCoder.encode(self.parentId, forKey: "parentId")
        aCoder.encode(self.payPassword, forKey: "payPassword")
        aCoder.encode(self.phone, forKey: "phone")
        aCoder.encode(self.qrcodeUrl, forKey: "qrcodeUrl")
        aCoder.encode(self.invitationCode, forKey: "invitationCode")
        
    }

    required init?(coder aDecoder: NSCoder) {
        super.init()
        self.avatar = aDecoder.decodeObject(forKey: "avatar") as? String
        self.userId = aDecoder.decodeObject(forKey: "userId") as? Int
        self.username = aDecoder.decodeObject(forKey: "username") as? String
        self.token = aDecoder.decodeObject(forKey: "token") as? String
        self.parentId = aDecoder.decodeObject(forKey: "parentId") as? Int
        self.payPassword = aDecoder.decodeObject(forKey: "payPassword") as? String
        self.phone = aDecoder.decodeObject(forKey: "phone") as? String
        self.qrcodeUrl = aDecoder.decodeObject(forKey: "qrcodeUrl") as? String
        self.invitationCode = aDecoder.decodeObject(forKey: "invitationCode") as? String
        
    }
}
