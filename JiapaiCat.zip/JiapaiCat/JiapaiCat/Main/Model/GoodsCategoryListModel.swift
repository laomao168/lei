//
//  GoodsCategoryListModel.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/22.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit
/*
 {
   "applyed": false,
   "categoryId": 1016,
   "channelId": "",
   "clicked": false,
   "createBy": "admin",
   "createTime": "2019-10-29 15:35:15",
   "deleted": 0,
   "desc": "desc",
   "deviceCode": "",
   "deviceType": "",
   "endTime": null,
   "id": null,
   "isRecommend": 1,
   "levelText": "",
   "name": "新手福利",
   "orderField": "",
   "page": {
     "currentResult": 0,
     "entityOrField": false,
     "pageNumber": 1,
     "pageSize": 10,
     "pageStr": "",
     "totalPage": 0,
     "totalResult": 0
   },
   "params": null,
   "parentId": 0,
   "parentName": "",
   "pic": "https://images.fmallnet.com/9e8727c0ebe74fec8390a4752704c2a5",
   "remark": "",
   "searchValue": "",
   "sort": 8,
   "startTime": null,
   "status": 0,
   "type": 1,
   "updateBy": "admin",
   "updateTime": "2019-12-09 00:07:10"
 }
 */
class GoodsCategoryListModel: NSObject, Codable {
    var applyed: Bool = false
    var categoryId: Int!
    var channelId: String?
    var clicked: Bool = false
    var content: String?
    var createTime: String?
    var deleted: Int?
    var desc: String?
    var id: Int?
    var pic: String!
    var name: String?
    var page: PageModel?
}
