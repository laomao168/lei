//
//  MyFansModel.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/24.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class MyFansModel: NSObject, Codable {
    var avatar: String?
    var nickname: String?
    var userId: Int?
    var username: String?
    var phone: String?
    var createTime: String!
    var invitationCode: String?
    var directNum: Int?
}
