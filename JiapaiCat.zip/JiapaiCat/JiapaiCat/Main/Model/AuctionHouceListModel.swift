//
//  AuctionHouceListModel.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/23.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit
class AuctionRecordResponse: NSObject, Codable {
    var data: [AuctionHouceListModel] = []
    var page: PageModel!
}
/*

     "applyed": false,
     "auctionDetailId": 256615,
     "auctionId": 8677,
     "avatar": "https://wx.qlogo.cn/mmopen/vi_32/DYAIOgq83eq96vJRGZSxk2lUo2GQAU4KNq75w7G6jBGEYluiaKrgCDoFJFUDg44ImZJiaNhFcib9b9A5yr6pqqOcw/132",
     "channelId": "",
     "clicked": false,
     "createBy": "",
     "createTime": null,
     "deleted": null,
     "desc": "desc",
     "deviceCode": "",
     "deviceType": "",
     "endTime": null,
     "guarantyPrice": 352.00,
     "markupTime": "2019-12-23 11:15",
     "orderField": "",
     "page": {
         "currentResult": 0,
         "entityOrField": false,
         "pageNumber": 1,
         "pageSize": 10,
         "pageStr": "",
         "totalPage": 0,
         "totalResult": 0
     },
     "params": null,
     "payPrice": 1760.00,
     "payType": 1,
     "remark": "",
     "searchValue": "",
     "startTime": null,
     "updateBy": "",
     "updateTime": null,
     "userId": 630,
     "userName": "JENNY ",
     "userType": 1
 }
 */
class AuctionHouceListModel: NSObject, Codable {
    var auctionId: Int!
    var auctionDetailId: Int?
    var avatar: String!
    var guarantyPrice: Double!
    var markupTime: String!
    var payPrice: Double!
    var nextCashDeposit: Double!
    var payType: Int?
    var userId: Int?
    var userName: String?
    var userType: Int?
}

/*
 {"auctionId":10504,"nextCashDeposit":288.000,"brokerage":2.00,"guarantyPrice":284.000,"payPrice":1420.00,"markupTime":1577600127085,"markupTimeString":"2019-12-29 14:15","avatar":"https://wx.qlogo.cn/mmopen/vi_32/jTyT48ezRdtD4micw5yJbwMOu5I6jmHibtX1xk52bPXB4iahTcAaOm2ym486BK5GBT3O59gL0VHiaeQeqMrgwwCsPQ/132","type":1,"userName":"迪诺文玩客服（不接收语音）","userId":1033}
 */

class WSReceiveModel: NSObject, Codable {
    var auctionId: Int!
    var nextCashDeposit: Double!
    var brokerage: Int?
    var guarantyPrice: Double!
    var payPrice: Double!
    var markupTimeString: String!
    var avatar: String!
    var type: Int?
    var userName: String?
    var userId: Int?
}
