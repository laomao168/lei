//
//  MallOrderListModel.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2020/1/13.
//  Copyright © 2020 刘文利. All rights reserved.
//

import UIKit

/*
    "acceptTime": null,
     "address": "浙江省杭州市西湖区翠苑街道分贝医院",
     "addressId": 639,
     "applyTime": null,
     "applyed": false,
     "avatar": "https://wx.qlogo.cn/mmopen/vi_32/h93CmZT6q0ebribd7lKHYzpvbvJX22HoZ22ibohYmQdTz57kYmLRO5wxvHuHZx6EUnOZk92IiaUbfBicKmmE2wOwZw/132",
     "buyerNamePhone": "",
     "carrierId": null,
     "channelId": "",
     "clicked": false,
     "complete": 0,
     "consignee": "刘文利",
     "contract": 0,
     "contractUrl": "",
     "costPrice": 95.00,
     "createBy": "刘文利",
     "createTime": "2020-01-13 18:37:10",
     "createTimeString": "",
     "deleted": 0,
     "deliverTime": null,
     "deliverTimeString": "",
     "desc": "desc",
     "deviceCode": "",
     "deviceType": "",
     "endCreateTime": "",
     "endTime": null,
     "endTimes": null,
     "fallReasons": "",
     "goodsId": 127,
     "goodsName": "小米无线充电器通用快充版Qi无线标准20W",
     "goodsNameId": "",
     "goodsType": 1,
     "integral": 360.00,
     "logisticsCode": "",
     "logisticsName": "",
     "logisticsNo": "",
     "logo": "https://images.fmallnet.com/0426fa7e3d1f47d8b1f4c06ca7763a7e",
     "mallOrderId": 4428,
     "mobile": "13396717793",
     "orderField": "",
     "orderNo": "LPOM200113183710176852",
     "orderPrice": null,
     "orderStatus": 1,
     "orderType": 1,
     "page": {
         "currentResult": 0,
         "entityOrField": false,
         "pageNumber": 1,
         "pageSize": 10,
         "pageStr": "",
         "totalPage": 0,
         "totalResult": 0
     },
     "params": null,
     "payStatus": 1,
     "payTime": "2020-01-13 18:37:11",
     "payTimeString": "",
     "phone": "13396717793",
     "pledgePrice": null,
     "price": 36.00,
     "priceType": 2,
     "reasonRemark": "",
     "receivingGoodsTime": null,
     "remark": "",
     "searchValue": "",
     "startCreateTime": "",
     "startTime": null,
     "statusText": "",
     "supplier": "已删除",
     "supplierId": 7,
     "transactionPrice": null,
     "type": 1,
     "updateBy": "刘文利",
     "updateTime": "2020-01-13 18:37:10",
     "updateTimeString": "",
     "userId": 1614,
     "userName": "刘文利"
 }
 */
class MallOrderListModel: OrderListModel {
    var goodsType: Int!
    var mallOrderId: Int?
    var integral: Double?//积分
    var price: Double?
    var priceType: Int?

    private enum CodingKeys: String, CodingKey {
        case goodsType
        case mallOrderId
        case integral
        case price
        case priceType
    }

    public required init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        goodsType = try container.decode(Int.self, forKey: CodingKeys.goodsType)
        mallOrderId = try container.decode(Int?.self, forKey: CodingKeys.mallOrderId)
        integral = try container.decode(Double?.self, forKey: CodingKeys.integral)
        price = try container.decode(Double?.self, forKey: CodingKeys.price)
        priceType = try container.decode(Int?.self, forKey: CodingKeys.priceType)
        try super.init(from: decoder)
    }
}
