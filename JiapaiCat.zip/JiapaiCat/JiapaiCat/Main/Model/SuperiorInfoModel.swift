//
//  SuperiorInfoModel.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/24.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit
/*
 {
   "overTime" : "",
   "orderMoney" : null,
   "lastLoginIp" : "",
   "accountDetailType" : null,
   "parentInvitationCode" : "",
   "parentNickname" : "",
   "failMoney" : null,
   "smsCode" : "",
   "qrcodeUrl" : "",
   "sjnickname" : "",
   "updateBy" : "2",
   "channelId" : "",
   "createBy" : "",
   "token" : "",
   "updateInviteCode" : 0,
   "username" : "彭佬",
   "lastLoginTime" : "2019-11-06 16:37:19",
   "parentTime" : null,
   "password" : "",
   "amount" : null,
   "status" : 0,
   "avatar" : "https:\/\/wx.qlogo.cn\/mmopen\/vi_32\/k5r6L01rTcPloaJjribNM8YcsgSyMLNfxWA4iacvR5JzlEQKrM5owX2ryeBfjBCZk6IfX4ATcXE8PNhl6fEp7O7A\/132",
   "blacklist" : 1,
   "type" : 100,
   "desc" : "desc",
   "page" : {
     "pageSize" : 10,
     "pageNumber" : 1,
     "entityOrField" : false,
     "currentResult" : 0,
     "totalResult" : 0,
     "pageStr" : "",
     "totalPage" : 0
   },
   "positMoney" : null,
   "userId" : 2,
   "tradeType" : null,
   "createIp" : "",
   "lockAmount" : null,
   "integralAmount" : null,
   "newPeople" : null,
   "outWithdraw" : null,
   "verifyCode" : "",
   "parentIdList" : [

   ],
   "totalIncome" : null,
   "openid" : "oQr774ice-SJfGZ69d9tSTLU61a4",
   "deleted" : 0,
   "deviceCode" : "",
   "backDeposit" : null,
   "parentId" : 0,
   "payPassword" : "83ef1de3016440380b821810a5fd2e27b19c174d10d36409",
   "isSendMsg" : null,
   "params" : null,
   "directNum" : null,
   "integralDetailType" : null,
   "orderField" : "",
   "searchValue" : "",
   "remark" : "",
   "beginTime" : "",
   "money" : null,
   "fanNums" : null,
   "birthday" : null,
   "startTime" : null,
   "chargeMoney" : null,
   "updateTime" : "2019-12-09 11:35:30",
   "endTime" : null,
   "nickname" : "特别游戏代理",
   "gender" : 0,
   "clicked" : false,
   "phone" : "18873851960",
   "unionid" : "",
   "isEarnings" : null,
   "invitationCode" : "D30642",
   "createTime" : "2019-11-07 06:37:18",
   "secondInviterId" : null,
   "indirectNum" : null,
   "applyed" : false,
   "partnerIncome" : null,
   "deviceType" : ""
 }
 */
class SuperiorInfoModel: NSObject, Codable {
    var avatar: String?
    var nickname: String?
    var userId: Int?
    var username: String?
    var phone: String?
    var createTime: String!
    var invitationCode: String?
}
