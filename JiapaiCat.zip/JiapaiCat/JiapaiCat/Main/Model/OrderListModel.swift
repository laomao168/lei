//
//  OrderListModel.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/27.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit
/*
 {
   "id" : null,
   "logo" : "https:\/\/images.fmallnet.com\/e49a6e2dee1544cf95d9a44a21b6ab80",
   "updateBy" : "",
   "channelId" : "",
   "createBy" : "system",
   "endCreateTime" : null,
   "goodsId" : 385,
   "orderNo" : "LP191202130001657441",
   "payTime" : null,
   "username" : "",
   "createTimeString" : "",
   "endDate" : "",
   "endTimes" : null,
   "status" : null,
   "goodsNameId" : "",
   "logisticsCode" : "",
   "deliverTime" : null,
   "type" : 1,
   "address" : "",
   "desc" : "desc",
   "page" : {
     "pageSize" : 10,
     "pageNumber" : 1,
     "entityOrField" : false,
     "currentResult" : 0,
     "totalResult" : 0,
     "pageStr" : "",
     "totalPage" : 0
   },
   "pledgePrice" : 216,
   "userId" : 7,
   "contractUrl" : "",
   "payStatus" : 2,
   "startCreateTime" : null,
   "deleted" : 0,
   "deviceCode" : "",
   "displayArea" : 1,
   "auctionId" : 3198,
   "payType" : null,
   "params" : null,
   "searchValue" : "",
   "costPrice" : 368,
   "orderField" : "",
   "logisticsName" : "",
   "orderStatus" : 4,
   "remark" : "",
   "supplier" : "1688",
   "money" : null,
   "transactionPrice" : 1080,
   "fallReasons" : "",
   "orderId" : 1255,
   "payTimeString" : "",
   "startTime" : null,
   "updateTime" : "2019-12-03 13:00:24",
   "userName" : "小甜甜",
   "transactionId" : "",
   "consignee" : "",
   "endTime" : null,
   "supplierId" : 7,
   "clicked" : false,
   "logisticsNo" : "",
   "orderType" : 1,
   "phone" : "13336145831",
   "buyerNamePhone" : "",
   "addressId" : null,
   "carrierId" : null,
   "createTime" : "2019-12-02 13:00:01",
   "mobile" : "",
   "applyed" : false,
   "orderPrice" : 864,
   "auctionDetailId" : 111288,
   "deviceType" : "",
   "goodsName" : "DIOR\/迪奥 迪奥魅惑唇膏 粉色 001# 3.5G+珊瑚色 004# 3.5G 组合装",
   "statusText" : "",
   "updateTimeString" : "",
   "deliverTimeString" : ""
 }
 */

class OrderListModel: NSObject, Codable {
    var id: Int?
    var logo: String!
    var goodsId: Int?
    var orderNo: String!
    var type: Int?
    var pledgePrice: Double?//保证金
    var userId: Int!
    var payStatus: Int!
    var auctionId: Int!
    var costPrice: Double?
    var orderStatus: Int!
    var supplier: String?
    var money: Double?
    var transactionPrice: Double?
    var orderId: Int!
    var updateTime: String?
    var userName: String?
    var orderType: Int?
    var phone: String?
    var createTime: String?
    var payTime: String?
    var deliverTime: String?//发货时间
    var endTime: String?
    var endDate: String?
    
    var orderPrice: Double?
    var auctionDetailId: Int?
    var goodsName: String?
    var remark: String?
    var address: String?
    var logisticsName: String?
    var logisticsCode: String?
    var logisticsNo: String?
    
}
