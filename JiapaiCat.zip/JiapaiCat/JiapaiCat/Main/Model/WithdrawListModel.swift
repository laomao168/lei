//
//  WithdrawListModel.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/25.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit
/*

     "account": "13396717793",
     "accountName": "刘文利",
     "alipay": "13396717793",
     "amount": 100.00,
     "applyTime": "2019-12-26 22:12:29",
     "applyed": false,
     "auditMan": "",
     "auditTime": null,
     "beginTime": "",
     "channelId": "",
     "clicked": false,
     "createBy": "刘文利",
     "createTime": "2019-12-26 22:12:29",
     "deleted": 0,
     "desc": "desc",
     "deviceCode": "",
     "deviceType": "",
     "endTime": null,
     "id": 3048,
     "orderField": "",
     "overTime": "",
     "page": {
         "currentResult": 0,
         "entityOrField": false,
         "pageNumber": 1,
         "pageSize": 10,
         "pageStr": "",
         "totalPage": 0,
         "totalResult": 0
     },
     "params": null,
     "payPassword": "",
     "remark": "",
     "searchValue": "",
     "serviceCharge": 0.60,
     "startTime": null,
     "status": 1,
     "thirdTradeNo": "",
     "updateBy": "",
     "updateTime": null,
     "userId": 1614
 }
 */
class WithdrawListModel: NSObject, Codable {
    var account: String!
    var accountName: String?
    var alipay: String?
    var amount: Double!
    var applyTime: String?
    var createTime: String!
    var id: Int!
    var serviceCharge: Double?
    var remark: String?
    var userId: Int!
    var status: Int!
}
