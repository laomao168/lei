//
//  AppVersionModel.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2020/1/5.
//  Copyright © 2020 刘文利. All rights reserved.
//

import UIKit
/*
 {
     "appVersionId": 52,
     "applyed": false,
     "channelId": "",
     "clicked": false,
     "createBy": "",
     "createTime": "2020-01-05 15:29:22",
     "deleted": null,
     "desc": "desc",
     "deviceCode": "",
     "deviceType": "",
     "downloadUrl": "https://bajiu.cn/ip/",
     "endTime": null,
     "orderField": "",
     "page": {
         "currentResult": 0,
         "entityOrField": false,
         "pageNumber": 1,
         "pageSize": 10,
         "pageStr": "",
         "totalPage": 0,
         "totalResult": 0
     },
     "params": null,
     "remark": "",
     "searchValue": "",
     "source": "ios",
     "startTime": null,
     "state": 1,
     "type": 1,
     "typeText": "",
     "updateBy": "",
     "updateTime": "2020-01-05 15:36:13",
     "updateTip": "rtest",
     "versionCode": 2,
     "versionCoded": "1.0.2",
     "versionName": "213"
 }
 */
class AppVersionModel: NSObject, Codable {
    var versionName: String?
    var versionCoded: String?
    var versionCode: Int?
    var updateTip: String?
    var type: Int!// '是否提示更新(默认0:否;1:是) ',
    var state: Int!//`state` tinyint(4) DEFAULT NULL COMMENT '是否强制升级(0:否;1:是) ',
    var downloadUrl: String?
}
