//
//  MyAmountListModel.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/24.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit
/*
 {
   "orderField" : "",
   "startTime" : null,
   "tradeNo" : "LPOM191209121106439376",
   "typeText" : "",
   "userId" : 7,
   "amount" : 20,
   "params" : null,
   "searchValue" : "",
   "tradeType" : 2,
   "deviceCode" : "",
   "deviceType" : "",
   "updateTime" : "2019-12-09 12:11:06",
   "deleted" : 0,
   "currentMoney" : 75982.699999999997,
   "endTime" : null,
   "type" : 0,
   "id" : 157638,
   "tradeTypeText" : "",
   "createBy" : "7",
   "updateBy" : "7",
   "page" : {
     "pageSize" : 10,
     "pageNumber" : 1,
     "entityOrField" : false,
     "currentResult" : 0,
     "totalResult" : 0,
     "pageStr" : "",
     "totalPage" : 0
   },
   "clicked" : false,
   "createTime" : "2019-12-09 12:11:06",
   "desc" : "desc",
   "remark" : "商城商品支付",
   "channelId" : "",
   "applyed" : false
 }
 */
class MyAmountListModel: NSObject, Codable {
    var tradeNo: String?
    var userId: Int?
    var amount: Double?
    var tradeType: Int!//0 提现 1 保证金 2, 订单 3, 充值余额 4,退保证金 5,拍卖红包 6,好友成交红包 7,平台操作 8,寄拍收入 9,拍卖成交红包 10,拍卖收入 11,解冻提现
    var currentMoney: Double!
    var type: Int!
    var id: Int!
    var createTime: String?
    var remark: String?
    var applyed: Bool = false
}
