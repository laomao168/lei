//
//  RechargeListModel.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/25.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit
/*
 {
     "applyed": false,
     "channelId": "",
     "clicked": false,
     "createBy": "",
     "createTime": "2019-12-26 21:31:59",
     "deleted": 0,
     "desc": "desc",
     "deviceCode": "",
     "deviceType": "",
     "endTime": null,
     "id": 2138401927,
     "money": 100.00,
     "orderField": "",
     "orderNo": "LPR191226213159159992",
     "page": {
         "currentResult": 0,
         "entityOrField": false,
         "pageNumber": 1,
         "pageSize": 10,
         "pageStr": "",
         "totalPage": 0,
         "totalResult": 0
     },
     "params": null,
     "payTime": "2019-12-26 21:31:59",
     "payType": 2,
     "remark": "微信(刘文利)",
     "searchValue": "",
     "startTime": null,
     "status": 1,
     "transactionId": "4200000461201912266927255675",
     "type": 0,
     "updateBy": "",
     "updateTime": null,
     "userId": 1614
 }
 */
class RechargeListModel: NSObject, Codable {
    var createTime: String!
    var id: Int!
    var money: Double!
    var orderNo: String!
    var payTime: String!
    var payType: Int!
    var remark: String?
    var status: Int!
    var type: Int!
    var userId: Int!
}
