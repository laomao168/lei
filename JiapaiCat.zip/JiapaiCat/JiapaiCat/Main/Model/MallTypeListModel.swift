//
//  MallTypeListModel.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2020/1/13.
//  Copyright © 2020 刘文利. All rights reserved.
//

import UIKit
/*

     "alias": "",
     "children": [],
     "color": "",
     "disabled": false,
     "leaf": false,
     "parentDataDictionary": null,
     "parentValue": "",
     "text": "特惠精品",
     "value": "1"
 },
 */
class MallTypeListModel: NSObject, Codable {
    var text: String!
    var value: String!
}
