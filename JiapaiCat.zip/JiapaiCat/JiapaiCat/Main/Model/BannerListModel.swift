//
//  BannerListModel.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/22.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit
/*
 {
   "applyed": false,
   "bannerType": 1,
   "channelId": "",
   "clicked": false,
   "content": "",
   "createBy": "",
   "createTime": "2019-11-24 10:46:34",
   "deleted": 0,
   "desc": "desc",
   "deviceCode": "",
   "deviceType": "",
   "endTime": null,
   "id": 35,
   "image": "https://images.fmallnet.com/58cabeda05dc410c963cdd08ff6582a0",
   "linkId": "https://h5.fmallnet.com/dist/introduce.html",
   "name": "免单公告",
   "orderField": "",
   "page": {
     "currentResult": 0,
     "entityOrField": false,
     "pageNumber": 1,
     "pageSize": 10,
     "pageStr": "",
     "totalPage": 0,
     "totalResult": 0
   },
   "params": null,
   "remark": "",
   "searchValue": "",
   "sort": 1,
   "startTime": null,
   "status": 0,
   "themeImage": "",
   "type": 4,
   "updateBy": "",
   "updateTime": "2019-11-29 21:25:51",
   "validity": 1
 }
 */
class BannerListModel: NSObject, Codable {
    var applyed: Bool = false
    var bannerType: Int!
    var channelId: String?
    var clicked: Bool = false
    var content: String?
    var createBy: String?
    var createTime: String?
    var deleted: Int?
    var desc: String?
    var id: Int!
    var image: String!
    var linkId: String?
    var name: String?
    var orderField: String?
    var page: PageModel?
    var type: Int?
}
