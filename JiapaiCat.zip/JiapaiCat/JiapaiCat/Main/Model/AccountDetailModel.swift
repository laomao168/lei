//
//  AccountDetailModel.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/24.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit
/*
 {
     "amount": 0.00,
     "lockAmount": 0,
     "todayIncome": 0,
     "totalIncome": 0.00,
     "userId": 1614,
     "yesterdayProfit": 0.00
 }*/
class AccountDetailModel: NSObject, Codable {
    var amount: Double!
    var lockAmount: Double!
    var todayIncome: Double!
    var totalIncome: Double!
    var userId: Int!
    var yesterdayProfit: Double!
}
