//
//  AuctionDetailModel.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/22.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit
/*
 {
     "assessPrice": 480.00,
     "auctionId": 8269,
     "brokerage": 5.0,
     "cashDepositScale": 0.2,
     "displayArea": 1,
     "endTime": "2019-12-23 09:15:00",
     "endTimes": 52356048,
     "goodsDetail": "<p><span><img src=\"https://images.oneauct.com/13b62f5950bc4244b1b7f9480d22b52f\"><img src=\"https://images.oneauct.com/39308e6ed63d4ecc8b320fb868a6ba58\"><img src=\"https://images.oneauct.com/5b9e2725fb204cc29fc1d158b6355131\"><img src=\"https://images.oneauct.com/2e3f677e993c45b79300a705346359ca\"></span><br></p>",
     "goodsName": "鲁花 食用油 5S物理压榨 压榨一级 花生油 6.18L（京东定制）",
     "headImage": "[\"https://images.oneauct.com/929c0aa7f5eb435facfaad5376ef86d8\",\"https://images.oneauct.com/f69923e3dd264ac6ab6c89c266c68491\",\"https://images.oneauct.com/c1a692524ed544aaa03f9ac628107fbe\"]",
     "logo": "https://images.oneauct.com/744a85b8ed694cd49eae8e5a58cb14ec",
     "mailingUserId": null,
     "markupNum": null,
     "markupPrice": 50,
     "nextCashDeposit": 34.000,
     "startPrice": 120.00,
     "startTime": "2019-12-23 09:00:00",
     "startTimes": 51456048,
     "status": 2,
     "supplierId": 4,
     "topPrice": 120.00,
     "transactionPrice": null,
     "viewCount": 19,
     "vipUserId": null
 }
 */
class AuctionDetailModel: NSObject, Codable {
    var assessPrice: Double?//估值
    var auctionId: Int!
    var brokerage: Double?//红包
    var cashDepositScale: Double?
    var displayArea: Int?
    var endTime: String!
    var endTimes: Int!
    var goodsDetail: String!
    var goodsName: String!
    var headImage: String!
    var logo: String!
    var markupNum: Int?
    var mailingUserId: Int?
    var markupPrice: Double?//出价幅度
    var nextCashDeposit: Double?//保证金？
    var startPrice: Double?
    var startTime: String!
    var startTimes: Int?
    var status: Int!
    var supplierId: Int!
    var topPrice: Double?
    var transactionPrice: Double?
    var viewCount: Int?
    var vipUserId: Int?
}
