//
//  AddressModel.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/24.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit
/*
 {
     "address": "你外婆哦",
     "addressId": 476,
     "applyed": false,
     "channelId": "",
     "city": "330100",
     "cityText": "杭州市",
     "clicked": false,
     "consignee": "刘文利",
     "createBy": "",
     "createTime": "2019-12-18 10:57:20",
     "deleted": 0,
     "desc": "desc",
     "deviceCode": "",
     "deviceType": "",
     "district": "330110",
     "districtText": "余杭区",
     "endTime": null,
     "mobile": "13396717793",
     "orderField": "",
     "page": {
         "currentResult": 0,
         "entityOrField": false,
         "pageNumber": 1,
         "pageSize": 10,
         "pageStr": "",
         "totalPage": 0,
         "totalResult": 0
     },
     "params": null,
     "province": "330000",
     "provinceText": "浙江省",
     "remark": "",
     "searchValue": "",
     "startTime": null,
     "street": "330110001",
     "streetText": "临平街道",
     "tolerant": 0,
     "updateBy": "",
     "updateTime": null,
     "userId": 1614
 }
 */
class AddressModel: NSObject, Codable {
    var address: String!
    var addressId: Int!
    var city: String!
    var cityText: String!
    var district: String!
    var districtText: String!
    var consignee: String!
    var createTime: String!
    var mobile: String!
    var province: String!
    var provinceText: String!
    var street: String!
    var streetText: String!
    var tolerant: Int!
    var userId: Int!
    var remark: String?
}
