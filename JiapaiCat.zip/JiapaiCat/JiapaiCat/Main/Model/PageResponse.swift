//
//  PageResponse.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/24.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class PageResponse<T: Codable>: Codable {
    var data: T?
    var page: PageModel?
}
class PageModel: NSObject, Codable {
    var pageNumber: Int!
    var pageSize: Int!
    var totalPage: Int!
}
