//
//  PrePayOrderModel.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/27.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit
/*
 {
   "order" : null,
   "memberAddress" : {
     "channelId" : "",
     "orderField" : "",
     "provinceText" : "浙江省",
     "district" : "330204",
     "province" : "330000",
     "params" : null,
     "remark" : "",
     "searchValue" : "",
     "consignee" : "owl",
     "deviceCode" : "",
     "deviceType" : "",
     "startTime" : null,
     "deleted" : 0,
     "street" : "330204003",
     "tolerant" : 0,
     "city" : "330200",
     "endTime" : null,
     "streetText" : "明楼街道",
     "updateTime" : null,
     "userId" : 7,
     "districtText" : "江东区",
     "createBy" : "",
     "updateBy" : "",
     "mobile" : "13396717793",
     "addressId" : 286,
     "cityText" : "宁波市",
     "clicked" : false,
     "createTime" : "2019-12-26 14:12:23",
     "desc" : "desc",
     "page" : {
       "pageSize" : 10,
       "pageNumber" : 1,
       "entityOrField" : false,
       "currentResult" : 0,
       "totalResult" : 0,
       "pageStr" : "",
       "totalPage" : 0
     },
     "address" : "999999999hao",
     "applyed" : false
   }
 }
 */
class PrePayOrderModel: NSObject, Codable {
    var order: OrderListModel?
    var memberAddress: AddressModel?
}
