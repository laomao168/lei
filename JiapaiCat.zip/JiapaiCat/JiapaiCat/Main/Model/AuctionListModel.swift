//
//  AuctionListModel.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/22.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit
/*
 "addPriceRuleId": null,
     "applyed": false,
     "assessPrice": null,
     "auctionId": 7700,
     "brokerage": null,
     "categoryId": null,
     "categoryName": "",
     "channelId": "",
     "clicked": false,
     "costPrice": null,
     "createBy": "",
     "createTime": null,
     "deleted": null,
     "desc": "desc",
     "deviceCode": "",
     "deviceType": "",
     "displayArea": null,
     "endEndTime": "",
     "endStartPrice": null,
     "endStartTime": "",
     "endTime": "2019-12-22 15:00:00",
     "endTimes": 113054,
     "fatherCategoryId": null,
     "goodsDetail": "",
     "goodsId": null,
     "goodsName": "新手体验活动 首次充值用户活动 全额退款 老用户禁止参与体验",
     "headImage": "",
     "list": [],
     "logo": "https://images.oneauct.com/cd2a923cf6384cc2ad8563ff9e403361",
     "mailingUserId": null,
     "mallGoodsId": null,
     "markupNum": 86,
     "markupPrice": null,
     "maxProtectPrice": null,
     "openRobot": null,
     "openRobotPrecent": null,
     "orderField": "",
     "page": {
         "currentResult": 0,
         "entityOrField": false,
         "pageNumber": 1,
         "pageSize": 10,
         "pageStr": "",
         "totalPage": 0,
         "totalResult": 0
     },
     "params": null,
     "passTitle": "",
     "platformGoodsId": null,
     "protectPrice": null,
     "remark": "",
     "robotPrecent": null,
     "searchValue": "",
     "sort": null,
     "source": null,
     "startEndTime": "",
     "startPrice": 520.00,
     "startStartPrice": null,
     "startStartTime": "",
     "startTime": "2019-12-22 14:45:00",
     "startTimes": -786946,
     "status": 3,
     "supplier": "",
     "supplierId": null,
     "topPrice": 2240.00,
     "transactionPrice": null,
     "type": null,
     "updateBy": "",
     "updateTime": null,
     "userId": null,
     "username": "",
     "viewCount": 318
 }

 */
class AuctionListResponse: NSObject, Codable {
    var data: [AuctionListModel] = []
    var page: PageModel!
}
class AuctionListModel: NSObject, Codable {
    var auctionId: Int!
    var categoryName: String?
    var startTime: String?
    var startTimes: Int?
    var endTime: String?
    var endTimes: Int?
    var topPrice: Double?
    var startPrice: Double?
    var viewCount: Int!
    var goodsId: Int?
    var goodsName: String?
    var logo: String?
    var markupNum: Int? //出价次数
    var status: Int! //2:即将开始，3:已开始
}
