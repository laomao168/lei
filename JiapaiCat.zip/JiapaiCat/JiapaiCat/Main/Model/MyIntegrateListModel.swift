//
//  MyIntegrateListModel.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/24.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

/*
 /*
 {
   "orderField" : "",
   "startTime" : null,
   "tradeNo" : "LPOM191210183329170869",
   "userId" : 7,
   "title" : "2013年福鼎白茶老白茶饼贡眉饼高山日晒枣香显-4饼装",
   "params" : null,
   "searchValue" : "",
   "tradeType" : 2,
   "deviceCode" : "",
   "deviceType" : "",
   "updateTime" : null,
   "deleted" : 0,
   "endTime" : null,
   "integralAmount" : 800,
   "type" : 0,
   "id" : 1792,
   "createBy" : "永远单身狗",
   "updateBy" : "",
   "page" : {
     "pageSize" : 10,
     "pageNumber" : 1,
     "entityOrField" : false,
     "currentResult" : 0,
     "totalResult" : 0,
     "pageStr" : "",
     "totalPage" : 0
   },
   "clicked" : false,
   "createTime" : "2019-12-10 18:33:29",
   "desc" : "desc",
   "remark" : "",
   "channelId" : "",
   "applyed" : false
 }
 */

 */
class MyIntegrateListModel: NSObject, Codable {
    var title: String?
    var userId: Int?
    var integralAmount: Double?
    var type: Int!//收支类型 0 支出 1收入
    var id: Int!
    var createBy: String?
    var createTime: String?
    var tradeType: Int!////订单类型（ 0 订单赠送积分， 1 平台赠送，2，积分兑换， 3，取消订单退回积分）
    var applyed: Bool = false
}
