//
//  BaseResponse.swift
//  caifujutou
//
//  Created by MAC on 2017/11/1.
//  Copyright © 2017年 tomcat360. All rights reserved.
//

import UIKit
class BaseResponse<T: Codable>: Codable {
    var success: Bool = false
    var result: Bool = false
    var code: String?
    var msg: String?
    var data: T?
    var count: Int?
}

struct EmptyResponse: Codable {}
