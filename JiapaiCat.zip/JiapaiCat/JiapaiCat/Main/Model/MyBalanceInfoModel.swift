//
//  MyBalanceInfoModel.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/24.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit
/*
 {
     "amount": 0.00,
     "fanNums": 0,
     "integralAmount": 0,
     "invitationCode": "G42409",
     "nickname": "刘文利",
     "phone": "13396717793"
 }
 */
class MyBalanceInfoModel: NSObject, Codable {
    var amount: Double!
    var fanNums: Int!
    var integralAmount: Double!
    var invitationCode: String!
    var nickname: String?
    var phone: String?
}
