//
//  WLWebViewController.swift
//  caifujutou
//
//  Created by MAC on 2017/9/7.
//  Copyright © 2017年 tomcat360. All rights reserved.
//

import UIKit
import WebKit
import SnapKit
import Photos
//enum WLWebViewProgressIndicatorStyle {
//    case none
//    case progress
//}
enum WLWebViewStyle {
    case url    //加载url
    case string //加载文本
//    case post   //post请求
}
class WLWebViewController: UIViewController {
    lazy var webView: WKWebView = {
        //配置环境
        let configuration = WKWebViewConfiguration()
        configuration.preferences.javaScriptEnabled = true
        // 注入JS对象名称"NativeMethod"，当JS通过NativeMethod来调用时，我们可以在WKScriptMessageHandler代理中接收到
        let userController = WKUserContentController()
        configuration.userContentController = userController
//        delegateController.delegate = self
//        configuration.userContentController.add(self, name: "NativeMethod")
        let webView = WKWebView(frame: self.view.frame, configuration: configuration)
        webView.allowsBackForwardNavigationGestures = true
        webView.navigationDelegate = self
        
        //目前不需要这个代理
//        webView.uiDelegate = self
        return webView
    }()
//    var delegateController: WKDelegateController = WKDelegateController()
    
    fileprivate lazy var progressView: UIProgressView = {
        let progressView = UIProgressView()
        progressView.trackTintColor = UIColor.white
        return progressView
    }()
    
    var isShowProgress: Bool = true {
        didSet {
            if isShowProgress {
                progressView.isHidden = false
            }else{
                progressView.isHidden = true
            }
        }
    }
    /// 加载类型
    fileprivate var webViewStyle: WLWebViewStyle = .url
    //返回按钮是否控制网页的回退
    fileprivate var isBack: Bool = false
    fileprivate var isShowTitle: Bool = true
    /// 网址
    private(set) var url: URL?
    fileprivate var htmlString: String?
    fileprivate var rightDetailButton: UIButton?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.automaticallyAdjustsScrollViewInsets = false
        
        view.addSubview(webView)
        webView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
//            make.left.right.top.bottom.equalToSuperview()
//            make.top.equalTo(topLayoutGuide.snp.bottom)
//            make.left.right.equalToSuperview()
//            make.bottom.equalTo(bottomLayoutGuide.snp.top)
        }
        view.addSubview(progressView)
        progressView.snp.makeConstraints { (make) in
            make.top.equalTo(topLayoutGuide.snp.bottom)
            make.left.right.equalToSuperview()
        }
        if webViewStyle == .url {
            if let url = url {
                webView.load(URLRequest(url: url))
            }
        }else if webViewStyle == .string {
            if let htmlStr = htmlString {
                webView.loadHTMLString(htmlStr, baseURL: nil)
            }
        }
        
        webView.addObserver(self, forKeyPath: "estimatedProgress", options: .new, context: nil)
        webView.addObserver(self, forKeyPath: "title", options: .new, context: nil)
        if isBack {
            
            let backButtonItem = UIBarButtonItem(image: UIImage(named: "nav_back"), style: .plain, target: self, action: #selector(backAction))
            navigationItem.leftBarButtonItem = backButtonItem
        }
//        view.addSubview(webView)
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        webView.configuration.userContentController.add(self, name: "NativeMethod")
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        webView.configuration.userContentController.removeScriptMessageHandler(forName: "NativeMethod")
    }
    /// deinit
    deinit {
        print("\(self.className)已经销毁")
        webView.removeObserver(self, forKeyPath: "estimatedProgress")
        webView.removeObserver(self, forKeyPath: "title")
        NotificationCenter.default.removeObserver(self)
    }
    
//    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
//        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
//        self.commonInit()
//    }
    
    convenience init(url: URL,isShowProgress: Bool = true, isShowTitle: Bool = true,isBack: Bool = false) {
        self.init()
        self.webViewStyle = .url
        self.url = url
        self.isShowTitle = isShowTitle
        self.isBack = isBack
        self.isShowProgress = isShowProgress
    }
    convenience init(htmlString: String,isShowProgress: Bool = true, isShowTitle: Bool = true,isBack: Bool = false) {
        self.init()
        self.webViewStyle = .string
        self.htmlString = htmlString
        self.isShowTitle = isShowTitle
        self.isBack = isBack
        self.isShowProgress = isShowProgress
    }
    
//    required public init?(coder aDecoder: NSCoder) {
//        super.init(coder: aDecoder)
//        self.commonInit()
//    }
    
//    func commonInit() {
//        view.addSubview(webView)
//        webView.snp.makeConstraints { (make) in
//            make.edges.equalToSuperview()
//        }
//        view.sendSubview(toBack: webView)
//    }
    
    @objc func backAction() {
        if webView.backForwardList.backList.count > 0 {
            webView.goBack()
        }else{
            navigationController?.popViewController(animated: true)
        }
    }
    
//    func loadUrl(_ url: URL) {
//        webView.load(URLRequest(url: url))
//    }
//
//    func loadHTMLString(_ string: String) {
//        webView.loadHTMLString(string, baseURL: nil)
//    }
    
//    func loadURLWithString(_ urlString: String) {
//        if let url = URL(string: urlString) {
//            ///scheme://host:port/path?
//            if (url.scheme != "") && (url.host != nil) {
//                loadUrl(url)
//            }else{
//                loadURLWithString("http://\(urlString)")
//            }
//        }
//    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        guard let keyPath = keyPath else {return}
        if keyPath == "estimatedProgress" {
            print("加载进度\(webView.estimatedProgress)")
            progressView.setProgress(Float(webView.estimatedProgress), animated: true)
//            progressView.isHidden = webView.estimatedProgress == 1
            progressView.alpha = webView.estimatedProgress == 1 ? 0 : 1
            if webView.estimatedProgress == 1 {
                progressView.progress = 0.0
            }
        }else if keyPath == "title" {
            if let _ = webView.title {
                if isShowTitle {
                    self.navigationItem.title = webView.title
                }
            }
        }
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}


// MARK: - WKNavigationDelegate
extension WLWebViewController: WKNavigationDelegate {
    // MARK: - 追踪加载过程
    // 页面开始加载时调用
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        print("开始加载")
    }
    // 内容开始返回
    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
        print("内容开始返回")
    }
    //页面加载完成
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        print("页面加载完成")
//        if isShowTitle {
//            self.navigationItem.title = webView.title
//        }
        //原生调用JS方法
//        webView.evaluateJavaScript("js代码", completionHandler: nil)
    }
    //页面内容加载失败
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        print("页面内容加载失败")
    }
    /*
    // MARK: - 页面跳转
    //在发送请求之前，决定是否跳转
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        print("在发送请求之前，决定是否跳转")
        decisionHandler(.allow)
    }
    
    //收到响应之后，决定是否跳转
    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        print("收到响应之后，决定是否跳转")
        decisionHandler(.allow)
    }
    
    //接受到服务器跳转请求之后调用
    func webView(_ webView: WKWebView, didReceiveServerRedirectForProvisionalNavigation navigation: WKNavigation!) {
        print("接受到服务器跳转请求之后调用")
    }
    
    //页面内容完全加载完
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        print("页面内容完全加载完")
    }
    
    //SSL认证
//    func webView(_ webView: WKWebView, didReceive challenge: URLAuthenticationChallenge, completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
//        print("SSL认证")
//    }
    */
}

// MARK: - WKUIDelegate
extension WLWebViewController: WKUIDelegate {
    // 创建一个新的WebView
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        return WKWebView()
    }
    //警告框
    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        
    }
    //输入框
    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String, defaultText: String?, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (String?) -> Void) {
        
    }
    //确认框
    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        
    }
    
}


// MARK: - WKScriptMessageHandler
extension WLWebViewController: WKScriptMessageHandler {
    //js调用原生
    //web端通过window.webkit.messageHandlers.<name>.postMessage(<messageBody>)发送数据
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        let name = message.name
        switch name {
        case "NativeMethod":
            print(message.body)
        default:
            break
        }
    }
}
