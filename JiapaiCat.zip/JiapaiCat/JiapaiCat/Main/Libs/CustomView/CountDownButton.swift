//
//  CountDownButton.swift
//  caifujutou
//
//  Created by MAC on 2017/9/14.
//  Copyright © 2017年 tomcat360. All rights reserved.
//

import UIKit

class CountDownButton: UIButton {
    override init(frame: CGRect) {
        super.init(frame: frame)
        initView()
    }
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initView()
    }
    func initView() {
//        self.contentHorizontalAlignment = .right
        self.setTitle(localizedString("获取验证码"), for: UIControl.State.normal)
    }
    private var countdownTimer: Timer?
    private var remainingSeconds: Int = 0 {
        willSet {
            self.setTitle("\(newValue)s\(localizedString("重新获取"))", for: .normal)
            self.backgroundColor = UIColor.gray9
            if newValue <= 0 {
                self.setTitle(localizedString("获取验证码"), for: .normal)
                self.backgroundColor = UIColor.mainColor
                isCounting = false
            }
        }
    }
    var isCounting: Bool = false {
        willSet {
            if newValue {
                countdownTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateTime), userInfo: nil, repeats: true)
                RunLoop.current.add(countdownTimer!, forMode: RunLoop.Mode.common)
                remainingSeconds = 60
//                self.setTitleColor(UIColor.lightGray, for: .normal)
//                self.backgroundColor = gray9Color
            }else{
                countdownTimer?.invalidate()
                countdownTimer = nil
//                self.setTitleColor(mainColor, for: .normal)
//                self.backgroundColor = mainColor
            }
            self.isEnabled = !newValue
        }
    }
    
    
    
    @objc private func updateTime() {
        // 计时开始时，逐秒减少remainingSeconds的值
        remainingSeconds -= 1
    }
}
