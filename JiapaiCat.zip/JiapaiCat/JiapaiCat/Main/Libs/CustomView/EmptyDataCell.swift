//
//  EmptyDataCell.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/17.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class EmptyDataCell: UITableViewCell {
    static let emptyHeight: CGFloat = 130
    
    var imgView: UIImageView!
    var titleLabel: UILabel!
    var button: UIButton!
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        initViews()
    }
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        initViews()
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func initViews() {
        self.separatorInset = UIEdgeInsets(top: 0, left: SWIDTH, bottom: 0, right: 0)
        self.backgroundColor = UIColor.clear
        self.selectionStyle = .none
        let bgView = UIView()
        bgView.backgroundColor = UIColor.white
        self.contentView.addSubview(bgView)
        imgView = UIImageView()
        imgView.image = UIImage(named: "noData")
        bgView.addSubview(imgView)
        titleLabel = UILabel()
        titleLabel.font = UIFont.systemFont(ofSize: 15)
        titleLabel.textColor = UIColor.gray6
        titleLabel.text = "暂无相关数据"
        
        button = UIButton(type: .custom)
        button.setTitle("分享邀请", for: UIControl.State.normal)
        button.setTitleColor(UIColor.mainColor, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        button.setBackgroundColor(UIColor(hexString: "#F9E2D0")!, forState: UIControl.State.normal)
        bgView.addSubview(titleLabel)
        button.kCornerRadius = 15
        bgView.addSubview(button)
        bgView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(15)
            make.right.equalToSuperview().offset(-15)
            make.top.equalToSuperview()
            make.bottom.equalToSuperview().offset(-10)
        }
        imgView.snp.makeConstraints { (make) in
            make.width.equalTo(74)
            make.height.equalTo(66)
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(15)
        }
        titleLabel.snp.makeConstraints { (make) in
            make.top.equalTo(imgView.snp.bottom).offset(13)
            make.centerX.equalToSuperview()
        }
        button.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.width.equalTo(150)
            make.height.equalTo(30)
            make.top.equalTo(titleLabel.snp.bottom).offset(13)
        }
        
        button.isHidden = true
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
