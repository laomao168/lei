//
//  SubmitButton.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/17.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit
@IBDesignable
class SubmitButton: UIButton {
    override init(frame: CGRect) {
        super.init(frame: frame)
        initViews()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        initViews()
    }
    func initViews() {
        self.setBackgroundImage(UIImage.commomGradient, for: UIControl.State.normal)
        self.setTitleColor(UIColor.white, for: UIControl.State.normal)
    }
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
