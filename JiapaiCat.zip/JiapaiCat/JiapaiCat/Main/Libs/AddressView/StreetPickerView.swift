//
//  StreetPickerView.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/26.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit
import RxSwift

class StreetPickerView: UIView {
    let disposeBag = DisposeBag()
    //MARK: -外部参数
    /// pickerView的字体大小
    public var pickerLabelFont: UIFont?{
        willSet{
            pickerView.reloadAllComponents()
        }
    }
    /// pickerView的字体颜色
    public var pickerLabelTextCoclor: UIColor?{
        willSet{
            pickerView.reloadAllComponents()
        }
    }
    
    // 设置取消、确定按钮的字体大小
    public var titleToolBarFont: UIFont?{
        willSet{
            sureButton.titleLabel?.font = newValue
            cancleButton.titleLabel?.font = newValue
        }
    }
    // 设置取消按钮的颜色
    public var cancleButtonCoclor: UIColor?{
        willSet{
            cancleButton.setTitleColor(newValue, for: .normal)
        }
    }
    // 设置确定按钮的颜色
    public var sureButtonCoclor: UIColor?{
        willSet{
            sureButton.setTitleColor(newValue, for: .normal)
        }
    }
    //设置titleToolBar的背景颜色
    public var titleToolBarBackgroundColor: UIColor?{
        willSet{
            titleToolBar.backgroundColor = newValue
        }
    }
    
    //设置pickView的背景颜色
    public var pickerViewBackgroundColor: UIColor?{
        willSet{
            pickerView.backgroundColor = newValue
        }
    }
    
    var streetArray: [AreaModel] = []
    var selectedStreet: AreaModel?
    // 街道block
    var selectedStreetBlock:((_ street:AreaModel)->())?
    //MARK: -懒加载
    /// 创建城市选择器
     lazy var pickerView: UIPickerView = {
       let pickerView = UIPickerView(frame: CGRect(x: 0, y:
            kl_scaleHeight(h: kToolBarHeight), width:klScreen_width , height: kl_scaleHeight(h: 270) - kl_scaleHeight(h: kToolBarHeight)))
//        let pickerView = UIPickerView()
        pickerView.delegate = self
        pickerView.dataSource = self
        pickerView.backgroundColor = UIColor().hexStringToColor(hexString: "0xffffff", alpha: 1)
        return pickerView
    }()
    
    /// 创建容器
     lazy var containView: UIView = {
        let containView = UIView(frame: CGRect(x: 0, y: klScreen_height, width:klScreen_width , height: kl_scaleHeight(h: 270)))
        containView.backgroundColor = UIColor.gray
        return containView
    }()
    
    /// 创建容器中的titleToolBar
     lazy var titleToolBar: UIView = {
        let titleToolBar = UIView(frame: CGRect(x: 0, y: 0, width: klScreen_width, height: kl_scaleHeight(h: kToolBarHeight)))
        titleToolBar.backgroundColor = UIColor().hexStringToColor(hexString: "0xf6f6f6",alpha: 1)
        return titleToolBar
    }()
    
    /// 创建确定按钮
     lazy var sureButton: UIButton = {
        let sureButton = UIButton(frame: CGRect(x: klScreen_width - kl_scaleWidth(w: 65), y: 0, width: kl_scaleWidth(w: 65), height: kl_scaleHeight(h: kToolBarHeight)))
//        let sureButton = UIButton()
        sureButton.setTitle("确定", for: .normal)
        sureButton.addTarget(self, action: #selector(addressButtonOnclik), for: .touchUpInside)
        sureButton.setTitleColor(UIColor().hexStringToColor(hexString: "0xff0000", alpha: 1), for: .normal)
        sureButton.tag = 1
        return sureButton
    }()
    
    /// 创建取消按钮
     lazy var cancleButton: UIButton = {
        let cancleButton = UIButton(frame: CGRect(x: 0, y: 0, width: kl_scaleWidth(w: 65), height: kl_scaleHeight(h: kToolBarHeight)))
//        let cancleButton = UIButton()
        cancleButton.setTitle("取消", for: .normal)
        cancleButton.addTarget(self, action: #selector(addressButtonOnclik), for: .touchUpInside)
        cancleButton.setTitleColor(UIColor().hexStringToColor(hexString: "0x666666", alpha: 1), for: .normal)
        return cancleButton
    }()
    
    //MARK: - 系统方法
    /// 系统初始化
    override init(frame: CGRect) {
        super.init(frame: frame)
        // 设置界面
        kl_setView()
        
        //设置数据
//        kl_layoutSubviws()
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    //MARK: -界面初始化
    /// 初始化界面
     func kl_setView(){
        self.frame = CGRect(x: 0, y: 0, width: klScreen_width, height: klScreen_height)
        // 添加容器
        addSubview(containView)
        // 添加titleToolBar
        containView.addSubview(titleToolBar)
        // 添加pickerView
        containView.addSubview(pickerView)
        // 添加确定按钮
        titleToolBar.addSubview(sureButton)
        // 添加取消按钮
        titleToolBar.addSubview(cancleButton)
    }
    
    /// 显示view
     func showView() {
        UIApplication.shared.keyWindow?.addSubview(self)
        backgroundColor = UIColor.clear
        UIView.animate(withDuration: 0.3) {
            self.backgroundColor = UIColor().hexStringToColor(hexString: "0x000000", alpha: 0.3)
            self.containView.kl_bottom = klScreen_height
        }
    }

    /// 隐藏View
     func hideView() {
        UIView.animate(withDuration: 0.3, animations: {
            self.backgroundColor = UIColor.clear
            self.containView.kl_y =  klScreen_height
        }) { (finish) in
            self.removeFromSuperview()
        }
    }
    //MARK: -自定义方法
    @objc func addressButtonOnclik(currentButton: UIButton){
        //隐藏界面
        hideView()
        if currentButton.tag == 1{
            if (selectedStreetBlock != nil), let street = selectedStreet {
                selectedStreetBlock?(street)
            }
        }
    }
    //MARK: - 基本方法
    func addressPickerViewWith(street: AreaModel?, parentId: Int, streetBlock:((AreaModel)->())?){
        selectedStreet = street
        selectedStreetBlock = streetBlock
        requestStreet(parentId: parentId)
        
        showView()
    }
    
    func requestStreet(parentId: Int) {
        noHUDprovider.rx.request(APITarget.areaList(parentId: parentId))
            .mapObject(BaseResponse<[AreaModel]>.self)
            .subscribe(onSuccess: { (res) in
                if let list = res.data {
                    self.streetArray = list
                    if self.selectedStreet == nil {
                        self.selectedStreet = self.streetArray.first
                    }
                    // 设置数据
                    var currentStreetIndex = 0
                    for i in (0 ... self.streetArray.count - 1) {
                        let street = self.streetArray[i]
                        if street.areaname == self.selectedStreet?.areaname {
                            currentStreetIndex = i
                            break
                        }
                    }
                    self.pickerView.reloadComponent(0)
                    self.pickerView.selectRow(currentStreetIndex, inComponent: 0, animated: true)
                }
            }, onError: { (error) in
                
            })
        .disposed(by: disposeBag)
    }
}
extension StreetPickerView: UIPickerViewDataSource, UIPickerViewDelegate {
    public func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    public func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return streetArray.count
    }
    
    public func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        var label = view as? UILabel
        if label == nil {
            label = UILabel(frame: CGRect(x: 0, y: 0, width: kl_width/3, height: 30))
            label?.adjustsFontSizeToFitWidth = true
            label?.textAlignment = .center
            label?.textColor = pickerLabelTextCoclor == nil ? UIColor().hexStringToColor(hexString: "0x666666", alpha: 1): pickerLabelTextCoclor
            label?.font = pickerLabelFont == nil ? UIFont.systemFont(ofSize: 17) : pickerLabelFont
        }
        
        let model = self.streetArray[row]
        label?.text = model.areaname
        return label!
    }
    
    public func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedStreet = streetArray[row]
    }
    
    public func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 40
    }
}
