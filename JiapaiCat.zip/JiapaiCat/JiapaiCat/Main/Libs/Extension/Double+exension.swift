//
//  Double+exension.swift
//  Exx
//
//  Created by mqt on 2017/7/7.
//  Copyright © 2017年 mqt. All rights reserved.
//


import Foundation

extension Double {
    
    /**
     向下取第几位小数
     
     - parameter places: 第几位小数 ，1
     
     15.96 * 10.0 = 159.6
     floor(159.6) = 159.0
     159.0 / 10.0 = 15.9
     
     - returns:  15.96 =  15.9
     */
    func f(places:Int) -> Double {
        let divisor = pow(10.0, Double(places))
        return floor(self * divisor) / divisor
    }
    
    /**
     截取到第几位小数
     */
    func toFloor(_ places:Int) -> String {
        let divisor = pow(10.0, Double(places))
        return (floor(self * divisor) / divisor).toString(maxF: places)
    }
    
    /**
     转化为字符串格式
     
     - parameter minF:
     - parameter maxF:
     - parameter minI:
     
     - returns:
     */
    func toString(_ minF: Int = 0, maxF: Int = 10, minI: Int = 1, roundMode: NumberFormatter.RoundingMode = .halfEven) -> String {
        let valueDecimalNumber = NSNumber(value: self)
//        let valueDecimalNumber = NSDecimalNumber(value: self)
        let twoDecimalPlacesFormatter = NumberFormatter()
        twoDecimalPlacesFormatter.maximumFractionDigits = maxF
        twoDecimalPlacesFormatter.minimumFractionDigits = minF
        twoDecimalPlacesFormatter.minimumIntegerDigits = minI
        twoDecimalPlacesFormatter.roundingMode = roundMode
        return twoDecimalPlacesFormatter.string(from: valueDecimalNumber)!
    }
    /**
     转化为金额格式
     
     - parameter minF:
     - parameter maxF:
     - parameter minI:
     
     - returns:
     */
    func mapToPrice() -> String {
        return self.toDecimalString(0, maxF: 2)
    }
    func toDecimalString(_ minF: Int = 0, maxF: Int = 10, minI: Int = 1, roundMode: NumberFormatter.RoundingMode = .halfEven) -> String {
//        let str = String(self)//精度缺失
//        let str = "\(self)"//精度缺失
//        let str = String(format: "%lf", self)//精度缺失，只能精确到6位
//        let str = String(format: "%.8lf", self)//精度缺失，不能只舍不入,后面多此一举了
//        let str = String(stringInterpolationSegment: self)//精度缺失
//        let valueDecimalNumber = NSDecimalNumber(value: self)
//        print(valueDecimalNumber.stringValue)
        let valueDecimalNumber = NSNumber(value: self)
        let twoDecimalPlacesFormatter = NumberFormatter()
        twoDecimalPlacesFormatter.maximumFractionDigits = maxF
        twoDecimalPlacesFormatter.minimumFractionDigits = minF
        twoDecimalPlacesFormatter.minimumIntegerDigits = minI
        twoDecimalPlacesFormatter.roundingMode = roundMode
        let str = twoDecimalPlacesFormatter.string(from: valueDecimalNumber)!
        return str
    }
    /**
     缩倍数
     
     - parameter multiole:除数（不为零）
     - parameter def:保留小数位
     */
//    public func toMultiple(multiole:Int = 1,def:Int = 6)->String{
//        var str = "0"
//        if self > 1000 {
//           str =  String(format: "%.\(def)fk", self / 1000)
//        }else{
//            str = self.toString().subString(def: def)
//        }
//        return str
//    }
    /**
     除法结果转换为string
     
     - parameter divisor:除数（不为零）
     - parameter dec:保留小数位
     */
    func divideResultToString(divisor:Double?,dec:Int = 3)->String{
        guard let divisor = divisor,divisor != 0,self != 0 else {
            return ""
        }
        return String(format: "%.\(dec)f", self / divisor)
    }
    
    /**
     
     乘积换成String
     - parameter multi:乘数
     - parameter dec:保留小数位
     */
    func multiResultToString(multi:Double?,dec:Int = 3)->String{
        guard let multi = multi,self != 0,multi != 0 else {
            return ""
        }
        return String(format: "%.\(dec)f", self * multi)
    }
    
    /// 转为非0字符串
    /// 如果数值为0用replace替代
    func toNonZeroString(_ replace: String = "", minF: Int = 0, maxF: Int = 10, minI: Int = 1) -> String {
        if self == 0 {
            return replace
        } else {
            return toString(minF, maxF: maxF, minI: minI)
        }
    }
    //和2的指数比较，能量等级
    func comparison() -> (index: Int, percent: Double, isEqual: Bool){
        let a: Double = 1000
        if self < a*pow(2.0, 0) {
            let p = self/(a*pow(2.0, 0))
            return (0, p, false)
        }else if self >= a*pow(2.0, 0) && self < a*pow(2.0, 1) {
            let p = (self-a*pow(2.0, 0))/((a*pow(2.0, 1))-(a*pow(2.0, 0)))
            let isEq = self == (a*pow(2.0, 0))
            return (1, p, isEq)
        }else if self >= a*pow(2.0, 1) && self < a*pow(2.0, 2) {
            let p = (self-a*pow(2.0, 1))/a*pow(2.0, 1)
            let isEq = self == (a*pow(2.0, 1))
            return (2, p, isEq)
        }else if self >= a*pow(2.0, 2) && self < a*pow(2.0, 3) {
            let p = (self-a*pow(2.0, 2))/a*pow(2.0, 2)
            let isEq = self == (a*pow(2.0, 2))
            return (3, p, isEq)
        }else if self >= a*pow(2.0, 3) && self < a*pow(2.0, 4) {
            let p = (self-a*pow(2.0, 3))/a*pow(2.0, 3)
            let isEq = self == (a*pow(2.0, 3))
            return (4, p, isEq)
        }else if self >= a*pow(2.0, 4) && self < a*pow(2.0, 5) {
            let p = (self-a*pow(2.0, 4))/a*pow(2.0, 4)
            let isEq = self == (a*pow(2.0, 4))
            return (5, p, isEq)
        }else if self >= a*pow(2.0, 5) && self < a*pow(2.0, 6) {
            let p = (self-a*pow(2.0, 5))/a*pow(2.0, 5)
            let isEq = self == (a*pow(2.0, 5))
            return (6, p, isEq)
        }else if self >= a*pow(2.0, 6) && self < a*pow(2.0, 7) {
            let p = (self-a*pow(2.0, 6))/a*pow(2.0, 6)
            let isEq = self == (a*pow(2.0, 6))
            return (7, p, isEq)
        }else if self >= a*pow(2.0, 7) && self < a*pow(2.0, 8) {
            let p = (self-a*pow(2.0, 7))/a*pow(2.0, 7)
            let isEq = self == (a*pow(2.0, 7))
            return (8, p, isEq)
        }else{
            let isEq = self == (a*pow(2.0, 8))
            return (9, 1, isEq)
        }
    }
    
    
    /**
    双精度的随机数
    */
    public static func randomDoubleNumber(lower: Double = 0,upper: Double = 100) -> Double {
        return (Double(arc4random())/Double(UInt32.max))*(upper - lower) + lower
    }
    
    
    
}
