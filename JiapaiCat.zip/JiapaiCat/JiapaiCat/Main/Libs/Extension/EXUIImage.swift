//
//  UIImage+Color.swift
//  KMNavigationBarTransition
//
//  Created by Zhouqi Mo on 1/1/16.
//  Copyright © 2017 Zhouqi Mo. All rights reserved.
//

import UIKit

public extension UIImage {
    class var commomGradient: UIImage {
        return UIImage(gradientColors: [RGBA(250, 137, 43, 1), RGBA(250, 86, 35, 1)])!
    }
    convenience init(color: UIColor, size: CGSize = CGSize(width: 1, height: 1)) {
        let rect = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        UIGraphicsBeginImageContextWithOptions(rect.size, false, 0)
        color.setFill()
        UIRectFill(rect)
        
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        self.init(cgImage: (image?.cgImage!)!)
    }
    
    convenience init?(gradientColors:[UIColor], size:CGSize = CGSize(width: 10, height: 10))
        {
           
            UIGraphicsBeginImageContextWithOptions(size, true, 0)
            let context = UIGraphicsGetCurrentContext()!
            let colorSpace = CGColorSpaceCreateDeviceRGB()
            let colors = gradientColors.map {(color: UIColor) -> AnyObject in return color.cgColor as AnyObject } as NSArray
            let gradient = CGGradient(colorsSpace: colorSpace, colors: colors, locations: nil)
            // 第二个参数是起始位置，第三个参数是终止位置
            context.drawLinearGradient(gradient!, start: CGPoint(x: 0, y: 0), end: CGPoint(x: size.width, y: 0), options: CGGradientDrawingOptions(rawValue: 0))
            let image = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()
            self.init(cgImage: (image?.cgImage!)!)
        }
    
    func subImageWithRect(_ rect: CGRect, scale: CGFloat) -> UIImage {
//        let scale = self.scale
        
        let scaleRect = CGRect(x: rect.origin.x / scale, y: rect.origin.y / scale, w: rect.size.width / scale, h: rect.size.height / scale)
        let newImageRef = self.cgImage!.cropping(to: scaleRect)
        let newImage = UIImage(cgImage: newImageRef!).rescaleImage(to: rect.size)
        return newImage;
    }
    
    ///压缩图片至指定尺寸
    func rescaleImage(to size: CGSize) -> UIImage {
        UIGraphicsBeginImageContextWithOptions(size, false, UIScreen.main.scale)
        self.draw(in: CGRect(origin: CGPoint.zero, size: size))
        let img = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return img!
    }
    ///按给定path剪裁图片
    /**
     path:路径，剪裁区域。
     mode:填充模式
     */
    func clipImageWith(path: UIBezierPath) -> UIImage {
        let originScale = self.size.width * 1.0 / self.size.height
        let boxBounds = path.bounds
        let width = boxBounds.width
        let height = width/originScale
        ///开启上下文
        UIGraphicsBeginImageContextWithOptions(boxBounds.size, false, 0)
        let bitmap = UIGraphicsGetCurrentContext()
        let newPath: UIBezierPath = path.copy() as! UIBezierPath
        newPath.apply(CGAffineTransform(translationX: -path.bounds.origin.x, y: -path.bounds.origin.y))
        newPath.addClip()
        ///移动原点至图片中心
        bitmap!.translateBy(x: boxBounds.size.width / 2.0, y: boxBounds.size.height / 2.0)
        bitmap!.scaleBy(x: 1.0, y: -1.0)
        bitmap?.draw(self.cgImage!, in: CGRect(x: -width / 2, y: -height / 2, w: width, h: height))
        ///生成图片
        let newImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        return newImage
    }
}
