//
//  EXUIDevice.swift
//  jiaoyisuo
//
//  Created by liuwenli on 2018/4/24.
//  Copyright © 2018年 liuwenli. All rights reserved.
//

import UIKit

extension UIDevice {
    class func switchNewOrientation(interfaceOrientation: UIInterfaceOrientation) {
        let resetOrientationTarget = NSNumber(integerLiteral: UIInterfaceOrientation.unknown.rawValue)
        UIDevice.current.setValue(resetOrientationTarget, forKey: "orientation")
        let orientationTarget = NSNumber(integerLiteral: interfaceOrientation.rawValue)
        UIDevice.current.setValue(orientationTarget, forKey: "orientation")
    }
    //判断是不是iPHoneX
    public func isX() -> Bool {
//        if UIScreen.main.bounds.height == 812 {
//            return true
//        }
//        return false
        var iphoneXSeries = false
        if self.userInterfaceIdiom != .phone {
            return iphoneXSeries
        }
        let application = UIApplication.shared.delegate as? AppDelegate
        let mainWindow = application?.window
        if #available(iOS 11.0, *) {
            if mainWindow?.safeAreaInsets.bottom ?? 0 > CGFloat(0.0) {
                iphoneXSeries = true
            }
        }
        return iphoneXSeries
    }
}
