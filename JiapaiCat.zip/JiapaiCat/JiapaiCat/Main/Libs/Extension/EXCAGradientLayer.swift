//
//  EXCAGradientLayer.swift
//  jiaoyisuo
//
//  Created by liuwenli on 2018/3/29.
//  Copyright © 2018年 liuwenli. All rights reserved.
//

import UIKit

extension CAGradientLayer {
    //渐变色
    class func rainbowLayer(colors: [CGColor]) -> CAGradientLayer {
        let gl = CAGradientLayer()
        //定义每种颜色所在的位置
        let gradientLocations:[NSNumber] = [0.0, 1.0]
        
        //创建CAGradientLayer对象并设置参数
        gl.colors = colors
        gl.locations = gradientLocations
        
        //设置渲染的起始结束位置（横向渐变）
        gl.startPoint = CGPoint(x: 0, y: 0)
        gl.endPoint = CGPoint(x: 1, y: 0)
        return gl
    }
    //渐变色2（0，0）-> (1,1)
    class func gradientLayer(colors: [CGColor]) -> CAGradientLayer {
        let gl = CAGradientLayer()
        //定义每种颜色所在的位置
        let gradientLocations:[NSNumber] = [0.0, 1.0]
        
        //创建CAGradientLayer对象并设置参数
        gl.colors = colors
        gl.locations = gradientLocations
        
        //设置渲染的起始结束位置（横向渐变）
        gl.startPoint = CGPoint(x: 0, y: 0)
        gl.endPoint = CGPoint(x: 1, y: 1)
        return gl
    }
}
