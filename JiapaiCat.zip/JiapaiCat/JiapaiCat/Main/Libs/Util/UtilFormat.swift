//
//  UtilFormat.swift
//  yidoumi
//
//  Created by sss on 2017/5/5.
//  Copyright © 2017年 sss. All rights reserved.
//

import UIKit

class UtilFormat: Any {
    
    /// 隐藏手机号中间四位
    ///
    /// - Parameter phoneNum:
    /// - Returns:
    class func hide(phoneNum:String?) -> String{
        guard let phoneNum = phoneNum else{
            return ""
        }
        return hide(string: phoneNum, start: 3, length: 4)
    }
    /// 隐藏账号（手机号，邮箱）中间四位
    ///
    /// - Parameter phoneNum:
    /// - Returns:
    class func hide(account: String?) -> String{
        guard let account = account else{
            return ""
        }
        return hide(string: account, start: 3, length: 4)
    }
    
    /// 隐藏银行卡号中间数字
    ///
    /// - Parameter num: 银行卡号
    /// - Returns:
    class func hide(bankCardNum num:String) -> String{
        /// 小于16位 直接返回
        if num.count < 16 { return num }
        return "\(String(num[..<num.index(num.startIndex, offsetBy: 4)])) **** **** **** \(String(num[num.index(num.endIndex, offsetBy: -4)...]))"
    }
    
    /// 隐藏身份证号中间数字
    ///
    /// - Parameter string:
    /// - Returns:
    class func hide(identityCard string:String) -> String{
        if string.count < 18 { return string }
        //        str.substring(to: index) In Swift 3
        return "\(String(string[..<string.index(string.startIndex, offsetBy: 4)])) **** ** **** \(String(string[string.index(string.endIndex, offsetBy: -4)...]))"
    }
    
    /// 隐藏部分姓名
    ///
    /// - Parameter name:
    /// - Returns:
    class func hideName(name: String) -> String{
        return hide(inCenter: name, left: 1, right: 1)
    }
    
    class func hide(inCenter string:String, left: Int = 3, right: Int = 4) -> String{
        if string.count < left+right { return string }
        var replaceStr = ""
        let replaceCount = string.count-(left+right)
        for _ in 0..<replaceCount {
            replaceStr.append("*")
        }
        //        str.substring(to: index) In Swift 3
        //        return "\(String(string[..<string.index(string.startIndex, offsetBy: left)]))\(replaceStr)\(String(string[string.index(string.endIndex, offsetBy: -right)...]))"
        return string.replacingCharacters(in: string.index(string.startIndex, offsetBy: left)..<string.index(string.endIndex, offsetBy: -right), with: replaceStr)
    }
    
    class func hide(string:String, start: Int = 3, length: Int = 4) -> String{
        let end = start+length
        if string.count < end { return string }
        var replaceStr = ""
        for _ in 0..<length {
            replaceStr.append("*")
        }
        return string.replacingCharacters(in: string.index(string.startIndex, offsetBy: start)..<string.index(string.startIndex, offsetBy: end), with: replaceStr)
    }
    
    
}
