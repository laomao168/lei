//
//  UtilDate.swift
//  yidoumi
//
//  Created by sss on 2017/4/18.
//  Copyright © 2017年 sss. All rights reserved.
//

import UIKit

class UtilDate: Any {

    static let dateFormatter = DateFormatter()
    
    /// 格式化时间为yyyyMM
    ///
    /// - Parameter date: date
    /// - Returns: string
    static func toStringWithYYYYMM(date: Date) -> String{
        
        dateFormatter.locale = Locale.current // 设置时区
        dateFormatter.dateFormat = "yyyyMM"
        return dateFormatter.string(from:date)
    }
    
    /// 格式化时间为YYYYMMDD
    ///
    /// - Parameter date: date
    /// - Returns: string
    static func toStringWithYYYYMMDD(date: Date) -> String{
    
        dateFormatter.locale = Locale.current // 设置时区
        dateFormatter.dateFormat = "yyyyMMdd"
        return dateFormatter.string(from:date)
    }
    
    static func toString(timeIntervalSince1970:Int) -> String{
        let date = Date(timeIntervalSince1970: TimeInterval(timeIntervalSince1970/1000))
        let dformatter = DateFormatter()
        dformatter.dateFormat = "yyyy.MM.dd"
        return dformatter.string(from: date)
    }
    
    static func toStringYYYYMMDD(timeIntervalSince1970:Int) -> String{
        let date = Date(timeIntervalSince1970: TimeInterval(timeIntervalSince1970/1000))
        let dformatter = DateFormatter()
        dformatter.dateFormat = "yyyy-MM-dd"
        return dformatter.string(from: date)
    }
    
    static func toStringYYYYMMDDHHMMSS(timeIntervalSince1970:Int) -> String{
        let date = Date(timeIntervalSince1970: TimeInterval(timeIntervalSince1970/1000))
        let dformatter = DateFormatter()
        dformatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        return dformatter.string(from: date)
    }
    
    //MARK: -根据后台时间戳返回几分钟前，几小时前，几天前
    static func updateTimeToCurrennTime(timeStamp: Int) -> String {
          //获取当前的时间戳
          let currentTime = Date().timeIntervalSince1970
          print(currentTime,   timeStamp, "sdsss")
          //时间戳为毫秒级要 ／ 1000， 秒就不用除1000，参数带没带000
          let timeSta:TimeInterval = TimeInterval(timeStamp/1000)
          //时间差
          let reduceTime : TimeInterval = currentTime - timeSta
          //时间差小于60秒
          if reduceTime < 60 {
              return "刚刚"
          }
          //时间差大于一分钟小于60分钟内
          let mins = Int(reduceTime / 60)
          if mins < 60 {
              return "\(mins)分钟前"
          }
          let hours = Int(reduceTime / 3600)
          if hours < 24 {
              return "\(hours)小时前"
          }
          let days = Int(reduceTime / 3600 / 24)
          if days < 30 {
              return "\(days)天前"
          }
          //不满足上述条件---或者是未来日期-----直接返回日期
          let date = NSDate(timeIntervalSince1970: timeSta)
          let dfmatter = DateFormatter()
          //yyyy-MM-dd HH:mm:ss
          dfmatter.dateFormat="yyyy年MM月dd日 HH:mm:ss"
          return dfmatter.string(from: date as Date)
      }
    
    /// 转换1970到月日
    ///
    /// - Parameter timeIntervalSince1970:
    /// - Returns:
    static func toStingMD(timeIntervalSince1970:Int) -> String {
        let date = Date(timeIntervalSince1970: TimeInterval(timeIntervalSince1970/1000))
        let dformatter = DateFormatter()
        dformatter.dateFormat = "MM/dd"
        return dformatter.string(from: date)
    }
    
    static func toString(format: String,timeIntervalSince1970: Int) -> String {
        let date = Date(timeIntervalSince1970: TimeInterval(timeIntervalSince1970/1000))
        let dformatter = DateFormatter()
        dformatter.dateFormat = format
        return dformatter.string(from: date)
    }
    static func getGMTDate() -> String {//毫秒级
        let date = NSDate()
        let a = (date.timeIntervalSince1970*1000).toInt
        return a.toString
    }
    
    //Int -> 15分0秒
    static func getMMSSFromSS(seconds: Int) -> String {
        //format of minute
        let minute = seconds/60
        let second = seconds%60
        let minuteUnit = localizedString("分")
        let secondUnit = localizedString("秒")
        
        let minuteStr = minute < 10 ? "0\(minute)" : "\(minute)"
        //format of second
        let secondStr = second < 10 ? "0\(second)" : "\(second)"
        let time = "\(minuteStr)\(minuteUnit)\(secondStr)\(secondUnit)"
        return time
    }
    //Int -> 15分0秒
    static func getDayHHMMSSFromSS(seconds: Int) -> String {
        let days = Int(seconds / 3600 / 24)
        
        let a = seconds - 3600*24*days
        let hours = Int(a / 3600)
        let b = a - 3600*hours
        let mins = Int(b / 60)
        let second = Int(b % 60)
        let dayStr = days > 0 ? "\(days)天" : ""
        let hourStr = hours > 0 ? "\(hours)时" : ""
        let time = "\(dayStr)\(hourStr)\(mins)分\(second)秒"
        return time
    }
    //
    static func removeDay(timeStr: String) -> String {
        let date = Date()
        let dformatter = DateFormatter()
        dformatter.dateFormat = "yyyy-MM-dd "
        let day = dformatter.string(from: date)
        let time = timeStr.replacingOccurrences(of: day, with: "")
        return time
    }
    //Int -> 15分0秒
    static func getDayHHMMFromSS(seconds: Int) -> String {
        //format of minute
//        let minute = seconds/60
//        let second = seconds%60
//        let minuteUnit = localizedString("分")
//        let secondUnit = localizedString("秒")
        //时间差大于一分钟小于60分钟内
        let days = Int(seconds / 3600 / 24)
        
        let a = seconds - 3600*24*days
        let hours = Int(a / 3600)
        let b = a - 3600*hours
        let mins = Int(b / 60)
        
        let time = "\(days)天\(hours)时\(mins)分"
        
        return time
    }
    
    
}
