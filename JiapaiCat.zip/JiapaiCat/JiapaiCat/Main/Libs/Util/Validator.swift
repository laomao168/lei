//
//  Validator.swift
//  yidoumi
//
//  Created by sss on 2017/4/18.
//  Copyright © 2017年 sss. All rights reserved.
//

import UIKit

/// 验证工具类
class Validator{
    
    /// 正则表达式验证
    ///
    /// - Parameters:
    ///   - regex: 正则
    ///   - object: object
    /// - Returns: bool
    class func validate(byRegex regex: String, withObject object: Any) -> Bool {
        let predicate = NSPredicate(format: "SELF MATCHES %@", regex)
        return predicate.evaluate(with: object)
    }
    //输入几位小数
    class func validate(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String, index: Int) -> Bool {
        let newString = (textField.text! as NSString).replacingCharacters(in: range, with: string)
        if index == 0 && string == "." {//只有整数就不要输入小数点了
            return false
        }
        let expression = "^([0-9]{0,9})((\\.)[0-9]{0,\(index)})?$"
        let regex = try! NSRegularExpression(pattern: expression, options: NSRegularExpression.Options.allowCommentsAndWhitespace)
        let numberOfMatches = regex.numberOfMatches(in: newString, options:NSRegularExpression.MatchingOptions.reportProgress, range: NSMakeRange(0, (newString as NSString).length))
        return numberOfMatches != 0
    }
    
    /// 手机号码验证
    ///
    /// - Parameter mobileNum: 手机号
    /// - Returns: bool
    class func isMobileNumber(_ string: String) -> Bool {
        //手机号以13，14，15，16，17，18，19 开头，八个 \d 数字字符
        return self.validate(byRegex: "^1[3456789]\\d{9}$", withObject: string)
    }
    /// 护照验证
    ///
    /// - Parameter mobileNum:
    /// - Returns: bool
    class func isPassport(_ string: String) -> Bool {
        return self.validate(byRegex: "^1[45][0-9]{7}|G[0-9]{8}|P[0-9]{7}|S[0-9]{7,8}|D[0-9]+$", withObject: string)
    }
    
    
    /// 验证是否纯字母包含大小写
    ///
    /// - Parameter password: 密码
    /// - Returns: bool
    class func isPasswordLetterOnly(_ string: String) -> Bool {
        return self.validate(byRegex: "[a-zA-Z]*", withObject: string)
    }
    
    
    
    /// 验证是否纯数字
    ///
    /// - Parameter string:
    /// - Returns: bool
    class func isNumberOnly(_ string: String) -> Bool {
        return self.validate(byRegex: "^[0-9]*$", withObject: string)
    }
    /// 验证是否是提币地址（数字和字母）
    ///
    /// - Parameter string:
    /// - Returns: bool
    class func isTibiAddress(_ string: String) -> Bool {
        //不能超过60位
         return self.validate(byRegex: "^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{1,60}$", withObject: string)
    }
    
    /// 验证是否是字母+数字
    ///
    /// - Parameter string:
    /// - Returns: bool
    class func password(_ string: String,min: Int = 6, max: Int = 16) -> Bool {
        //6-16位数字,字母
        return self.validate(byRegex: "^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{\(min),\(max)}$", withObject: string)
    }
    
    
    /// 银行卡号
    ///
    /// - Parameter cardNo:
    /// - Returns:
    class func checkCardNo( _ cardNo: String) -> Bool {
        var cardNo = cardNo
        var oddsum: Int = 0
        //奇数求和
        var evensum: Int = 0
        //偶数求和
        var allsum: Int = 0
        let cardNoLength = Int(cardNo.count)
        let lastNum = cardNo[cardNo.index(cardNo.endIndex, offsetBy: -1)..<cardNo.endIndex]
        cardNo = String(cardNo[cardNo.startIndex...cardNo.index(cardNo.endIndex, offsetBy: -1)])
        var i = cardNoLength - 1
        while i >= 1 {
            let tmpString: String = (cardNo as NSString).substring(with: NSRange(location: i - 1, length: 1))
            var tmpVal: Int = (tmpString as NSString).integerValue
            if cardNoLength % 2 == 1 {
                if (i % 2) == 0 {
                    tmpVal *= 2
                    if tmpVal >= 10 {
                        tmpVal -= 9
                    }
                    evensum += tmpVal
                }
                else {
                    oddsum += tmpVal
                }
            }
            else {
                if (i % 2) == 1 {
                    tmpVal *= 2
                    if tmpVal >= 10 {
                        tmpVal -= 9
                    }
                    evensum += tmpVal
                }
                else {
                    oddsum += tmpVal
                }
            }
            i -= 1
        }
        allsum = oddsum + evensum
        allsum = allsum + (NumberFormatter().number(from: String(lastNum))?.intValue ?? 0)
        
        if (allsum % 10) == 0 {
            return true
        }
        else {
            return false
        }
    }
    
    /// 验证身份证号码
    ///
    /// - Parameter sfz: 身份证号码
    /// - Returns:
    class func validateIDCardNumber(sfz:String)->Bool{
        
        let value = sfz.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
        
        var length = 0
        if value == ""{
            return false
        }else{
            length = value.count
            if length != 15 && length != 18{
                return false
            }
        }
        
        //省份代码
        let arearsArray = ["11","12", "13", "14",  "15", "21",  "22", "23",  "31", "32",  "33", "34",  "35", "36",  "37", "41",  "42", "43",  "44", "45",  "46", "50",  "51", "52",  "53", "54",  "61", "62",  "63", "64",  "65", "71",  "81", "82",  "91"]
        let valueStart2 = (value as NSString).substring(to: 2)
        var arareFlag = false
        if arearsArray.contains(valueStart2){
            
            arareFlag = true
        }
        if !arareFlag{
            return false
        }
        var regularExpression = NSRegularExpression()
        
        var numberofMatch = Int()
        var year = 0
        switch (length){
        case 15:
            year = Int((value as NSString).substring(with: NSRange(location:6,length:2)))!
            if year%4 == 0 || (year%100 == 0 && year%4 == 0){
                do{
                    regularExpression = try NSRegularExpression.init(pattern: "^[1-9][0-9]{5}[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}$", options: .caseInsensitive) //检测出生日期的合法性
                }catch{
                }
            }else{
                do{
                    regularExpression =  try NSRegularExpression.init(pattern: "^[1-9][0-9]{5}[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))[0-9]{3}$", options: .caseInsensitive) //检测出生日期的合法性
                }catch{}
            }
            
            numberofMatch = regularExpression.numberOfMatches(in: value, options:NSRegularExpression.MatchingOptions.reportProgress, range: NSMakeRange(0, value.count))
            
            if(numberofMatch > 0) {
                return true
            }else {
                return false
            }
            
        case 18:
            year = Int((value as NSString).substring(with: NSRange(location:6,length:4)))!
            if year%4 == 0 || (year%100 == 0 && year%4 == 0){
                do{
                    regularExpression = try NSRegularExpression.init(pattern: "^[1-9][0-9]{5}19[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}[0-9Xx]$", options: .caseInsensitive) //检测出生日期的合法性
                    
                }catch{
                    
                }
            }else{
                do{
                    regularExpression =  try NSRegularExpression.init(pattern: "^[1-9][0-9]{5}19[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))[0-9]{3}[0-9Xx]$", options: .caseInsensitive) //检测出生日期的合法性
                    
                }catch{}
            }
            
            numberofMatch = regularExpression.numberOfMatches(in: value, options:NSRegularExpression.MatchingOptions.reportProgress, range: NSMakeRange(0, value.count))
            
            if(numberofMatch > 0) {
                var s = (Int((value as NSString).substring(with: NSRange(location:0,length:1)))! +
                    Int((value as NSString).substring(with: NSRange(location:10,length:1)))!) * 7
                
                s += (Int((value as NSString).substring(with: NSRange(location:1,length:1)))! +
                    Int((value as NSString).substring(with: NSRange(location:11,length:1)))!) * 9
                s += (Int((value as NSString).substring(with: NSRange(location:2,length:1)))! +
                    Int((value as NSString).substring(with: NSRange(location:12,length:1)))!) * 10
                s  += (Int((value as NSString).substring(with: NSRange(location:3,length:1)))! +
                    Int((value as NSString).substring(with: NSRange(location:13,length:1)))!) * 5
                s  += (Int((value as NSString).substring(with: NSRange(location:4,length:1)))! +
                    Int((value as NSString).substring(with: NSRange(location:14,length:1)))!) * 8
                s += (Int((value as NSString).substring(with: NSRange(location:5,length:1)))! +
                    Int((value as NSString).substring(with: NSRange(location:15,length:1)))!) * 4
                s  += (Int((value as NSString).substring(with: NSRange(location:6,length:1)))! +
                    Int((value as NSString).substring(with: NSRange(location:16,length:1)))!) *  2
                s += Int((value as NSString).substring(with: NSRange(location:7,length:1)))! * 1 +  Int((value as NSString).substring(with: NSRange(location:8,length:1)))! * 6 + (Int((value as NSString).substring(with: NSRange(location:9,length:1)))! * 3)
                
                let Y = s%11
                var M = "F"
                let JYM = "10X98765432"
                
                M = (JYM as NSString).substring(with: NSRange(location:Y,length:1))
                if M == (value as NSString).substring(with: NSRange(location:17,length:1))
                {
                    return true
                }else{return false}
                
                
            }else {
                return false
            }
            
        default:
            return false
        }
        
    }
    
    
    
    /// 是否是中文姓名
    ///
    /// - Parameter name: 姓名
    /// - Returns: bool
    class func isName(name: String) -> Bool {
        
        for (_, value) in name.enumerated() {
            if "\(value)".lengthOfBytes(using: String.Encoding.utf8) != 3{
                return false
            }
        }
        return true
    }
    
    
    /// 是否为整数
    ///
    /// - Parameter string:
    /// - Returns:
    class func isPurnInt(string: String) -> Bool {
        
        let scan: Scanner = Scanner(string: string)
        
        var val:Int = 0
        
        return scan.scanInt(&val) && scan.isAtEnd
        
    }
    /// 是否为路径
    ///
    /// - Parameter string:
    /// - Returns:
    class func isURL(string: String) -> Bool {
        return self.validate(byRegex: "[a-zA-z]+://[^\\s]*", withObject: string)
    }
    
}

//
//enum Validate {
//
//    case email(_: String)
//
//    case phoneNum(_: String)
//
//    case telephone(_: String)
//
//    case carNum(_: String)
//
//    case username(_: String)
//
//    case password(_: String)
//
//    case nickname(_: String)
//
//    case JudgeTheillegalCharacter(_: String)
//
//    case URL(_: String)
//
//    case IP(_: String)
//
//
//
//
//
//    var isRight: Bool {
//
//        var predicateStr:String!
//
//        var currObject:String!
//
//        switch self {
//
//        case let .email(str):
//
//            predicateStr = "^([a-z0-9_\\.-]+)@([\\da-z\\.-]+)\\.([a-z\\.]{2,6})$"
//
//            currObject = str
//
//        case let .phoneNum(str):
//
//            predicateStr = "^((13[0-9])|(15[^4,\\D]) |(17[0,0-9])|(18[0,0-9]))\\d{8}$"
//
//            currObject = str
//
//        case let .telephone(str):
//
//            predicateStr = "^((\\d{3,4}\\-)|)\\d{7,8}(|([-\\u8f6c]{1}\\d{1,5}))$"
//
//            currObject = str
//
//        case let .carNum(str):
//
//            predicateStr = "^[A-Za-z]{1}[A-Za-z_0-9]{5}$"
//
//            currObject = str
//
//        case let .username(str):
//
//            predicateStr = "^[A-Za-z0-9]{6,20}+$"
//
//            currObject = str
//
//        case let .password(str):
//
//            predicateStr = "^[a-zA-Z0-9]{6,20}+$"
//
//            currObject = str
//
//        case let .nickname(str):
//
//            predicateStr = "^[\\u4e00-\\u9fa5]{4,8}$"
//
//            currObject = str
//
//        case let .URL(str):
//
//            predicateStr = "^(https?:\\/\\/)?([\\da-z\\.-]+)\\.([a-z\\.]{2,6})([\\/\\w \\.-]*)*\\/?$"
//
//            currObject = str
//
//        case let .IP(str):
//
//            predicateStr = "^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$"
//
//            currObject = str
//
//        case let .JudgeTheillegalCharacter(str):
//
//            predicateStr = "^[A-Za-z0-9\\u4e00-\\u9fa5]+$"
//
//            currObject = str
//
//        }
//
//
//
//        let predicate =  NSPredicate(format: "SELF MATCHES %@" ,predicateStr)
//
//        return predicate.evaluate(with: currObject)
//
//    }
//
//}

