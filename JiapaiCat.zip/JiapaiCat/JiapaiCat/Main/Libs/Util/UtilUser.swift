//
//  UtilUser.swift
//  CBIT
//
//  Created by 刘文利 on 2019/9/2.
//  Copyright © 2019 网泰信息. All rights reserved.
//

import UIKit
import RxSwift
class UtilUser: NSObject {
    static let disposeBag = DisposeBag()
    
    
    //获取topNavigationController
    class func getNavigationController() -> BaseNavigationController? {
        let rootVC = UIApplication.shared.keyWindow?.rootViewController
        var navigatonController: BaseNavigationController?
        if let nav = rootVC as? BaseNavigationController {//登录流程
            navigatonController = nav
        }else if let mainVC = rootVC as? MainViewController {//登录之后
            
            let homeNav = mainVC.viewControllers?[mainVC.selectedIndex] as? BaseNavigationController
            navigatonController = homeNav
        }
        return navigatonController
    }
    
    class func openLogin() {
        let loginVC = LoginPromptController()
        let loginNav = BaseNavigationController(rootViewController: loginVC)
        loginNav.modalPresentationStyle = .fullScreen
        let rootVC = UIApplication.shared.keyWindow?.rootViewController
        rootVC?.present(loginNav, animated: true, completion: nil)
    }
    
//    static func getImageView() -> UIImageView {
//        let imgView = UIImageView()
//        imgView.contentMode = .scaleAspectFill
//        imgView.clipsToBounds = true
//        imgView.isUserInteractionEnabled = true
//        
//        imgView.snp.makeConstraints { (make) in
//            make.width.equalTo(imgView.snp.height)
//        }
//        return imgView
//    }
}
