//
//  CommomColor.swift
//  HayekExGlobal
//
//  Created by liuwenli on 2018/11/21.
//  Copyright © 2018年 liuwenli. All rights reserved.
//

import UIKit

extension UIColor {
    class var mainColor: UIColor {
        return RGBA(250, 87, 35, 1)
    }
    class var gray3: UIColor {
        return UIColor(hexString: "#333333")!
    }
    class var gray6: UIColor {
        return UIColor(hexString: "#666666")!
    }
    class var gray9: UIColor {
        return UIColor(hexString: "#999999")!
        
    }
    class var tableViewBg: UIColor {
        return UIColor(hexString: "#F0F0F0")!
        
    }
    class var separatorColor: UIColor {
        return UIColor(hexString: "#E6E6E6")!
    }
}

