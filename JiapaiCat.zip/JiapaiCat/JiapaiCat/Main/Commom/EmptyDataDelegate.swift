//
//  EmptyDataDelegate.swift
//  CBIT
//
//  Created by 刘文利 on 2019/11/12.
//  Copyright © 2019 网泰信息. All rights reserved.
//

import UIKit
import DZNEmptyDataSet

class EmptyDataDelegate: NSObject, DZNEmptyDataSetSource, DZNEmptyDataSetDelegate {
    weak var scrollView: UIScrollView?
    init(scrollView: UIScrollView) {
        super.init()
        self.scrollView = scrollView
    }
    var emptyDataStyle: EmptyDataStyle = .none {
        didSet {
            self.scrollView?.reloadEmptyDataSet()
        }
    }
    deinit {
        print("EmptyDataDelegate销毁")
    }
    /// 空数据图片展示
        func image(forEmptyDataSet scrollView: UIScrollView!) -> UIImage! {
    //        return UIImage(named: "noData")
            switch emptyDataStyle {
            case .none:
                return nil
            case .noData:
                return UIImage(named: "noData")
            case .networkError:
                return UIImage(named: "networkError")
            default:
                return UIImage(named: "networkError")
            }
        }
        func emptyDataSetShouldAllowScroll(_ scrollView: UIScrollView!) -> Bool {
            return true
        }
        
        func emptyDataSetShouldAnimateImageView(_ scrollView: UIScrollView!) -> Bool {
            return true
        }
        func title(forEmptyDataSet scrollView: UIScrollView!) -> NSAttributedString! {
            var msg = ""
            switch emptyDataStyle {
            case .none:
                msg = ""
            case .noData:
                msg = "暂无数据~"
            case .networkError:
                msg = "您的网络好像不太给力哦～"
            default:
                msg = "您的网络好像不太给力哦～"
            }
            let attributes = [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 14),NSAttributedString.Key.foregroundColor: UIColor(hexString: "0xD8D8D8")!]
            return NSAttributedString(string: msg, attributes: attributes)
        }
        func verticalOffset(forEmptyDataSet scrollView: UIScrollView!) -> CGFloat {
            if let tableView = scrollView as? UITableView {
                let height = (tableView.tableHeaderView?.frame.size.height ?? 0)/2.0
                return height
            }
            return 0
        }

}
