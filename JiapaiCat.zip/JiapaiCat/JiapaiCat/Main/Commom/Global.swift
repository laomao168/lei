//
//  Global.swift
//  HayekExGlobal
//
//  Created by liuwenli on 2018/11/20.
//  Copyright © 2018年 liuwenli. All rights reserved.
//

import UIKit
import LocalAuthentication
import EZSwiftExtensions
import SnapKit
import AdSupport
/// RGBA的颜色设置
func RGBA(_ r:CGFloat, _ g:CGFloat, _ b:CGFloat,_ a:CGFloat = 1) -> UIColor {
    return UIColor(red: r / 255.0, green: g / 255.0, blue: b / 255.0, alpha: a)
}

// NSLocalizedString(key, comment,tbl) 本质,tbl：自定义strings文件的名字
// NSlocalizeString 第一个参数是内容,根据第一个参数去对应语言的文件中取对应的字符串，第二个参数将会转化为字符串文件里的注释，可以传nil，也可以传空字符串@""。
func localizedString(_ key: String?, comment: String? = nil, table: String? = nil) -> String {
    return key ?? ""
//    guard let key = key else { return "" }
//    if isLanguagesZH {
//        let path = Bundle.main.path(forResource: "zh-Hans", ofType: "lproj")
//        let localBundle = Bundle(path: path!)!
//        let str = localBundle.localizedString(forKey: key, value: comment, table: table)
//        return str
//    }else{//en和其他语言
//        let path = Bundle.main.path(forResource: "en", ofType: "lproj")
//        let localBundle = Bundle(path: path!)!
//        let str = localBundle.localizedString(forKey: key, value: comment, table: table)
//        return str
//    }
    //    let str = Bundle.main.localizedString(forKey: key, value: comment, table: table)
    //    return str
}

var isLanguagesZH: Bool {
    get {
        let lanArr: [String] = UserDefaults.standard.object(forKey: "AppleLanguages") as! [String]
        let lan = lanArr.first!
        return lan.hasPrefix("zh")
    }
}

//广告id
let idfaUuid = ASIdentifierManager.shared().advertisingIdentifier.uuidString

var deviceNo: String {
    return idfaUuid
}
/// size
let SWIDTH  = UIScreen.main.bounds.size.width
let SHEIGHT = UIScreen.main.bounds.size.height

let currentAppVersion = Bundle.main.infoDictionary!["CFBundleShortVersionString"] as! String
//导航栏高度
let kNavBarHeight: CGFloat = UIDevice.current.isX() ? 88 : 64
let kSafeAreaBottomHeight: CGFloat = UIDevice.current.isX() ? 34 : 0
let kStatusBarHeight: CGFloat = UIDevice.current.isX() ? 44 : 20

//导航栏颜色变化
let NAVBAR_COLORCHANGE_POINT:CGFloat = 50
///// 状态栏高度
//let kStatusBarHeight: CGFloat = UIApplication.shared.statusBarFrame.size.height
///// 导航栏高度
//let kNavBarHeight: CGFloat = 44.0
//MARK:- Color
let mainColor = RGBA(250, 87, 35, 1)
let kCancelButtonBGColor = RGBA(79, 108, 229, 0.1)


//网易云信appkey
//let NIMSDKAppKey = "8fc95f505b6cbaedf613677c8e08fc0b"
//申请的
let NIMSDKAppKey = "c0f7f82eda27b1a5acd34755bd664057"
//友盟
let kUM_AppKey = "5d5df7944ca357c009000535"
let kUM_channel = "App Store"
//微信分享
let kWechat_AppKey = "wx10eb27bde7ae5089"

//let kWechat_AppSecret = "692fcabf1ac2aebca5badf69df957f51"


let defaultMsg = "不明信息,请告知"

//更新地址


////客服电话
let kefu_hotline = "4008013931"
////微信号
//let wechat_No = "liuhe191314"
//token
//var APIToken: String {
//    return UserInfoManager.shared.token ?? ""
//}
var kUserInfo: UserInfoModel? {
    return UserInfoManager.shared.userInfo
}


let defaultImgName = "https://ss.csdn.net/p?https://mmbiz.qpic.cn/mmbiz_jpg/3ibgsEOESticwRfmlmicXJIdPjAql1dAs0JibvndluEGheibjAiaW8ia0LToWjyQhZTuUmUVicrJoRQBibTQsiapVBMZxFpA/640?wx_fmt=jpeg"

//下载安装链接

let AppStoreURL = "https://itunes.apple.com/cn/app/id1494556414?mt=8"
//URL Scheme
let kAppScheme = "JiapaiCat"

//匹配所有字符串正则: "[^"]*[\u4E00-\u9FA5]+[^"\n]*?",replace:localizedString(key: $0)

//0已完成申请 1已退出 2未完成申请
