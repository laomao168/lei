//
//  NotificationName.swift
//  HayekExGlobal
//
//  Created by liuwenli on 2019/6/27.
//  Copyright © 2019 liuwenli. All rights reserved.
//

import UIKit

extension Notification.Name {
    static let goHome = Notification.Name(rawValue: "Gohome")
    static let succeedLogin = Notification.Name(rawValue: "succeedLogin")
    static let wechatPayResult = Notification.Name(rawValue: "wechatPayResult")
    static let alipayResult = Notification.Name(rawValue: "alipayResult")
}
