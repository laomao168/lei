//
//  SysConfig.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2020/1/5.
//  Copyright © 2020 刘文利. All rights reserved.
//

import UIKit

class SysConfig: NSObject {
    static let shared = SysConfig()
    var rechargeType: String = "0"
}
