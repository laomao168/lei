//
//  UserInfoManager.swift
//  CBIT
//
//  Created by 刘文利 on 2019/8/21.
//  Copyright © 2019 网泰信息. All rights reserved.
//

import UIKit

class UserInfoManager: NSObject {
    static let shared = UserInfoManager()
    
    var isLogined: Bool {
        return token != nil
    }
//    var weChatLoginCode = "0231xprl1qMfFq02Pmpl1Ahmrl11xprX"
    
    //用户信息token
    var token: String? {
        set {
            UserDefaults.standard.set(newValue, forKey: "token")
            UserDefaults.standard.synchronize()
        }
        get {
//            if appURL == "https://api.oneauct.com/" {
//                return "yXD2V0Xztooh6vB0gtAuVMyjuMXijJsfLoWhLgYX9u9es6HKsZNqCnjstKWtgBek"
//            }
            return UserDefaults.standard.string(forKey: "token")
        }
    }
    
//    var userInfo: UserInfoModel?
        
    var userInfo: UserInfoModel? {
        set {
            if let value = newValue {
                let marketData = NSKeyedArchiver.archivedData(withRootObject: value)
                UserDefaults.standard.set(marketData, forKey: "userInfo")

            }else{
                UserDefaults.standard.removeObject(forKey: "userInfo")
            }
            UserDefaults.standard.synchronize()
        }
        get {
            if let userInfoData = UserDefaults.standard.object(forKey: "userInfo") as? Data {
                let model = NSKeyedUnarchiver.unarchiveObject(with: userInfoData) as? UserInfoModel
                return model
            }else{
                return nil
            }
        }
    }
}
