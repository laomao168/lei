//
//  Enums.swift
//  CBIT
//
//  Created by 刘文利 on 2019/8/14.
//  Copyright © 2019 网泰信息. All rights reserved.
//

import UIKit

enum NodeStyle: Int {
    case rose = 1//玫瑰
    case crystal = 2//水晶
    case diamond = 3//钻石
    case crown = 4//皇冠
}
enum AnctionStatus: Int {
    case notStarted = 2
    case started = 3
    case end = 4
}

//订单类型
enum OrderStyle: String {
    case all//全部
    case pendingPayment//待付款
    case delivered//待发货
    case pendingReceipt//待收货
    case completed//已完成
}

enum OrderStatus: Int {
    case pendingPayment = 0//待付款
    case delivered = 1//待发货
    case pendingReceipt = 2//待收货
    case completed = 3//已完成
    case fail = 4//失败
    case cancel = 5//已取消
    case close = 6//关闭订单（免单
    var description: String {
        switch self {
        case .pendingPayment:
            return "待付款"
        case .delivered:
            return "待发货"
        case .pendingReceipt:
            return "待收货"
        case .completed:
            return "交易完成"
        case .fail:
            return "交易失败"
        case .cancel:
            return "已取消"
        case .close:
            return "交易关闭"
        }
    }
}
