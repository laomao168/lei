//
//  Response+Demo.swift
//  RxNetwork_Example
//
//  Created by GorXion on 2018/7/18.
//  Copyright © 2018年 CocoaPods. All rights reserved.
//

import Moya
//import RxNetwork

public extension Response {
    
    func mapObject<T: Codable>(_ type: T.Type, ignoreCode: [String] = []) throws -> T {
        if self.statusCode == 401 {
            SVProgressHUD.showError(withStatus: "登录失效")
            UserInfoManager.shared.token = nil
            UserInfoManager.shared.userInfo = nil
            if let mainVC = UIApplication.shared.keyWindow?.rootViewController as? MainViewController {
                mainVC.selectedIndex = 0
            }
            throw NetworkError.status(code: "401", message: "登录失效")
        }
        let response = try map(BaseResponse<EmptyResponse>.self)
        if response.success {
            let res = try map(T.self)
            return res
        }else{
//            if response.code == "401" {//token失效
//                SVProgressHUD.showError(withStatus: "登录失效")
//                UserInfoManager.shared.token = nil
//                if let mainVC = UIApplication.shared.keyWindow?.rootViewController as? MainViewController {
//                    mainVC.selectedIndex = 0
//                }
//            }else{
                if !ignoreCode.isEmpty, ignoreCode.contains(response.code ?? "0") {
                    
                }else{
                    SVProgressHUD.showError(withStatus: response.msg)
                }
//            }
            throw NetworkError.status(code: response.code, message: response.msg)
        }
        
    }
    
//    func mapCode() throws -> Int {
//        return try map(Int.self, atKeyPath: "code")
//    }
//    
//    func mapMessage() throws -> String {
//        return try map(String.self, atKeyPath: "message")
//    }
}

