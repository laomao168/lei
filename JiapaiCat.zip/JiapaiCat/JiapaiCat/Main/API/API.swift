//
//  API.swift
//  jiaoyisuo
//
//  Created by liuwenli on 2018/4/4.
//  Copyright © 2018年 liuwenli. All rights reserved.
//

import UIKit

//MARK:- 服务器地址
//测试
//let appURL = "https://api.test.fmallnet.com/"
//let kHtml_baseUrl = "https://h5.fmallnet.com/"
//let websocketUrl = "wss://websocket.test.fmallnet.com/api/websocket"
let appURL = "https://api.lepai988.cn/"
let kHtml_baseUrl = "https://h5.lepai988.cn/"
let websocketUrl = "wss://websocket.lepai988.cn/api/websocket"
//预发
//let appURL = "https://betaapp.cupid-bit.com/"
//let kHtml_baseUrl = "https://betah5.cbit.love/"

//////MARK:- 上线,把moya打印关掉
//let appURL = "https://api.oneauct.com/"
//let kHtml_baseUrl = "https://h5.oneauct.com/"
//let websocketUrl = "wss://websocket.oneauct.com/api/websocket"


let imageURL = ""

//注册

//登录
//https://api.oneauct.com/api/home/login
let API_login = "api/home/login"
//POST /api/home/banner/list查询广告位列表
let API_homeBannerList = "api/home/banner/list"
//POST /api/goodsCategory/list查询商品分类列表
let API_goodsCategoryList = "api/goodsCategory/list"
//POST /api/auctionRecordInfo/listToday今日热拍
let API_listToday = "api/auctionRecordInfo/listToday"
//POST /api/auctionRecordInfo/listDate今日或明日或后日的预展拍卖纪录列表
let API_listDate = "api/auctionRecordInfo/listDate"
//https://api.oneauct.com/api/auctionRecordInfo/listFatherCategory?page.pageNumber=1&page.pageSize=10
//POST /api/auctionRecordInfo/listFatherCategory一级类目下的拍卖纪录列表
let API_listFatherCategory = "api/auctionRecordInfo/listFatherCategory"
//POST /api/auctionRecordInfo/auctionRecordInfo拍卖纪录详情
let API_auctionRecordInfo = "api/auctionRecordInfo/auctionRecordInfo"

//https://api.oneauct.com/api/auctionRecordDetail/listByAuctionId?page.pageNumber=1&page.pageSize=20
//POST /api/auctionRecordDetail/listByAuctionId出价列表
let API_auctionRecordDetail = "api/auctionRecordDetail/listByAuctionId"
//POST /api/auctionRecordDetail/rankingList收益排行榜
let API_rankingList = "api/auctionRecordDetail/rankingList"
//POST /api/home/appLogin app登录
let API_appLogin = "api/home/appLogin"
//POST /api/home/sendSms绑定手机号发送短信
let API_sendSms = "api/home/sendSms"
//POST /api/member/balanceAndIntegralAndFans我的余额数、积分数、粉丝数、邀请码
let API_balanceAndIntegralAndFans = "api/member/balanceAndIntegralAndFans"
//POST /api/member/myTotalIntegrate我的总积分
let API_myTotalIntegrate = "api/member/myTotalIntegrate"
//member/myIntegrate 积分明细列表
let API_myIntegrate = "api/member/myIntegrate"
//POST /api/account/detail detail
let API_accountDetail = "api/account/detail"
//POST /api/account/todayincome todayincome
let API_todayincome = "api/account/todayincome"
//POST /api/member/myAmountList我的余额明细列表
let API_myAmountList = "api/member/myAmountList"
//POST /api/member/fans我的粉丝
let API_fans = "api/member/fans"
//https://api.oneauct.com/api/member/superiorInfo 上级
let API_superiorInfo = "api/member/superiorInfo"
//POST /api/member/getAllMyFans所有粉丝（直属+间属
let API_getAllMyFans = "api/member/getAllMyFans"
//POST /api/member/getQRcode
let API_getQRcode = "api/member/getQRcode"
//POST /api/auctionRecordInfo/myList我的竞拍
let API_myAuctionList = "api/auctionRecordInfo/myList"
//POST /api/memberAddress/list查询会员地址列表
let API_addressList = "api/memberAddress/list"
//是否实名https://api.oneauct.com/api/memberRealperson/checkRealPerson
let API_checkRealPerson = "api/memberRealperson/checkRealPerson"
//https://api.oneauct.com/api/member/isSetPassword 是否设置支付密码
let API_isSetPassword = "api/member/isSetPassword"
//https://api.oneauct.com/api/member/setPassword
let API_setPassword = "api/member/setPassword"
//POST /api/memberRealperson/realPerson实名认证
let API_realPerson = "api/memberRealperson/realPerson"
//https://api.oneauct.com/api/config/key
let API_configKey = "api/config/key"
//https://api.oneauct.com/api/order/rechargeList?page.pageNumber=1&page.pageSize=20
let API_rechargeList = "api/order/rechargeList"
//POST /api/account/recharge recharge
let API_recharge = "api/account/recharge"
//memberwithdraw/weixin 提现
let API_withdraw_weixin = "api/memberwithdraw/weixin"
//memberwithdraw/list 提现明细列表
let API_withdrawList = "api/memberwithdraw/list"
//https://api.oneauct.com/api/memberAddress/allList
let API_areaList = "api/memberAddress/allList"
let API_addressDetail = "api/memberAddress/detail"
//POST /api/memberAddress/add
let API_addAddress = "api/memberAddress/add"
//POST /api/memberAddress/add
let API_addressEdit = "api/memberAddress/edit"
//POST /api/auctionRecordDetail/add会员用户出价
let API_bid = "api/auctionRecordDetail/add"
let API_inviteCode = "api/member/inviteCode"
let API_orderStatistics = "api/order/statistics"
//POST /api/order/list查询订单列表
let API_orderList = "api/order/list"
//POST /api/order/detail获取详情
let API_orderDetail = "api/order/detail"
//POST /api/order/receipt确认收货
let API_orderReceipt = "api/order/receipt"
//POST /api/order/prePayOrder预支付订单
let API_prePayOrder = "api/order/prePayOrder"
////POST /api/order/orderPay支付
//let API_orderPay = "api/order/orderPay"
//api/auctionRecordInfo/isTransaction判断是否到了开拍时间
let API_isTransaction = "api/auctionRecordInfo/isTransaction"
//api/lepaiAppversion/getBySource检测更新
let API_getBySource = "api/lepaiAppversion/getBySource"
//app下单 支付接口                 /api/common/order
let API_commonOrder = "api/common/order"
//https://api.oneauct.com/api/mallGoodsInfo/list?page.pageNumber=1&page.pageSize=10
let API_mallGoodsInfoList = "api/mallGoodsInfo/list"
//https://api.oneauct.com/api/mallGoodsInfo/detail
let API_mallGoodsInfoDetail = "api/mallGoodsInfo/detail"
//https://api.oneauct.com/api/mallOrder/prePayOrder
let API_mallPrePayOrder = "api/mallOrder/prePayOrder"
//POST /api/mallOrder/prePayOrderByOrderId预支付订单
let API_mallPrePayOrderByOrderId = "api/mallOrder/prePayOrderByOrderId"
//https://api.oneauct.com/api/mallGoodsInfo/typelist?goodsType=2
let API_mallTypeList = "api/mallGoodsInfo/typelist"
//https://api.oneauct.com/api/mallOrder/list?page.pageNumber=1&page.pageSize=10
let API_mallOrderList = "api/mallOrder/list"
//POST /api/mallOrder/detail获取详情
let API_mallOrderDetail = "api/mallOrder/detail"
//POST /api/mallOrder/receipt商城确认收货
let API_mallOrderReceipt = "api/mallOrder/receipt"


let kHtml_distRule = kHtml_baseUrl+"rule.html"//拍卖规则
let kHtml_distRule2 = kHtml_baseUrl+"rule2.html"//用户须知
let kHtml_kefu = kHtml_baseUrl+"kefu.html"//客服
 
