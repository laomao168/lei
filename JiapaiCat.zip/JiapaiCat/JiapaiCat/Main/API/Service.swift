//
//  Service.swift
//  MoyaService
//
//  Created by SSS on 2017/9/18.
//  Copyright © 2017年 sss. All rights reserved.
//

import UIKit
import Moya

enum NetworkError: Swift.Error {
    case status(code: String?, message: String?)
    case mapToModelError
    case connectionError(code: String?, message: String?)
    var code: String? {
        switch self {
        case .status(let code, _):
            return code
        case .mapToModelError:
            return nil
        case .connectionError(let code, _):
            return code
        }
    }
    
    var message: String? {
        switch self {
        case .status(_, let message):
            return message
        case .mapToModelError:
            return "反序列化错误"
        case .connectionError(_, let message):
            return message
        }
    }
}
/*
/// 网络请求
class Service: Any {
    
    /// request
    ///
    /// - Parameters:
    ///   - target: 网络请求
    ///   - model:  反序列化模型
    ///   - success: 
    ///   - failure:
    static func request<T>(_ provider: MoyaProvider<APITarget> = provider, target: APITarget, model:T.Type, success: @escaping ((BaseResponse<T>)-> Void), failure: ((_ error: Error)-> Void)? ) {
        provider.request(target) { (result) in
            switch result{
            case .success(let value):
                switch value.response!.statusCode{
                case 200:
                    do{
                        let res = try JSONDecoder().decode(BaseResponse<T>.self, from: value.data)
                        if res.retCode == "0" {
                            success(res)
                        }else{
                            let err = NetworkError.status(code: res.retCode, message: res.errorMsg)
                            failure?(err)
                            if res.retCode == "10002" {
                                //登录失效
                                
                            }else {
                                SVProgressHUD.showError(withStatus: res.errorMsg)
                            }
                        }
                    }catch{/// 反序列化错误
                        print("反序列化错误\n",error)
                        failure?(NetworkError.mapToModelError)
                    }
                default:
                    SVProgressHUD.showError(withStatus: localizedString("网络错误"))
                    let err = NetworkError.connectionError(code: value.response!.statusCode.toString, message: localizedString("网络错误"))
                    //                    let error = MoyaError.statusCode(value)
                    failure?(err)
                }
                
            case .failure(let error):
                SVProgressHUD.showError(withStatus: localizedString("连接到服务器失败"))
                print(error)
                failure?(error)
            }
        }
    }

}

*/
