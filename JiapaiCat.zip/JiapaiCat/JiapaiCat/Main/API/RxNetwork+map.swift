//
//  RxNetwork+Demo.swift
//  RxNetwork_Example
//
//  Created by GorXion on 2018/7/18.
//  Copyright © 2018年 CocoaPods. All rights reserved.
//

import Moya
import RxSwift

public extension PrimitiveSequence where TraitType == SingleTrait, ElementType == Response {
    
    func mapObject<T: Codable>(_ type: T.Type, ignoreCode: [String] = []) -> Single<T> {
        return flatMap { response -> Single<T> in
            return Single.just(try response.mapObject(type, ignoreCode: ignoreCode))
        }
    }
}

public extension ObservableType where E == Response {
    
    func mapObject<T: Codable>(_ type: T.Type, ignoreCode: [String] = []) -> Observable<T> {
        return flatMap { response -> Observable<T> in
            return Observable.just(try response.mapObject(type, ignoreCode: ignoreCode))
        }
    }
}
