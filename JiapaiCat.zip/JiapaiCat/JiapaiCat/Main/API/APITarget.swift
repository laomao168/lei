//
//  APITarget.swift
//  jiaoyisuo
//
//  Created by liuwenli on 2018/4/4.
//  Copyright © 2018年 liuwenli. All rights reserved.
//

import UIKit
import Moya
import RxSwift

let provider = MoyaProvider<APITarget>(requestClosure: requestTimeoutClosure ,plugins: [activityPlugin, NetworkLoggerPlugin(verbose: true, responseDataFormatter: JSONResponseDataFormatter)], trackInflights: true)
let noHUDprovider = MoyaProvider<APITarget>(requestClosure: requestTimeoutClosure ,plugins: [NetworkLoggerPlugin(verbose: true, responseDataFormatter: JSONResponseDataFormatter)], trackInflights: true)
//

let requestTimeoutClosure = { (endpoint: Endpoint, done: MoyaProvider.RequestResultClosure) in
    guard var request = try? endpoint.urlRequest() else { return }
    request.timeoutInterval = 30    //设置请求超时时间
    request.cachePolicy = .reloadIgnoringLocalCacheData
    done(.success(request))
}

var numberOfRequests: Int = 0 {
    didSet {
        if numberOfRequests > 1 { return }
        DispatchQueue.main.async {
            UIApplication.shared.isNetworkActivityIndicatorVisible = numberOfRequests > 0
        }
        if numberOfRequests > 0 {
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+0.5) {
                if numberOfRequests > 0 {
                    SVProgressHUD.show()
                }
            }
        }else{
            SVProgressHUD.dismiss()
        }
    }
}
let activityPlugin = NetworkActivityPlugin(networkActivityClosure: {state,arg  in
    if state == .began{
        numberOfRequests = numberOfRequests+1
    }else{
        numberOfRequests = numberOfRequests-1
    }
})

// Provider setup
func JSONResponseDataFormatter(_ data: Data) -> Data {
    do {
        let dataAsJSON = try JSONSerialization.jsonObject(with: data)
        let prettyData =  try JSONSerialization.data(withJSONObject: dataAsJSON, options: .prettyPrinted)
        return prettyData
    } catch {
        return data // fallback to original data if it can't be serialized.
    }
}

public enum APITarget{
    case homeBannerList(bannerType: Int)
    case goodsCategoryList(parentId: Int, isRecommend: Int)
    case listToday(pageNumber: Int, pageSize: Int)
    case listDate(pageNumber: Int, pageSize: Int, type: Int)
    case listFatherCategory(pageNumber: Int, pageSize: Int, fatherCategoryId: Int)
    case auctionRecordInfo(auctionId: Int)
    case auctionRecordDetail(auctionId: Int, pageNumber: Int, pageSize: Int)
    case rankingList(auctionId: Int)
    case login(code: String)
    case appLogin(phone: String, verifyCode: String)
    case sendSms(mobile: String, use: String)
    case balanceAndIntegralAndFans
    case myTotalIntegrate
    case myIntegrate(pageNumber: Int, pageSize: Int)
    case accountDetail
    case todayincome
    case myAmountList(pageNumber: Int, pageSize: Int)
    case fans(pageNumber: Int, pageSize: Int)
    case superiorInfo
    case getAllMyFans(pageNumber: Int, pageSize: Int)
    case noPara(url: String)
    case myAuctionList(pageNumber: Int, pageSize: Int)
    case addressList
    case setPassword(phone: String, payPass: String, verifyCode: String)
    case realPerson(userName: String, alipay: String, idCard: String, bankName: String, bankCardNo: String, bankBranch: String)
    case rechargeList(pageNumber: Int, pageSize: Int)
    case configKey(sysConfigKey: String)
    case recharge(amount: Double)
    case withdraw_weixin(amount: Double, payPassword: String)
    case withdrawList(pageNumber: Int, pageSize: Int)
    case areaList(parentId: Int)
    case addressDetail(addressId: Int)
    case addAddress(consignee: String, mobile: String, province: Int, city: Int, district: Int, street: Int, address: String, tolerant: Int)
    case addressEdit(addressId: Int, consignee: String, mobile: String, province: Int, city: Int, district: Int, street: Int, address: String, tolerant: Int)
    case bid(auctionId: Int, payPrice: Double)
    case inviteCode(code: String)
    case orderList(pageNumber: Int, pageSize: Int, current: Int, orderStatus: String)
    case orderDetail(orderId: Int)
    case orderReceipt(orderId: Int)
    case prePayOrder(orderId: Int)
//    case orderPay(orderId: Int, addressId: Int, goodsId: Int, payType: Int, payPassWord: String)
    case isTransaction(auctionId: Int)
    case getBySource
    case commonOrder(orderType: Int, type: Int, payType: Int, amount: String?, goodsId: Int?, addressId: Int?, payPassWord: String?, orderId: Int?)
    case mallGoodsInfoList(pageNumber: Int, pageSize: Int, goodsType: Int?, boutique: Int?, categoryId: String?)
    case mallGoodsInfoDetail(goodsId: Int)
    case mallPrePayOrder(goodsId: Int)
    case mallTypeList(goodsType: Int)
    case mallOrderList(pageNumber: Int, pageSize: Int, orderStatus: Int?, orderType: Int?, goodsType: Int)
    case mallOrderDetail(orderId: Int)
    case mallOrderReceipt(orderId: Int)
    case mallPrePayOrderByOrderId(orderId: Int)
}

extension APITarget: TargetType{
    
    public var baseURL: URL {
        return URL(string: appURL)!
    }
    
    public var path: String {
        switch self {
        case .homeBannerList:
            return API_homeBannerList
        case .goodsCategoryList:
            return API_goodsCategoryList
        case .listToday:
            return API_listToday
        case .listDate:
            return API_listDate
        case .listFatherCategory:
            return API_listFatherCategory
        case .auctionRecordInfo:
            return API_auctionRecordInfo
        case .auctionRecordDetail:
            return API_auctionRecordDetail
        case .rankingList:
            return API_rankingList
        case .login:
            return API_login
        case .appLogin:
            return API_appLogin
        case .sendSms:
            return API_sendSms
        case .balanceAndIntegralAndFans:
            return API_balanceAndIntegralAndFans
        case .myTotalIntegrate:
            return API_myTotalIntegrate
        case .myIntegrate:
            return API_myIntegrate
        case .accountDetail:
            return API_accountDetail
        case .todayincome:
            return API_todayincome
        case .myAmountList:
            return API_myAmountList
        case .fans:
            return API_fans
        case .superiorInfo:
            return API_superiorInfo
        case .getAllMyFans:
            return API_getAllMyFans
        case .noPara(let url):
            return url
        case .myAuctionList:
            return API_myAuctionList
        case .addressList:
            return API_addressList
        case .setPassword:
            return API_setPassword
        case .realPerson:
            return API_realPerson
        case .rechargeList:
            return API_rechargeList
        case .configKey:
            return API_configKey
        case .recharge:
            return API_recharge
        case .withdraw_weixin(_):
            return API_withdraw_weixin
        case .withdrawList:
            return API_withdrawList
        case .areaList:
            return API_areaList
        case .addressDetail:
            return API_addressDetail
        case .addAddress:
            return API_addAddress
        case .addressEdit:
            return API_addressEdit
        case .bid:
            return API_bid
        case .inviteCode:
            return API_inviteCode
        case .orderList:
            return API_orderList
        case .orderDetail:
            return API_orderDetail
        case .orderReceipt:
            return API_orderReceipt
        case .prePayOrder:
            return API_prePayOrder
//        case .orderPay:
//            return API_orderPay
        case .isTransaction:
            return API_isTransaction
        case .getBySource:
            return API_getBySource
        case .commonOrder:
            return API_commonOrder
        case .mallGoodsInfoList:
            return API_mallGoodsInfoList
        case .mallGoodsInfoDetail:
            return API_mallGoodsInfoDetail
        case .mallPrePayOrder:
            return API_mallPrePayOrder
        case .mallTypeList:
            return API_mallTypeList
        case .mallOrderList:
            return API_mallOrderList
        case .mallOrderDetail:
            return API_mallOrderDetail
        case .mallOrderReceipt:
            return API_mallOrderReceipt
        case .mallPrePayOrderByOrderId:
            return API_mallPrePayOrderByOrderId
        }
    }
    
    public var method: Moya.Method {
        switch self {
//        case .setPayPwd:
//            return .get
        default:
            return .post
        }
    }
    
    public var sampleData: Data {
        return "{\"data\":{\"id\":\"your_new_gif_id\"},\"meta\":{\"status\":200,\"msg\":\"OK\"}}".data(using: String.Encoding.utf8)!
    }
    
    public var task: Task {
        switch self {
        case .homeBannerList(let bannerType):
            return ["bannerType": bannerType].bodyTask
        case .goodsCategoryList(let parentId, let isRecommend):
            return ["parentId": parentId, "isRecommend": isRecommend].bodyTask
        case .listToday(let pageNumber, let pageSize):
            return ["page.pageNumber": pageNumber, "page.pageSize": pageSize].queryTask
        case .listDate(let pageNumber, let pageSize, let type):
            return ["page.pageNumber": pageNumber, "page.pageSize": pageSize, "type": type].queryTask
        case .listFatherCategory(let pageNumber, let pageSize, let fatherCategoryId):
            return ["page.pageNumber": pageNumber, "page.pageSize": pageSize, "fatherCategoryId": fatherCategoryId].queryTask
        case .auctionRecordInfo(let auctionId):
            return ["auctionId": auctionId].bodyTask
        case .auctionRecordDetail(let auctionId, let pageNumber, let pageSize):
            return ["auctionId": auctionId, "page.pageNumber": pageNumber, "page.pageSize": pageSize].bodyTask
        case .rankingList(let auctionId):
            return ["auctionId": auctionId].bodyTask
        case .login(let code):
            return ["code": code].bodyTask
        case .appLogin(let phone, let verifyCode):
            return ["phone": phone, "verifyCode": verifyCode].bodyTask
        case .sendSms(let mobile, let use):
            return ["mobile": mobile, "use": use].bodyTask
        case .balanceAndIntegralAndFans:
            return [:].queryTask
        case .myTotalIntegrate:
            return [:].queryTask
        case .myIntegrate(let pageNumber, let pageSize):
            return ["page.pageNumber": pageNumber, "page.pageSize": pageSize].queryTask
        case .accountDetail:
            return [:].queryTask
        case .todayincome:
            return [:].queryTask
        case .myAmountList(let pageNumber, let pageSize):
            return ["page.pageNumber": pageNumber, "page.pageSize": pageSize].queryTask
        case .fans(let pageNumber, let pageSize):
            return ["page.pageNumber": pageNumber, "page.pageSize": pageSize].queryTask
        case .superiorInfo:
            return [:].queryTask
        case .getAllMyFans(let pageNumber, let pageSize):
            return ["page.pageNumber": pageNumber, "page.pageSize": pageSize].queryTask
        case .noPara:
            return [:].queryTask
        case .myAuctionList(let pageNumber, let pageSize):
            return ["page.pageNumber": pageNumber, "page.pageSize": pageSize].queryTask
        case .addressList:
            return [:].bodyTask
        case .setPassword(let phone, let payPass, let verifyCode):
            return ["phone": phone, "payPass": payPass, "verifyCode": verifyCode].bodyTask
        case .realPerson(let userName, let alipay, let idCard, let bankName, let bankCardNo, let bankBranch):
            return ["userName": userName, "alipay": alipay, "idCard": idCard, "bankName": bankName, "bankCardNo": bankCardNo, "bankBranch": bankBranch].bodyTask
        case .rechargeList(let pageNumber, let pageSize):
            return ["page.pageNumber": pageNumber, "page.pageSize": pageSize].queryTask
        case .configKey(let sysConfigKey):
            return ["sysConfigKey": sysConfigKey].queryTask
        case .recharge(let amount):
            return ["amount": amount].bodyTask
        case .withdraw_weixin(let amount, let payPassword):
            return ["amount": amount, "payPassword": payPassword].bodyTask
        case .withdrawList(let pageNumber, let pageSize):
            return ["page.pageNumber": pageNumber, "page.pageSize": pageSize].queryTask
        case .areaList(let parentId):
            return ["parentId": parentId].queryTask
        case .addressDetail(let addressId):
            return ["addressId": addressId].bodyTask
        case .addAddress(let consignee, let mobile, let province, let city, let district, let street, let address, let tolerant):
            return ["consignee": consignee, "mobile": mobile, "province": province, "city": city, "district": district, "street": street, "address": address, "tolerant": tolerant].bodyTask
        case .addressEdit(let addressId, let consignee, let mobile, let province, let city, let district, let street, let address, let tolerant):
            return ["addressId": addressId, "consignee": consignee, "mobile": mobile, "province": province, "city": city, "district": district, "street": street, "address": address, "tolerant": tolerant].bodyTask
        case .bid(let auctionId, let payPrice):
            return ["auctionId": auctionId, "payPrice": payPrice].bodyTask
        case .inviteCode(let code):
            return ["code": code].queryTask
        case .orderList(let pageNumber, let pageSize, let current, let orderStatus):
            return ["page.pageNumber": pageNumber, "page.pageSize": pageSize, "current": current, "orderStatus": orderStatus].bodyTask
        case .orderDetail(let orderId):
            return ["orderId": orderId].bodyTask
        case .orderReceipt(let orderId):
            return ["orderId": orderId].bodyTask
        case .prePayOrder(let orderId):
            return ["orderId": orderId].bodyTask
//        case .orderPay(let orderId, let addressId, let goodsId, let payType, let payPassWord):
//            return ["orderId": orderId, "addressId": addressId, "goodsId": goodsId, "payType": payType, "payPassWord": payPassWord].bodyTask
        case .isTransaction(let auctionId):
            return ["auctionId": auctionId].bodyTask
        case .getBySource:
            return ["source": "ios"].queryTask
        case .commonOrder(let orderType, let type, let payType, let amount, let goodsId, let addressId, let payPassWord, let orderId):
            var para: [String: Any] = ["orderType": orderType, "type": type, "payType": payType]
            if let amount = amount {para["amount"] = amount}
            if let goodsId = goodsId {para["goodsId"] = goodsId}
            if let addressId = addressId {para["addressId"] = addressId}
            if let payPassWord = payPassWord {para["payPassWord"] = payPassWord}
            if let orderId = orderId {para["orderId"] = orderId}
            return para.bodyTask
        case .mallGoodsInfoList(let pageNumber, let pageSize, let goodsType, let boutique, let categoryId):
            var para: [String: Any] = ["page.pageNumber": pageNumber, "page.pageSize": pageSize]
            if let goodsType = goodsType {para["goodsType"] = goodsType}
            if let boutique = boutique {para["boutique"] = boutique}
            if let categoryId = categoryId {para["categoryId"] = categoryId}
            return para.bodyTask
        case .mallGoodsInfoDetail(let goodsId):
            return ["goodsId": goodsId].bodyTask
        case .mallPrePayOrder(let goodsId):
            return ["goodsId": goodsId].bodyTask
        case .mallTypeList(let goodsType):
            return ["goodsType": goodsType].queryTask
        case .mallOrderList(let pageNumber, let pageSize, let orderStatus, let orderType, let goodsType):
            var para: [String: Any] = ["page.pageNumber": pageNumber, "page.pageSize": pageSize, "goodsType": goodsType]
            if let orderStatus = orderStatus {para["orderStatus"] = orderStatus}
            if let orderType = orderType {para["orderType"] = orderType}
            return para.bodyTask
        case .mallOrderDetail(let orderId):
            return ["orderId": orderId].bodyTask
        case .mallOrderReceipt(let orderId):
            return ["orderId": orderId].bodyTask
        case .mallPrePayOrderByOrderId(let orderId):
            return ["orderId": orderId].bodyTask
        }
    }
    
    public var headers: [String : String]? {
        var para: [String: String] = ["os":"iOS"]
        if let token = UserInfoManager.shared.token {
            para["Authorization"] = token
        }
        return para
    }
}

extension Dictionary {
    var queryTask:Task {
        get{ return Task.requestParameters(parameters: self as! [String : Any], encoding: URLEncoding.queryString) }
    }
    var bodyTask:Task {
        get{ return Task.requestParameters(parameters: self as! [String : Any], encoding: URLEncoding.httpBody) }
    }
    var jsonTask: Task {
        get{ return Task.requestParameters(parameters: self as! [String : Any], encoding: JSONEncoding.default) }
    }
}
