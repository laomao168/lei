//
//  BalanceHeaderView.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/17.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class BalanceHeaderView: UIView {
    @IBOutlet weak var balanceNumLabel: UILabel!
    @IBOutlet weak var freezeAmountLabel: UILabel!
    @IBOutlet weak var tipsImgView: UIImageView!
    
    @IBOutlet weak var detailButton: UIButton!
    
    @IBOutlet weak var todayIncomeLabel: UILabel!
    @IBOutlet weak var yestodayIncomeLabel: UILabel!
    @IBOutlet weak var totalIncomeLabel: UILabel!
    
    @IBAction func clickTipAction(_ sender: UIButton) {
        tipsImgView.isHidden = !tipsImgView.isHidden
        
    }
    @IBAction func clickDetailAction(_ sender: UIButton) {
        let vc = BalanceDetailController()
        self.currentController()?.navigationController?.pushViewController(vc, animated: true)
    }
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
