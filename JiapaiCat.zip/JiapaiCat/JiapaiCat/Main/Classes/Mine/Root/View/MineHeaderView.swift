//
//  MineHeaderView.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/16.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class MineHeaderView: UIView {
    @IBOutlet weak var avatarImgView: UIImageView!
    
    @IBOutlet weak var nickNameLabel: UILabel!
    
    @IBOutlet weak var inviteCodeLabel: UILabel!
    
    @IBOutlet weak var jifenLabel: UILabel!
    
    @IBOutlet weak var balanceLabel: UILabel!
    
    @IBOutlet weak var friendLabel: UILabel!
    
    
    @IBOutlet weak var jifenButton: UIButton!
    
    @IBOutlet weak var balanceButton: UIButton!
    @IBOutlet weak var friendButton: UIButton!
    
    @IBOutlet weak var userInfoBgView: UIView!
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
