//
//  MineOrderCell.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/16.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class MineOrderCell: UITableViewCell {
    @IBOutlet weak var allOrderButton: UIButton!
    
    @IBOutlet weak var orderTypeButton1: UIButton!
    @IBOutlet weak var orderTypeButton2: UIButton!
    @IBOutlet weak var orderTypeButton3: UIButton!
    @IBOutlet weak var orderTypeButton4: UIButton!
    
    @IBOutlet weak var numLabel1: MarginCustomLabel!
    @IBOutlet weak var numLabel2: MarginCustomLabel!
    @IBOutlet weak var numLabel3: MarginCustomLabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        let margin: CGFloat = 5
        numLabel1.textInsets = UIEdgeInsets(top: 0, left: margin, bottom: 0, right: margin)
        numLabel2.textInsets = UIEdgeInsets(top: 0, left: margin, bottom: 0, right: margin)
        numLabel3.textInsets = UIEdgeInsets(top: 0, left: margin, bottom: 0, right: margin)
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
