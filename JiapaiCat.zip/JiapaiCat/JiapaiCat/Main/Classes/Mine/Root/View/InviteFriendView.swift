//
//  InviteFriendView.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/23.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class InviteFriendView: UIView {
    
    @IBOutlet weak var imgView1: UIImageView!
    @IBOutlet weak var avatarImgView: UIImageView!
    
    @IBOutlet weak var nickLabel: UILabel!
    
    @IBOutlet weak var inviteCodeLabel: UILabel!
    
    @IBOutlet weak var qrCodeImgView: UIImageView!
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
