//
//  ChangePayPwdController.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/17.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class ChangePayPwdController: BaseViewController {
    @IBOutlet weak var oldPasswordTF: UITextField!
    
    @IBOutlet weak var newPwdTF: UITextField!
    
    @IBOutlet weak var corfirmPwdTF: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "修改密码"
        // Do any additional setup after loading the view.
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
