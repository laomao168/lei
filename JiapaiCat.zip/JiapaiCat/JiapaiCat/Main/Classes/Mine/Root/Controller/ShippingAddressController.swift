//
//  ShippingAddressController.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/18.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class ShippingAddressController: BaseViewController {
    var selectAddress: ((_ model: AddressModel) -> Void)?
    lazy var tableView: UITableView = {
        let tableView = UITableView(frame: CGRect.zero, style: .plain)
        tableView.dataSource = self
        tableView.delegate = self
        return tableView
    }()
    var dataList: [AddressModel] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "收货地址"
        setupUI()
        requestData()
        // Do any additional setup after loading the view.
    }
    func setupUI() {
        self.view.addSubview(tableView)
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        tableView.backgroundColor = UIColor.tableViewBg
        tableView.tableHeaderView = UIView(frame: CGRect(x: 0, y: 0, width: SWIDTH, height: 10))
        let footerView = UIView(frame: CGRect(x: 0, y: 0, width: SWIDTH, height: 150))
        let submitButton = UIButton(type: .custom)
        submitButton.setTitle("新增收货地址", for: UIControl.State.normal)
        submitButton.setTitleColor(UIColor.white, for: UIControl.State.normal)
        submitButton.setBackgroundImage(UIImage.commomGradient, for: UIControl.State.normal)
        submitButton.addTarget(self, action: #selector(addAddress(_:)), for: UIControl.Event.touchUpInside)
        footerView.addSubview(submitButton)
        submitButton.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(15)
            make.right.equalToSuperview().offset(-15)
            make.height.equalTo(50)
            make.top.equalToSuperview().offset(50)
        }
        submitButton.kCornerRadius = 5
        tableView.tableFooterView = footerView
        tableView.rowHeight = 65
        tableView.register(UINib(nibName: "ShippingAddressCell", bundle: nil), forCellReuseIdentifier: String(describing: ShippingAddressCell.self))
    }
    func requestData() {
        provider.rx.request(APITarget.addressList)
            .mapObject(BaseResponse<PageResponse<[AddressModel]>>.self)
            .subscribe(onSuccess: { (res) in
                if let list = res.data?.data {
                    self.dataList = list
                    self.tableView.reloadData()
                }
            }, onError: { (error) in
                
            })
        .disposed(by: disposeBag)

    }
    
    
    @objc func clickEditAction(_ sender: UIButton) {
        let index = sender.tag
        let vc = AddAddressController()
        vc.model = self.dataList[index]
        vc.completedBlock = {[weak self] in
            self?.requestData()
        }
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @objc func addAddress(_ sender: UIButton) {
        let vc = AddAddressController()
        vc.completedBlock = {[weak self] in
            self?.requestData()
        }
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension ShippingAddressController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: ShippingAddressCell.self), for: indexPath) as! ShippingAddressCell
        cell.selectionStyle = .none
        let count = tableView.numberOfRows(inSection: indexPath.section)
        var corners: UIRectCorner?
        if count == 1 {
            corners = .allCorners
        }else{
            if indexPath.row == 0 {
                corners = [.topLeft, .topRight]
            }else if indexPath.row == count-1 {
                corners = [.bottomLeft, .bottomRight]
            }else{
                corners = nil
            }
        }
        if let corner = corners {
            //部分圆角
            let path = UIBezierPath(roundedRect: CGRect(x: 0, y: 0, width: SWIDTH-15*2, height: 65), byRoundingCorners: corner, cornerRadii: CGSize(width: 5, height: 5))
            let shapeLayer = CAShapeLayer()
            shapeLayer.path = path.cgPath
            cell.bgView.layer.mask = shapeLayer
        }else{
            cell.bgView.layer.mask = nil
        }
        if indexPath.row == count-1 {
            cell.separatorInset = UIEdgeInsets(top: 0, left: SWIDTH, bottom: 0, right: 0)
        }else{
            cell.separatorInset = UIEdgeInsets(top: 0, left: 25, bottom: 0, right: 25)
        }
        let model = dataList[indexPath.row]
        let address = "\(model.provinceText!)\(model.cityText!)\(model.districtText!)\(model.streetText!)\(model.address!)"
        cell.addressLabel.text = address
        cell.nameLabel.text = model.consignee
        cell.mobileLabel.text = model.mobile
        if model.tolerant == 0 {//默认
            cell.defaultLabel.isHidden = false
        }else{
            cell.defaultLabel.isHidden = true
        }
        cell.editButton.tag = indexPath.row
        cell.editButton.addTarget(self, action: #selector(clickEditAction(_:)), for: UIControl.Event.touchUpInside)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let model = dataList[indexPath.row]
        if let selectBlock = selectAddress {
            selectBlock(model)
            self.navigationController?.popViewController(animated: true)
        }
    }
}
