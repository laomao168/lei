//
//  SetPasswordViewController.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/20.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit
import SwiftyRSA
class SetPasswordViewController: BaseViewController {
    @IBOutlet weak var mobileTF: UITextField!
    
    @IBOutlet weak var codeTF: UITextField!
    
    @IBOutlet weak var pwdBgView1: UIView!
    
    @IBOutlet weak var pwdBgView2: UIView!
    
    @IBOutlet weak var passwordView: WCLPassWordView!
    @IBOutlet weak var repasswordView: WCLPassWordView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "设置密码"
        setupUI()
        // Do any additional setup after loading the view.
    }
    func setupUI() {
        pwdBgView1.isHidden = true
        pwdBgView2.isHidden = true
        passwordView.delegate = self
        repasswordView.delegate = self
        passwordView.backgroundColor = UIColor.clear
        repasswordView.backgroundColor = UIColor.clear
        passwordView.resignFirstResponder()
        repasswordView.resignFirstResponder()
    }

    @IBAction func sendMsgCode(_ sender: CountDownButton) {
        let mobile = mobileTF.text!
        if mobile.isEmpty {
            SVProgressHUD.showInfo(withStatus: "请输入手机号")
            return
        }
        guard Validator.isMobileNumber(mobile) else {
            SVProgressHUD.showInfo(withStatus: "手机号格式不对")
            return
        }
        provider.rx.request(APITarget.sendSms(mobile: mobile, use: "password"))
            .mapObject(BaseResponse<EmptyResponse>.self)
            .subscribe(onSuccess: { (res) in
                sender.isCounting = true
            }, onError: { (error) in
                
            })
        .disposed(by: disposeBag)
    }
    
    @IBAction func confirm(_ sender: UIButton) {
        pwdBgView1.isHidden = false
        pwdBgView2.isHidden = true
        passwordView.becomeFirstResponder()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension SetPasswordViewController: WCLPassWordViewDelegate {
    func passWordCompleteInput(_ passWord: WCLPassWordView!) {
        if passWord == passwordView {
            let text = passWord.textStore!
            if text.length != 6 {
                return
            }
            pwdBgView1.isHidden = true
            pwdBgView2.isHidden = false
            repasswordView.becomeFirstResponder()
        }else{
            let oldPassword = passwordView.textStore!
            let rePassowrd = repasswordView.textStore!
            if oldPassword == rePassowrd {
               let mobile = mobileTF.text!
                let code = codeTF.text!
                if code.isEmpty {
                    SVProgressHUD.showInfo(withStatus: "请输入验证码")
                    return
                }
                let pwd = oldPassword as String
                let pwdEncry = pwd.getRSAEncry()
                 provider.rx.request(APITarget.setPassword(phone: mobile, payPass: pwdEncry, verifyCode: code))
                    .mapObject(BaseResponse<EmptyResponse>.self)
                    .subscribe(onSuccess: { (res) in
                        SVProgressHUD.showSuccess(withStatus: "成功")
                        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+2) {
                            self.navigationController?.popViewController(animated: true)
                        }
                    }, onError: { (error) in
                        
                    })
                .disposed(by: disposeBag)
            }
        }
        
    }
}
