//
//  BalanceDetailController.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/17.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class BalanceDetailController: BaseTableViewController {
    var dataList: [MyAmountListModel] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "余额明细"
        setupUI()
        requestData()
        // Do any additional setup after loading the view.
    }
    func setupUI() {
        let headerView = UIView(frame: CGRect(x: 0, y: 0, w: SWIDTH, h: 10))
        
        tableView.tableHeaderView = headerView
        tableView.separatorStyle = .none
        tableView.backgroundColor = UIColor.tableViewBg
        tableView.register(UINib(nibName: "MyScoresCell", bundle: nil), forCellReuseIdentifier: String(describing: MyScoresCell.self))

    }
    override func requestData() {
        provider.rx.request(APITarget.myAmountList(pageNumber: self.pageNumber, pageSize: self.pageSize))
            .mapObject(BaseResponse<PageResponse<[MyAmountListModel]>>.self)
            .subscribe(onSuccess: { (res) in
                self.endRefresh(res.data?.page?.totalPage)
                if self.pageNumber == 1 {
                    self.dataList.removeAll()
                }
                if let list = res.data?.data {
                    self.dataList += list
                }
                self.tableView.reloadData()
            }, onError: { (error) in
                self.endRefresh()
            })
        .disposed(by: disposeBag)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension BalanceDetailController {
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if dataList.isEmpty {
            return 1
        }
        return dataList.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if dataList.isEmpty {
            let cell = EmptyDataCell()
            return cell
        }
        let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: MyScoresCell.self), for: indexPath) as! MyScoresCell
        cell.selectionStyle = .none
        let count = tableView.numberOfRows(inSection: indexPath.section)
        var corners: UIRectCorner?
        if count == 1 {
            corners = .allCorners
        }else{
            if indexPath.row == 0 {
                corners = [.topLeft, .topRight]
            }else if indexPath.row == count-1 {
                corners = [.bottomLeft, .bottomRight]
            }else{
                corners = nil
            }
        }
        if let corner = corners {
            //部分圆角
            let path = UIBezierPath(roundedRect: CGRect(x: 0, y: 0, width: SWIDTH-15*2, height: 70), byRoundingCorners: corner, cornerRadii: CGSize(width: 5, height: 5))
            let shapeLayer = CAShapeLayer()
            shapeLayer.path = path.cgPath
            cell.bgView.layer.mask = shapeLayer
        }else{
            cell.bgView.layer.mask = nil
        }
        
        if indexPath.section == count-1 {
            cell.lineView.isHidden = true
        }else{
            cell.lineView.isHidden = false
        }
        
        let model = dataList[indexPath.row]
        let tradeType = model.tradeType//0 提现 1 保证金 2, 订单 3, 充值余额 4,退保证金 5,拍卖红包 6,好友成交红包 7,平台操作 8,寄拍收入 9,拍卖成交红包 10,拍卖收入 11,解冻提现
        if tradeType == 0 {
            cell.titleLabel.text = "提现"
        }else if tradeType == 1 {
            cell.titleLabel.text = "保证金"
        }else if tradeType == 2 {
            cell.titleLabel.text = "订单"
        }else if tradeType == 3 {
            cell.titleLabel.text = "充值余额"
        }else if tradeType == 4 {
            cell.titleLabel.text = "退保证金"
        }else if tradeType == 5 {
            cell.titleLabel.text = "拍卖红包"
        }else if tradeType == 6 {
            cell.titleLabel.text = "好友成交红包"
        }else if tradeType == 7 {
            cell.titleLabel.text = "平台操作"
        }else if tradeType == 8 {
            cell.titleLabel.text = "寄拍收入"
        }else if tradeType == 9 {
            cell.titleLabel.text = "拍卖成交红包"
        }else if tradeType == 10 {
            cell.titleLabel.text = "拍卖收入"
        }else if tradeType == 11 {
            cell.titleLabel.text = "解冻提现"
        }else{
            cell.titleLabel.text = "其他"
        }
        cell.imgView.image = UIImage(named: "icon_integral_smrz")
        cell.timeLabel.text = model.createTime
        if model.type == 0 {
            cell.amoutLabel.text = "-"+(model.amount?.mapToPrice() ?? "0")
        }else{
            cell.amoutLabel.text = "+"+(model.amount?.mapToPrice() ?? "0")
        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if dataList.isEmpty {
            return EmptyDataCell.emptyHeight
        }
        return 70
    }
}
