//
//  MyScoresViewController.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/17.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class MyScoresViewController: BaseTableViewController {
    var headerView: MyScoresHeaderView!
    var dataList: [MyIntegrateListModel] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "我的积分"
        setupUI()
        requestData()
        // Do any additional setup after loading the view.
    }
    func setupUI() {
        headerView = Bundle.main.loadNibNamed("MyScoresHeaderView", owner: self, options: nil)?.first as? MyScoresHeaderView
        let homeHeaderView = UIView(frame: CGRect(x: 0, y: 0, w: SWIDTH, h: 102+20))
            
        homeHeaderView.addSubview(headerView)
        headerView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        tableView.tableHeaderView = homeHeaderView
        tableView.separatorStyle = .none
        tableView.backgroundColor = UIColor.tableViewBg
        tableView.register(UINib(nibName: "MyScoresCell", bundle: nil), forCellReuseIdentifier: String(describing: MyScoresCell.self))

    }
    override func requestData() {
        if self.pageNumber == 1 {
            provider.rx.request(APITarget.myTotalIntegrate)
                .mapObject(BaseResponse<Double>.self)
                .subscribe(onSuccess: { (res) in
                    self.headerView.scoresNumLabel.text = (res.data ?? 0).toDecimalString(0, maxF: 0)
                }, onError: { (error) in
                    
                })
            .disposed(by: disposeBag)
        }
        provider.rx.request(APITarget.myIntegrate(pageNumber: self.pageNumber, pageSize: self.pageSize))
            .mapObject(BaseResponse<PageResponse<[MyIntegrateListModel]>>.self)
            .subscribe(onSuccess: { (res) in
                self.endRefresh(res.data?.page?.totalPage)
                if self.pageNumber == 1 {
                    self.dataList.removeAll()
                }
                if let list = res.data?.data {
                    self.dataList += list
                }
                self.tableView.reloadData()
            }, onError: { (error) in
                self.endRefresh()
            })
        .disposed(by: disposeBag)
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension MyScoresViewController {
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if dataList.isEmpty {
            return 1
        }
        return dataList.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if dataList.isEmpty {
            let cell = EmptyDataCell()
            return cell
        }
        let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: MyScoresCell.self), for: indexPath) as! MyScoresCell
        cell.selectionStyle = .none
        let count = tableView.numberOfRows(inSection: indexPath.section)
        var corners: UIRectCorner?
        if count == 1 {
            corners = .allCorners
        }else{
            if indexPath.row == 0 {
                corners = [.topLeft, .topRight]
            }else if indexPath.row == count-1 {
                corners = [.bottomLeft, .bottomRight]
            }else{
                corners = nil
            }
        }
        if let corner = corners {
            //部分圆角
            let path = UIBezierPath(roundedRect: CGRect(x: 0, y: 0, width: SWIDTH-15*2, height: 70), byRoundingCorners: corner, cornerRadii: CGSize(width: 5, height: 5))
            let shapeLayer = CAShapeLayer()
            shapeLayer.path = path.cgPath
            cell.bgView.layer.mask = shapeLayer
        }else{
            cell.bgView.layer.mask = nil
        }
        
        if indexPath.section == count-1 {
            cell.lineView.isHidden = true
        }else{
            cell.lineView.isHidden = false
        }
        
        let model = dataList[indexPath.row]
        let tradeType = model.tradeType
        if tradeType == 0 {//订单类型（ 0 订单赠送积分， 1 平台赠送，2，积分兑换， 3，取消订单退回积分）
            cell.titleLabel.text = "订单赠送积分"
        }else if tradeType == 1 {
            cell.titleLabel.text = "平台赠送"
        }else if tradeType == 2 {
            cell.titleLabel.text = "积分兑换"
        }else if tradeType == 3 {
            cell.titleLabel.text = "取消订单退回积分"
        }else{
            cell.titleLabel.text = ""
        }
        cell.imgView.image = UIImage(named: "icon_integral_smrz")
        cell.timeLabel.text = model.createTime
        if model.type == 0 {
            cell.amoutLabel.text = "-"+(model.integralAmount?.mapToPrice() ?? "0")
        }else{
            cell.amoutLabel.text = "+"+(model.integralAmount?.mapToPrice() ?? "0")
        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if dataList.isEmpty {
            return EmptyDataCell.emptyHeight
        }
        return 70
    }
}
