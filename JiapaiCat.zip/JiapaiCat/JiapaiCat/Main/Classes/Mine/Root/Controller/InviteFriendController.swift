//
//  InviteFriendController.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/18.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit
import Photos

class InviteFriendController: BaseViewController {
    @IBOutlet weak var imageView: UIImageView!
    
    private lazy var shareView: InviteFriendView = {
        guard let shareView = Bundle.main.loadNibNamed("InviteFriendView", owner: self, options: nil)?.first as? InviteFriendView else {
            return InviteFriendView()
        }
        return shareView
    }()
    private lazy var shareImage: UIImage = {
        let bgView = UIView(frame: CGRect(x: 0, y: 0, w: 375, h: 667))
        bgView.backgroundColor = UIColor.white
        bgView.addSubview(shareView)
        shareView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        let img = bgView.toShareImage()
        return img
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "邀请好友"
        setupShareImage()
        getQrCodeImage()
        
//        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+2) {
//            self.imageView.image = self.shareImage
//        }
        
        // Do any additional setup after loading the view.
    }
    
    func getQrCodeImage() {
        provider.rx.request(APITarget.noPara(url: API_getQRcode))
            .mapObject(BaseResponse<String>.self)
            .subscribe(onSuccess: { (res) in
                if let imgURL = res.data {
                    let qrcodeUrl = imgURL
                    self.shareView.qrCodeImgView.kf.setImage(with: URL(string: qrcodeUrl)) { (result) in
                        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+0.5) {
                            SVProgressHUD.dismiss()
                            self.imageView.image = self.shareImage
                        }
                    }
                }
            }, onError: { (error) in
                
            })
        .disposed(by: disposeBag)
    }
    
    func setupShareImage() {
//        SVProgressHUD.show()
        shareView.imgView1.contentMode = .scaleToFill
        shareView.imgView1.image = UIImage.commomGradient
        if let userInfo = UserInfoManager.shared.userInfo {
            var num = 0
            shareView.avatarImgView.kf.setImage(with: URL(string: userInfo.avatar ?? ""), placeholder: UIImage(named: "头像")) { (result) in
//                num = num + 1
//                if num == 2 {
//                    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+2) {
//                        SVProgressHUD.dismiss()
//                        self.imageView.image = self.shareImage
//                    }
//                }
            }
            shareView.nickLabel.text = userInfo.username
            shareView.inviteCodeLabel.text = "邀请码：\(userInfo.invitationCode ?? "")"
        }
        
    }
    

    @IBAction func share(_ sender: UIButton) {
        let imageData = shareImage.jpegData(compressionQuality: 0.7)!
        let imageObject = WXImageObject()
        imageObject.imageData = imageData

        let message = WXMediaMessage()
//        NSString *filePath = [[NSBundle mainBundle] pathForResource:@"res5"
//                                                             ofType:@"jpg"];
//        message.thumbData = [NSData dataWithContentsOfFile:filePath];
        message.mediaObject = imageObject;

        let req = SendMessageToWXReq()
        req.bText = false
        req.message = message
        req.scene = Int32(WXSceneSession.rawValue)
        WXApi.send(req)
    }
    
    @IBAction func saveImage(_ sender: UIButton) {
        //            UIImageWriteToSavedPhotosAlbum(img, self, #selector(image(_:didFinishSavingWithError:contextInfo:)), nil)
        PHPhotoLibrary.requestAuthorization { (status) in
            switch (status)
            {
            case .authorized:
                // Permission Granted
                PHPhotoLibrary.shared().performChanges({
                    PHAssetChangeRequest.creationRequestForAsset(from: self.shareImage)
                }) { (isSuc, err) in
                    if isSuc {
                        SVProgressHUD.showSuccess(withStatus: localizedString("成功"))
                    }else{
                        SVProgressHUD.showError(withStatus: localizedString("失败"))
                    }
                }
            case .denied:
                // Permission Denied
                print("User denied")
            default:
                print("Restricted")
            }
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
