//
//  MineViewController.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/16.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class MineViewController: BaseViewController {
    lazy var tableView: UITableView = {
        let tableView = UITableView(frame: CGRect.zero, style: .grouped)
        tableView.dataSource = self
        tableView.delegate = self
        return tableView
    }()
    var headerView: MineHeaderView!
    var titleAndPicList = [("我的竞拍", "icon_my_wdjp"),
                           ("账户与安全", "mine_账户与安全"),
                           ("地址管理", "mine_地址管理"),
                           ("邀请好友", "mine_邀请好友"),
                           ("拍卖须知", "mine_拍卖须知"),
                           ("专属客服", "icon_my_zskf"),
                            ("退出登录", "mine_拍卖须知")]
    var myBalanceInfoModel: MyBalanceInfoModel?
    var orderStatisticsModel: OrderStatisticsModel?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "我的"
        setupUI()
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        requestData()
    }
    func requestData() {
        provider.rx.request(APITarget.balanceAndIntegralAndFans)
            .mapObject(BaseResponse<MyBalanceInfoModel>.self)
            .subscribe(onSuccess: { (res) in
                self.myBalanceInfoModel = res.data
                guard let model = self.myBalanceInfoModel else {
                    return
                }
                let avatar = UserInfoManager.shared.userInfo?.avatar ?? ""
                self.headerView.avatarImgView.kf.setImage(with: URL(string: avatar), placeholder: UIImage(named: "头像"))
                self.headerView.nickNameLabel.text = kUserInfo?.username
                self.headerView.inviteCodeLabel.text = "邀请码：\(model.invitationCode ?? "")"
                self.headerView.jifenLabel.text = model.integralAmount.mapToPrice()
                self.headerView.balanceLabel.text = model.amount.mapToPrice()
                self.headerView.friendLabel.text = model.fanNums.toString
            }, onError: { (error) in
                
            })
        .disposed(by: disposeBag)
        provider.rx.request(APITarget.noPara(url: API_orderStatistics))
            .mapObject(BaseResponse<OrderStatisticsModel>.self)
            .subscribe(onSuccess: { (res) in
                if let model = res.data {
                    self.orderStatisticsModel = model
                }
                self.tableView.reloadData()
            }, onError: { (error) in
                
            })
        .disposed(by: disposeBag)

    }
    
    
    func setupUI() {
        self.view.addSubview(tableView)
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        tableView.tableFooterView = UIView()
        tableView.separatorStyle = .none
        tableView.backgroundColor = UIColor(hexString: "#F0F0F0")
        
        headerView = Bundle.main.loadNibNamed("MineHeaderView", owner: self, options: nil)?.first as? MineHeaderView
        headerView.jifenButton.addTarget(self, action: #selector(clickJifenDetail), for: UIControl.Event.touchUpInside)
        headerView.balanceButton.addTarget(self, action: #selector(clickBalanceDetail), for: UIControl.Event.touchUpInside)
        headerView.friendButton.addTarget(self, action: #selector(clickFriendDetail), for: UIControl.Event.touchUpInside)
        let tap = UITapGestureRecognizer(target: self, action: #selector(clickUserInfo))
        headerView.userInfoBgView.addGestureRecognizer(tap)
        let homeHeaderView = UIView(frame: CGRect(x: 0, y: 0, w: SWIDTH, h: 166+20))
            
        homeHeaderView.addSubview(headerView)
        headerView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        tableView.tableHeaderView = homeHeaderView
        
        tableView.register(UINib(nibName: "MineOrderCell", bundle: nil), forCellReuseIdentifier: String(describing: MineOrderCell.self))
        tableView.register(UINib(nibName: "MineCell", bundle: nil), forCellReuseIdentifier: String(describing: MineCell.self))
    }
    
    @objc func clickUserInfo() {
        let vc = UserInfoDetailController()
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @objc func clickJifenDetail() {
        let vc = MyScoresViewController()
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @objc func clickBalanceDetail() {
        let vc = BalanceViewController()
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @objc func clickFriendDetail() {
        let vc = MyFriendsController()
        vc.friendCount = self.myBalanceInfoModel?.fanNums ?? 0
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @objc func clickAllOrder() {
        let vc = OrderContainerController()
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @objc func clickOrderTypeDetail(_ sender: UIButton) {
        let index = sender.tag
        let vc = OrderContainerController()
        if index == 0 {
            vc.setValue(NSNumber(value: 1), forKey: "currentIndex")
        }else if index == 1 {
            vc.setValue(NSNumber(value: 2), forKey: "currentIndex")
        }else if index == 2 {
            vc.setValue(NSNumber(value: 3), forKey: "currentIndex")
        }else if index == 3 {
            vc.setValue(NSNumber(value: 4), forKey: "currentIndex")
        }
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension MineViewController: UITableViewDataSource, UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return 1
        }else{
            return titleAndPicList.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: MineOrderCell.self), for: indexPath) as! MineOrderCell
            cell.selectionStyle = .none
            if let model = orderStatisticsModel {
                let waitPay = model.waitPay > 0 ? model.waitPay.toString : ""
                let waitReceivingGoods = model.waitReceivingGoods > 0 ? model.waitReceivingGoods.toString : ""
                let waitDeliverGoods = model.waitDeliverGoods > 0 ? model.waitDeliverGoods.toString : ""
                cell.numLabel1.text = waitPay
                cell.numLabel2.text = waitDeliverGoods
                cell.numLabel3.text = waitReceivingGoods
            }else{
                cell.numLabel1.text = ""
                cell.numLabel2.text = ""
                cell.numLabel3.text = ""
            }
            cell.allOrderButton.addTarget(self, action: #selector(clickAllOrder), for: UIControl.Event.touchUpInside)
            cell.orderTypeButton1.addTarget(self, action: #selector(clickOrderTypeDetail(_:)), for: UIControl.Event.touchUpInside)
            cell.orderTypeButton2.addTarget(self, action: #selector(clickOrderTypeDetail(_:)), for: UIControl.Event.touchUpInside)
            cell.orderTypeButton3.addTarget(self, action: #selector(clickOrderTypeDetail(_:)), for: UIControl.Event.touchUpInside)
            cell.orderTypeButton4.addTarget(self, action: #selector(clickOrderTypeDetail(_:)), for: UIControl.Event.touchUpInside)
            return cell
        }else{
            let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: MineCell.self), for: indexPath) as! MineCell
            cell.selectionStyle = .none
            let count = tableView.numberOfRows(inSection: indexPath.section)
            if indexPath.row == 0 {
                //部分圆角
                let path = UIBezierPath(roundedRect: CGRect(x: 0, y: 0, width: SWIDTH-15*2, height: 44), byRoundingCorners: [.topLeft, .topRight], cornerRadii: CGSize(width: 5, height: 5))
                let shapeLayer = CAShapeLayer()
                shapeLayer.path = path.cgPath
                cell.bgView.layer.mask = shapeLayer
                cell.lineView.isHidden = false
            }else if indexPath.row == count-1 {
                //部分圆角
                let path = UIBezierPath(roundedRect: CGRect(x: 0, y: 0, width: SWIDTH-15*2, height: 44), byRoundingCorners: [.bottomLeft, .bottomRight], cornerRadii: CGSize(width: 5, height: 5))
                let shapeLayer = CAShapeLayer()
                shapeLayer.path = path.cgPath
                cell.bgView.layer.mask = shapeLayer
                cell.lineView.isHidden = true
            }else{
                cell.bgView.layer.mask = nil
                cell.lineView.isHidden = false
            }
            let item = titleAndPicList[indexPath.row]
            cell.titleLabel.text = item.0
            cell.imgView.image = UIImage(named: item.1)
            return cell
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0 {
            return 139
        }else{
            return 44
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0.1
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 10
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return UIView()
    }
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.section == 1 {
            if indexPath.row == 0 {
                let vc = MyAuctionViewController()
                self.navigationController?.pushViewController(vc, animated: true)
            }else if indexPath.row == 1 {
                let vc = AccountSafeController()
                self.navigationController?.pushViewController(vc, animated: true)
            }else if indexPath.row == 2 {
                let vc = ShippingAddressController()
                self.navigationController?.pushViewController(vc, animated: true)
            }else if indexPath.row == 3 {
                let vc = InviteFriendController()
                self.navigationController?.pushViewController(vc, animated: true)
            }else if indexPath.row == 4 {
                let vc = WLWebViewController(url: URL(string: kHtml_distRule2)!)
                vc.title = "用户须知"
                self.navigationController?.pushViewController(vc, animated: true)
            }else if indexPath.row == 5 {
//                let url = URL(string: "tel://\(kefu_hotline)")!
//                UIApplication.shared.open(url, options: [:], completionHandler: nil)
                let vc = WLWebViewController(url: URL(string: kHtml_kefu)!)
                vc.title = "专属客服"
                self.navigationController?.pushViewController(vc, animated: true)
            }else if indexPath.row == 6 {
                let alertVC = UIAlertController(title: "退出登录", message: "是否退出登录?", preferredStyle: UIAlertController.Style.alert)
                let cancelAction = UIAlertAction(title: "取消", style: UIAlertAction.Style.cancel) { (action) in
                }
                let okAction = UIAlertAction(title: "确定", style: UIAlertAction.Style.default) { (action) in
                    UserInfoManager.shared.userInfo = nil
                    UserInfoManager.shared.token = nil
                    self.tabBarController?.selectedIndex = 0
                }
                alertVC.addAction(cancelAction)
                alertVC.addAction(okAction)
                self.present(alertVC, animated: true, completion: nil)
            }
        }
    }
    
}
