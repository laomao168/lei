//
//  RechargeDetailController.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/25.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class RechargeDetailController: BaseTableViewController {
    var dataList: [RechargeListModel] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "充值明细"
        setupUI()
        requestData()
        // Do any additional setup after loading the view.
    }
    func setupUI() {
        let headerView = UIView(frame: CGRect(x: 0, y: 0, w: SWIDTH, h: 10))
        
        tableView.tableHeaderView = headerView
        tableView.separatorStyle = .none
        tableView.backgroundColor = UIColor.tableViewBg
        tableView.register(UINib(nibName: "MyScoresCell", bundle: nil), forCellReuseIdentifier: String(describing: MyScoresCell.self))

    }
    override func requestData() {
        provider.rx.request(APITarget.rechargeList(pageNumber: self.pageNumber, pageSize: self.pageSize))
            .mapObject(BaseResponse<PageResponse<[RechargeListModel]>>.self)
            .subscribe(onSuccess: { (res) in
                self.endRefresh(res.data?.page?.totalPage)
                if self.pageNumber == 1 {
                    self.dataList.removeAll()
                }
                if let list = res.data?.data {
                    self.dataList += list
                }
                self.tableView.reloadData()
            }, onError: { (error) in
                self.endRefresh()
            })
        .disposed(by: disposeBag)
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension RechargeDetailController {
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if dataList.isEmpty {
            return 1
        }
        return dataList.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if dataList.isEmpty {
            let cell = EmptyDataCell()
            return cell
        }
        let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: MyScoresCell.self), for: indexPath) as! MyScoresCell
        cell.selectionStyle = .none
        let count = tableView.numberOfRows(inSection: indexPath.section)
        var corners: UIRectCorner?
        if count == 1 {
            corners = .allCorners
        }else{
            if indexPath.row == 0 {
                corners = [.topLeft, .topRight]
            }else if indexPath.row == count-1 {
                corners = [.bottomLeft, .bottomRight]
            }else{
                corners = nil
            }
        }
        if let corner = corners {
            //部分圆角
            let path = UIBezierPath(roundedRect: CGRect(x: 0, y: 0, width: SWIDTH-15*2, height: 70), byRoundingCorners: corner, cornerRadii: CGSize(width: 5, height: 5))
            let shapeLayer = CAShapeLayer()
            shapeLayer.path = path.cgPath
            cell.bgView.layer.mask = shapeLayer
        }else{
            cell.bgView.layer.mask = nil
        }
        
        if indexPath.section == count-1 {
            cell.lineView.isHidden = true
        }else{
            cell.lineView.isHidden = false
        }
        let model = dataList[indexPath.row]
        cell.titleLabel.text = "充值"
        cell.imgView.image = UIImage(named: "icon_cashdetail_cz")
        cell.timeLabel.text = model.createTime
        cell.amoutLabel.text = "+"+model.money.mapToPrice()
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if dataList.isEmpty {
            return EmptyDataCell.emptyHeight
        }
        return 70
    }
}
