//
//  AddAddressController.swift
//  CBIT
//
//  Created by 刘文利 on 2019/11/7.
//  Copyright © 2019 网泰信息. All rights reserved.
//

import UIKit
import Presentr
class AddAddressController: BaseViewController {
    var model: AddressModel?
    
    var completedBlock: (() -> Void)?
    
    let address = KLCityPickerView()
    let streetPicker = StreetPickerView()
    
    var selectProvince: AreaModel?
    var selectCity: AreaModel?
    var selectArea: AreaModel?
    var selectStreet: AreaModel?
    
    
    @IBOutlet weak var detailAddressTextField: UITextField!
    
    @IBOutlet weak var nameTextField: UITextField!
    
    @IBOutlet weak var mobileTextField: UITextField!
    
    @IBOutlet weak var streetLabel: UILabel!
    @IBOutlet weak var addressLabel: UILabel!
    
    @IBOutlet weak var isDefaultSwitch: UISwitch!
    
    @IBOutlet weak var submitButton: SubmitButton!
    var isChange: Bool {
        return model != nil
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let model = model {
            self.title = "编辑收货地址"
            self.selectProvince = AreaModel(areaname: model.provinceText, id: model.province!.toInt())
            self.selectCity = AreaModel(areaname: model.cityText, id: model.city!.toInt())
            self.selectArea = AreaModel(areaname: model.districtText, id: model.district!.toInt())
            self.selectStreet = AreaModel(areaname: model.streetText, id: model.street!.toInt())
            self.nameTextField.text = model.consignee
            self.addressLabel.textColor = UIColor.gray3
            self.streetLabel.textColor = UIColor.gray3
            self.addressLabel.text = model.provinceText+model.cityText+model.district
            self.streetLabel.text = model.streetText
            self.detailAddressTextField.text = model.address
            self.mobileTextField.text = model.mobile
            self.isDefaultSwitch.isOn = model.tolerant == 0
            self.submitButton.setTitle("修改", for: UIControl.State.normal)
        }else{
           self.title = "新增收货地址"
            self.addressLabel.textColor = UIColor.gray9
            self.streetLabel.textColor = UIColor.gray9
            self.addressLabel.text = "请选择省市区"
            self.streetLabel.text = "请选择街道"
            self.submitButton.setTitle("保存", for: UIControl.State.normal)
        }
        setupUI()
        // Do any additional setup after loading the view.
    }
    
    func setupUI() {
        if isChange {
//            let rightItem = UIBarButtonItem(title: "删除", style: UIBarButtonItem.Style.plain, target: self, action: #selector(deleteAddress))
//            rightItem.setTitleTextAttributes([NSAttributedString.Key.font : UIFont.systemFont(ofSize: 18), NSAttributedString.Key.foregroundColor: UIColor.gray3], for: UIControl.State.normal)
//            self.navigationItem.rightBarButtonItem = rightItem
        }
    }
   
    
    @objc func deleteAddress() {
        guard let id = model?.addressId else {
            return
        }
//        providerV3.rx.request(APIV3Target.delAddress(addressId: id))
//            .mapObject(BaseResponse<EmptyResponse>.self)
//            .subscribe(onSuccess: { (res) in
//                SVProgressHUD.showSuccess(withStatus: "删除成功")
//                self.completedBlock?()
//                self.navigationController?.popViewController(animated: true)
//            }, onError: { (error) in
//
//            })
//        .disposed(by: disposeBag)
    }

    @IBAction func clickStreetAction(_ sender: UIButton) {
        guard let area = selectArea else {
            SVProgressHUD.showInfo(withStatus: "请先选择省市区")
            return
        }
        let parentId = area.id!
        streetPicker.addressPickerViewWith(street: nil, parentId: parentId) { [weak self](street) in
            self?.streetLabel.textColor = UIColor.gray3
            self?.streetLabel.text = street.areaname
            
            self?.selectStreet = street
        }
        // 设置确定按钮的文字颜色
        streetPicker.sureButtonCoclor = UIColor.mainColor
    }
    

    @IBAction func selectAddressAction(_ sender: UIButton) {
        address.areaPickerViewWithProvince(province: nil, city: nil, area: nil) { [weak self](pro, city, area) in
            self?.selectProvince = pro
            self?.selectCity = city
            self?.selectArea = area
            self?.selectStreet = nil
            self?.addressLabel.textColor = UIColor.gray3
            self?.streetLabel.textColor = UIColor.gray9
            self?.streetLabel.text = "请选择街道"
            self?.addressLabel.text = "\(pro.areaname!)\(city.areaname!)\(area.areaname!)"
        }
        // 设置确定按钮的文字颜色
        address.sureButtonCoclor = UIColor.mainColor
                /// 设置pickerView字体颜色和大小
        //        address.pickerLabelFont = UIFont.systemFont(ofSize: 20)
        //        address.pickerLabelTextCoclor = UIColor.green
                
                // 设置取消按钮的文字颜色
        //        address.cancleButtonCoclor = UIColor.blue
                
                // 设置确定和取消按钮的文字大小
        //        address.titleToolBarFont = UIFont.systemFont(ofSize: 20)
        //
        //        // 设置toolBar的背景颜色
        //        address.titleToolBarBackgroundColor = UIColor.brown
        //
        //        // 设置pickerView的背景颜色
        //        address.pickerViewBackgroundColor = UIColor.yellow
    }
    
    @IBAction func save(_ sender: Any) {
        let name = nameTextField.text!
        if name.isEmpty {
            SVProgressHUD.showInfo(withStatus: nameTextField.placeholder)
            return
        }
        let mobileNo = mobileTextField.text!
        guard Validator.isMobileNumber(mobileNo) else {
            SVProgressHUD.showInfo(withStatus: "手机号格式不正确")
            return
        }
        guard let provinceId = self.selectProvince?.id, let cityId = self.selectCity?.id, let areaId = self.selectArea?.id else {
            SVProgressHUD.showInfo(withStatus: "请选择省、市、区")
            return
        }
        guard let streetId = self.selectStreet?.id else {
            SVProgressHUD.showInfo(withStatus: "请选择街道")
            return
        }
        let address = detailAddressTextField.text!
        if address.isEmpty {
            SVProgressHUD.showInfo(withStatus: detailAddressTextField.placeholder)
            return
        }
        let isDefault = isDefaultSwitch.isOn ? 0 : 1
        
        if isChange {
            guard let id = model?.addressId else {
                return
            }
            provider.rx.request(APITarget.addressEdit(addressId: id, consignee: name, mobile: mobileNo, province: provinceId, city: cityId, district: areaId, street: streetId, address: address, tolerant: isDefault))
                .mapObject(BaseResponse<EmptyResponse>.self)
                .subscribe(onSuccess: { (res) in
                    SVProgressHUD.showSuccess(withStatus: "成功")
                    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+2) {
                        self.completedBlock?()
                        self.navigationController?.popViewController(animated: true)
                    }
                }, onError: { (error) in
                    
                })
            .disposed(by: disposeBag)
        }else{
            provider.rx.request(APITarget.addAddress(consignee: name, mobile: mobileNo, province: provinceId, city: cityId, district: areaId, street: streetId, address: address, tolerant: isDefault))
                .mapObject(BaseResponse<EmptyResponse>.self)
                .subscribe(onSuccess: { (res) in
                    SVProgressHUD.showSuccess(withStatus: "成功")
                    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+2) {
                        self.completedBlock?()
                        self.navigationController?.popViewController(animated: true)
                    }
                }, onError: { (error) in
                    
                })
            .disposed(by: disposeBag)
        }
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
