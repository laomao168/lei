//
//  RechargeViewController.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/17.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class RechargeViewController: BaseViewController {
    var completed: (() -> Void)?
    private var accountDetailModel: AccountDetailModel!
    
    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet weak var amountTextField: UITextField!
    
    @IBOutlet weak var submitButton: UIButton!
    
    @IBOutlet weak var balanceLabel: UILabel!
    @IBOutlet weak var balanceDesLabel: UILabel!
    
    var minValue: String = "100"
    
    lazy var bankCardTypeView: PaymentTypeView = {
        let view = Bundle.main.loadNibNamed("PaymentTypeView", owner: self, options: nil)?.first as! PaymentTypeView
        view.tag = 1
        view.imgView.image = UIImage(named: "icon_pay_yue")
        view.typeLabel.text = "银行卡"
        return view
    }()
    lazy var weChatTypeView: PaymentTypeView = {
        let view = Bundle.main.loadNibNamed("PaymentTypeView", owner: self, options: nil)?.first as! PaymentTypeView
        view.imgView.image = UIImage(named: "icon_pay_weixin")
        view.typeLabel.text = "微信"
        view.tag = 2
        return view
    }()
    lazy var alipayTypeView: PaymentTypeView = {
        let view = Bundle.main.loadNibNamed("PaymentTypeView", owner: self, options: nil)?.first as! PaymentTypeView
        view.tag = 3
        view.imgView.image = UIImage(named: "icon_pay_zfb")
        view.typeLabel.text = "支付宝"
        return view
    }()
    var isSuppotWechat: Bool = true
    var isSuppotAlipay: Bool = true
    var isSuppotBankCard: Bool = false
    var payTypeSelectIndex: Int = 0
    
    @IBOutlet weak var otherTypeBgView: UIView!
    @IBOutlet weak var bankMsgBgView: UIView!
    
    @IBOutlet weak var bankNameMsgLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "账户充值"
        setupUI()
        requestData()
        NotificationCenter.default.addObserver(self, selector: #selector(wechatPayResult(_:)), name: NSNotification.Name.wechatPayResult, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(alipaymentResult(_:)), name: NSNotification.Name.alipayResult, object: nil)
        // Do any additional setup after loading the view.
    }
    
    @objc func wechatPayResult(_ noti: Notification) {
        guard let errCode = noti.userInfo?["errCode"] as? Int else {
            return
        }
        if errCode == 0 {//0:成功,-1:错误
            SVProgressHUD.showSuccess(withStatus: "支付成功")
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+2) {
                self.completed?()
                self.navigationController?.popViewController(animated: true)
            }
        }else if errCode == -1 {
            SVProgressHUD.showInfo(withStatus: "支付错误")
        }else if errCode == -2 {
            SVProgressHUD.showInfo(withStatus: "支付取消")
        }
    }
    @objc func alipaymentResult(_ noti: Notification) {
        guard let resultStatus = noti.userInfo?["resultStatus"] as? String else {
            return
        }
        alipayResult(resultStatus)
    }
    func setupUI() {
        let image = UIImage(gradientColors: [RGBA(250, 137, 43, 1), RGBA(250, 86, 35, 1)])
        submitButton.setBackgroundImage(image, for: UIControl.State.normal)
        amountTextField.delegate = self
        
        //1微信，2原生支付宝，3 第三方支付宝，4微信，原生支付宝5微信，第三方支付宝
        let rechargeType = SysConfig.shared.rechargeType
        bankMsgBgView.isHidden = true
        otherTypeBgView.isHidden = true
        if rechargeType == "1" {
            isSuppotBankCard = false
            isSuppotWechat = true
            isSuppotAlipay = false
            clickPayTypeView(weChatTypeView)
        }else if rechargeType == "2" {
            isSuppotBankCard = false
            isSuppotWechat = false
            isSuppotAlipay = true
            clickPayTypeView(alipayTypeView)
        }else if rechargeType == "3" {
            isSuppotBankCard = true
            isSuppotWechat = false
            isSuppotAlipay = false
            clickPayTypeView(bankCardTypeView)
        }else if rechargeType == "4" {
            isSuppotBankCard = false
            isSuppotWechat = true
            isSuppotAlipay = true
            clickPayTypeView(weChatTypeView)
        }else if rechargeType == "5" {
            isSuppotBankCard = true
            isSuppotWechat = true
            isSuppotAlipay = false
            clickPayTypeView(bankCardTypeView)
        }else{
            let list = rechargeType.components(separatedBy: "|")
            if list.count >= 1 && list.first == "9" {
                isSuppotBankCard = true
                isSuppotWechat = false
                isSuppotAlipay = false
                clickPayTypeView(bankCardTypeView)
                let text = list[1..<list.count].joined(separator: "\n")
                bankNameMsgLabel.text = text
            
            }else{
                isSuppotBankCard = false
                isSuppotWechat = false
                isSuppotAlipay = false
            }
        }
        if isSuppotBankCard {
            self.stackView.addArrangedSubview(bankCardTypeView)
            bankCardTypeView.clickButton.addTarget(self, action: #selector(clickPayTypeAction(_:)), for: .touchUpInside)
        }
        if isSuppotWechat {
            self.stackView.addArrangedSubview(weChatTypeView)
            weChatTypeView.clickButton.addTarget(self, action: #selector(clickPayTypeAction(_:)), for: .touchUpInside)
        }
        if isSuppotAlipay {
            self.stackView.addArrangedSubview(alipayTypeView)
            alipayTypeView.clickButton.addTarget(self, action: #selector(clickPayTypeAction(_:)), for: .touchUpInside)
        }
    }
    
    @objc func clickPayTypeAction(_ sender: UIButton) {
        guard let typeView = sender.superview as? PaymentTypeView else {
            return
        }
        if payTypeSelectIndex == typeView.tag {
            return
        }
        clickPayTypeView(typeView)
    }
    func clickPayTypeView(_ typeView: PaymentTypeView) {
        payTypeSelectIndex = typeView.tag
        bankCardTypeView.isSelectButton.isSelected = false
        weChatTypeView.isSelectButton.isSelected = false
        alipayTypeView.isSelectButton.isSelected = false
        
        typeView.isSelectButton.isSelected = true
        if typeView == bankCardTypeView {
            bankMsgBgView.isHidden = false
            balanceDesLabel.text = "从银行卡充值到余额"
        }else if typeView == weChatTypeView {
            bankMsgBgView.isHidden = true
            balanceDesLabel.text = "从微信充值到余额"
        }else if typeView == alipayTypeView {
            bankMsgBgView.isHidden = true
            balanceDesLabel.text = "从支付宝充值到余额"
        }
    }
    
    @IBAction func submit(_ sender: UIButton) {
        let amount = amountTextField.text!
        let amountDouble = amount.toDouble() ?? 0
        let valueDouble = minValue.toDouble() ?? 0
        if amount.isEmpty {
            SVProgressHUD.showInfo(withStatus: "请输入金额")
            return
        }
        if amountDouble < valueDouble {
            SVProgressHUD.showInfo(withStatus: amountTextField.placeholder)
            return
        }
        
        if payTypeSelectIndex == 0 {
            SVProgressHUD.showInfo(withStatus: "请选择支付方式")
        }else if payTypeSelectIndex == 1 {
            SVProgressHUD.showInfo(withStatus: "暂未对接")
        }else if payTypeSelectIndex == 2 {
           //orderType: 3充值，1拍卖，2商场，type：1订单 2商品 payType:1余额 2微信 3支付宝 4积分
            provider.rx.request(APITarget.commonOrder(orderType: 3, type: 2, payType: 2, amount: amount, goodsId: nil, addressId: nil, payPassWord: nil, orderId: nil))
                .mapObject(BaseResponse<RechargeWechatModel>.self)
                .subscribe(onSuccess: { (res) in
                    if let model = res.data {
                        self.paymentWechat(orderModel: model)
                    }
                }, onError: { (error) in

                })
            .disposed(by: disposeBag)
        }else if payTypeSelectIndex == 3 {
            provider.rx.request(APITarget.commonOrder(orderType: 3, type: 2, payType: 3, amount: amount, goodsId: nil, addressId: nil, payPassWord: nil, orderId: nil))
                .mapObject(BaseResponse<RechargeAlipayModel>.self)
                .subscribe(onSuccess: { (res) in
                    if let order = res.data?.order {
                        self.paymentAlipay(orderInfo: order)
                    }
                }, onError: { (error) in
                })
            .disposed(by: disposeBag)
        }
        
    }
    
    @IBAction func clickDetail(_ sender: UIButton) {
        let vc = RechargeDetailController()
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func requestData() {
        provider.rx.request(APITarget.accountDetail)
            .mapObject(BaseResponse<AccountDetailModel>.self)
            .subscribe(onSuccess: { (res) in
                if let model = res.data {
                    self.accountDetailModel = model
                    self.balanceLabel.text = model.amount.mapToPrice()
                }
            }, onError: { (error) in
                
            })
        .disposed(by: disposeBag)
        
        provider.rx.request(APITarget.configKey(sysConfigKey: "min_recharge_money"))
            .mapObject(BaseResponse<String>.self)
            .subscribe(onSuccess: { (res) in
                if let value = res.data {
                    self.minValue = value
                    self.amountTextField.placeholder = "最低充值\(value)元"
                }
            }, onError: { (error) in
                
            })
        .disposed(by: disposeBag)
    }
    //微信支付
    func paymentWechat(orderModel: RechargeWechatModel) {
        if WXApi.isWXAppInstalled() && WXApi.isWXAppSupport() {//检查微信是否已被用户安装
            let req = PayReq()
            req.partnerId = orderModel.partnerId ?? ""
            req.prepayId = orderModel.prepayId ?? ""
            req.package = orderModel.package ?? "Sign=WXPay"
            req.nonceStr = orderModel.nonceStr ?? ""
            req.timeStamp = UInt32(orderModel.timeStamp?.toInt() ?? 0)
            req.sign = orderModel.sign ?? ""
            WXApi.send(req)
        }else{
            SVProgressHUD.showInfo(withStatus: "请更新当前微信版本!")
        }
    }
    func paymentAlipay(orderInfo: String) {
        //应用注册scheme,在AliSDKDemo-Info.plist定义URL types
        let appScheme = kAppScheme
        // NOTE: 将签名成功字符串格式化为订单字符串,请严格按照该格式
        AlipaySDK.defaultService()?.payOrder(orderInfo, fromScheme: appScheme, callback: { (resultDic) in
            print("resultDic = \(resultDic)")
            let resultStatus = (resultDic?["resultStatus"] as? String) ?? ""
            self.alipayResult(resultStatus)
        })
    }
    func alipayResult(_ resultStatus: String) {
        /*
         /*
         9000    订单支付成功
         8000    正在处理中，支付结果未知（有可能已经支付成功），请查询商户订单列表中订单的支付状态
         4000    订单支付失败
         5000    重复请求
         6001    用户中途取消
         6002    网络连接出错
         6004    支付结果未知（有可能已经支付成功），请查询商户订单列表中订单的支付状态
         其它    其它支付错误
         */
         */
        if resultStatus == "9000" {
            SVProgressHUD.showSuccess(withStatus: "支付成功")
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+2) {
                self.completed?()
                self.navigationController?.popViewController(animated: true)
            }
        }else if resultStatus == "8000" {
            SVProgressHUD.showInfo(withStatus: "正在处理中")
        }else if resultStatus == "4000" {
            SVProgressHUD.showInfo(withStatus: "订单支付失败")
        }else if resultStatus == "5000" {
            SVProgressHUD.showInfo(withStatus: "重复请求")
        }else if resultStatus == "6001" {
            SVProgressHUD.showInfo(withStatus: "用户中途取消")
        }else if resultStatus == "6002" {
            SVProgressHUD.showInfo(withStatus: "网络连接出错")
        }else if resultStatus == "6004" {
            SVProgressHUD.showInfo(withStatus: "正在处理中")
        }else{
            SVProgressHUD.showInfo(withStatus: "其它支付错误")
        }
    }
    
    @IBAction func copyText(_ sender: UIButton) {
        if let bankMsg = self.bankNameMsgLabel.text {
            UIPasteboard.general.string = bankMsg
            SVProgressHUD.showSuccess(withStatus: "复制成功")
        }
    }
    
//    func LLPay() {
//        LLPaySdk.shared()?.sdkDelegate = self
//        
////        LLPaySdk.shared()?.presentLLPaySign(in: self, with: LLPayType.verify, andTraderInfo: <#T##[AnyHashable : Any]!#>)
//    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension RechargeViewController: UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        return Validator.validate(textField, shouldChangeCharactersIn: range, replacementString: string, index: 2)
    }
}
//extension RechargeViewController: LLPStdSDKDelegate {
//    func paymentEnd(_ resultCode: LLPStdSDKResult, withResultDic dic: [AnyHashable : Any]!) {
//        print(resultCode)
//    }
//
//}
