//
//  BalanceViewController.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/17.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class BalanceViewController: BaseTableViewController {
    override var isHeaderRefresh: Bool {
        return false
    }
    override var isFooterRefresh: Bool {
        return false
    }
    override var isEmptyDataSet: Bool {
        return false
    }
    var accountDetailModel: AccountDetailModel?
    var headerView: BalanceHeaderView!
    var isSetPayPwd: Bool = false
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "我的余额"
        setupUI()
        requestData()
        // Do any additional setup after loading the view.
    }
    func setupUI() {
        headerView = Bundle.main.loadNibNamed("BalanceHeaderView", owner: self, options: nil)?.first as? BalanceHeaderView
        let homeHeaderView = UIView(frame: CGRect(x: 0, y: 0, w: SWIDTH, h: 202+20))
            
        homeHeaderView.addSubview(headerView)
        headerView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        tableView.tableHeaderView = homeHeaderView
        tableView.rowHeight = 70
        tableView.separatorStyle = .none
        tableView.backgroundColor = UIColor.tableViewBg
        tableView.register(UINib(nibName: "BalanceTypeCell", bundle: nil), forCellReuseIdentifier: String(describing: BalanceTypeCell.self))

    }
    
    override func requestData() {
        provider.rx.request(APITarget.accountDetail)
            .mapObject(BaseResponse<AccountDetailModel>.self)
            .subscribe(onSuccess: { (res) in
                if let model = res.data {
                    self.accountDetailModel = model
                    self.headerView.balanceNumLabel.text = model.amount.mapToPrice()
                    self.headerView.freezeAmountLabel.text = "冻结金额："+model.lockAmount.mapToPrice()
                    self.headerView.todayIncomeLabel.text = "¥"+model.todayIncome.mapToPrice()
                    self.headerView.yestodayIncomeLabel.text = "¥"+model.yesterdayProfit.mapToPrice()
                    self.headerView.totalIncomeLabel.text = "¥"+model.totalIncome.mapToPrice()
                }
            }, onError: { (error) in
                
            })
        .disposed(by: disposeBag)
//        provider.rx.request(APITarget.todayincome)
//            .mapObject(BaseResponse<Double>.self)
//            .subscribe(onSuccess: { (res) in
//
//            }, onError: { (error) in
//
//            })
//        .disposed(by: disposeBag)
        provider.rx.request(APITarget.noPara(url: API_isSetPassword))
            .map(BaseResponse<EmptyResponse>.self)
            .subscribe(onSuccess: { (res) in
                let isSetPayPwd = res.success
                self.isSetPayPwd = isSetPayPwd
            }, onError: { (error) in
                
            })
        .disposed(by: disposeBag)
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension BalanceViewController {
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: BalanceTypeCell.self), for: indexPath) as! BalanceTypeCell
        cell.selectionStyle = .none
        let count = tableView.numberOfRows(inSection: indexPath.section)
        var corners: UIRectCorner?
        if count == 1 {
            corners = .allCorners
        }else{
            if indexPath.row == 0 {
                corners = [.topLeft, .topRight]
            }else if indexPath.row == count-1 {
                corners = [.bottomLeft, .bottomRight]
            }else{
                corners = nil
            }
        }
        if let corner = corners {
            //部分圆角
            let path = UIBezierPath(roundedRect: CGRect(x: 0, y: 0, width: SWIDTH-15*2, height: 70), byRoundingCorners: corner, cornerRadii: CGSize(width: 5, height: 5))
            let shapeLayer = CAShapeLayer()
            shapeLayer.path = path.cgPath
            cell.bgView.layer.mask = shapeLayer
        }else{
            cell.bgView.layer.mask = nil
        }
        
        if indexPath.section == count-1 {
            cell.lineView.isHidden = true
        }else{
            cell.lineView.isHidden = false
        }
        if indexPath.row == 0 {
            cell.imgView.image = UIImage(named: "icon_cash_cz")
            cell.titleLabel.text = "充值"
        }else{
            cell.imgView.image = UIImage(named: "icon_cash_yetx")
            cell.titleLabel.text = "余额提现"
        }
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0 {
            let vc = RechargeViewController()
            vc.completed = {[weak self] in
                self?.requestData()
            }
            self.navigationController?.pushViewController(vc, animated: true)
        }else{
            if !isSetPayPwd {
                SVProgressHUD.showInfo(withStatus: "请先设置支付密码")
                return
            }
            provider.rx.request(APITarget.noPara(url: API_checkRealPerson))
                .map(BaseResponse<EmptyResponse>.self)
                .subscribe(onSuccess: { (res) in
                    let isReal = res.success
                    if isReal {
                        let vc = WithdrawViewController()
                        vc.completed = {[weak self] in
                            self?.requestData()
                        }
                        vc.accountDetailModel = self.accountDetailModel
                        self.navigationController?.pushViewController(vc, animated: true)
                    }else{
                        let alertVC = UIAlertController(title: "提示", message: "为保证资金安全，请先实名认证", preferredStyle: UIAlertController.Style.alert)
                        let cancelAction = UIAlertAction(title: "取消", style: UIAlertAction.Style.cancel) { (action) in
                            
                        }
                        let okAction = UIAlertAction(title: "确定", style: UIAlertAction.Style.default) { (action) in
                            let vc = VerifiedViewController()
                            self.navigationController?.pushViewController(vc, animated: true)
                        }
                        alertVC.addAction(cancelAction)
                        alertVC.addAction(okAction)
                        self.present(alertVC, animated: true, completion: nil)
                    }
                }, onError: { (error) in
                })
            .disposed(by: disposeBag)

        }
    }
}
