//
//  VerifiedViewController.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/17.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class VerifiedViewController: BaseViewController {
    @IBOutlet weak var mobileTF: UITextField!
    
    @IBOutlet weak var alipayAccountTF: UITextField!
    @IBOutlet weak var idCardTF: UITextField!
    
    @IBOutlet weak var submitButton: UIButton!
    
    @IBOutlet weak var bankCardNoTF: UITextField!
    @IBOutlet weak var bankCardTF: UITextField!
    @IBOutlet weak var bankBranchTF: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "实名认证"
        setupUI()
        // Do any additional setup after loading the view.
    }
    func setupUI() {
        submitButton.setBackgroundImage(UIImage.commomGradient, for: UIControl.State.normal)
    }

    @IBAction func submit(_ sender: UIButton) {
        let userName = mobileTF.text!
        let alipay = alipayAccountTF.text!
        let idCard = idCardTF.text!
        let bankCardNo = bankCardNoTF.text!
        let bankCard = bankCardTF.text!
        let bankBranch = bankBranchTF.text!
        if userName.isEmpty {
            SVProgressHUD.showInfo(withStatus: mobileTF.placeholder)
            return
        }
        if alipay.isEmpty {
            SVProgressHUD.showInfo(withStatus: alipayAccountTF.placeholder)
            return
        }
        if bankCardNo.isEmpty {
            SVProgressHUD.showInfo(withStatus: bankCardNoTF.placeholder)
            return
        }
        if bankCard.isEmpty {
            SVProgressHUD.showInfo(withStatus: bankCardTF.placeholder)
            return
        }
        if idCard.isEmpty {
            SVProgressHUD.showInfo(withStatus: idCardTF.placeholder)
            return
        }
        if bankBranch.isEmpty {
            SVProgressHUD.showInfo(withStatus: bankBranchTF.placeholder)
            return
        }
        provider.rx.request(APITarget.realPerson(userName: userName, alipay: alipay, idCard: idCard, bankName: bankCard, bankCardNo: bankCardNo, bankBranch: bankBranch))
            .mapObject(BaseResponse<EmptyResponse>.self)
            .subscribe(onSuccess: { (res) in
                SVProgressHUD.showSuccess(withStatus: "成功")
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+2) {
                    self.navigationController?.popViewController(animated: true)
                }
            }, onError: { (error) in
                
            })
        .disposed(by: disposeBag)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
