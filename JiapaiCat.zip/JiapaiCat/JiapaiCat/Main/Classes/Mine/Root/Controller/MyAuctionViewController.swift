//
//  MyAuctionViewController.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/17.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class MyAuctionViewController: BaseTableViewController {
    override var tableViewStyle: UITableView.Style {
        return .grouped
    }
    var dataList: [MyAuctionModel] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "我的竞拍"
        setupUI()
        requestData()
        // Do any additional setup after loading the view.
    }
    
    func setupUI() {
        tableView.tableHeaderView = UIView(frame: CGRect(x: 0, y: 0, width: SWIDTH, height: 10))
        tableView.separatorStyle = .none
        tableView.backgroundColor = UIColor.tableViewBg
        tableView.register(UINib(nibName: "MyAuctionCell", bundle: nil), forCellReuseIdentifier: String(describing: MyAuctionCell.self))
    }
    
    override func requestData() {
        provider.rx.request(APITarget.myAuctionList(pageNumber: self.pageNumber, pageSize: self.pageSize))
            .mapObject(BaseResponse<PageResponse<[MyAuctionModel]>>.self)
            .subscribe(onSuccess: { (res) in
                self.endRefresh(res.data?.page?.totalPage)
                if self.pageNumber == 1 {
                    self.dataList.removeAll()
                }
                if let list = res.data?.data {
                    self.dataList += list
                }
                self.tableView.reloadData()
            }, onError: { (error) in
                self.endRefresh()
            })
        .disposed(by: disposeBag)

    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension MyAuctionViewController {
     override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if dataList.isEmpty {
            return 1
        }
        return dataList.count
     }
     
     override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if dataList.isEmpty {
            let cell = EmptyDataCell()
            return cell
        }
         let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: MyAuctionCell.self), for: indexPath) as! MyAuctionCell
         cell.selectionStyle = .none
        let model = self.dataList[indexPath.row]
        let grayAtt = [NSAttributedString.Key.font : UIFont.systemFont(ofSize: 11), NSAttributedString.Key.foregroundColor : UIColor.gray6]
        let mainAtt = [NSAttributedString.Key.font : UIFont.systemFont(ofSize: 11), NSAttributedString.Key.foregroundColor : UIColor.mainColor]
        
//        let numAttrText = NSMutableAttributedString(string: "我出价", attributes: grayAtt)
//        numAttrText.append(NSAttributedString(string: "1", attributes: mainAtt))
//        numAttrText.append(NSAttributedString(string: "次", attributes: grayAtt))
        cell.numLabel.attributedText = nil
        cell.timeLabel.text = model.createTime
        
         cell.nameLabel.text = model.goodsName
         cell.imgView.kf.setImage(with: URL(string: model.logo ?? ""))
        var priceDesText = "最新出价"
        if model.status == 3 {//正在拍卖
             priceDesText = "最新出价"
        }else if model.status > 3 {//已结束
            priceDesText = "成交价"
        }
        let priceAttrText = NSMutableAttributedString(string: priceDesText, attributes: grayAtt)
        priceAttrText.append(NSAttributedString(string: "¥"+"\(model.topPrice?.mapToPrice() ?? "0")", attributes: mainAtt))
        cell.priceLabel.attributedText = priceAttrText
         return cell
     }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if dataList.isEmpty {
            return EmptyDataCell.emptyHeight
        }
        return 141+10
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if dataList.isEmpty {
            return
        }
        let model = self.dataList[indexPath.row]
        let vc = AuctionDetailViewController()
        vc.auctionId = model.auctionId
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

