//
//  UserInfoDetailController.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/17.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class UserInfoDetailController: BaseViewController {
    @IBOutlet weak var avatarImgView: UIImageView!
    @IBOutlet weak var nickLabel: UILabel!
    
    @IBOutlet weak var inviteCodeTF: UITextField!
    @IBOutlet weak var mobileLabel: UILabel!
    
    @IBOutlet weak var saveButton: SubmitButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "个人资料"
        setupUI()
        requestData()
        // Do any additional setup after loading the view.
    }

    func setupUI() {
        guard let userInfo = kUserInfo else {
            return
        }
        self.avatarImgView.kf.setImage(with: URL(string: userInfo.avatar ?? ""), placeholder: UIImage(named: "头像"))
        self.nickLabel.text = userInfo.username
        self.mobileLabel.text = userInfo.phone
        
    }
    func requestData() {
        provider.rx.request(APITarget.superiorInfo)
            .mapObject(BaseResponse<SuperiorInfoModel>.self)
            .subscribe(onSuccess: { (res) in
                if let model = res.data {
                    self.inviteCodeTF.isEnabled = false
                    self.saveButton.isHidden = true
                    self.inviteCodeTF.text = model.invitationCode
                }else{
                    self.inviteCodeTF.isEnabled = true
                    self.saveButton.isHidden = false
                }
            }, onError: { (error) in
                self.inviteCodeTF.isEnabled = true
                self.saveButton.isHidden = false
            })
        .disposed(by: disposeBag)
    }

    @IBAction func save(_ sender: SubmitButton) {
        let code = inviteCodeTF.text!
        if code.isEmpty {
            return
        }
        provider.rx.request(APITarget.inviteCode(code: code))
            .mapObject(BaseResponse<EmptyResponse>.self)
            .subscribe(onSuccess: { (res) in
                SVProgressHUD.showInfo(withStatus: "成功")
                self.inviteCodeTF.isEnabled = false
                self.saveButton.isHidden = true
            }, onError: { (error) in
                
            })
        .disposed(by: disposeBag)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
