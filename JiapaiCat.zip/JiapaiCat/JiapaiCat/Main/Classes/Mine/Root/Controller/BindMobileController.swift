//
//  BindMobileController.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/17.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class BindMobileController: BaseViewController {
    @IBOutlet weak var mobileTF: UITextField!
    
    @IBOutlet weak var codeTF: UITextField!
    
    @IBOutlet weak var submitButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "绑定手机号"
        setupUI()
        // Do any additional setup after loading the view.
    }
    func setupUI() {
        submitButton.setBackgroundImage(UIImage.commomGradient, for: UIControl.State.normal)
    }

    @IBAction func sendMsgCode(_ sender: CountDownButton) {
        sender.isCounting = true
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
