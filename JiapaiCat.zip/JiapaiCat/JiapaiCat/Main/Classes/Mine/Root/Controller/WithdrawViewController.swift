//
//  WithdrawViewController.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/17.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class WithdrawViewController: BaseViewController {
    var completed: (() -> Void)?
    var accountDetailModel: AccountDetailModel!
    var balance: Double {
        return accountDetailModel.amount ?? 0
    }
    @IBOutlet weak var amountTextField: UITextField!
    
    @IBOutlet weak var submitButton: UIButton!
    
    @IBOutlet weak var balanceButton: UIButton!
    
    @IBOutlet weak var remarkLabel: UILabel!
    var min_withdraw_money: String = "0"
    var max_withdraw_money: String = "0"
    var withdraw_service_charge: String = "0"
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "余额提现"
        setupUI()
        requestData()
        // Do any additional setup after loading the view.
    }
    func setupUI() {
        let image = UIImage(gradientColors: [RGBA(250, 137, 43, 1), RGBA(250, 86, 35, 1)])
        submitButton.setBackgroundImage(image, for: UIControl.State.normal)
        self.amountTextField.delegate = self
    }

    func requestData() {
        let group = DispatchGroup()
        // 给队列添加任务并放到队列组中
         group.enter()
        provider.rx.request(APITarget.configKey(sysConfigKey: "min_withdraw_money"))
            .mapObject(BaseResponse<String>.self)
            .subscribe(onSuccess: { (res) in
                if let value = res.data {
                    self.min_withdraw_money = value
                }
                group.leave()
            }, onError: { (error) in
                group.leave()
            })
        .disposed(by: disposeBag)
        group.enter()
        provider.rx.request(APITarget.configKey(sysConfigKey: "max_withdraw_money"))
            .mapObject(BaseResponse<String>.self)
            .subscribe(onSuccess: { (res) in
                if let value = res.data {
                    self.max_withdraw_money = value
                }
                group.leave()
            }, onError: { (error) in
                group.leave()
            })
        .disposed(by: disposeBag)
        group.enter()
        provider.rx.request(APITarget.configKey(sysConfigKey: "withdraw_service_charge"))
            .mapObject(BaseResponse<String>.self)
            .subscribe(onSuccess: { (res) in
                if let value = res.data {
                    self.withdraw_service_charge = value
                }
                group.leave()
            }, onError: { (error) in
                group.leave()
            })
        .disposed(by: disposeBag)
        group.notify(queue: DispatchQueue.main) {
            print(self.min_withdraw_money+self.max_withdraw_money+self.withdraw_service_charge)
            self.balanceButton.setTitle("¥\(self.balance.mapToPrice())，全部提现", for: UIControl.State.normal)
            let withdraw_service_chargeDecimal = NSDecimalNumber(string: self.withdraw_service_charge)
            let decimal100 = NSDecimalNumber(string: "100")
            let str = withdraw_service_chargeDecimal.multiplying(by: decimal100).stringValue
            self.remarkLabel.text = "提现收取\(str)%服务费,到账时间T+1"
            
        }
    }
    @IBAction func submit(_ sender: UIButton) {
        let amount = amountTextField.text!
        if amount.isEmpty {
            SVProgressHUD.showInfo(withStatus: "请输入提现金额")
            return
        }
        let amountDouble = amount.toDouble() ?? 0
        let min_withdraw_moneyDouble = min_withdraw_money.toDouble() ?? 0
        if amountDouble > balance {
            SVProgressHUD.showInfo(withStatus: "可提现余额不足")
            return
        }
        if amountDouble < min_withdraw_moneyDouble {
            SVProgressHUD.showInfo(withStatus: "最低\(min_withdraw_money)元可提")
            return
        }
        let payPwdVC = PayPasswordController()
        payPwdVC.money = amountDouble
        payPwdVC.forgetBlock = {[weak self] in
            let vc = SetPasswordViewController()
            self?.navigationController?.pushViewController(vc, animated: true)
        }
        payPwdVC.completed = {[weak self] (pwd) in
            guard let `self` = self else {
                return
            }
            let pwdEncry = pwd.getRSAEncry()
            provider.rx.request(APITarget.withdraw_weixin(amount: amountDouble, payPassword: pwdEncry))
                .mapObject(BaseResponse<EmptyResponse>.self)
                .subscribe(onSuccess: { (res) in
                    SVProgressHUD.showSuccess(withStatus: "成功")
                    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+2) {
                        self.completed?()
                        self.navigationController?.popViewController(animated: true)
                    }
                }, onError: { (error) in
                    
                })
                .disposed(by: self.disposeBag)
        }
        self.customPresentViewController(payPresenter, viewController: payPwdVC, animated: true)
        
    }
    //全部提现
    @IBAction func widrawAll(_ sender: UIButton) {
        self.amountTextField.text = balance.mapToPrice()
        
    }
    
    @IBAction func clickDetail(_ sender: UIButton) {
        let vc = WithdrawListController()
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension WithdrawViewController: UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        return Validator.validate(textField, shouldChangeCharactersIn: range, replacementString: string, index: 2)
    }
}
