//
//  MyFriendsController.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/19.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class MyFriendsController: BaseTableViewController {
    var friendCount: Int = 0
    @IBOutlet weak var lineView1: UIImageView!
    
    @IBOutlet weak var lineView2: UIImageView!
    
    @IBOutlet weak var typeButton1: UIButton!
    @IBOutlet weak var typeButton2: UIButton!
    
    @IBOutlet weak var friendNumLabel: UILabel!
    
    @IBOutlet weak var shangjiLabel: UILabel!
    var selectIndex: Int = 0
    var dataList: [MyFansModel] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "我的朋友"
        setupUI()
        requestData()
        getSuperiorInfo()
        // Do any additional setup after loading the view.
    }

    func setupUI() {
        tableView.separatorColor = UIColor.separatorColor
        tableView.backgroundColor = UIColor.tableViewBg
        tableView.register(UINib(nibName: "MyFriendsCell", bundle: nil), forCellReuseIdentifier: String(describing: MyFriendsCell.self))
        selectIndex = 0
        typeButton1.isSelected = true
        typeButton2.isSelected = false
        lineView1.isHidden = false
        lineView2.isHidden = true
        
        self.friendNumLabel.text = friendCount.toString
    }
    
    override func requestData() {
        if selectIndex == 0 {
            provider.rx.request(APITarget.fans(pageNumber: self.pageNumber, pageSize: self.pageSize))
                .mapObject(BaseResponse<PageResponse<[MyFansModel]>>.self)
                .subscribe(onSuccess: { (res) in
                    self.endRefresh(res.data?.page?.totalPage)
                    if self.pageNumber == 1 {
                        self.dataList.removeAll()
                    }
                    if let list = res.data?.data {
                        self.dataList += list
                    }
                    self.tableView.reloadData()
                }, onError: { (error) in
                    self.endRefresh()
                })
            .disposed(by: disposeBag)
        }else{
            provider.rx.request(APITarget.getAllMyFans(pageNumber: self.pageNumber, pageSize: self.pageSize))
                .mapObject(BaseResponse<PageResponse<[MyFansModel]>>.self)
                .subscribe(onSuccess: { (res) in
                    self.endRefresh(res.data?.page?.totalPage)
                    if self.pageNumber == 1 {
                        self.dataList.removeAll()
                    }
                    if let list = res.data?.data {
                        self.dataList += list
                    }
                    self.tableView.reloadData()
                }, onError: { (error) in
                    self.endRefresh()
                })
            .disposed(by: disposeBag)
        }
        
    }
    
    func getSuperiorInfo() {
        provider.rx.request(APITarget.superiorInfo)
            .mapObject(BaseResponse<SuperiorInfoModel>.self)
            .subscribe(onSuccess: { (res) in
                if let model = res.data {
                    self.shangjiLabel.text = "我的上级：\(model.username ?? "无")"
                }else{
                    self.shangjiLabel.text = "我的上级：无"
                }
            }, onError: { (error) in
                self.shangjiLabel.text = "我的上级：无"
            })
        .disposed(by: disposeBag)
    }
    
    @IBAction func changeType(_ sender: UIButton) {
        let index = sender.tag
        if index == selectIndex {
            return
        }
        let isSelected = (index == 0)
        typeButton1.isSelected = isSelected
        typeButton2.isSelected = !isSelected
        lineView1.isHidden = !isSelected
        lineView2.isHidden = isSelected
        
        selectIndex = index
        self.pageNumber = 1
        self.requestData()
    }
    
    @objc func clickAddFriendAction() {
        let vc = InviteFriendController()
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension MyFriendsController {
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if dataList.isEmpty {
            return 1
        }
        return dataList.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if dataList.isEmpty {
            let cell = EmptyDataCell()
            cell.button.isHidden = false
            cell.button.addTarget(self, action: #selector(clickAddFriendAction), for: .touchUpInside)
            return cell
        }
        let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: MyFriendsCell.self), for: indexPath) as! MyFriendsCell
        cell.selectionStyle = .none
        let count = tableView.numberOfRows(inSection: indexPath.section)
        var corners: UIRectCorner?
        if count == 1 {
            corners = .allCorners
        }else{
            if indexPath.row == 0 {
                corners = [.topLeft, .topRight]
            }else if indexPath.row == count-1 {
                corners = [.bottomLeft, .bottomRight]
            }else{
                corners = nil
            }
        }
        if let corner = corners {
            //部分圆角
            let path = UIBezierPath(roundedRect: CGRect(x: 0, y: 0, width: SWIDTH-15*2, height: 70), byRoundingCorners: corner, cornerRadii: CGSize(width: 5, height: 5))
            let shapeLayer = CAShapeLayer()
            shapeLayer.path = path.cgPath
            cell.bgView.layer.mask = shapeLayer
        }else{
            cell.bgView.layer.mask = nil
        }
        
        if indexPath.section == count-1 {
            cell.separatorInset = UIEdgeInsets(top: 0, left: SWIDTH, bottom: 0, right: 0)
        }else{
            cell.separatorInset = UIEdgeInsets(top: 0, left: 25, bottom: 0, right: 25)
        }
        let model = dataList[indexPath.row]
        cell.imgView.kf.setImage(with: URL(string: model.avatar ?? ""), placeholder: UIImage(named: "头像"))
        cell.titleLabel.text = model.username
        cell.timeLabel.text = model.createTime
        if self.selectIndex == 0 {
            let fanNums = "\(model.directNum ?? 0)"
            let grayAtt = [NSAttributedString.Key.font : UIFont.systemFont(ofSize: 11), NSAttributedString.Key.foregroundColor : UIColor.gray6]
            let mainAtt = [NSAttributedString.Key.font : UIFont.systemFont(ofSize: 11), NSAttributedString.Key.foregroundColor : UIColor.mainColor]
            let numAttrText = NSMutableAttributedString(string: "邀请", attributes: grayAtt)
            numAttrText.append(NSAttributedString(string: fanNums, attributes: mainAtt))
            numAttrText.append(NSAttributedString(string: "人", attributes: grayAtt))
            cell.numLabel.attributedText = numAttrText
        }else{
            cell.numLabel.attributedText = nil
        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if dataList.isEmpty {
            return 175
        }
        return 70
    }
}
