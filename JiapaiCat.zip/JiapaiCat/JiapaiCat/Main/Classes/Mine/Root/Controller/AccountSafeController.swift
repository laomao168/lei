//
//  AccountSafeController.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/17.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class AccountSafeController: BaseViewController {
    lazy var tableView: UITableView = {
        let tableView = UITableView(frame: CGRect.zero, style: .plain)
        tableView.dataSource = self
        tableView.delegate = self
        return tableView
    }()
    var titleAndPicList = [("实名认证", "icon_account_realname"),
                            ("支付密码", "icon_account_paypwd")]
    var isSetPayPwd: Bool = false
    var isBindMobile: Bool = false
    var isVerified: Bool = false
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "账号与安全"
        setupUI()
            // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        requestData()
    }
    func setupUI() {
        self.view.addSubview(tableView)
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        tableView.backgroundColor = UIColor.tableViewBg
        tableView.tableFooterView = UIView()
        tableView.tableHeaderView = UIView(frame: CGRect(x: 0, y: 0, w: SWIDTH, h: 10))
        tableView.register(UINib(nibName: "MineCell", bundle: nil), forCellReuseIdentifier: String(describing: MineCell.self))
    }
    func requestData() {
        let group = DispatchGroup()
        // 给队列添加任务并放到队列组中
         group.enter()
        provider.rx.request(APITarget.noPara(url: API_checkRealPerson))
            .map(BaseResponse<EmptyResponse>.self)
            .subscribe(onSuccess: { (res) in
                let isReal = res.success
                self.isVerified = isReal
                group.leave()
            }, onError: { (error) in
                group.leave()
            })
        .disposed(by: disposeBag)
        group.enter()
        provider.rx.request(APITarget.noPara(url: API_isSetPassword))
            .map(BaseResponse<EmptyResponse>.self)
            .subscribe(onSuccess: { (res) in
                let isSetPayPwd = res.success
                self.isSetPayPwd = isSetPayPwd
                group.leave()
            }, onError: { (error) in
                group.leave()
            })
        .disposed(by: disposeBag)
        group.notify(queue: DispatchQueue.main) {
            self.tableView.reloadData()
        }
    }
    // Do any additional setup after loading the view.

}
extension AccountSafeController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return titleAndPicList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: MineCell.self), for: indexPath) as! MineCell
        cell.selectionStyle = .none
        let count = tableView.numberOfRows(inSection: indexPath.section)
        var corners: UIRectCorner?
        if count == 1 {
            corners = .allCorners
        }else{
            if indexPath.row == 0 {
                corners = [.topLeft, .topRight]
            }else if indexPath.row == count-1 {
                corners = [.bottomLeft, .bottomRight]
            }else{
                corners = nil
            }
        }
        if let corner = corners {
            //部分圆角
            let path = UIBezierPath(roundedRect: CGRect(x: 0, y: 0, width: SWIDTH-15*2, height: 70), byRoundingCorners: corner, cornerRadii: CGSize(width: 5, height: 5))
            let shapeLayer = CAShapeLayer()
            shapeLayer.path = path.cgPath
            cell.bgView.layer.mask = shapeLayer
        }else{
            cell.bgView.layer.mask = nil
        }
        cell.lineView.isHidden = true
        if indexPath.row == count-1 {
            cell.separatorInset = UIEdgeInsets(top: 0, left: SWIDTH, bottom: 0, right: 0)
        }else{
            cell.separatorInset = UIEdgeInsets(top: 0, left: 25, bottom: 0, right: 25)
        }
//        if indexPath.row == 0 {
//            if isBindMobile {
//                cell.detailLabel.text = "13333333333"
//            }else{
//                cell.detailLabel.text = "未绑定"
//            }
//        }else
        if indexPath.row == 0 {
            if isVerified {
                cell.detailLabel.text = "已实名"
            }else{
                cell.detailLabel.text = "未实名"
            }
        }else if indexPath.row == 1 {
            if isSetPayPwd {
                cell.detailLabel.text = "修改"
            }else{
                cell.detailLabel.text = "未设置"
            }
        }
        let item = titleAndPicList[indexPath.row]
        cell.titleLabel.text = item.0
        cell.imgView.image = UIImage(named: item.1)
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        if indexPath.row == 0 {
//            let vc = BindMobileController()
//            self.navigationController?.pushViewController(vc, animated: true)
//        }else
        if indexPath.row == 0 {
            if !isVerified {
                let vc = VerifiedViewController()
                self.navigationController?.pushViewController(vc, animated: true)
            }
        }else if indexPath.row == 1 {
            let vc = SetPasswordViewController()
            self.navigationController?.pushViewController(vc, animated: true)
            
//            if isSetPayPwd {
//                let vc = ChangePayPwdController()
//                self.navigationController?.pushViewController(vc, animated: true)
//            }else{
//
//            }
        }
    }
}
