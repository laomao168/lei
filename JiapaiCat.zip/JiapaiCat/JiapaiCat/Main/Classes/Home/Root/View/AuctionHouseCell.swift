//
//  AuctionHouseCell.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/19.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class AuctionHouseCell: UITableViewCell {
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var avatarImgView: UIImageView!
    @IBOutlet weak var nickLabel: UILabel!
    
    @IBOutlet weak var msgLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
