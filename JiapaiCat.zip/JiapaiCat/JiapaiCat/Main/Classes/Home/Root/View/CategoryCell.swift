//
//  CategoryCell.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/22.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class CategoryCell: UICollectionViewCell {
    @IBOutlet weak var imgView: UIImageView!
    
    @IBOutlet weak var titleLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
