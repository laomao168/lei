//
//  AuctionDetailHeaderView.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/18.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit
import FSPagerView
class AuctionDetailHeaderView: UIView {
    var firstImage: UIImage?
    @IBOutlet weak var pagerView: FSPagerView!
    
    @IBOutlet weak var pageControl: FSPageControl!
    
    @IBOutlet weak var bottomView: UIView!
    @IBOutlet weak var priceBgView: UIView!
    @IBOutlet weak var priceLabel: UILabel!
    
    @IBOutlet weak var timeDesLabel: UILabel!
    
//    var status: AnctionStatus = .notStarted {
//        didSet {
//            setupStatus()
//        }
//    }
    var bannerList: [String] = [] {
        didSet {
            self.pageControl.numberOfPages = self.bannerList.count
            if self.bannerList.isEmpty {
                self.pagerView.isInfinite = false
            }else{
                self.pagerView.isInfinite = true
            }
            self.pagerView.reloadData()
        }
    }
    override init(frame: CGRect) {
        super.init(frame: frame)
        initViews()
    }
    required init?(coder: NSCoder) {
        super.init(coder: coder)
//        initViews()
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        initViews()
    }
    func initViews() {
        setuppageView()
    }
    
    func setuppageView() {
        let width = SWIDTH
        let height: CGFloat = width*147/375
        self.pagerView.dataSource = self
        self.pagerView.delegate = self
        self.pagerView.itemSize = CGSize(width: width, height: height)//self.pagerView.frame.size.applying(CGAffineTransform(scaleX: newScale, y: newScale))
        self.pagerView.automaticSlidingInterval = 0
        self.pagerView.interitemSpacing = 0
        self.pagerView.isInfinite = true
        self.pagerView.isScrollEnabled = true
        self.pagerView.scrollDirection = .horizontal
        self.pagerView.register(FSPagerViewCell.self, forCellWithReuseIdentifier: "cell")
        
        self.pageControl.backgroundColor = UIColor.clear
        self.pageControl.contentHorizontalAlignment = .center
        self.pageControl.setFillColor(UIColor(white: 1, alpha: 0.5), for: .normal)
        self.pageControl.setFillColor(UIColor.mainColor, for: .selected)
        self.pageControl.contentInsets = UIEdgeInsets(top: 0, left: 20, bottom: 0, right: 20)
        self.pageControl.hidesForSinglePage = true

    }

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
extension AuctionDetailHeaderView: FSPagerViewDataSource, FSPagerViewDelegate {
// MARK:- FSPagerViewDataSource
        
    func numberOfItems(in pagerView: FSPagerView) -> Int {
        return bannerList.count
    }


    public func pagerView(_ pagerView: FSPagerView, cellForItemAt index: Int) -> FSPagerViewCell {
        let cell = pagerView.dequeueReusableCell(withReuseIdentifier: "cell", at: index)
        let pic = self.bannerList[index]
        
        cell.imageView?.kf.setImage(with: URL(string: pic), completionHandler: { [weak self] (result) in
            switch result {
            case .success(let res):
                self?.firstImage = res.image
                break
            case .failure(let error):
                break
            }
        })
        cell.imageView?.contentMode = .scaleAspectFill
        return cell
    }

    func pagerView(_ pagerView: FSPagerView, didSelectItemAt index: Int) {
    }
    func pagerViewDidScroll(_ pagerView: FSPagerView) {
        guard self.pageControl.currentPage != pagerView.currentIndex else {
            return
        }
        self.pageControl.currentPage = pagerView.currentIndex // Or Use KVO with property "currentIndex"
    }
}
