//
//  HomeHeaderView.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/16.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit
import FSPagerView

@objc protocol HomeHeaderDelegate: NSObjectProtocol {
//    @objc optional func clickClass(index: Int)
    
    @objc optional func tabChanged(index: Int)
}

class HomeHeaderView: UIView {
    weak var delegate: HomeHeaderDelegate?
    @IBOutlet weak var pagerView: FSPagerView!
    
    @IBOutlet weak var pageControl: FSPageControl!
    
    @IBOutlet weak var tabView1: HomeTabView!
    
    @IBOutlet weak var tabView2: HomeTabView!
    
    @IBOutlet weak var typeCollectionView: UICollectionView! {
        didSet {
            let layout: UICollectionViewFlowLayout = typeCollectionView.collectionViewLayout as! UICollectionViewFlowLayout
            typeCollectionView.backgroundColor = UIColor.white
            typeCollectionView.delegate = self
            typeCollectionView.dataSource = self
            typeCollectionView.showsVerticalScrollIndicator = false
            
            layout.minimumInteritemSpacing = 0
            layout.minimumLineSpacing = 0
            let itemW = SWIDTH/4
            let itemH: CGFloat = 169/2
            layout.itemSize = CGSize(width: itemW, height: itemH)
        }
    }
    
    var selectIndex: Int = 0
    var bannerList: [BannerListModel] = [] {
        didSet {
            if self.bannerList.count <= 1 {
                self.pagerView.automaticSlidingInterval = 0
                self.pagerView.isInfinite = false
            }
            self.pageControl.numberOfPages = self.bannerList.count
            self.pagerView.reloadData()
        }
    }
    var typeList: [GoodsCategoryListModel] = [] {
        didSet {
            self.typeCollectionView.reloadData()
        }
    }
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        initViews()
    }
    required init?(coder: NSCoder) {
        super.init(coder: coder)
//        initViews()
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        initViews()
    }
    func initViews() {
        tabView1.tag = 0
        tabView2.tag = 1
        
        tabView1.titleLabel.text = "今日"
        tabView1.statusLabel.text = "正在拍卖"
        tabView2.titleLabel.text = "预展"
        tabView2.statusLabel.text = "即将开始"
        let tap = UITapGestureRecognizer(target: self, action: #selector(clickTab(_:)))
        tabView1.addGestureRecognizer(tap)
        let tap2 = UITapGestureRecognizer(target: self, action: #selector(clickTab(_:)))
        tabView2.addGestureRecognizer(tap2)
        
        setupPagerView()
        self.selectIndex = 0
        tabView1.isSelected = true
        
        typeCollectionView.register(UINib(nibName: "CategoryCell", bundle: nil), forCellWithReuseIdentifier: String(describing: CategoryCell.self))
    }
    
    func setupPagerView() {
        let width = SWIDTH
        let height: CGFloat = width*147/375
        self.pagerView.dataSource = self
        self.pagerView.delegate = self
        self.pagerView.itemSize = CGSize(width: width, height: height)//self.pagerView.frame.size.applying(CGAffineTransform(scaleX: newScale, y: newScale))
        self.pagerView.automaticSlidingInterval = 3
        self.pagerView.interitemSpacing = 0
        self.pagerView.isInfinite = true
        self.pagerView.isScrollEnabled = true
        self.pagerView.scrollDirection = .horizontal
        self.pagerView.register(FSPagerViewCell.self, forCellWithReuseIdentifier: "cell")
        
        self.pageControl.backgroundColor = UIColor.clear
        self.pageControl.contentHorizontalAlignment = .center
        self.pageControl.setFillColor(UIColor(white: 1, alpha: 0.5), for: .normal)
        self.pageControl.setFillColor(UIColor.mainColor, for: .selected)
        self.pageControl.contentInsets = UIEdgeInsets(top: 0, left: 20, bottom: 0, right: 20)
        self.pageControl.hidesForSinglePage = true

    }

    
    @objc func clickTab(_ tap: UITapGestureRecognizer) {
        let sender = tap.view! as! HomeTabView
        if sender.tag == selectIndex {
            return
        }
        tabView1.isSelected = false
        tabView2.isSelected = false
        sender.isSelected = true
        self.selectIndex = sender.tag
        delegate?.tabChanged?(index: self.selectIndex)
    }

}
extension HomeHeaderView: FSPagerViewDataSource, FSPagerViewDelegate {
// MARK:- FSPagerViewDataSource
        
    func numberOfItems(in pagerView: FSPagerView) -> Int {
        return bannerList.count
    }


    public func pagerView(_ pagerView: FSPagerView, cellForItemAt index: Int) -> FSPagerViewCell {
        let cell = pagerView.dequeueReusableCell(withReuseIdentifier: "cell", at: index)
        let model = self.bannerList[index]
        let pic = model.image ?? ""
        cell.imageView?.contentMode = .scaleAspectFill
        cell.imageView?.kf.setImage(with: URL(string: pic), placeholder: nil, options: nil, progressBlock: nil, completionHandler: { (result) in
        })
        cell.imageView?.kf.setImage(with: URL(string: pic))
        return cell
    }

    func pagerView(_ pagerView: FSPagerView, didSelectItemAt index: Int) {
        /*
         广告跳转类型
         type  ：
            NBYM(1, "内部页面"),
         PMXQ(2, "拍卖详情"),
         PMFL(3, "拍卖分类"),
         BTZ(5, "不跳转"),
         H5(4, "h5页面");
         */
        let model = self.bannerList[index]
        let type = model.type
        guard let linkId = model.linkId, !linkId.isEmpty else {
            return
        }
        if type == 1 {
            if linkId.contains("shareFriend") {
                guard UserInfoManager.shared.isLogined else {
                    UtilUser.openLogin()
                    return
                }
                let vc = InviteFriendController()
                self.currentController()?.navigationController?.pushViewController(vc, animated: true)
            }
        }else if type == 2 {
            if let auctionId = linkId.toInt() {
                let vc = AuctionDetailViewController()
                vc.auctionId = auctionId
                self.currentController()?.navigationController?.pushViewController(vc, animated: true)
            }
        }else if type == 3 {
            if let categoryId = linkId.toInt() {
                let vc = ClassificationController()
                vc.title = model.name
                vc.categoryId = categoryId
                self.currentController()?.navigationController?.pushViewController(vc, animated: true)
            }
        }else if type == 4 {
            if Validator.isURL(string: linkId) {
                let webVC = WLWebViewController(url: URL(string: linkId)!)
               webVC.title = "一口拍"
                
                self.currentController()?.navigationController?.pushViewController(webVC, animated: true)
            }
        }else if type == 5 {
            
        }
    }
    func pagerViewDidScroll(_ pagerView: FSPagerView) {
        guard self.pageControl.currentPage != pagerView.currentIndex else {
            return
        }
        self.pageControl.currentPage = pagerView.currentIndex // Or Use KVO with property "currentIndex"
    }
}
extension HomeHeaderView: UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return typeList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: String(describing: CategoryCell.self), for: indexPath) as! CategoryCell
        let model = typeList[indexPath.row]
        cell.imgView.kf.setImage(with: URL(string: model.pic))
        cell.titleLabel.text = model.name
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let model = typeList[indexPath.row]
        if model.categoryId == 9999 {
            let vc = WLWebViewController(url: URL(string: kHtml_distRule)!)
            vc.title = "拍卖规则"
            self.currentController()?.navigationController?.pushViewController(vc, animated: true)
        }else if model.categoryId == 8888 {//充值
            if !UserInfoManager.shared.isLogined {
                UtilUser.openLogin()
                return
            }
            let vc = RechargeViewController()
            self.currentController()?.navigationController?.pushViewController(vc, animated: true)
        }else{
            let vc = ClassificationController()
            vc.title = model.name
            vc.categoryId = model.categoryId ?? 0
            self.currentController()?.navigationController?.pushViewController(vc, animated: true)
        }
        
    }
    
}
