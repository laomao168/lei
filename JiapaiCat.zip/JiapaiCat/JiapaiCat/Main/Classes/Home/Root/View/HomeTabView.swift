//
//  HomeTabView.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/16.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class HomeTabView: UIView {
    var titleLabel: UILabel!
    var statusLabel: UILabel!
    private var gradLayer: CAGradientLayer!
    private var bgView: UIView!
    var isSelected: Bool = false {
        didSet {
            if isSelected {
//                gradLayer.frame = CGRect(x: 0, y: 0, w: 69, h: 20)
                titleLabel.textColor = UIColor.mainColor
                statusLabel.textColor = UIColor.white
                bgView.isHidden = false
            }else{
//                gradLayer.frame = CGRect.zero
                titleLabel.textColor = UIColor.gray3
                statusLabel.textColor = UIColor.gray6
                bgView.isHidden = true
            }
        }
    }
    override init(frame: CGRect) {
        super.init(frame: frame)
        initViews()
    }
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        initViews()
    }
    func initViews() {
        titleLabel = UILabel()
        titleLabel.font = UIFont.systemFont(ofSize: 15)
        titleLabel.textColor = UIColor.gray3
        self.addSubview(titleLabel)
        bgView = UIView()
        self.addSubview(bgView)
        
        statusLabel = UILabel()
        statusLabel.font = UIFont.systemFont(ofSize: 12)
        statusLabel.textColor = UIColor.gray6
        statusLabel.textAlignment = .center
        self.addSubview(statusLabel)
        titleLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(20)
            make.centerX.equalToSuperview()
        }
        
        
        statusLabel.snp.makeConstraints { (make) in
            make.top.equalTo(titleLabel.snp.bottom).offset(5)
            make.width.equalTo(69)
            make.height.equalTo(20)
            make.centerX.equalToSuperview()
        }
        bgView.snp.makeConstraints { (make) in
            make.left.right.top.bottom.equalTo(statusLabel)
        }
        
        gradLayer = CAGradientLayer.rainbowLayer(colors: [RGBA(250, 137, 43, 1).cgColor, RGBA(250, 86, 35, 1).cgColor])
        gradLayer.frame = CGRect(x: 0, y: 0, w: 69, h: 20)
        bgView.layer.addSublayer(gradLayer)
        bgView.layer.cornerRadius = 10
        bgView.layer.masksToBounds = true
        self.isSelected = false
    }
}
