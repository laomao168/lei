//
//  HomeCell.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/16.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class HomeCell: UITableViewCell {
    @IBOutlet weak var tipsImgView: UIImageView!
    
    @IBOutlet weak var imgView: UIImageView!
    
    @IBOutlet weak var isFinishLabel: UILabel!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var numLabel: UILabel!
    @IBOutlet weak var numDesLabel: UILabel!
    @IBOutlet weak var priceDesLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    
    @IBOutlet weak var timeDesLabel: UILabel!
    
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var manNumLabel: UILabel!
    @IBOutlet weak var manDesLabel: UILabel!
    
    
    @IBOutlet weak var buyButton: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        
        isFinishLabel.isHidden = true
        buyButton.isUserInteractionEnabled = false
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
