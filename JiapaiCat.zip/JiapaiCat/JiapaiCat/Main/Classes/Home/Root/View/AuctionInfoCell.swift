//
//  AuctionInfoCell.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/18.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class AuctionInfoCell: UITableViewCell {
    @IBOutlet weak var shopNameLabel: UILabel!
    @IBOutlet weak var weiguanLabel: UILabel!
    @IBOutlet weak var chujiaLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
