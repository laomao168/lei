//
//  AuctionSectionHeaderView.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/18.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class AuctionSectionHeaderView: UIView {

    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var moreButton: UIButton!
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
