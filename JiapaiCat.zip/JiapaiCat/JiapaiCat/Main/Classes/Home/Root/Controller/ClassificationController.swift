//
//  ClassificationController.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/16.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class ClassificationController: BaseTableViewController {
    var categoryId: Int = 0
    override var tableViewStyle: UITableView.Style {
        return .grouped
    }
    var dataList: [AuctionListModel] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
//        self.title = "分类列表"
        requestData()
        // Do any additional setup after loading the view.
    }
    override func requestData() {
        provider.rx.request(APITarget.listFatherCategory(pageNumber: self.pageNumber, pageSize: self.pageSize, fatherCategoryId: categoryId))
        .mapObject(BaseResponse<AuctionListResponse>.self)
        .subscribe(onSuccess: { (res) in
            self.endRefresh(res.data?.page.totalPage)
            if self.pageNumber == 1 {
                self.dataList.removeAll()
            }
            if let list = res.data?.data {
                self.dataList = self.dataList + list
            }
            self.tableView.reloadData()
        }, onError: { (error) in
            self.endRefresh()
        })
        .disposed(by: disposeBag)
    }
    func setupUI() {
        tableView.tableHeaderView = UIView(frame: CGRect(x: 0, y: 0, w: 0, h: 10))
        tableView.register(UINib(nibName: "HomeCell", bundle: nil), forCellReuseIdentifier: String(describing: HomeCell.self))
        tableView.sectionHeaderHeight = 0.1
        tableView.sectionFooterHeight = 10
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension ClassificationController {
    func numberOfSections(in tableView: UITableView) -> Int {
        if dataList.isEmpty {
            return 1
        }
        return dataList.count
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if dataList.isEmpty {
            let cell = EmptyDataCell()
            return cell
        }
        let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: HomeCell.self), for: indexPath) as! HomeCell
        cell.selectionStyle = .none
        
        let model = self.dataList[indexPath.section]
        cell.nameLabel.text = model.goodsName
        cell.imgView.kf.setImage(with: URL(string: model.logo ?? ""))
        cell.isFinishLabel.isHidden = !(model.status > 3)
         cell.priceLabel.text = "\(model.topPrice?.mapToPrice() ?? "0")"
        if model.status == 2 {//即将开始
             cell.priceDesLabel.text = "起拍价"
             cell.numLabel.text = ""
             cell.numDesLabel.text = ""
             cell.timeDesLabel.text = "开拍时间"
             cell.timeLabel.text = UtilDate.removeDay(timeStr: "\(model.startTime ?? "")")
             cell.manNumLabel.text = "\(model.viewCount ?? 0)"
             cell.manDesLabel.text = "人围观"
             cell.buyButton.isHidden = true
             cell.tipsImgView.image = UIImage(named: "icon_list_start")
         }else if model.status == 3 {//正在拍卖
             cell.priceDesLabel.text = "当前价"
             cell.numLabel.text = "\(model.markupNum ?? 0)"
             cell.numDesLabel.text = "出价"
             cell.timeDesLabel.text = "结拍时间"
             cell.timeLabel.text = UtilDate.removeDay(timeStr: "\(model.endTime ?? "")")
             cell.manNumLabel.text = ""
             cell.manDesLabel.text = ""
             cell.buyButton.isHidden = false
             cell.tipsImgView.image = UIImage(named: "icon_list_auction")
         }else if model.status > 3 {//已结束
            cell.priceDesLabel.text = "成交价"
            cell.numLabel.text = "\(model.markupNum ?? 0)"
            cell.numDesLabel.text = "出价"
            cell.timeDesLabel.text = "结拍时间"
            cell.timeLabel.text = UtilDate.removeDay(timeStr: "\(model.endTime ?? "")")
            cell.manNumLabel.text = ""
            cell.manDesLabel.text = ""
            cell.buyButton.isHidden = true
            cell.tipsImgView.image = nil
        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if dataList.isEmpty {
            return EmptyDataCell.emptyHeight
        }
        return 160
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if dataList.isEmpty {
            return
        }
        let model = self.dataList[indexPath.section]
        let vc = AuctionDetailViewController()
        vc.auctionId = model.auctionId
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
