//
//  HomeViewController.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/16.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class HomeViewController: BaseTableViewController {
    var headerView: HomeHeaderView!
    var bannerList: [BannerListModel] = []
    var goodsCategoryList: [GoodsCategoryListModel] = []
    var dataList: [AuctionListModel] = []
    var selectTypeIndex: Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "首页"
        setupUI()
        requestData()
        // Do any additional setup after loading the view.
    }
    func setupUI() {
        self.view.addSubview(tableView)
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        tableView.tableFooterView = UIView()
        tableView.rowHeight = 160
        tableView.register(UINib(nibName: "HomeCell", bundle: nil), forCellReuseIdentifier: String(describing: HomeCell.self))
        
        headerView = Bundle.main.loadNibNamed("HomeHeaderView", owner: self, options: nil)?.first as? HomeHeaderView
        headerView.delegate = self
        let homeHeaderView = UIView(frame: CGRect(x: 0, y: 0, w: SWIDTH, h: SWIDTH*(390/750)+20+169+70))
        homeHeaderView.addSubview(headerView)
        headerView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        tableView.tableHeaderView = homeHeaderView
    }
    func getHomeData() {
        
//        let group = DispatchGroup()
//        // 给队列添加任务并放到队列组中
//         group.enter()
          provider.rx.request(APITarget.homeBannerList(bannerType: 1))
            .mapObject(BaseResponse<[BannerListModel]>.self)
            .subscribe(onSuccess: { (res) in
                self.bannerList = res.data ?? []
                self.headerView.bannerList = self.bannerList
//                group.leave()
            }, onError: { (error) in
//                group.leave()
            })
        .disposed(by: disposeBag)
//        group.enter()
        provider.rx.request(APITarget.goodsCategoryList(parentId: 0, isRecommend: 1))
            .mapObject(BaseResponse<[GoodsCategoryListModel]>.self)
            .subscribe(onSuccess: { (res) in
                self.goodsCategoryList = res.data ?? []
                self.headerView.typeList = self.goodsCategoryList
//                group.leave()
            }, onError: { (error) in
//                group.leave()
            })
        .disposed(by: disposeBag)
//        group.notify(queue: DispatchQueue.main) {
//            self.headerView.bannerList = self.bannerList
//            self.headerView.typeList = self.goodsCategoryList
//        }
    }
    override func requestData() {
        if self.pageNumber == 1 {
            if goodsCategoryList.isEmpty || bannerList.isEmpty {
                getHomeData()
            }
        }
        if self.selectTypeIndex == 0 {
            provider.rx.request(APITarget.listToday(pageNumber: self.pageNumber, pageSize: self.pageSize))
            .mapObject(BaseResponse<AuctionListResponse>.self)
            .subscribe(onSuccess: { (res) in
                self.endRefresh(res.data?.page.totalPage)
                if self.pageNumber == 1 {
                    self.dataList.removeAll()
                }
                if let list = res.data?.data {
                    self.dataList = self.dataList + list
                }
                self.tableView.reloadData()
            }, onError: { (error) in
                self.endRefresh()
            })
            .disposed(by: disposeBag)
        }else{
            provider.rx.request(APITarget.listDate(pageNumber: self.pageNumber, pageSize: self.pageSize, type: 2))
            .mapObject(BaseResponse<AuctionListResponse>.self)
            .subscribe(onSuccess: { (res) in
                self.endRefresh(res.data?.page.totalPage)
                if self.pageNumber == 1 {
                    self.dataList.removeAll()
                }
                if let list = res.data?.data {
                    self.dataList = self.dataList + list
                }
                self.tableView.reloadData()
            }, onError: { (error) in
                self.endRefresh()
            })
            .disposed(by: disposeBag)
        }
        
    }
}
extension HomeViewController {
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataList.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: HomeCell.self), for: indexPath) as! HomeCell
        cell.selectionStyle = .none
        let model = self.dataList[indexPath.row]
        cell.nameLabel.text = model.goodsName
        cell.imgView.kf.setImage(with: URL(string: model.logo ?? ""))
        cell.isFinishLabel.isHidden = !(model.status > 3)
        cell.priceLabel.text = "\(model.topPrice?.mapToPrice() ?? "0")"
       if model.status == 2 {//即将开始
            cell.priceDesLabel.text = "起拍价"
            cell.numLabel.text = ""
            cell.numDesLabel.text = ""
            cell.timeDesLabel.text = "开拍时间"
            cell.timeLabel.text = UtilDate.removeDay(timeStr: "\(model.startTime ?? "")")
            cell.manNumLabel.text = "\(model.viewCount ?? 0)"
            cell.manDesLabel.text = "人围观"
            cell.buyButton.isHidden = true
            cell.tipsImgView.image = UIImage(named: "icon_list_start")
        }else if model.status == 3 {//正在拍卖
            cell.priceDesLabel.text = "当前价"
            cell.numLabel.text = "\(model.markupNum ?? 0)"
            cell.numDesLabel.text = "出价"
            cell.timeDesLabel.text = "结拍时间"
            cell.timeLabel.text = UtilDate.removeDay(timeStr: "\(model.endTime ?? "")")
            cell.manNumLabel.text = ""
            cell.manDesLabel.text = ""
            cell.buyButton.isHidden = false
            cell.tipsImgView.image = UIImage(named: "icon_list_auction")
        }else if model.status > 3 {//已结束
           cell.priceDesLabel.text = "成交价"
           cell.numLabel.text = "\(model.markupNum ?? 0)"
           cell.numDesLabel.text = "出价"
           cell.timeDesLabel.text = "结拍时间"
           cell.timeLabel.text = UtilDate.removeDay(timeStr: "\(model.endTime ?? "")")
           cell.manNumLabel.text = ""
           cell.manDesLabel.text = ""
           cell.buyButton.isHidden = true
           cell.tipsImgView.image = nil
       }
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let model = self.dataList[indexPath.row]
        let vc = AuctionDetailViewController()
        vc.auctionId = model.auctionId
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}
extension HomeViewController: HomeHeaderDelegate {
//    func clickClass(index: Int) {
//        if index == 0 {
//            let vc = ClassificationController()
//            self.navigationController?.pushViewController(vc, animated: true)
//        }else{
//            let vc = ClassificationController()
//            self.navigationController?.pushViewController(vc, animated: true)
//        }
//    }
    
    func tabChanged(index: Int) {
        self.selectTypeIndex = index
        self.pageNumber = 1
        self.requestData()
    }
}
