//
//  AuctionDetailViewController.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/18.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit
import WebKit
import SnapKit
import Presentr
import Starscream

class AuctionDetailViewController: BaseViewController {
    var auctionId: Int = 0
    var model: AuctionDetailModel?
    var rankingList: [RankingListModel] = []
//    var footprintTypeList: [FootprintTypeListModel] = []
    lazy var tableView: UITableView = {
        let tableView = UITableView(frame: CGRect.zero, style: UITableView.Style.grouped)
        tableView.dataSource = self
        tableView.delegate = self
        return tableView
    }()
    var topPrice: Double = 0
    var nextCashDeposit: Double = 0
    var headerView: AuctionDetailHeaderView!
    var bottomView: UIView!
    var startView: UIView!
    var priceLabel: UILabel!
    var statusLabel: UILabel!
    var backButton: UIButton!
    let auctionHouseVC = AuctionHouseController()
    lazy var webView: WKWebView = {
        //配置环境
        let configuration = WKWebViewConfiguration()
        configuration.preferences.javaScriptEnabled = true
        // 注入JS对象名称"NativeMethod"，当JS通过NativeMethod来调用时，我们可以在WKScriptMessageHandler代理中接收到
        let userController = WKUserContentController()
        configuration.userContentController = userController
        //        delegateController.delegate = self
        //        configuration.userContentController.add(self, name: "NativeMethod")
        let webView = WKWebView(frame: CGRect(x: 0, y: 0, width: SWIDTH, height: SHEIGHT), configuration: configuration)
        webView.allowsBackForwardNavigationGestures = false
        webView.navigationDelegate = self
        
        //目前不需要这个代理
        //        webView.uiDelegate = self
        webView.scrollView.isScrollEnabled = false
        return webView
    }()
    var webHeight: CGFloat = 0
    private let cellId1 = "cellId1"
    private let cellId2 = "cellId2"
    private let cellId3 = "cellId3"
    private let cellId4 = "cellId4"
    
    var status: AnctionStatus {
        let state = model?.status ?? 0
        return AnctionStatus(rawValue: state) ?? .end
    }
    
    //定时器
    private var countdownTimer: Timer?
    
    private var remainingSeconds: Double = 0 {
        didSet {
            auctionHouseVC.remainingSeconds = remainingSeconds
            if let label = headerView.timeDesLabel {
                let timeStr = UtilDate.getDayHHMMSSFromSS(seconds: Int(remainingSeconds))
                if status == .notStarted {
                    label.text = "距开始时间：\(timeStr)"
                }else if status == .started {
                    label.text = "距结束时间：\(timeStr)"
                }else{
                    label.text = "已结束"
                }
            }
            if remainingSeconds <= 0 {
                countdownTimer?.invalidate()
                countdownTimer = nil
                //有延迟，过一秒再请求
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+1) {
                    self.requestData()
                }
            }
        }
    }
    
    var socket: WebSocket!
    var headBeat: Timer?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "商品详情"
        
        setupUI()
        
        requestData()
        // Do any additional setup after loading the view.
    }
    
    func setupUI() {
        setupBottomView()
        self.view.addSubview(tableView)
        tableView.snp.makeConstraints { (make) in
            make.left.top.right.equalToSuperview()
            make.bottom.equalTo(bottomView.snp.top)
        }
        
        headerView = Bundle.main.loadNibNamed("AuctionDetailHeaderView", owner: self, options: nil)?.first as? AuctionDetailHeaderView
        let homeHeaderView = UIView(frame: CGRect(x: 0, y: 0, w: SWIDTH, h: SWIDTH*1+50))
        homeHeaderView.addSubview(headerView)
        headerView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        tableView.tableHeaderView = homeHeaderView
        
        tableView.separatorStyle = .none
        tableView.backgroundColor = UIColor(hexString: "#EEEEEE")
        tableView.tableFooterView = UIView()
        tableView.register(UINib(nibName: "AuctionInfoCell", bundle: nil), forCellReuseIdentifier: cellId1)
        tableView.register(UINib(nibName: "AuctionCell1", bundle: nil), forCellReuseIdentifier: cellId2)
        tableView.register(UINib(nibName: "AuctionCell2", bundle: nil), forCellReuseIdentifier: cellId3)
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: cellId4)
        
        backButton = UIButton(type: .custom)
        backButton.setTitle("点\n击\n进\n入\n拍\n卖", for: UIControl.State.normal)
        backButton.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        backButton.titleLabel?.numberOfLines = 0
        backButton.setBackgroundColor(UIColor(white: 0, alpha: 0.5), forState: UIControl.State.normal)
        backButton.addTarget(self, action: #selector(clickAuctionHouseDetail), for: UIControl.Event.touchUpInside)
        self.view.addSubview(backButton)
        backButton.snp.makeConstraints { (make) in
            make.right.equalToSuperview()
            make.bottom.equalToSuperview().offset(-(kSafeAreaBottomHeight+50+100))
            make.width.equalTo(30)
            make.height.equalTo(120)
        }
        let path = UIBezierPath(roundedRect: CGRect(x: 0, y: 0, width: 30, height: 120), byRoundingCorners: [.topLeft, .bottomLeft], cornerRadii: CGSize(width: 3, height: 3))
        let shapeLayer = CAShapeLayer()
        shapeLayer.path = path.cgPath
        backButton.layer.mask = shapeLayer
        setupActionHouse()
        setupWebSocket()
    }
    //拍卖场
    func setupActionHouse() {//697, 640
        auctionHouseVC.auctionId = self.auctionId
        let h = SHEIGHT-kSafeAreaBottomHeight-50-kNavBarHeight//-57
        auctionHouseVC.view.frame = CGRect(x: SWIDTH, y: 0, w: SWIDTH, h: h)
        self.addChild(auctionHouseVC)
        self.view.addSubview(auctionHouseVC.view)
        auctionHouseVC.view.snp.makeConstraints { (make) in
            make.width.equalTo(SWIDTH)
            make.height.equalTo(h)
            make.top.equalToSuperview()
            make.left.equalToSuperview().offset(SWIDTH)
        }
        auctionHouseVC.backBlock = {[weak self] in
            self?.auctionHouseVC.isShow = false
            self?.auctionHouseVC.view.snp.updateConstraints({ (make) in
                make.left.equalToSuperview().offset(SWIDTH)
            })
            self?.auctionHouseVC.beginAppearanceTransition(false, animated: true)
            UIView.animate(withDuration: 0.5, animations: {
//                self?.auctionHouseVC.view.x = SWIDTH
                
                self?.view.layoutIfNeeded()
            }) { (isFinish) in
                self?.auctionHouseVC.endAppearanceTransition()
            }
        }
    }
    
    func setupBottomView() {
        bottomView = UIView()
        bottomView.backgroundColor = UIColor.white
        self.view.addSubview(bottomView)
        bottomView.snp.makeConstraints { (make) in
            make.bottom.equalToSuperview().offset(-kSafeAreaBottomHeight)
            make.height.equalTo(49)
            make.left.right.equalToSuperview()
        }
        let shareButton = UIButton(type: .custom)
        shareButton.addTarget(self, action: #selector(shareAction), for: UIControl.Event.touchUpInside)
        bottomView.addSubview(shareButton)
        shareButton.setTitle("分享", for: UIControl.State.normal)
        shareButton.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        shareButton.setTitleColor(UIColor.mainColor, for: UIControl.State.normal)
        shareButton.setImage(UIImage(named: "btn_botfixed_share"), for: UIControl.State.normal)
        shareButton.isHidden = true
        bottomView.addSubview(shareButton)
        shareButton.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(20)
            make.centerY.equalToSuperview()
            make.width.height.equalTo(49)
        }
        shareButton.imagePosition(style: .top, spacing: 0)
        
        statusLabel = UILabel()
        statusLabel.font = UIFont.systemFont(ofSize: 18)
        statusLabel.textAlignment = .center
        statusLabel.textColor = UIColor.white
        bottomView.addSubview(statusLabel)
        statusLabel.snp.makeConstraints { (make) in
            make.top.bottom.right.equalToSuperview()
            make.width.equalTo(124)
        }
        
        startView = UIView()
        startView.backgroundColor = UIColor.mainColor
        bottomView.addSubview(startView)
        startView.snp.makeConstraints { (make) in
            make.top.bottom.right.equalToSuperview()
            make.width.equalTo(180)
        }
        let startLabel = UILabel()
        startLabel.font = UIFont.systemFont(ofSize: 12)
        startLabel.textColor = UIColor.white
        startLabel.text = "立即出价"
        startView.addSubview(startLabel)
        startLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(11)
            make.centerX.equalToSuperview()
        }
        
        priceLabel = UILabel()
        priceLabel.font = UIFont.systemFont(ofSize: 10)
        priceLabel.textColor = UIColor.white
        startView.addSubview(priceLabel)
        priceLabel.snp.makeConstraints { (make) in
            make.bottom.equalToSuperview().offset(-6)
            make.centerX.equalToSuperview()
        }
        
        
        let auctionButton = UIButton(type: .custom)
        auctionButton.addTarget(self, action: #selector(auctionAction), for: UIControl.Event.touchUpInside)
        startView.addSubview(auctionButton)
        auctionButton.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    func addHeatBeat() {
        headBeat = Timer.scheduledTimer(withTimeInterval: 5, repeats: true) { [weak self](timer) in
            self?.socket.write(string: "heartbeat")
        }
        RunLoop.main.add(self.headBeat!, forMode: RunLoop.Mode.common)
    }
    func setupWebSocket() {
        socket = WebSocket(url: URL(string: websocketUrl)!)
        //websocketDidConnect
        socket.onConnect = {[weak self] in
            self?.addHeatBeat()
            self?.socket.write(string: self?.auctionId.toString ?? "")
            print("websocket is connected")
        }
        //websocketDidDisconnect
        socket.onDisconnect = { [weak self](error: Error?) in
            self?.headBeat?.invalidate()
            self?.headBeat = nil
            print("websocket is disconnected: \(error?.localizedDescription)")
        }
        //websocketDidReceiveMessage
        socket.onText = { [weak self](text: String) in
            print("got some text: \(text)")
            guard let `self` = self else {
                return
            }
            if text == "heartbeat" {
                return
            }
            if let data = text.data(using: String.Encoding.utf8) {
                do{
                    let res = try JSONDecoder().decode(WSReceiveModel.self, from: data)
                    //需要转换
                    let model = AuctionHouceListModel()
                    model.auctionId = res.auctionId
                    model.nextCashDeposit = res.nextCashDeposit
                    model.guarantyPrice = res.guarantyPrice
                    model.payPrice = res.payPrice
                    model.markupTime = res.markupTimeString
                    model.avatar = res.avatar
                    model.payType = res.type
                    model.userName = res.userName
                    model.userId = res.userId
                    self.receiveNewPrice(model)
               
                }catch{
                    print(error)
                }
            }else{
                print("转Data失败")
            }
        }
//        //websocketDidReceiveData
//        socket.onData = { (data: Data) in
//            print("got some data: \(data.count)")
//        }
        //you could do onPong as well.
    }
    
    func receiveNewPrice(_ model: AuctionHouceListModel) {
        self.topPrice = model.payPrice
        self.nextCashDeposit = model.nextCashDeposit
        setupTopPrice()
        auctionHouseVC.receiveNewPrice(model)
    }
    
    func setupStatus() {
        guard let model = model else {
            return
        }
        //实时数据
        if status == .started {
            socket.connect()
        }else{
            socket.disconnect()
        }
        if status == .notStarted {
            startView.isHidden = true
            statusLabel.isHidden = false
            statusLabel.text = "即将开始"
            statusLabel.backgroundColor = UIColor(hexString: "#009A86")
        }else if status == .started {
            startView.isHidden = false
            statusLabel.isHidden = true
            statusLabel.text = "开始"
        }else if status == .end {
            startView.isHidden = true
            statusLabel.isHidden = false
            statusLabel.text = "已结束"
            statusLabel.backgroundColor = UIColor(hexString: "#9A9A9A")
        }
        
        switch status {
        case .notStarted:
            
            let time = UtilDate.getDayHHMMSSFromSS(seconds: (model.startTimes ?? 0))
            headerView.timeDesLabel.text = time
            addTimer()
            headerView.timeDesLabel.textColor = UIColor.mainColor
            headerView.bottomView.backgroundColor = UIColor(hexString: "#F9E2D0")
            headerView.priceBgView.backgroundColor = UIColor.mainColor
            break
        case .started:
            let time = UtilDate.getDayHHMMSSFromSS(seconds: model.endTimes ?? 0)
            headerView.timeDesLabel.text = time
            addTimer()
            headerView.timeDesLabel.textColor = UIColor.mainColor
            headerView.bottomView.backgroundColor = UIColor(hexString: "#F9E2D0")
            headerView.priceBgView.backgroundColor = UIColor.mainColor
            break
        case .end:
            headerView.timeDesLabel.text = "已结束"
            headerView.timeDesLabel.textColor = UIColor.gray6
            headerView.bottomView.backgroundColor = UIColor(hexString: "#ECECEC")
            headerView.priceBgView.backgroundColor = UIColor(hexString: "#9A9A9A")
            break
        }
        setupTopPrice()
        if status != .notStarted {
            backButton.isHidden = false
        }else{
            backButton.isHidden = true
        }
        auctionHouseVC.status = self.status
        
    }
    
    func setupTopPrice() {
        guard let model = model else {
            return
        }
        var priceDesText = ""
        let price = "¥"+topPrice.mapToPrice()
        switch status {
        case .notStarted:
            priceDesText = "起拍价"
            break
        case .started:
            priceDesText = "当前出价"
            let myPrice = topPrice+(model.markupPrice ?? 0)
            priceLabel.text = "我出价 ¥\(myPrice.mapToPrice())（含保证金 ¥\(nextCashDeposit.mapToPrice())）"
            break
        case .end:
            priceDesText = "成交价"
            break
        }
        let priceAttr = NSMutableAttributedString(string: priceDesText, attributes: [NSAttributedString.Key.font : UIFont.systemFont(ofSize: 12)])
        priceAttr.append(NSAttributedString(string: price, attributes: [NSAttributedString.Key.font : UIFont.systemFont(ofSize: 18)]))
        headerView.priceLabel.attributedText = priceAttr
    }
    
    func addTimer() {
            //定时器
        if status != .end {
    //            let time = 2*60-(currentTime-orderTime)/1000
            var time: Double = 0
            if status == .notStarted {
                time = Double((model?.startTimes ?? 0)/1000)
            }else if status == .started {
                time = Double((model?.endTimes ?? 0)/1000)
            }
                
            if time > 0 {
                //15分钟
                remainingSeconds = time
                //先关闭
                countdownTimer?.invalidate()
                countdownTimer = nil
                
                countdownTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true, block: { [weak self](timer) in
                    self?.updateTime()
                })
                RunLoop.main.add(countdownTimer!, forMode: RunLoop.Mode.common)
            }
//            else{
//                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+1) {
//                    self.requestData()
//                }
//            }
        }else{
            countdownTimer?.invalidate()
            countdownTimer = nil
        }
    }
    
    @objc private func updateTime() {
        // 计时开始时，逐秒减少remainingSeconds的值
        remainingSeconds -= 1
    }

    func requestData() {
        provider.rx.request(APITarget.auctionRecordInfo(auctionId: auctionId))
            .mapObject(BaseResponse<AuctionDetailModel>.self)
            .subscribe(onSuccess: { (res) in
                self.model = res.data
                self.setupData()
                if self.status == .end {
                    self.getRankingList()
                }else{
                    self.tableView.reloadData()
                }
            }, onError: { (error) in
                
            })
        .disposed(by: disposeBag)
        
//        provider.rx.request(APITarget.isTransaction(auctionId: auctionId))
//            .map(BaseResponse<AuctionDetailModel>.self)
//            .subscribe(onSuccess: { (res) in
//                let isTransaction = res.success
//            }, onError: { (error) in
//                
//            })
//        .disposed(by: disposeBag)
        
    }
    //收益排行
    func getRankingList() {
        provider.rx.request(APITarget.rankingList(auctionId: auctionId))
            .mapObject(BaseResponse<[RankingListModel]>.self)
            .subscribe(onSuccess: { (res) in
                if let list = res.data {
                    self.rankingList = list
                }
                self.tableView.reloadData()
            }, onError: { (error) in
                
            })
        .disposed(by: disposeBag)
    }

    func setupData() {
        guard let model = model else {
            return
        }
        self.topPrice = model.topPrice ?? 0
        self.nextCashDeposit = model.nextCashDeposit ?? 0
        self.auctionHouseVC.brokerage = model.brokerage ?? 0
        setupStatus()
        let htmlStr = model.goodsDetail.addHtmlHeardImageStyle(title: "")
        self.webView.loadHTMLString(htmlStr, baseURL: nil)
        if let banner = model.headImage {
            let data = banner.data(using: .utf8)!
            if let arr = try? JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) as? [String] {
                headerView.bannerList = arr
            }
        }
    }
    
    //点击拍卖场
    @objc func clickAuctionHouseDetail() {
        showHouse()
    }
    func showHouse() {
        self.auctionHouseVC.isShow = true
        self.auctionHouseVC.view.snp.updateConstraints({ (make) in
            make.left.equalToSuperview()
        })
        self.auctionHouseVC.beginAppearanceTransition(true, animated: true)
        UIView.animate(withDuration: 0.5, animations: {
//            self.auctionHouseVC.view.x = 0
            self.view.layoutIfNeeded()
        }) { (isFinsh) in
            self.auctionHouseVC.endAppearanceTransition()
        }
    }
    @objc func shareAction() {
        /*
        let object = WXMiniProgramObject();
        object.webpageUrl = "https://open.weixin.qq.com"
        object.userName = ""
        object.path = ""
        if let img = headerView.firstImage {
            object.hdImageData = img.jpegData(compressionQuality: 0.7)
        }
        object.withShareTicket = false
        object.miniProgramType = .release
        let message = WXMediaMessage()
        message.title = "一口拍";
        message.description = "新手体验活动 首次充值用户活动 全额退款 老用户禁止";
        message.thumbData = nil;  //兼容旧版本节点的图片，小于32KB，新版本优先
                                  //使用WXMiniProgramObject的hdImageData属性
        message.mediaObject = object;
        let req = SendMessageToWXReq()
        req.bText = false
        req.message = message
        req.scene = Int32(WXSceneSession.rawValue)  //目前只支持会话
        WXApi.send(req)
         */
        
        let webpageObject = WXWebpageObject()
        
        webpageObject.webpageUrl = AppStoreURL
        let message = WXMediaMessage()
        message.title = "欢迎加入一口拍"
        message.description = model?.goodsName ?? ""
        message.setThumbImage(UIImage(named: "img_salesroom_logo")!)
        message.mediaObject = webpageObject
        let req = SendMessageToWXReq()
        req.bText = false
        req.message = message
        req.scene = Int32(WXSceneSession.rawValue)
        WXApi.send(req)
    }
    //竞拍
    @objc func auctionAction() {
        if !auctionHouseVC.isShow {
            showHouse()
        }
        guard UserInfoManager.shared.isLogined else {
            UtilUser.openLogin()
            return
        }
        print("竞拍")
        guard let model = model else {
            return
        }
        let myPrice = topPrice
        provider.rx.request(APITarget.bid(auctionId: model.auctionId, payPrice: myPrice))
        .mapObject(BaseResponse<EmptyResponse>.self, ignoreCode: ["201"])
        .subscribe(onSuccess: { (res) in
            SVProgressHUD.showInfo(withStatus: "出价成功")
        }, onError: { (error) in
            if let err = error as? NetworkError {
                if err.code == "201" {
                    self.alertNoBalance()
                }
            }
        })
        .disposed(by: self.disposeBag)
    }
    
    func alertNoBalance() {
        let alertVC = UIAlertController(title: "您的账号余额不足\n请充值", message: nil, preferredStyle: UIAlertController.Style.alert)
        let cancelAction = UIAlertAction(title: "我知道了", style: UIAlertAction.Style.cancel) { (action) in
        }
        let okAction = UIAlertAction(title: "去充值", style: UIAlertAction.Style.default) { (action) in
            let vc = RechargeViewController()
            self.navigationController?.pushViewController(vc, animated: true)
        }
        alertVC.addAction(cancelAction)
        alertVC.addAction(okAction)
        self.present(alertVC, animated: true, completion: nil)
    }
    
    @objc func clickRule() {
        let vc = WLWebViewController(url: URL(string: kHtml_distRule)!)
        vc.title = "拍卖规则"
        self.navigationController?.pushViewController(vc, animated: true)
    }
    deinit {
        socket.disconnect()
        socket = nil
    }
}
extension AuctionDetailViewController: UITableViewDataSource, UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        if model == nil {
            return 0
        }
        return 5
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return 1
        }else if section == 1 {
            return min(rankingList.count, 5)
        }else if section == 2 {
            return 1
        }else if section == 3 {
            return 1
        }else if section == 4 {
            return 1
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: cellId1, for: indexPath) as! AuctionInfoCell
            cell.selectionStyle = .none
            cell.shopNameLabel.text = model?.goodsName
            let grayAttDic = [NSAttributedString.Key.font : UIFont.systemFont(ofSize: 13), NSAttributedString.Key.foregroundColor : UIColor.gray3]
            let attDic3 = [NSAttributedString.Key.font : UIFont.systemFont(ofSize: 13), NSAttributedString.Key.foregroundColor : UIColor.mainColor]
            let weiguanAttr = NSMutableAttributedString(string: "围观：", attributes: grayAttDic)
            weiguanAttr.append(NSAttributedString(string: "\(model?.viewCount ?? 0)", attributes: attDic3))
            weiguanAttr.append(NSAttributedString(string: "人", attributes: grayAttDic))
            cell.weiguanLabel.attributedText = weiguanAttr
//            if status == .notStarted || status == .started {
                cell.chujiaLabel.attributedText = nil
//            }else{
//                let chujiaAttr = NSMutableAttributedString(string: "出价：", attributes: grayAttDic)
//                weiguanAttr.append(NSAttributedString(string: "\(model?.markupNum ?? 0)", attributes: attDic3))
//                weiguanAttr.append(NSAttributedString(string: "人", attributes: grayAttDic))
//                cell.chujiaLabel.attributedText = chujiaAttr
//            }
            return cell
        }else if indexPath.section == 1 {
            let model = rankingList[indexPath.row]
            let grayAttDic = [NSAttributedString.Key.font : UIFont.systemFont(ofSize: 13), NSAttributedString.Key.foregroundColor: UIColor.gray3]
            let mainAttDic = [NSAttributedString.Key.font : UIFont.systemFont(ofSize: 13), NSAttributedString.Key.foregroundColor: UIColor.mainColor]
            if indexPath.row == 0 {
                let cell = tableView.dequeueReusableCell(withIdentifier: cellId2, for: indexPath) as! AuctionCell1
                cell.selectionStyle = .none
                cell.avatarImgView.kf.setImage(with: URL(string: model.avatar?.toImageURL ?? ""))
                cell.nickLabel.text = model.userName
                
                let attr = NSMutableAttributedString(string: model.num.toString, attributes: mainAttDic)
                attr.append(NSAttributedString(string: "次出价，收益", attributes: grayAttDic))
                attr.append(NSAttributedString(string: "¥"+model.totalPrice.mapToPrice(), attributes: mainAttDic))
                cell.descriptionLabel.attributedText = attr
                return cell
            }else{
                let cell = tableView.dequeueReusableCell(withIdentifier: cellId3, for: indexPath) as! AuctionCell2
                cell.selectionStyle = .none
                cell.imgView.kf.setImage(with: URL(string: model.avatar?.toImageURL ?? ""))
                cell.nickLabel.text = model.userName
                let attr = NSMutableAttributedString(string: model.num.toString, attributes: mainAttDic)
                attr.append(NSAttributedString(string: "次出价", attributes: grayAttDic))
                cell.priceLabel.attributedText = attr
                let attr2 = NSMutableAttributedString(string: "收益", attributes: grayAttDic)
                attr2.append(NSAttributedString(string: "¥"+model.totalPrice.mapToPrice(), attributes: mainAttDic))
                cell.yongjinLabel.attributedText = attr2
                
                return cell
            }
        }else if indexPath.section == 2 {
            if let cell = Bundle.main.loadNibNamed("AuctionCell3", owner: self, options: nil)?.first as? AuctionCell3 {
                cell.selectionStyle = .none
                cell.moneyLabel1.text = "¥"+(model?.startPrice?.mapToPrice() ?? "")
                cell.moneyLabel2.text = "¥"+(model?.markupPrice?.mapToPrice() ?? "")
                cell.moneyLabel3.text = "¥"+(model?.assessPrice?.mapToPrice() ?? "")
                cell.moneyLabel4.text = "¥"+(model?.brokerage?.mapToPrice() ?? "")
                return cell
            }
        }else if indexPath.section == 3 {
            if let cell = Bundle.main.loadNibNamed("AuctionCell4", owner: self, options: nil)?.first as? AuctionCell4 {
                cell.selectionStyle = .none
                return cell
            }
        }else if indexPath.section == 4 {
            let cell = tableView.dequeueReusableCell(withIdentifier: cellId4, for: indexPath)
            cell.selectionStyle = .none
            if webView.superview == nil {
                cell.contentView.addSubview(webView)
                webView.snp.makeConstraints { (make) in
                    make.edges.equalToSuperview()
                }
            }
            return cell
        }
        return UITableViewCell()
    }
    
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 1 {
            if indexPath.row == 0 {
                return 151
            }else{
                return 48
            }
        }else if indexPath.section == 2 {
            return 84
        }else if indexPath.section == 3 {
            return 94
        }else if indexPath.section == 4 && indexPath.row == 0 {//html详情
            return webHeight
        }
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 0 || section == 1 {
            return 0.1
        }
        return 40
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if section == 0 || section == 1 {
            return UIView()
        }else{
            let headerView = Bundle.main.loadNibNamed("AuctionSectionHeaderView", owner: self, options: nil)?.first as? AuctionSectionHeaderView
            headerView?.moreButton.isHidden = true
            if section == 2 {
                headerView?.titleLabel.text = "拍卖须知"
                headerView?.moreButton.isHidden = false
                headerView?.moreButton.addTarget(self, action: #selector(clickRule), for: UIControl.Event.touchUpInside)
            }else if section == 3 {
                headerView?.titleLabel.text = "玩法指南"
            }else if section == 4 {
                headerView?.titleLabel.text = "拍品详情"
            }
            return headerView
        }
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        if section == 0 {
            return 0.1
        }
        return 10
    }
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }
}
extension AuctionDetailViewController: WKNavigationDelegate {
    //页面加载完成
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        print("页面加载完成")
        //原生调用JS方法
        webView.evaluateJavaScript("document.body.offsetHeight;") { (result, error) in
            if let res = result {
                let resFloat = res as? CGFloat
                print("resFloat=\(resFloat)")
                //必须加上一点
                let height = (resFloat ?? 0)+30
                self.webHeight = CGFloat(height)

                self.tableView.reloadData()
            }
        }
    }
}
