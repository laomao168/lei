//
//  PayPasswordController.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/26.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit
import Presentr
//弹窗
let payPresenter: Presentr = {
    let width = ModalSize.custom(size: 265)
    let height = ModalSize.custom(size: 210)
    let presentationType = PresentationType.custom(width: width, height: height, center: .center)
    let presenter = Presentr(presentationType: presentationType)
    presenter.transitionType = TransitionType.coverVertical
    presenter.dismissOnSwipe = false
    presenter.roundCorners = true
        presenter.cornerRadius = 5
    presenter.backgroundOpacity = 0.3
    return presenter
}()
class PayPasswordController: BaseViewController {
    var money: Double = 0
    var forgetBlock: (()-> Void)?
    var completed: ((_ pwd: String)-> Void)?
    @IBOutlet weak var passwordView: WCLPassWordView!
    @IBOutlet weak var moneyLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.layer.cornerRadius = 5
        self.view.layer.masksToBounds = true
        self.moneyLabel.text = "¥"+money.mapToPrice()
        passwordView.delegate = self
        // Do any additional setup after loading the view.
    }
    @IBAction func cancel(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func forgetPassword(_ sender: UIButton) {
        self.dismiss(animated: true) {
            self.forgetBlock?()
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension PayPasswordController: WCLPassWordViewDelegate {
    func passWordCompleteInput(_ passWord: WCLPassWordView!) {
        let text = passWord.textStore! as String
        if text.count != 6 {
            return
        }
        self.dismiss(animated: true) {
            self.completed?(text)
        }
    }
}
