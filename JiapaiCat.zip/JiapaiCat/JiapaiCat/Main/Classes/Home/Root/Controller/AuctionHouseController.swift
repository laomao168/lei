//
//  AuctionHouseController.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/19.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class AuctionHouseController: BaseViewController {
    var auctionId: Int = 0
    var brokerage: Double = 0
    var isShow: Bool = false
    var status: AnctionStatus = .notStarted {
        didSet {
            if status == .end {
                self.timeBgView.isHidden = true
                self.endTimeLabel.isHidden = false
            }else if status == .notStarted {
                self.timeBgView.isHidden = false
                self.endTimeLabel.isHidden = true
                self.timeDesLabel.text = "距开始"
            }else if status == .started {
                self.timeBgView.isHidden = false
                self.endTimeLabel.isHidden = true
                self.timeDesLabel.text = "距结束"
            }
        }
    }
    
    var remainingSeconds: Double = 0 {
        didSet {
            let timeStr = UtilDate.getDayHHMMSSFromSS(seconds: Int(remainingSeconds))
            timeLabel.text = "\(timeStr)"
        }
    }
    
    var backBlock: (() -> Void)?
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var topAvatarImgView: UIImageView!
    
    @IBOutlet weak var timeDesLabel: UILabel!
    @IBOutlet weak var nickLabel: UILabel!
    
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var topPriceLabel: UILabel!
    @IBOutlet weak var timeBgView: UIView!
    @IBOutlet weak var endTimeLabel: UILabel!
    var dataList: [AuctionHouceListModel] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        SVProgressHUD.setDefaultMaskType(SVProgressHUDMaskType.none)
        requestData()
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        SVProgressHUD.setDefaultMaskType(SVProgressHUDMaskType.clear)
    }
    func receiveNewPrice(_ model: AuctionHouceListModel) {
        self.dataList.append(model)
        self.dataListChanged()
    }
    
    func setupUI() {
        self.view.backgroundColor = UIColor.black
        let backButton = UIButton(type: .custom)
        backButton.setTitle(" 》\n点\n击\n查\n看\n商\n品", for: UIControl.State.normal)
        backButton.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        backButton.titleLabel?.numberOfLines = 0
        backButton.setBackgroundColor(UIColor(white: 0, alpha: 0.5), forState: UIControl.State.normal)
        backButton.addTarget(self, action: #selector(back), for: UIControl.Event.touchUpInside)
        self.view.addSubview(backButton)
        backButton.snp.makeConstraints { (make) in
            make.right.equalToSuperview()
            make.centerY.equalToSuperview()
            make.width.equalTo(30)
            make.height.equalTo(120)
        }
        let path = UIBezierPath(roundedRect: CGRect(x: 0, y: 0, width: 30, height: 120), byRoundingCorners: [.topLeft, .bottomLeft], cornerRadii: CGSize(width: 3, height: 3))
        let shapeLayer = CAShapeLayer()
        shapeLayer.path = path.cgPath
        backButton.layer.mask = shapeLayer
        
        self.tableView.backgroundColor = UIColor.clear
        self.tableView.dataSource = self
        self.tableView.delegate = self
        self.tableView.tableFooterView = UIView()
        self.tableView.separatorStyle = .none
        self.tableView.register(UINib(nibName: "AuctionHouseCell", bundle: nil), forCellReuseIdentifier: String(describing: AuctionHouseCell.self))
        self.tableView.register(UINib(nibName: "AuctionHouseCell2", bundle: nil), forCellReuseIdentifier: String(describing: AuctionHouseCell2.self))
        
        self.tableView.register(UINib(nibName: "MyAuctionHouseCell", bundle: nil), forCellReuseIdentifier: String(describing: MyAuctionHouseCell.self))
        

    }

    func requestData() {
        provider.rx.request(APITarget.auctionRecordDetail(auctionId: auctionId, pageNumber: 1, pageSize: 20))
            .mapObject(BaseResponse<AuctionRecordResponse>.self)
            .subscribe(onSuccess: { (res) in
                if let list = res.data?.data {
                    self.dataList = list.reversed()
                }
                self.dataListChanged()
            }, onError: { (error) in
               
            })
        .disposed(by: disposeBag)
    }
    func dataListChanged() {
        self.tableView.reloadData()
        if let topModel = self.dataList.last {
            self.topAvatarImgView.kf.setImage(with: URL(string: topModel.avatar.toImageURL))
            self.nickLabel.text = topModel.userName
            self.topPriceLabel.text = "¥"+topModel.payPrice.mapToPrice()
        }
        //        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+0.5) {
        //
        //        }
        if !self.dataList.isEmpty {
            self.tableView.scrollToRow(at: IndexPath(row: self.dataList.count-1, section: 1), at: UITableView.ScrollPosition.bottom, animated: false)
        }
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
    }
    @objc func back() {
        backBlock?()
    }
    @IBAction func clickTopAction(_ sender: UIButton) {
        self.tableView.scrollToRow(at: IndexPath(row: 0, section: 0), at: UITableView.ScrollPosition.none, animated: false)
//        self.tableView.setContentOffset(.zero, animated: true)
    }
    
}
extension AuctionHouseController: UITableViewDataSource, UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return 1
        }
        return dataList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: AuctionHouseCell2.self), for: indexPath) as! AuctionHouseCell2
            cell.selectionStyle = .none
            cell.msgLabel.text = """
            欢迎大家参与本场拍卖！请仔细阅读下面的拍前须知。
            1.点击右下角红色”出价“按钮，即可出价；如账号余额不够，系统会提示您充值保证金。
            2.保证金比例为拍品当前价格的20%，出价即冻结，出价被超越即释放。
            3.如果本次出价被人超越，则可获得一定的拍卖收益红包奖励。
            4.竞买人出价到达保留价或竞拍时间结束，则竞拍成功。
            5.请在24小时内支付尾款，否则系统将自动关闭并扣除保证金。
            6.只显示最近20条拍卖记录
            希望大家能在一口拍享受到拍卖的乐趣。
            """
            cell.nickLabel.text = "一口拍"
            cell.avatarImgView.image = UIImage(named: "img_salesroom_logo")
            return cell
        }else{
            let model = self.dataList[indexPath.row]
            if model.userId == kUserInfo?.userId {
                let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: MyAuctionHouseCell.self), for: indexPath) as! MyAuctionHouseCell
                cell.selectionStyle = .none
                
                cell.avatarImgView.kf.setImage(with: URL(string: model.avatar.toImageURL))
                cell.timeLabel.text = model.markupTime
                cell.nickLabel.text = model.userName
                cell.msgLabel.text = "出价\(model.payPrice.mapToPrice())元，获得红包\(brokerage.mapToPrice())元。"
                return cell
            }else{
                let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: AuctionHouseCell.self), for: indexPath) as! AuctionHouseCell
                cell.selectionStyle = .none
                
                cell.avatarImgView.kf.setImage(with: URL(string: model.avatar.toImageURL))
                cell.timeLabel.text = model.markupTime
                cell.nickLabel.text = model.userName
                cell.msgLabel.text = "出价\(model.payPrice.mapToPrice())元，获得红包\(brokerage.mapToPrice())元。"
                return cell
            }
        }
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0 {
            return UITableView.automaticDimension
        }
        return 92
    }
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    
}
