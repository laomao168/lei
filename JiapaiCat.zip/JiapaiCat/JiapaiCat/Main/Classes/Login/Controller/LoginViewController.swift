//
//  LoginViewController.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/16.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class LoginViewController: BaseViewController {
    @IBOutlet weak var mobileTF: UITextField!
    
    @IBOutlet weak var codeTF: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "登录"
        // Do any additional setup after loading the view.
    }
    
    @IBAction func sendMsg(_ sender: CountDownButton) {
        let mobile = mobileTF.text!
        if mobile.isEmpty {
            SVProgressHUD.showInfo(withStatus: "请输入手机号")
            return
        }
        guard Validator.isMobileNumber(mobile) else {
            SVProgressHUD.showInfo(withStatus: "手机号格式不对")
            return
        }
        provider.rx.request(APITarget.sendSms(mobile: mobile, use: "register"))
            .mapObject(BaseResponse<EmptyResponse>.self)
            .subscribe(onSuccess: { (res) in
                sender.isCounting = true
            }, onError: { (error) in

            })
        .disposed(by: disposeBag)
    }
    
    @IBAction func submit(_ sender: UIButton) {
        let mobile = mobileTF.text!
        let code = codeTF.text!
        if mobile.isEmpty {
            SVProgressHUD.showInfo(withStatus: "请输入手机号")
            return
        }
        if code.isEmpty {
            SVProgressHUD.showInfo(withStatus: "请输入验证码")
            return
        }
        guard Validator.isMobileNumber(mobile) else {
            SVProgressHUD.showInfo(withStatus: "手机号格式不对")
            return
        }
        
        provider.rx.request(APITarget.appLogin(phone: mobile, verifyCode: code))
            .mapObject(BaseResponse<UserInfoModel>.self)
            .subscribe(onSuccess: { (res) in
                if let token = res.data?.token {
                    UserInfoManager.shared.token = token
                    UserInfoManager.shared.userInfo = res.data
                }
                NotificationCenter.default.post(name: NSNotification.Name.succeedLogin, object: nil)
                self.dismiss(animated: true, completion: nil)
            }, onError: { (error) in

            })
        .disposed(by: disposeBag)
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
