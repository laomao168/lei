//
//  MainViewController.swift
//  caifujutou
//
//  Created by MAC on 2017/9/19.
//  Copyright © 2017年 tomcat360. All rights reserved.
//

import UIKit
import RxSwift
class MainViewController: UITabBarController {
    let disposeBag = DisposeBag()
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        self.tabBar.barTintColor = UIColor.white
        self.tabBar.tintColor = UIColor.mainColor
//        self.tabBar.backgroundImage = UIImage.imageFrom(color: UIColor.white)
//        self.tabBar.shadowImage = UIImage.imageFrom(color: kShadowImageColor)
        //首页
        let homeVC = HomeViewController()
        let homeNav = BaseNavigationController(rootViewController: homeVC)
        
        let mallVC = PointsMallViewController()
        let mallNVC: BaseNavigationController = BaseNavigationController(rootViewController: mallVC)
//        
        let mineVC = MineViewController()
        let mineNVC: BaseNavigationController = BaseNavigationController(rootViewController: mineVC)
        add(viewController: homeNav, title: "首页", normalmageName: "tab_botfixed_home_normal", selectedImageName: "tab_botfixed_home_select")
        add(viewController: mallNVC, title: "积分商城", normalmageName: "tab_botfixed_mall_normal", selectedImageName: "tab_botfixed_mall_select")
        add(viewController: mineNVC, title: "我的", normalmageName: "tab_botfixed_my_normal", selectedImageName: "tab_botfixed_my_select")
        
        self.delegate = self
        getConfigData()
        NotificationCenter.default.addObserver(self, selector: #selector(loginSuccessed), name: NSNotification.Name.succeedLogin, object: nil)
        // Do any additional setup after loading the view.
    }
    
    @objc func loginSuccessed() {
        getConfigData()
    }
    func getConfigData() {
        noHUDprovider.rx.request(APITarget.configKey(sysConfigKey: "rechargeType"))
            .mapObject(BaseResponse<String>.self)
            .subscribe(onSuccess: { (res) in
                if let value = res.data {
                    SysConfig.shared.rechargeType = value
                }
            }, onError: { (error) in
                
            })
        .disposed(by: disposeBag)
    }
    
//    override var preferredStatusBarStyle: UIStatusBarStyle {
//        return .lightContent
//    }
    
//    override var preferredStatusBarStyle: UIStatusBarStyle {
//        return .lightContent
//    }
    
    deinit {
        print("MainViewController销毁")
        NotificationCenter.default.removeObserver(self)
    }

    func add(viewController: UIViewController, title: String, normalmageName: String, selectedImageName: String) {
        viewController.tabBarItem.title = title
        viewController.tabBarItem.image = UIImage(named: normalmageName)?.withRenderingMode(.alwaysOriginal)
        viewController.tabBarItem.selectedImage = UIImage(named: selectedImageName)?.withRenderingMode(.alwaysOriginal)
//        viewController.tabBarItem.landscapeImagePhone = UIImage(named: normalmageName)
//        if #available(iOS 11.0, *) {
//            viewController.tabBarItem.largeContentSizeImage = UIImage(named: normalmageName)
//        } else {
//            // Fallback on earlier versions
//        }
        viewController.tabBarItem.setTitleTextAttributes([NSAttributedString.Key.foregroundColor : UIColor.gray3], for: .normal)
        viewController.tabBarItem.setTitleTextAttributes([NSAttributedString.Key.foregroundColor : mainColor], for: .selected)
        
        self.addChild(viewController)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
}

extension MainViewController: UITabBarControllerDelegate {
    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool {
        let vc = viewController as? BaseNavigationController
        if vc?.viewControllers.first is MineViewController {
            if !UserInfoManager.shared.isLogined {
                UtilUser.openLogin()
                return false
            }
        }
        return true
    }
}
