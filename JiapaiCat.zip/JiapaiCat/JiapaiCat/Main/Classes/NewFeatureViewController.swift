//
//  NewFeatureViewController.swift
//  CBIT
//
//  Created by 刘文利 on 2019/10/30.
//  Copyright © 2019 网泰信息. All rights reserved.
//

import UIKit
import WebKit
class NewFeatureViewController: UIViewController {
    var imageNameList: [String] = []
    var completed: (() -> Void)?
    var scrollView: UIScrollView!
    var pageCotrol: UIPageControl!
    var completedButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        // Do any additional setup after loading the view.
    }
    
    func setupUI() {
        let webView = WKWebView()
        webView.load(URLRequest(url: URL(string: "https://www.baidu.com")!))
        
        self.view.backgroundColor = UIColor.white
        scrollView = UIScrollView()
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.showsVerticalScrollIndicator = false
        scrollView.bounces = true
        scrollView.isPagingEnabled = true
        scrollView.delegate = self
        self.scrollView.backgroundColor = UIColor.white
        self.view.addSubview(scrollView)
        pageCotrol = UIPageControl()
        pageCotrol.pageIndicatorTintColor = UIColor.gray9
        pageCotrol.currentPageIndicatorTintColor = UIColor.mainColor
        self.view.addSubview(pageCotrol)
        completedButton = SubmitButton(type: .custom)
        completedButton.layer.cornerRadius = 5
        completedButton.layer.masksToBounds = true
        completedButton.setTitle("立即体验", for: UIControl.State.normal)
        completedButton.setTitleColor(UIColor.white, for: .normal)
        completedButton.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        completedButton.addTarget(self, action: #selector(clickCompleted), for: UIControl.Event.touchUpInside)
        self.view.addSubview(completedButton)
        completedButton.alpha = 0
        scrollView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
//            make.left.right.top.equalToSuperview()
//            make.bottom.equalToSuperview().offset(-70)
        }
        pageCotrol.snp.makeConstraints { (make) in
            make.bottom.equalToSuperview().offset(-65)
            make.centerX.equalToSuperview()
        }
        completedButton.snp.makeConstraints { (make) in
            make.bottom.equalToSuperview().offset(-88)
            make.centerX.equalToSuperview()
            make.height.equalTo(49)
            make.width.equalTo(250)
        }
        scrollView.contentSize = CGSize(width: SWIDTH*CGFloat(imageNameList.count), height: SHEIGHT)
        pageCotrol.numberOfPages = imageNameList.count
        for (i, item) in imageNameList.enumerated() {
            let imageView = UIImageView(frame: CGRect(x: CGFloat(i)*SWIDTH, y: 0, width: SWIDTH, height: SHEIGHT-65))
            imageView.image = UIImage(named: item)
            imageView.contentMode = .scaleAspectFit
            self.scrollView.addSubview(imageView)
        }
        
    }
    @objc func clickCompleted() {
        completed?()
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension NewFeatureViewController: UIScrollViewDelegate {
    // 滚动视图减速完成，滚动将停止时，调用该方法。一次有效滑动，只执行一次。
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let offsetX = scrollView.contentOffset.x
        let index = Int(offsetX/SWIDTH)
        self.pageCotrol.currentPage = index
        if index == imageNameList.count - 1 {//最后
            UIView.animate(withDuration: 0.25) {
                self.completedButton.alpha = 1
                self.pageCotrol.alpha = 0
            }
        }else{
            self.completedButton.alpha = 0
            self.pageCotrol.alpha = 1
        }
    }
}
