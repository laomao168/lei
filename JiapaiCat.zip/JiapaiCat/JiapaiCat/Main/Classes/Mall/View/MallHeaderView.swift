//
//  MallHeaderView.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/19.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit
import FSPagerView
class MallHeaderView: UICollectionReusableView {
    @IBOutlet weak var pagerView: FSPagerView!
    
    @IBOutlet weak var pageControl: FSPageControl!
    var bannerList: [BannerListModel] = [] {
        didSet {
            if self.bannerList.count <= 1 {
                self.pagerView.automaticSlidingInterval = 0
                self.pagerView.isInfinite = false
            }else{
                self.pagerView.automaticSlidingInterval = 3
                self.pagerView.isInfinite = true
            }
            self.pageControl.numberOfPages = self.bannerList.count
            self.pageControl.currentPage = 0
            self.pagerView.reloadData()
        }
    }
    override init(frame: CGRect) {
        super.init(frame: frame)
        initViews()
    }
    required init?(coder: NSCoder) {
        super.init(coder: coder)
//        initViews()
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        initViews()
    }
    func initViews() {
        setupPagerView()
    }
    
    func setupPagerView() {
        let width = SWIDTH
        let height: CGFloat = width*147/375
        self.pagerView.dataSource = self
        self.pagerView.delegate = self
        self.pagerView.itemSize = CGSize(width: width, height: height)//self.pagerView.frame.size.applying(CGAffineTransform(scaleX: newScale, y: newScale))
        self.pagerView.automaticSlidingInterval = 3
        self.pagerView.interitemSpacing = 0
        self.pagerView.isInfinite = true
        self.pagerView.isScrollEnabled = true
        self.pagerView.scrollDirection = .horizontal
        self.pagerView.register(FSPagerViewCell.self, forCellWithReuseIdentifier: "cell")
        
        self.pageControl.backgroundColor = UIColor.clear
        self.pageControl.contentHorizontalAlignment = .center
        self.pageControl.setFillColor(UIColor(white: 1, alpha: 0.5), for: .normal)
        self.pageControl.setFillColor(UIColor.mainColor, for: .selected)
        self.pageControl.contentInsets = UIEdgeInsets(top: 0, left: 20, bottom: 0, right: 20)
        self.pageControl.hidesForSinglePage = true
    }
    
    @IBAction func clickTypeAction(_ sender: UIButton) {
        let index = sender.tag
        if index == 0 {//换购区
            let vc = GoodsContainerViewController()
            self.currentController()?.navigationController?.pushViewController(vc, animated: true)
        }else if index == 1 {//商城
            let vc = GoodsListViewController()
            vc.goodsType = 1
            vc.boutique = 2
            self.currentController()?.navigationController?.pushViewController(vc, animated: true)
        }else if index == 2 {//我的换购
            guard UserInfoManager.shared.isLogined else {
                UtilUser.openLogin()
                return
            }
            let vc = MallOrderContainerController()
            vc.isRedemption = true
            self.currentController()?.navigationController?.pushViewController(vc, animated: true)
        }else if index == 3 {//商城订单
            guard UserInfoManager.shared.isLogined else {
                UtilUser.openLogin()
                return
            }
            let vc = MallOrderContainerController()
            vc.isRedemption = false
            self.currentController()?.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
}
extension MallHeaderView: FSPagerViewDataSource, FSPagerViewDelegate {
// MARK:- FSPagerViewDataSource
        
    func numberOfItems(in pagerView: FSPagerView) -> Int {
        return bannerList.count
    }


    public func pagerView(_ pagerView: FSPagerView, cellForItemAt index: Int) -> FSPagerViewCell {
        let cell = pagerView.dequeueReusableCell(withReuseIdentifier: "cell", at: index)
        let model = self.bannerList[index]
        cell.imageView?.contentMode = .scaleAspectFill
        cell.imageView?.kf.setImage(with: URL(string: model.image))
        return cell
    }

    func pagerView(_ pagerView: FSPagerView, didSelectItemAt index: Int) {
        /*
         广告跳转类型
         type  ：
            NBYM(1, "内部页面"),
         PMXQ(2, "拍卖详情"),
         PMFL(3, "拍卖分类"),
         BTZ(5, "不跳转"),
         H5(4, "h5页面");
         */
        let model = self.bannerList[index]
        let type = model.type
        guard let linkId = model.linkId, !linkId.isEmpty else {
            return
        }
        if type == 1 {
            if linkId.contains("shareFriend") {
                guard UserInfoManager.shared.isLogined else {
                    UtilUser.openLogin()
                    return
                }
                let vc = InviteFriendController()
                self.currentController()?.navigationController?.pushViewController(vc, animated: true)
            }
        }else if type == 2 {
            if let auctionId = linkId.toInt() {
                let vc = AuctionDetailViewController()
                vc.auctionId = auctionId
                self.currentController()?.navigationController?.pushViewController(vc, animated: true)
            }
        }else if type == 3 {
            if let categoryId = linkId.toInt() {
                let vc = ClassificationController()
                vc.title = model.name
                vc.categoryId = categoryId
                self.currentController()?.navigationController?.pushViewController(vc, animated: true)
            }
        }else if type == 4 {
            if Validator.isURL(string: linkId) {
                let webVC = WLWebViewController(url: URL(string: linkId)!)
               webVC.title = "一口拍"
                
                self.currentController()?.navigationController?.pushViewController(webVC, animated: true)
            }
        }else if type == 5 {
            
        }
    }
    func pagerViewDidScroll(_ pagerView: FSPagerView) {
        guard self.pageControl.currentPage != pagerView.currentIndex else {
            return
        }
        self.pageControl.currentPage = pagerView.currentIndex // Or Use KVO with property "currentIndex"
    }
}
