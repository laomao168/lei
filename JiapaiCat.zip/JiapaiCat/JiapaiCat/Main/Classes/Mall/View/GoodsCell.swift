//
//  GoodsCell.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/19.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class GoodsCell: UICollectionViewCell {
    @IBOutlet weak var imgView: UIImageView!
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
