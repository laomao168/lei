//
//  ConfirmOrderController.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/20.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class ConfirmOrderController: BaseViewController {
    var orderId: Int?
    var goodsId: Int?
    var isMall: Bool = false
    private var selectAddressModel: AddressModel?
    private var orderModel: OrderListModel?
    private var mallGoodsInfoModel: MallGoodsInfoModel?
    
    @IBOutlet weak var stackView: UIStackView!
    
    @IBOutlet weak var noAddressBgView: UIView!
    @IBOutlet weak var addressBgView: UIView!
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var mobileLabel: UILabel!
    
    @IBOutlet weak var addressLabel: UILabel!
    
    @IBOutlet weak var goodsPicImgView: UIImageView!
    
    @IBOutlet weak var goodsNameLabel: UILabel!
    
    @IBOutlet weak var numLabel: UILabel!
    
    @IBOutlet weak var priceLabel: UILabel!
    
    @IBOutlet weak var payTypeBgView: UIView!
    
    lazy var balanceTypeView: PaymentTypeView = {
        let view = Bundle.main.loadNibNamed("PaymentTypeView", owner: self, options: nil)?.first as! PaymentTypeView
        view.tag = 1
        view.imgView.image = UIImage(named: "icon_pay_yue")
        view.typeLabel.text = "账户余额"
        return view
    }()
    lazy var weChatTypeView: PaymentTypeView = {
        let view = Bundle.main.loadNibNamed("PaymentTypeView", owner: self, options: nil)?.first as! PaymentTypeView
        view.imgView.image = UIImage(named: "icon_pay_weixin")
        view.typeLabel.text = "微信"
        view.tag = 2
        return view
    }()
    lazy var alipayTypeView: PaymentTypeView = {
        let view = Bundle.main.loadNibNamed("PaymentTypeView", owner: self, options: nil)?.first as! PaymentTypeView
        view.tag = 3
        view.imgView.image = UIImage(named: "icon_pay_zfb")
        view.typeLabel.text = "支付宝"
        return view
    }()
    lazy var bankCardTypeView: PaymentTypeView = {
        let view = Bundle.main.loadNibNamed("PaymentTypeView", owner: self, options: nil)?.first as! PaymentTypeView
        view.tag = 4
        view.imgView.image = UIImage(named: "icon_pay_yue")
        view.typeLabel.text = "银行卡"
        return view
    }()
    var isSuppotWechat: Bool = true
    var isSuppotAlipay: Bool = true
    var isSuppotBankCard: Bool = false
    var payTypeSelectIndex: Int = 1
    var balance: Double?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "支付"
        requestData()
        
        NotificationCenter.default.addObserver(self, selector: #selector(wechatPayResult(_:)), name: NSNotification.Name.wechatPayResult, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(alipaymentResult(_:)), name: NSNotification.Name.alipayResult, object: nil)
        // Do any additional setup after loading the view.
    }
    
    func setupPayType() {
        self.stackView.addArrangedSubview(balanceTypeView)
        balanceTypeView.clickButton.addTarget(self, action: #selector(clickPayTypeAction(_:)), for: .touchUpInside)
        
        //1微信，2原生支付宝，3 第三方支付宝，4微信，原生支付宝5微信，第三方支付宝
        let rechargeType = SysConfig.shared.rechargeType
        clickPayTypeView(balanceTypeView)
        if rechargeType == "1" {
            isSuppotBankCard = false
            isSuppotWechat = true
            isSuppotAlipay = false
        }else if rechargeType == "2" {
            isSuppotBankCard = false
            isSuppotWechat = false
            isSuppotAlipay = true
        }else if rechargeType == "3" {
            isSuppotBankCard = true
            isSuppotWechat = false
            isSuppotAlipay = false
        }else if rechargeType == "4" {
            isSuppotBankCard = false
            isSuppotWechat = true
            isSuppotAlipay = true
        }else if rechargeType == "5" {
            isSuppotBankCard = true
            isSuppotWechat = true
            isSuppotAlipay = false
        }
        
        if isSuppotWechat {
            self.stackView.addArrangedSubview(weChatTypeView)
            weChatTypeView.clickButton.addTarget(self, action: #selector(clickPayTypeAction(_:)), for: .touchUpInside)
        }
        if isSuppotAlipay {
            self.stackView.addArrangedSubview(alipayTypeView)
            alipayTypeView.clickButton.addTarget(self, action: #selector(clickPayTypeAction(_:)), for: .touchUpInside)
        }
        if isSuppotBankCard {
            self.stackView.addArrangedSubview(bankCardTypeView)
            weChatTypeView.clickButton.addTarget(self, action: #selector(clickPayTypeAction(_:)), for: .touchUpInside)
        }
    }
    
    @objc func wechatPayResult(_ noti: Notification) {
        guard let errCode = noti.userInfo?["errCode"] as? Int else {
            return
        }
        if errCode == 0 {//0:成功,-1:错误
            let vc = BuySuccessController()
            vc.isMall = self.isMall
            vc.orderId = self.orderId
            self.navigationController?.pushViewController(vc, animated: true)
        }else if errCode == -1 {
            SVProgressHUD.showInfo(withStatus: "支付错误")
        }else if errCode == -2 {
            SVProgressHUD.showInfo(withStatus: "支付取消")
        }
    }
    @objc func alipaymentResult(_ noti: Notification) {
        guard let resultStatus = noti.userInfo?["resultStatus"] as? String else {
            return
        }
        alipayResult(resultStatus)
    }
    
    @objc func clickPayTypeAction(_ sender: UIButton) {
        guard let typeView = sender.superview as? PaymentTypeView else {
            return
        }
        if payTypeSelectIndex == typeView.tag {
            return
        }
        clickPayTypeView(typeView)
    }
    func clickPayTypeView(_ typeView: PaymentTypeView) {
        payTypeSelectIndex = typeView.tag
        balanceTypeView.isSelectButton.isSelected = false
        weChatTypeView.isSelectButton.isSelected = false
        alipayTypeView.isSelectButton.isSelected = false
        bankCardTypeView.isSelectButton.isSelected = false
        
        typeView.isSelectButton.isSelected = true
    }
    
    func requestData() {
        if isMall {
            if let orderId = self.orderId {//已经生成订单了
                provider.rx.request(APITarget.mallPrePayOrderByOrderId(orderId: orderId))
                    .mapObject(BaseResponse<MallPayOrderModel>.self)
                    .subscribe(onSuccess: { (res) in
                        if let address = res.data?.memberAddress {
                            self.selectAddressModel = address
                        }
                        self.setupSelectAddress()
                        if let model = res.data?.mallGoodsInfo {
                            self.mallGoodsInfoModel = model
                            self.goodsNameLabel.text = model.goodsName
                            self.goodsPicImgView.kf.setImage(with: URL(string: model.logo))
                            var priceText = "\(model.integral.mapToPrice())积分"
                            if model.priceType == 2, let price = model.price {
                                priceText = priceText + "+¥\(price.mapToPrice())"
                                self.payTypeBgView.isHidden = false
                                self.setupPayType()
                            }else{
                                self.payTypeBgView.isHidden = true
                            }
                            self.priceLabel.text = priceText
                        }
                    }, onError: { (error) in
                    })
                .disposed(by: disposeBag)
            }else{
                provider.rx.request(APITarget.mallPrePayOrder(goodsId: goodsId ?? 0))
                    .mapObject(BaseResponse<MallPayOrderModel>.self)
                    .subscribe(onSuccess: { (res) in
                        if let address = res.data?.memberAddress {
                            self.selectAddressModel = address
                        }
                        self.setupSelectAddress()
                        if let model = res.data?.mallGoodsInfo {
                            self.mallGoodsInfoModel = model
                            self.goodsNameLabel.text = model.goodsName
                            self.goodsPicImgView.kf.setImage(with: URL(string: model.logo))
                            var priceText = "\(model.integral.mapToPrice())积分"
                            if model.priceType == 2, let price = model.price {
                                priceText = priceText + "+¥\(price.mapToPrice())"
                                self.payTypeBgView.isHidden = false
                                self.setupPayType()
                            }else{
                                self.payTypeBgView.isHidden = true
                            }
                            self.priceLabel.text = priceText
                        }
                    }, onError: { (error) in
                    })
                .disposed(by: disposeBag)
            }
        }else{
            provider.rx.request(APITarget.prePayOrder(orderId: orderId ?? 0))
                .mapObject(BaseResponse<PrePayOrderModel>.self)
                .subscribe(onSuccess: { (res) in
                    if let address = res.data?.memberAddress {
                        self.selectAddressModel = address
                    }
                    self.setupSelectAddress()
                    if let order = res.data?.order {
                        self.orderModel = order
                        self.goodsNameLabel.text = order.goodsName
                        self.goodsPicImgView.kf.setImage(with: URL(string: order.logo))
                        self.priceLabel.text = "¥"+(order.orderPrice?.mapToPrice() ?? "")
                    }
                }, onError: { (error) in
                    
                })
            .disposed(by: disposeBag)
        }
        
        provider.rx.request(APITarget.balanceAndIntegralAndFans)
            .mapObject(BaseResponse<MyBalanceInfoModel>.self)
            .subscribe(onSuccess: { (res) in
                self.balance = res.data?.amount
                
                let attr = NSMutableAttributedString(string: "账户余额\n", attributes: [NSAttributedString.Key.foregroundColor : UIColor.gray3])
                attr.append(NSAttributedString(string: "(¥\(self.balance?.mapToPrice() ?? "0"))", attributes: [NSAttributedString.Key.foregroundColor : UIColor.gray6]))
                self.balanceTypeView.typeLabel.attributedText = attr
            }, onError: { (error) in
                
            })
        .disposed(by: disposeBag)
    }
    func setupSelectAddress() {
        if let model = selectAddressModel {
            self.addressBgView.isHidden = false
            self.noAddressBgView.isHidden = true
            let address = "\(model.provinceText!)\(model.cityText!)\(model.districtText!)\(model.streetText!)\(model.address!)"
            self.addressLabel.text = address
            self.nameLabel.text = model.consignee
            self.mobileLabel.text = model.mobile
        }else{
            self.addressBgView.isHidden = true
            self.noAddressBgView.isHidden = false
        }
    }
    
    @IBAction func clickAddressAction(_ sender: UIButton) {
        let addressVC = ShippingAddressController()
        addressVC.selectAddress = {[weak self] (address) in
            self?.selectAddressModel = address
            self?.setupSelectAddress()
        }
        self.navigationController?.pushViewController(addressVC, animated: true)
    }
    
    @IBAction func confirmAction(_ sender: UIButton) {
        guard let addressId = selectAddressModel?.addressId else {
            SVProgressHUD.showInfo(withStatus: "请选择收货地址")
            return
        }
        //orderType: 3充值，1拍卖，2商场，type：1订单 2商品 payType:1余额 2微信 3支付宝 4积分
        var goodsId: Int?
        var orderId: Int?
        var money: Double = 0
        var orderType: Int = 0
        var type: Int = 0
        var payType = payTypeSelectIndex
        if isMall {
            goodsId = mallGoodsInfoModel?.goodsId
            money = mallGoodsInfoModel?.price ?? 0
            if self.orderId == nil {
                type = 2
                orderId = nil
            }else{
                type = 1
                orderId = self.orderId
            }
            orderType = 2
            if mallGoodsInfoModel?.priceType == 1 && mallGoodsInfoModel?.price == nil {
                payType = 4
            }
        }else{
            goodsId = orderModel?.goodsId
            orderId = orderModel?.orderId
            money = orderModel?.orderPrice ?? 0
            type = 1
            orderType = 1
        }
        let payPwdVC = PayPasswordController()
        payPwdVC.money = money
        payPwdVC.forgetBlock = {[weak self] in
            let vc = SetPasswordViewController()
            self?.navigationController?.pushViewController(vc, animated: true)
        }
        if payType == 1 {
            payPwdVC.completed = {[weak self] (pwd) in
                guard let `self` = self else {
                    return
                }
                let pwdEncry = pwd.getRSAEncry()
                provider.rx.request(APITarget.commonOrder(orderType: orderType, type: type, payType: payType, amount: nil, goodsId: goodsId, addressId: addressId, payPassWord: pwdEncry, orderId: orderId))
                       .mapObject(BaseResponse<Int>.self)
                       .subscribe(onSuccess: { (res) in
                           let vc = BuySuccessController()
                            vc.isMall = self.isMall
                            vc.orderId = res.data
                            self.navigationController?.pushViewController(vc, animated: true)
                       }, onError: { (error) in

                       })
                       .disposed(by: self.disposeBag)
            }
            self.customPresentViewController(payPresenter, viewController: payPwdVC, animated: true)
        }else if payType == 2 {
            provider.rx.request(APITarget.commonOrder(orderType: orderType, type: type, payType: payType, amount: nil, goodsId: goodsId, addressId: addressId, payPassWord: nil, orderId: orderId))
            .mapObject(BaseResponse<RechargeWechatModel>.self)
            .subscribe(onSuccess: { (res) in
                if let model = res.data {
                    self.paymentWechat(orderModel: model)
                }
            }, onError: { (error) in

            })
            .disposed(by: self.disposeBag)
        }else if payType == 3 {
            provider.rx.request(APITarget.commonOrder(orderType: orderType, type: type, payType: payType, amount: nil, goodsId: goodsId, addressId: addressId, payPassWord: nil, orderId: orderId))
            .mapObject(BaseResponse<RechargeAlipayModel>.self)
            .subscribe(onSuccess: { (res) in
                if let order = res.data?.order {
                    self.paymentAlipay(orderInfo: order)
                }
            }, onError: { (error) in

            })
            .disposed(by: self.disposeBag)
        }else if payType == 4 {
            provider.rx.request(APITarget.commonOrder(orderType: orderType, type: type, payType: payType, amount: nil, goodsId: goodsId, addressId: addressId, payPassWord: nil, orderId: orderId))
            .mapObject(BaseResponse<Int>.self)
            .subscribe(onSuccess: { (res) in
                let vc = BuySuccessController()
                vc.isMall = self.isMall
                vc.orderId = res.data
                self.navigationController?.pushViewController(vc, animated: true)
            }, onError: { (error) in

            })
            .disposed(by: self.disposeBag)
        }
    }

    //微信支付
    func paymentWechat(orderModel: RechargeWechatModel) {
        if WXApi.isWXAppInstalled() && WXApi.isWXAppSupport() {//检查微信是否已被用户安装
            let req = PayReq()
            req.partnerId = orderModel.partnerId ?? ""
            req.prepayId = orderModel.prepayId ?? ""
            req.package = orderModel.package ?? "Sign=WXPay"
            req.nonceStr = orderModel.nonceStr ?? ""
            req.timeStamp = UInt32(orderModel.timeStamp?.toInt() ?? 0)
            req.sign = orderModel.sign ?? ""
            WXApi.send(req)
        }else{
            SVProgressHUD.showInfo(withStatus: "请更新当前微信版本!")
        }
    }
    func paymentAlipay(orderInfo: String) {
        //应用注册scheme,在AliSDKDemo-Info.plist定义URL types
        let appScheme = kAppScheme
        // NOTE: 将签名成功字符串格式化为订单字符串,请严格按照该格式
        AlipaySDK.defaultService()?.payOrder(orderInfo, fromScheme: appScheme, callback: { (resultDic) in
            print("resultDic = \(resultDic)")
            let resultStatus = (resultDic?["resultStatus"] as? String) ?? ""
            self.alipayResult(resultStatus)
        })
    }
    func alipayResult(_ resultStatus: String) {
        /*
         /*
         9000    订单支付成功
         8000    正在处理中，支付结果未知（有可能已经支付成功），请查询商户订单列表中订单的支付状态
         4000    订单支付失败
         5000    重复请求
         6001    用户中途取消
         6002    网络连接出错
         6004    支付结果未知（有可能已经支付成功），请查询商户订单列表中订单的支付状态
         其它    其它支付错误
         */
         */
        if resultStatus == "9000" {
            let vc = BuySuccessController()
            vc.isMall = self.isMall
            vc.orderId = self.orderId
            self.navigationController?.pushViewController(vc, animated: true)
        }else if resultStatus == "8000" {
            SVProgressHUD.showInfo(withStatus: "正在处理中")
        }else if resultStatus == "4000" {
            SVProgressHUD.showInfo(withStatus: "订单支付失败")
        }else if resultStatus == "5000" {
            SVProgressHUD.showInfo(withStatus: "重复请求")
        }else if resultStatus == "6001" {
            SVProgressHUD.showInfo(withStatus: "用户中途取消")
        }else if resultStatus == "6002" {
            SVProgressHUD.showInfo(withStatus: "网络连接出错")
        }else if resultStatus == "6004" {
            SVProgressHUD.showInfo(withStatus: "正在处理中")
        }else{
            SVProgressHUD.showInfo(withStatus: "其它支付错误")
        }
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
