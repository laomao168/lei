//
//  OrderListController.swift
//  CBIT
//
//  Created by 刘文利 on 2019/11/7.
//  Copyright © 2019 网泰信息. All rights reserved.
//

import UIKit
import XLPagerTabStrip
import Presentr
class OrderListController: BaseTableViewController, IndicatorInfoProvider {
    //弹窗
    let cancelOrderPresenter: Presentr = {
        let width = ModalSize.sideMargin(value: 40)
        let height = ModalSize.custom(size: 367)
        let presentationType = PresentationType.custom(width: width, height: height, center: .center)
        let presenter = Presentr(presentationType: presentationType)
        presenter.transitionType = TransitionType.coverVertical
        presenter.dismissOnSwipe = false
        presenter.roundCorners = true
        presenter.cornerRadius = 8
        presenter.backgroundOpacity = 0.3
        return presenter
    }()
    var style: OrderStyle = OrderStyle.all
    var dataList: [OrderListModel] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.pageNumber = 1
        self.requestData()
    }
    override func requestData() {
        //订单状态: 未付款-unpaid 已支付-haspaid 已发货-send 已收货/待评价-hassend 完成-finish 已取消(关闭)-cancel
        print("style=\(style)")
        var status = ""
        switch style {
        case .all:
            break
        case .pendingPayment:
            status = "0"
        case .delivered:
            status = "1"
        case .pendingReceipt:
            status = "2"
        case .completed:
            status = "3"
        }
        provider.rx.request(APITarget.orderList(pageNumber: self.pageNumber, pageSize: self.pageSize, current: 1, orderStatus: status))
            .mapObject(BaseResponse<PageResponse<[OrderListModel]>>.self)
            .subscribe(onSuccess: { (res) in
                self.endRefresh(res.data?.page?.totalPage)
                if self.pageNumber == 1 {
                    self.dataList.removeAll()
                }
                if let list = res.data?.data {
                    self.dataList += list
                }
                self.tableView.reloadData()
            }, onError: { (error) in
                self.endRefresh()
            })
        .disposed(by: disposeBag)
    }
    func setupUI() {
        self.tableView.tableHeaderView = UIView(frame: CGRect(x: 0, y: 0, w: SWIDTH, h: 10))
        tableView.separatorColor = UIColor.separatorColor
        tableView.register(UINib(nibName: "OrderListCell", bundle: nil), forCellReuseIdentifier: String(describing: OrderListCell.self))
        tableView.backgroundColor = UIColor.tableViewBg
    }
    
    @objc func viewDetail(_ sender: UIButton) {
        let index = sender.tag
        let model = self.dataList[index]
        let vc = OrderDetailController()
        vc.isMall = false
        vc.orderId = model.orderId
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
//    //付款
//    @objc func payment(_ sender: UIButton) {
//        let index = sender.tag
//        let model = self.dataList[index]
//        let vc = ConfirmOrderController()
//        vc.orderId = model.orderId
//        self.navigationController?.pushViewController(vc, animated: true)
//    }
//    //收货
//    @objc func confirmReceipt(_ sender: UIButton) {
//        let index = sender.tag
//        let model = self.dataList[index]
//
//        provider.rx.request(APITarget.orderReceipt(orderId: model.orderId))
//            .mapObject(BaseResponse<EmptyResponse>.self)
//            .subscribe(onSuccess: { (res) in
//                self.pageNumber = 1
//                self.requestData()
//            }, onError: { (error) in
//
//            })
//        .disposed(by: disposeBag)
//
//    }
    
    func indicatorInfo(for pagerTabStripController: PagerTabStripViewController) -> IndicatorInfo {
        switch style {
        case .all:
            return "全部"
        case .pendingPayment:
            return "待付款"
        case .delivered:
            return "待发货"
        case .pendingReceipt:
            return "待收货"
        case .completed:
            return "已完成"
        }
    }
}
extension OrderListController {
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if dataList.isEmpty {
            return 1
        }
        return dataList.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if dataList.isEmpty {
            return EmptyDataCell()
        }
        let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: OrderListCell.self), for: indexPath) as! OrderListCell
        cell.selectionStyle = .none
        
        let model = dataList[indexPath.row]
        cell.viewDetailButton.tag = indexPath.row
        cell.viewDetailButton.addTarget(self, action: #selector(viewDetail(_:)), for: UIControl.Event.touchUpInside)
        cell.goodsPicImgView.kf.setImage(with: URL(string: model.logo))
        cell.timeLabel.text = model.createTime
        cell.goodsNameLabel.text = model.goodsName
        cell.priceLabel.text = "成交价：¥\(model.transactionPrice?.mapToPrice() ?? "")"
        cell.statusButton.isHidden = true
        cell.statusButton.tag = indexPath.row
        
        if model.orderStatus == 0 {//待付款
            cell.statusLabel.text = "待付款"
            cell.statusButton.isHidden = false
            cell.statusButton.setTitle("立即付款", for: UIControl.State.normal)
            cell.statusButton.addTarget(self, action: #selector(viewDetail(_:)), for: UIControl.Event.touchUpInside)
        }else if model.orderStatus == 1 {//待发货
            cell.statusLabel.text = "待发货"
        }else if model.orderStatus == 2 {//待收货
            cell.statusLabel.text = "待收货"
            cell.statusButton.isHidden = false
            cell.statusButton.setTitle("确认收货", for: UIControl.State.normal)
            cell.statusButton.addTarget(self, action: #selector(viewDetail(_:)), for: UIControl.Event.touchUpInside)
        }else if model.orderStatus == 3 {//完成
            cell.statusLabel.text = "交易完成"
        }else if model.orderStatus == 5 {
            cell.statusLabel.text = "已取消"
        }else if model.orderStatus == 6 {
            cell.statusLabel.text = "交易关闭"
        }else{//4
            cell.statusLabel.text = "交易失败"
        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if dataList.isEmpty {
            return EmptyDataCell.emptyHeight
        }
        return 196
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if dataList.isEmpty {
            return
        }
        
    }
}
