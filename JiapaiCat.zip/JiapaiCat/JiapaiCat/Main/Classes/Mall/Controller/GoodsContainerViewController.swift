//
//  GoodsContainerViewController.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2020/1/13.
//  Copyright © 2020 刘文利. All rights reserved.
//

import UIKit
import XLPagerTabStrip
import RxSwift
class GoodsContainerViewController: ButtonBarPagerTabStripViewController {
    let disposeBag = DisposeBag()
    var typeList: [MallTypeListModel] = []
    override func viewDidLoad() {
        setupButtonBar()
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        self.title = "换购区"
        if #available(iOS 11.0, *) {
            self.containerView.contentInsetAdjustmentBehavior = .never
        } else {
            // Fallback on earlier versions
            self.automaticallyAdjustsScrollViewInsets = false
        }
        self.buttonBarView.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            make.left.right.equalToSuperview()
            make.height.equalTo(47)
        }
        self.containerView.snp.makeConstraints { (make) in
            make.top.equalTo(self.buttonBarView.snp.bottom)
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        requestData()
        // Do any additional setup after loading the view.
    }
    func requestData() {
        
        provider.rx.request(APITarget.mallTypeList(goodsType: 2))
            .mapObject(BaseResponse<[MallTypeListModel]>.self)
            .subscribe(onSuccess: { (res) in
                self.typeList = res.data ?? []
                self.reloadPagerTabStripView()
            }, onError: { (error) in
                
            })
        .disposed(by: disposeBag)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    func setupButtonBar() {
        settings.style.buttonBarBackgroundColor = .white
        settings.style.buttonBarItemBackgroundColor = .white
        settings.style.selectedBarBackgroundColor = .clear
        settings.style.buttonBarItemFont = UIFont.systemFont(ofSize: 13)
        settings.style.selectedBarHeight = 2
        settings.style.buttonBarMinimumLineSpacing = 0
        settings.style.buttonBarMinimumInteritemSpacing = 0
        settings.style.buttonBarItemTitleColor = UIColor.gray3
        settings.style.buttonBarItemsShouldFillAvailableWidth = true
        settings.style.buttonBarLeftContentInset = 0
        settings.style.buttonBarRightContentInset = 0
        changeCurrentIndexProgressive = {  (oldCell: ButtonBarViewCell?, newCell: ButtonBarViewCell?, progressPercentage: CGFloat, changeCurrentIndex: Bool, animated: Bool) -> Void in
            guard changeCurrentIndex == true else { return }
            oldCell?.label.textColor = UIColor.gray3
            newCell?.label.textColor = UIColor.mainColor
        }
    }

    // MARK: - PagerTabStripDataSource
    override func viewControllers(for pagerTabStripController: PagerTabStripViewController) -> [UIViewController] {
        var list = [UIViewController]()
        if typeList.isEmpty {
            let vc1 = EmptyOpenNodeController()
            list.append(vc1)
        }else{
            let vc1 = GoodsListViewController()
            vc1.goodsType = 2
            vc1.boutique = 2
            list.append(vc1)
        }
        for type in typeList {
            let vc = GoodsListViewController()
            vc.type = type
            vc.goodsType = 2
            vc.boutique = 2
            list.append(vc)
        }
        return list
    }

}
