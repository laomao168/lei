//
//  GoodsListViewController.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2020/1/13.
//  Copyright © 2020 刘文利. All rights reserved.
//

import UIKit
import XLPagerTabStrip
import MJRefresh
class GoodsListViewController: BaseViewController, IndicatorInfoProvider {
    var goodsType: Int?
    var boutique: Int?
    var type: MallTypeListModel?
    var pageNumber: Int = 1
    var pageSize: Int = 20
    lazy var collectionView: UICollectionView = {
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        let collectionView = UICollectionView(frame: CGRect.zero, collectionViewLayout: layout)
        collectionView.backgroundColor = UIColor.tableViewBg
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.showsVerticalScrollIndicator = false
        
        let margin: CGFloat = 15
        let space: CGFloat = 10
        layout.minimumInteritemSpacing = space
        layout.minimumLineSpacing = space
        let itemW = (SWIDTH-2*margin-1*space)/2
        let itemH: CGFloat = itemW+60
        layout.itemSize = CGSize(width: itemW, height: itemH)
        layout.sectionInset = UIEdgeInsets(top: 10, left: margin, bottom: 10, right: margin)
        return collectionView
    }()
    var dataList: [MallGoodsInfoModel] = []
    var emptyDelegate: EmptyDataDelegate!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "寄拍区"
        self.view.addSubview(collectionView)
        collectionView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        setupUI()
        addRefresh()
        requestData()
        // Do any additional setup after loading the view.
    }
    func addRefresh() {
        let header = MJRefreshNormalHeader {[weak self] in
            self?.pageNumber = 1
            self?.requestData()
        }
        header.lastUpdatedTimeLabel?.isHidden = true
        collectionView.mj_header = header
        
        let footer = MJRefreshBackNormalFooter{[weak self] in
            self?.pageNumber += 1
            self?.requestData()
        }
        collectionView.mj_footer = footer
    }
    
    func setupUI() {
        emptyDelegate = EmptyDataDelegate(scrollView: self.collectionView)
        self.collectionView.emptyDataSetSource = emptyDelegate
        self.collectionView.emptyDataSetDelegate = emptyDelegate
        collectionView.register(UINib(nibName: "GoodsCell", bundle: nil), forCellWithReuseIdentifier: String(describing: GoodsCell.self))
    }
    
    func requestData() {
        provider.rx.request(APITarget.mallGoodsInfoList(pageNumber: self.pageNumber, pageSize: self.pageSize, goodsType: goodsType, boutique: boutique, categoryId: type?.value))
            .mapObject(BaseResponse<PageResponse<[MallGoodsInfoModel]>>.self)
            .subscribe(onSuccess: { (res) in
                self.emptyDelegate.emptyDataStyle = .noData
                self.endRefresh(res.data?.page?.totalPage)
                if self.pageNumber == 1 {
                    self.dataList.removeAll()
                }
                if let list = res.data?.data {
                    self.dataList += list
                }
                self.collectionView.reloadData()
            }, onError: { (error) in
                self.emptyDelegate.emptyDataStyle = .noData
                self.endRefresh()
            })
        .disposed(by: disposeBag)
    }
    
    func endRefresh(_ totalPages: Int? = -1) {
        let totalPage = totalPages ?? 0
        self.collectionView.mj_header?.endRefreshing()
        if totalPage > -1 && pageNumber >= totalPage-1 {
            self.collectionView.mj_footer?.endRefreshingWithNoMoreData()
        }else{
            self.collectionView.mj_footer?.endRefreshing()
        }
    }

    func indicatorInfo(for pagerTabStripController: PagerTabStripViewController) -> IndicatorInfo {
        return IndicatorInfo(title: type?.text ?? "推荐")
    }
}
extension GoodsListViewController: UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return dataList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: String(describing: GoodsCell.self), for: indexPath) as! GoodsCell
        cell.backgroundColor = UIColor.white
        cell.layer.cornerRadius = 5
        cell.layer.masksToBounds = true
        let model = dataList[indexPath.row]
        
        cell.imgView.kf.setImage(with: URL(string: model.logo))
        cell.nameLabel.text = model.goodsName
        var priceText = "\(model.integral.mapToPrice())积分"
        if model.priceType == 2, let price = model.price {
            priceText = priceText + "+¥\(price.mapToPrice())"
        }
        cell.priceLabel.text = priceText
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let model = dataList[indexPath.row]
        let vc = ShopDetailController()
        vc.id = model.goodsId
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
