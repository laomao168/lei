//
//  OrderDetailController.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/20.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class OrderDetailController: BaseViewController {
    var orderId: Int = 0
    var isMall: Bool = false
    private var orderDetailModel: OrderListModel?
    var status: OrderStatus {
        if let state = orderDetailModel?.orderStatus {
            let a = OrderStatus(rawValue: state) ?? .fail
            return a
        }
        return .fail
    }
    @IBOutlet weak var createTimeLabel: UILabel!
    @IBOutlet weak var payTimeLabel: UILabel!
    @IBOutlet weak var shipTimeLabel: UILabel!//收货时间
    @IBOutlet weak var closingTimeLabel: UILabel!//交易时间
    @IBOutlet weak var statusLabel: UILabel!
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var mobileLabel: UILabel!
    @IBOutlet weak var addressLabel: UILabel!
    @IBOutlet weak var goodsPicImgView: UIImageView!
    
    @IBOutlet weak var goodsNameLabel: UILabel!
    @IBOutlet weak var moneyLabel: UILabel!
    
    @IBOutlet weak var courierCompanyLabel: UILabel!
    
    @IBOutlet weak var trackNoLabel: UILabel!
    
    @IBOutlet weak var addressBgView: UIView!
    
    @IBOutlet weak var deliveryInfoBgView: UIView!
    
    @IBOutlet weak var confirmButton: SubmitButton!
    
    @IBOutlet weak var paymentTipsLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "订单详情"
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        requestData()
    }

    func requestData() {
        if isMall {
            provider.rx.request(APITarget.mallOrderDetail(orderId: orderId))
                .mapObject(BaseResponse<MallOrderListModel>.self)
                .subscribe(onSuccess: { (res) in
                    self.orderDetailModel = res.data
                    self.setupData()
                }, onError: { (error) in
                    
                })
            .disposed(by: disposeBag)
        }else{
            provider.rx.request(APITarget.orderDetail(orderId: orderId))
                .mapObject(BaseResponse<OrderListModel>.self)
                .subscribe(onSuccess: { (res) in
                    self.orderDetailModel = res.data
                    self.setupData()
                }, onError: { (error) in
                    
                })
            .disposed(by: disposeBag)
        }
    }
    func setupData() {
        guard let model = orderDetailModel else {
            return
        }
        self.goodsPicImgView.kf.setImage(with: URL(string: model.logo))
        self.goodsNameLabel.text = model.goodsName
        if isMall {
            let mallOrderModel = model as! MallOrderListModel
            var priceText = "\(mallOrderModel.integral?.mapToPrice() ?? "0")积分"
            if mallOrderModel.priceType == 2, let price = mallOrderModel.price {
                priceText = priceText + "+¥\(price.mapToPrice())"
            }
            self.moneyLabel.text = priceText
        }else{
            self.moneyLabel.text = "¥"+(model.transactionPrice?.mapToPrice() ?? "")
        }
        self.createTimeLabel.text = "下单时间："+(model.createTime ?? "")
        
        self.statusLabel.text = status.description
        paymentTipsLabel.isHidden = true
        self.payTimeLabel.isHidden = false
        self.shipTimeLabel.isHidden = false
        self.closingTimeLabel.isHidden = false
        self.addressBgView.isHidden = false
        self.deliveryInfoBgView.isHidden = false
        if status == .pendingPayment {
            let attr = NSMutableAttributedString(string: "支付截止时间：", attributes: [NSAttributedString.Key.foregroundColor : UIColor.gray3])
            attr.append(NSAttributedString(string: (model.endDate ?? "无"), attributes: [NSAttributedString.Key.foregroundColor : UIColor.mainColor]))
            self.payTimeLabel.attributedText = attr
            self.shipTimeLabel.isHidden = true
            self.closingTimeLabel.isHidden = true
            self.addressBgView.isHidden = true
            self.deliveryInfoBgView.isHidden = true
            self.confirmButton.isHidden = false
            self.confirmButton.setTitle("去支付", for: UIControl.State.normal)
            let submitAttr = NSMutableAttributedString(string: "去支付", attributes: [NSAttributedString.Key.font : UIFont.systemFont(ofSize: 18), NSAttributedString.Key.foregroundColor : UIColor.white])
            var orderPriceText = ""
            if isMall {
                let mallOrderModel = model as! MallOrderListModel
                orderPriceText = "\(mallOrderModel.integral?.mapToPrice() ?? "0")积分"
                if mallOrderModel.priceType == 2, let price = mallOrderModel.price {
                    orderPriceText = orderPriceText + "+¥\(price.mapToPrice())"
                }
                if mallOrderModel.goodsType == 2 {//商城订单描述不同
                    switch status {
                    case .pendingPayment:
                        self.statusLabel.text = "待付款"
                    case .delivered:
                        self.statusLabel.text = "待处理"
                    case .pendingReceipt:
                        self.statusLabel.text = "处理中"
                    case .completed:
                        self.statusLabel.text = "处理完成"
                    case .fail:
                        self.statusLabel.text = "交易失败"
                    case .cancel:
                        self.statusLabel.text = "已取消"
                    case .close:
                        self.statusLabel.text = "交易关闭"
                    }
                }
                paymentTipsLabel.isHidden = true
                orderPriceText = "（\(orderPriceText)）"
            }else{
                orderPriceText = "（尾款¥\(model.orderPrice?.mapToPrice() ?? "")）"
                paymentTipsLabel.isHidden = false
            }
            submitAttr.append(NSAttributedString(string: orderPriceText, attributes: [NSAttributedString.Key.font : UIFont.systemFont(ofSize: 13), NSAttributedString.Key.foregroundColor : UIColor.white]))
            self.confirmButton.setAttributedTitle(submitAttr, for: UIControl.State.normal)
        }else if status == .delivered {
            self.payTimeLabel.text = "付款时间："+(model.payTime ?? "无")
            self.shipTimeLabel.isHidden = true
            self.closingTimeLabel.isHidden = true
            self.confirmButton.isHidden = true
            self.addressBgView.isHidden = false
            self.deliveryInfoBgView.isHidden = true
            self.nameLabel.text = model.userName
            self.mobileLabel.text = model.phone
            self.addressLabel.text = model.address
        }else if status == .pendingReceipt {
            self.payTimeLabel.text = "付款时间："+(model.payTime ?? "无")
            self.shipTimeLabel.text = "发货时间："+(model.deliverTime ?? "无")
            self.closingTimeLabel.isHidden = true
            
            self.addressBgView.isHidden = false
            self.deliveryInfoBgView.isHidden = false
            self.confirmButton.isHidden = false
            self.confirmButton.setTitle("确认收货", for: UIControl.State.normal)
            self.nameLabel.text = model.userName
            self.mobileLabel.text = model.phone
            self.addressLabel.text = model.address
            self.courierCompanyLabel.text = "快递公司："+(model.logisticsName ?? "无")
            self.trackNoLabel.text = "快递单号："+(model.logisticsNo ?? "无")
        }else if status == .completed {
            self.payTimeLabel.text = "付款时间："+(model.payTime ?? "无")
            self.shipTimeLabel.text = "发货时间："+(model.deliverTime ?? "无")
            self.closingTimeLabel.text = "成交时间："+(model.updateTime ?? "无")
            self.confirmButton.isHidden = true
            self.addressBgView.isHidden = false
            self.deliveryInfoBgView.isHidden = true
            self.nameLabel.text = model.userName
            self.mobileLabel.text = model.phone
            self.addressLabel.text = model.address
        }else {
            self.payTimeLabel.isHidden = true
            self.shipTimeLabel.isHidden = true
            self.closingTimeLabel.isHidden = true
            self.confirmButton.isHidden = true
            self.addressBgView.isHidden = true
            self.deliveryInfoBgView.isHidden = true
        }
    }
    @IBAction func confirm(_ sender: SubmitButton) {
        if status == .pendingPayment {
            let vc = ConfirmOrderController()
            vc.isMall = self.isMall
            vc.orderId = self.orderId
            self.navigationController?.pushViewController(vc, animated: true)
        }else{//收货
            if isMall {
                provider.rx.request(APITarget.mallOrderReceipt(orderId: orderId))
                    .mapObject(BaseResponse<EmptyResponse>.self)
                    .subscribe(onSuccess: { (res) in
                        SVProgressHUD.showSuccess(withStatus: "成功")
                        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+2) {
                            self.requestData()
                        }
                    }, onError: { (error) in

                    })
                .disposed(by: disposeBag)
            }else{
                provider.rx.request(APITarget.orderReceipt(orderId: orderId))
                    .mapObject(BaseResponse<EmptyResponse>.self)
                    .subscribe(onSuccess: { (res) in
                        SVProgressHUD.showSuccess(withStatus: "成功")
                        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+2) {
                            self.requestData()
                        }
                    }, onError: { (error) in

                    })
                .disposed(by: disposeBag)
            }
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
