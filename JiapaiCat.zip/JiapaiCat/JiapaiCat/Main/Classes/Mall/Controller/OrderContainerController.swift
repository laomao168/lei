//
//  OrderContainerController.swift
//  CBIT
//
//  Created by 刘文利 on 2019/11/7.
//  Copyright © 2019 网泰信息. All rights reserved.
//

import UIKit
import XLPagerTabStrip
class OrderContainerController: ButtonBarPagerTabStripViewController {

    override func viewDidLoad() {
        setupButtonBar()
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        self.title = "我的订单"
        if #available(iOS 11.0, *) {
            self.containerView.contentInsetAdjustmentBehavior = .never
        } else {
            // Fallback on earlier versions
            self.automaticallyAdjustsScrollViewInsets = false
        }
        self.buttonBarView.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            make.left.right.equalToSuperview()
            make.height.equalTo(47)
        }
        self.containerView.snp.makeConstraints { (make) in
            make.top.equalTo(self.buttonBarView.snp.bottom)
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    func setupButtonBar() {
        settings.style.buttonBarBackgroundColor = .white
        settings.style.buttonBarItemBackgroundColor = .white
        settings.style.selectedBarBackgroundColor = .mainColor
        settings.style.buttonBarItemFont = UIFont.systemFont(ofSize: 13)
        settings.style.selectedBarHeight = 2
        settings.style.buttonBarMinimumLineSpacing = 0
        settings.style.buttonBarMinimumInteritemSpacing = 0
        settings.style.buttonBarItemTitleColor = UIColor.gray3
        settings.style.buttonBarItemsShouldFillAvailableWidth = true
        settings.style.buttonBarLeftContentInset = 0
        settings.style.buttonBarRightContentInset = 0
        changeCurrentIndexProgressive = {  (oldCell: ButtonBarViewCell?, newCell: ButtonBarViewCell?, progressPercentage: CGFloat, changeCurrentIndex: Bool, animated: Bool) -> Void in
            guard changeCurrentIndex == true else { return }
            oldCell?.label.textColor = UIColor.gray3
            newCell?.label.textColor = UIColor.mainColor
        }
    }

    // MARK: - PagerTabStripDataSource
    override func viewControllers(for pagerTabStripController: PagerTabStripViewController) -> [UIViewController] {
        var list = [UIViewController]()
        
        let vc1 = OrderListController()
        vc1.style = .all
        list.append(vc1)
        let vc2 = OrderListController()
        vc2.style = .pendingPayment
        list.append(vc2)
        let vc3 = OrderListController()
        vc3.style = .delivered
        list.append(vc3)
        let vc4 = OrderListController()
        vc4.style = .pendingReceipt
        list.append(vc4)
        let vc5 = OrderListController()
        vc5.style = .completed
        list.append(vc5)
        if list.isEmpty {
            let vc = EmptyOpenNodeController()
            list.append(vc)
        }
        
        return list
    }

}
