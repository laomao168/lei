//
//  BuySuccessController.swift
//  JiapaiCat
//
//  Created by 刘文利 on 2019/12/20.
//  Copyright © 2019 刘文利. All rights reserved.
//

import UIKit

class BuySuccessController: BaseViewController {
    var orderId: Int?
    var isMall: Bool = false
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "购买成功"
        //不用再显示这个页面了
        for (i, vc) in (self.navigationController?.viewControllers ?? []).enumerated() {
            if vc is ConfirmOrderController {
                self.navigationController?.viewControllers.remove(at: i)
                break
            }
        }
        // Do any additional setup after loading the view.
    }

    @IBAction func complete(_ sender: UIButton) {
        let isContain = (self.navigationController?.viewControllers ?? []).contains(where: { (vc) -> Bool in
            return vc is OrderDetailController
        })
        if isContain {
            for (i, vc) in (self.navigationController?.viewControllers ?? []).enumerated() {
                if vc is OrderDetailController {
                   self.navigationController?.popToViewController(vc, animated: true)
                    break
                }
            }
        }else{
            guard let orderId = orderId else {
                SVProgressHUD.showInfo(withStatus: "支付页面后台没有传orderId,需要添加")
                return
            }
            let vc = OrderDetailController()
            vc.isMall = self.isMall
            vc.orderId = orderId
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
