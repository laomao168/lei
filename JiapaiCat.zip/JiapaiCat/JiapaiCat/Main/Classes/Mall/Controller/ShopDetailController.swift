//
//  ShopDetailController.swift
//  CBIT
//
//  Created by 刘文利 on 2019/11/6.
//  Copyright © 2019 网泰信息. All rights reserved.
//

import UIKit
import WebKit
import Presentr
import FSPagerView
class ShopDetailController: BaseViewController {
    var id: Int = 0
    private var model: MallGoodsInfoModel?
    lazy var tableView: UITableView = {
        let tableView = UITableView(frame: CGRect.zero, style: .grouped)
        tableView.dataSource = self
        tableView.delegate = self
        tableView.backgroundColor = UIColor(hexString: "#EEEEEE")
        return tableView
    }()
    //弹窗
    let chooseAttributePresenter: Presentr = {
        let width = ModalSize.sideMargin(value: 0)
        let height = ModalSize.custom(size: 551)
        let presentationType = PresentationType.custom(width: width, height: height, center: ModalCenterPosition.customOrigin(origin: CGPoint(x: 0, y: SHEIGHT-551)))
        let presenter = Presentr(presentationType: presentationType)
        presenter.transitionType = TransitionType.coverVertical
        presenter.dismissOnSwipe = false
        presenter.roundCorners = false
//        presenter.cornerRadius = 8
        presenter.backgroundOpacity = 0.3
        return presenter
    }()
    
    lazy var webView: WKWebView = {
        //配置环境
        let configuration = WKWebViewConfiguration()
        configuration.preferences.javaScriptEnabled = true
        // 注入JS对象名称"NativeMethod"，当JS通过NativeMethod来调用时，我们可以在WKScriptMessageHandler代理中接收到
        let userController = WKUserContentController()
        configuration.userContentController = userController
        //        delegateController.delegate = self
        //        configuration.userContentController.add(self, name: "NativeMethod")
        let webView = WKWebView(frame: CGRect(x: 0, y: 0, width: SWIDTH, height: SHEIGHT), configuration: configuration)
        webView.allowsBackForwardNavigationGestures = false
        webView.navigationDelegate = self
        
        //目前不需要这个代理
        //        webView.uiDelegate = self
        webView.scrollView.isScrollEnabled = false
        return webView
    }()
    
    var webHeight: CGFloat = 0
    private let cellId1 = "ShopDetailCell"
    private let priceCellId = "priceCellId"
    
//    var headerImageView: UIImageView!
    var bottomView: UIView!

    var bannerList: [String] = []
    
    lazy var pagerView: FSPagerView = {
        let pagerView = FSPagerView()
        let width = SWIDTH
        let height: CGFloat = width*375/375
        pagerView.dataSource = self
        pagerView.delegate = self
        pagerView.itemSize = CGSize(width: width, height: height)//self.pagerView.frame.size.applying(CGAffineTransform(scaleX: newScale, y: newScale))
        pagerView.automaticSlidingInterval = 0
        pagerView.interitemSpacing = 0
        pagerView.backgroundColor = UIColor.white
        pagerView.isInfinite = false
        pagerView.isScrollEnabled = true
        pagerView.scrollDirection = .horizontal
        pagerView.register(FSPagerViewCell.self, forCellWithReuseIdentifier: "cell")
        return pagerView
    }()
    lazy var pageControl: FSPageControl = {
        let pageControl = FSPageControl()
        pageControl.contentHorizontalAlignment = .center
        pageControl.setFillColor(UIColor(white: 1, alpha: 0.5), for: .normal)
        pageControl.setFillColor(UIColor.mainColor, for: .selected)
        pageControl.contentInsets = UIEdgeInsets(top: 0, left: 20, bottom: 0, right: 20)
        pageControl.hidesForSinglePage = true
        return pageControl
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "商品详情"
        setupUI()
        requestData()
        // Do any additional setup after loading the view.
    }
    
    func requestData() {
        provider.rx.request(APITarget.mallGoodsInfoDetail(goodsId: id))
            .mapObject(BaseResponse<MallGoodsInfoModel>.self)
            .subscribe(onSuccess: { (res) in
                self.model = res.data
                self.setupData()
                self.tableView.reloadData()
            }, onError: { (error) in
                
            })
        .disposed(by: disposeBag)

        
    }
    
    
    func setupUI() {
        self.view.addSubview(tableView)
        tableView.separatorColor = UIColor.separatorColor
        tableView.backgroundColor = UIColor(hexString: "#EEEEEE")
        
        tableView.register(UINib(nibName: "ShopPriceCell", bundle: nil), forCellReuseIdentifier: priceCellId)
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: cellId1)
                
        let bottomView = UIView()
        bottomView.backgroundColor = UIColor.white
        self.view.addSubview(bottomView)
        let shareButton = UIButton(type: .custom)
        shareButton.addTarget(self, action: #selector(shareAction), for: UIControl.Event.touchUpInside)
        bottomView.addSubview(shareButton)
        shareButton.setTitle("分享", for: UIControl.State.normal)
        shareButton.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        shareButton.setTitleColor(UIColor.mainColor, for: UIControl.State.normal)
        shareButton.setImage(UIImage(named: "btn_botfixed_share"), for: UIControl.State.normal)
        shareButton.isHidden = true
        bottomView.addSubview(shareButton)
        shareButton.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(20)
            make.centerY.equalToSuperview()
            make.width.height.equalTo(49)
        }
        shareButton.imagePosition(style: .top, spacing: 0)
        
        let buyButton = UIButton(type: .custom)
        buyButton.setTitle("立即购买", for: UIControl.State.normal)
        buyButton.setTitleColor(UIColor.white, for: .normal)
        buyButton.setBackgroundImage(UIImage.commomGradient, for: UIControl.State.normal)
        buyButton.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        buyButton.addTarget(self, action: #selector(buyAction), for: UIControl.Event.touchUpInside)
        bottomView.addSubview(buyButton)
        
        bottomView.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(self.view.safeAreaLayoutGuide.snp.bottom)
            } else {
                // Fallback on earlier versions
                make.bottom.equalToSuperview()
            }
            make.height.equalTo(49)
        }
        tableView.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.bottom.equalTo(bottomView.snp.top)
        }
        
        buyButton.snp.makeConstraints { (make) in
            make.top.right.bottom.equalToSuperview()
            make.width.equalTo(125)
        }
        
        let tableHeaderView = UIView(frame: CGRect(x: 0, y: 0, width: SWIDTH, height: SWIDTH*1))
        //        headerImageView = UIImageView(frame: CGRect(x: 0, y: 0, width: SWIDTH, height: SWIDTH*(1/1)))
                
        //        tableHeaderView.addSubview(headerImageView)
                tableHeaderView.addSubview(pagerView)
                tableHeaderView.addSubview(pageControl)
                tableView.tableHeaderView = tableHeaderView
                
                pagerView.snp.makeConstraints { (make) in
                    make.left.right.top.equalToSuperview()
                    make.height.equalTo(pagerView.snp.width)
                }
                pageControl.snp.makeConstraints { (make) in
                    make.bottom.equalTo(pagerView.snp.bottom).offset(-20)
                    make.height.equalTo(20)
                    make.left.right.equalToSuperview()
                }
    }
    
    func setupData() {
        guard let model = model else { return }
        if let banner = model.headImage {
            let data = banner.data(using: .utf8)!
            if let arr = try? JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) as? [String] {
                self.bannerList = arr
            }
        }
        pageControl.numberOfPages = bannerList.count
        self.pagerView.reloadData()
        let str = (model.goodsDetail ?? "").addHtmlHeardImageStyle(title: "")
        self.webView.loadHTMLString(str, baseURL: nil)
    }
    
    @objc func buyAction() {
        guard UserInfoManager.shared.isLogined else {
            UtilUser.openLogin()
            return
        }
        let vc = ConfirmOrderController()
        vc.isMall = true
        vc.goodsId = model?.goodsId
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc func shareAction() {
        let webpageObject = WXWebpageObject()
        
        webpageObject.webpageUrl = AppStoreURL
        let message = WXMediaMessage()
        message.title = "欢迎加入一口拍"
        message.description = model?.goodsName ?? ""
        message.setThumbImage(UIImage(named: "img_salesroom_logo")!)
        message.mediaObject = webpageObject
        let req = SendMessageToWXReq()
        req.bText = false
        req.message = message
        req.scene = Int32(WXSceneSession.rawValue)
        WXApi.send(req)
    }
    
}

extension ShopDetailController: UITableViewDataSource, UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: priceCellId, for: indexPath) as! ShopPriceCell
            cell.selectionStyle = .none
            if let model = model {
                cell.shopNameLabel.text = model.goodsName
                var priceText = "\(model.integral.mapToPrice())积分"
                if model.priceType == 2, let price = model.price {
                    priceText = priceText + "+¥\(price.mapToPrice())"
                }
                cell.priceLabel.text = priceText
                cell.guzhiLabel.text = "¥\(model.assessPrice.mapToPrice())"
            }
            return cell
        }else if indexPath.section == 1 {
            let cell = tableView.dequeueReusableCell(withIdentifier: cellId1, for: indexPath)
            cell.selectionStyle = .none
            if webView.superview == nil {
                cell.contentView.addSubview(webView)
                webView.snp.makeConstraints { (make) in
                    make.left.right.top.bottom.equalToSuperview()
                }
            }
            return cell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0 {
            return UITableView.automaticDimension
        }else if indexPath.section == 1 {
            return webHeight
        }
        return 0
    }
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 1 {
            return 40
        }
        return 0.1
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 10
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if section == 1 {
            let headerView = Bundle.main.loadNibNamed("AuctionSectionHeaderView", owner: self, options: nil)?.first as? AuctionSectionHeaderView
            headerView?.moreButton.isHidden = true
            headerView?.titleLabel.text = "商品详情"
            return headerView
        }
        return UIView()
    }
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }
}
extension ShopDetailController: WKNavigationDelegate {
    //页面加载完成
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        print("页面加载完成")
        //原生调用JS方法
        webView.evaluateJavaScript("document.body.offsetHeight;") { (result, error) in
            if let res = result {
                let resFloat = res as? CGFloat
                print("resFloat=\(resFloat)")
                //必须加上一点
                let height = (resFloat ?? 0)+30
                self.webHeight = CGFloat(height)

                self.tableView.reloadData()
            }
        }
    }
}
extension ShopDetailController: FSPagerViewDataSource, FSPagerViewDelegate {
    // MARK:- FSPagerViewDataSource
            
    func numberOfItems(in pagerView: FSPagerView) -> Int {
        return bannerList.count
    }
    
    
    public func pagerView(_ pagerView: FSPagerView, cellForItemAt index: Int) -> FSPagerViewCell {
        let cell = pagerView.dequeueReusableCell(withReuseIdentifier: "cell", at: index)
        let pic = self.bannerList[index]
        cell.imageView?.contentMode = .scaleAspectFill
        cell.imageView?.kf.setImage(with: URL(string: pic))
        return cell
    }
    
    func pagerView(_ pagerView: FSPagerView, didSelectItemAt index: Int) {
        
    }
    func pagerViewDidScroll(_ pagerView: FSPagerView) {
        guard self.pageControl.currentPage != pagerView.currentIndex else {
            return
        }
        self.pageControl.currentPage = pagerView.currentIndex // Or Use KVO with property "currentIndex"
    }
}
