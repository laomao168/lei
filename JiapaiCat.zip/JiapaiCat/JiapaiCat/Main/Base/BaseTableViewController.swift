//
//  BaseTableViewController.swift
//  yidoumi
//
//  Created by sss on 2017/3/31.
//  Copyright © 2017年 sss. All rights reserved.
//

import UIKit
import MJRefresh
import DZNEmptyDataSet
import Moya

enum EmptyDataStyle: Int {
    case none
    case noData//暂无数据
    case networkError//网络错误
    case noNetwork//没有网络
    
}
/// 列表页的父类 处理上下拉刷新、翻页控制、网络请求
class BaseTableViewController: BaseViewController {
    /// tableview
    @IBOutlet weak var tableView: UITableView!
    var isHeaderRefresh: Bool {
        return true
    }
    var isFooterRefresh: Bool {
        return true
    }
    var isEmptyDataSet: Bool {
        return false
    }
    var tableViewStyle: UITableView.Style {
        return .plain
    }
    /// 当前页数
    var pageNumber = 1
    /// 每页数量
    var pageSize:Int = 10
    
    /// 总页数
    var totalPages: Int = 0
    
//    /// cell id
//    var cellReuseId:String = "" {
//        didSet{ if cellReuseId != "" { register(nibName: cellReuseId) } }
//    }
    
    /// cell数据
//    var dataArrar:[Codable] = []
    var emptyDataStyle: EmptyDataStyle = .none {
        didSet {
            self.tableView.reloadEmptyDataSet()
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        let tableViewAU = tableView ?? {
            let tableView = UITableView(frame: CGRect(x: 0, y: 0, width: SWIDTH, height: SHEIGHT), style: tableViewStyle)
            tableView.dataSource = self
            tableView.delegate = self
            tableView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            return tableView
            }()
        self.tableView = tableViewAU
        if tableView.superview == nil {
            view.addSubview(tableView)
        }
        if tableView.delegate == nil {
            tableView.delegate = self
        }
        if tableView.dataSource == nil {
            tableView.dataSource = self
        }
        
        tableView.tableFooterView = UIView()
        tableView.separatorColor = UIColor.separatorColor
        if isEmptyDataSet {
            tableView.emptyDataSetSource = self
            tableView.emptyDataSetDelegate = self
        }
        
//        tableView.estimatedRowHeight = 44;
//        tableView.rowHeight = UITableViewAutomaticDimension
//        tableView.backgroundColor = UIColor.groupTableViewBackground
        
        setupRefreshControl()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    /// 设置下拉刷新
    func setupRefreshControl(){
        if isHeaderRefresh {
            addHeaderRefresh()
        }
        if isFooterRefresh {
            addFooterRefresh()
        }
        
//        guard target != nil else {
//            return
//        }
//        tableView.mj_header.beginRefreshing()
    }
    func addHeaderRefresh() {
        let header = MJRefreshNormalHeader {[weak self] in
            self?.pageNumber = 1
            self?.requestData()
        }
        header.lastUpdatedTimeLabel?.isHidden = true
        header.isAutomaticallyChangeAlpha = true
        tableView.mj_header = header
    }
    
    func addFooterRefresh() {
//        MJRefreshAutoNormalFooter
        let footer = MJRefreshBackNormalFooter{[weak self] in
            self?.pageNumber += 1
            self?.requestData()
        }
        tableView.mj_footer = footer
    }
    
//    func emptyData() {
//        self.dataArrar = []
//        self.pageNumber = 1
//    }
    
    /// 结束下拉刷新 判断是否有更多数据
    ///
    /// - Parameter paga: 传入服务器传回总页数
    func endRefresh(_ totalPages: Int? = -1) {
        let totalPage = totalPages ?? 0
        self.tableView.mj_header?.endRefreshing()
        if totalPage > -1 && pageNumber >= totalPage-1 {
            self.tableView.mj_footer?.endRefreshingWithNoMoreData()
        }else{
            self.tableView.mj_footer?.endRefreshing()
        }
    }
    
    /// 网络请求
    func requestData(){
        assertionFailure("此方法需要重写")
    }
    
}

extension BaseTableViewController: UITableViewDataSource, UITableViewDelegate {
    
    
//    /// 注册cell
//    ///
//    /// - Parameter nibName: nibName
//    func register(nibName:String) {
//        tableView.register(UINib.init(nibName: nibName, bundle: nil), forCellReuseIdentifier: nibName)
//    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        assertionFailure("override tableView numberOfRowsInSection")
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        assertionFailure("override tableView cellForRowAt")
        return UITableViewCell()
    }
    
}

extension BaseTableViewController: DZNEmptyDataSetSource,DZNEmptyDataSetDelegate{
    
    /// 空数据图片展示
    func image(forEmptyDataSet scrollView: UIScrollView!) -> UIImage! {
//        return UIImage(named: "noData")
        switch emptyDataStyle {
        case .none:
            return nil
        case .noData:
            return UIImage(named: "noData")
        case .networkError:
            return UIImage(named: "networkError")
        default:
            return UIImage(named: "networkError")
        }
    }
    func emptyDataSetShouldAllowScroll(_ scrollView: UIScrollView!) -> Bool {
        return true
    }
    
    func emptyDataSetShouldAnimateImageView(_ scrollView: UIScrollView!) -> Bool {
        return true
    }
    func title(forEmptyDataSet scrollView: UIScrollView!) -> NSAttributedString! {
        var msg = ""
        switch emptyDataStyle {
        case .none:
            msg = ""
        case .noData:
            msg = "暂无数据~"
        case .networkError:
            msg = "您的网络好像不太给力哦～"
        default:
            msg = "您的网络好像不太给力哦～"
        }
        let attributes = [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 14),NSAttributedString.Key.foregroundColor: UIColor(hexString: "0xD8D8D8")!]
        return NSAttributedString(string: msg, attributes: attributes)
    }
    func verticalOffset(forEmptyDataSet scrollView: UIScrollView!) -> CGFloat {
        let height = (self.tableView.tableHeaderView?.frame.size.height ?? 0)/2.0
        return height
    }
}


