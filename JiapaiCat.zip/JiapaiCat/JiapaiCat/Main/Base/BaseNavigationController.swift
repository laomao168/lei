//
//  BaseNavigationController.swift
//  caifujutou
//
//  Created by MAC on 2017/8/15.
//  Copyright © 2017年 tomcat360. All rights reserved.
//

import UIKit
//import YPNavigationBarTransition
class BaseNavigationController: UINavigationController {
//    var barTitleColor: UIColor = gray3Color {
//        didSet {
//            let attributes = [NSAttributedString.Key.foregroundColor:barTitleColor,NSAttributedString.Key.font:UIFont.boldSystemFont(ofSize: 17)]
//            navigationBar.titleTextAttributes = attributes
//            navigationBar.tintColor = barTitleColor
//        }
//    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
//        navigationBar.backIndicatorImage = UIImage(named: "nav_back")
//        navigationBar.backIndicatorTransitionMaskImage = UIImage(named: "nav_back")
        navigationBar.barTintColor = UIColor.white
        let attributes = [NSAttributedString.Key.foregroundColor:UIColor.white, NSAttributedString.Key.font:UIFont.systemFont(ofSize: 18)]
        navigationBar.titleTextAttributes = attributes
        navigationBar.tintColor = UIColor.white
//        navigationBar.isTranslucent = true
//        var image = UIImage(gradientColors: [RGBA(250, 137, 43, 1), RGBA(250, 86, 35, 1)], size: CGSize(width: SWIDTH, height: kNavBarHeight))
//        image = image?.resizableImage(withCapInsets: UIEdgeInsets.zero, resizingMode: UIImage.ResizingMode.stretch)
//        navigationBar.setBackgroundImage(image, for: UIBarMetrics.default)
        var image = UIImage(named: "nav_bg")
        image = image?.resizableImage(withCapInsets: UIEdgeInsets.zero, resizingMode: UIImage.ResizingMode.stretch)
        navigationBar.setBackgroundImage(image, for: .default)
        
        navigationBar.shadowImage = UIImage()//隐藏线条
//
//        if #available(iOS 11.0, *) {
//            navigationBar.prefersLargeTitles = true
//        } else {
//            // Fallback on earlier versions
//        }
        //隐藏放回文字
//    UIBarButtonItem.appearance().setBackButtonTitlePositionAdjustment(UIOffsetMake(-200, 0), for: .default)
//        UIBarButtonItem.appearance().setTitleTextAttributes([NSAttributedStringKey.foregroundColor: UIColor.clear], for: UIControlState.normal)
        // Do any additional setup after loading the view.
    }
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
//    override var childForStatusBarStyle: UIViewController? {
//        return topViewController
//    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func pushViewController(_ viewController: UIViewController, animated: Bool) {
        if viewControllers.count > 0 {
            viewController.hidesBottomBarWhenPushed = true
        }
        //去掉backBarButtonItem的文字
        let  item = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        self.topViewController?.navigationItem.backBarButtonItem = item
        super.pushViewController(viewController, animated: animated)
    }
//    override func navigationBar(_ navigationBar: UINavigationBar, shouldPop item: UINavigationItem) -> Bool {
//        return true
//    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
}
