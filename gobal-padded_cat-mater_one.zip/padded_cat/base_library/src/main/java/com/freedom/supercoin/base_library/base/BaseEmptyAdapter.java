package com.freedom.supercoin.base_library.base;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.freedom.supercoin.base_library.R;
import com.freedom.supercoin.base_library.databinding.ItemEmptyViewBinding;
import com.freedom.supercoin.base_library.utils.NetworkUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zzq on 2018/4/18.
 * RecyclerView 的基类 Adapter 提供了数据源为空时 空布局展示
 */

public abstract class BaseEmptyAdapter<T, VB extends ViewDataBinding> extends RecyclerView.Adapter<BaseEmptyAdapter.BaseViewHolder<VB>> {

    final int EMPTY = 0;
    final int NO_EMPTY = 1;
    ItemEmptyViewBinding binding;
    protected List<T> data = new ArrayList<>();
    public boolean empty;

    protected OnItemClickListener<T> onItemClickListener;
    private boolean isShowEmpty = true;
    public Context context;

    public void setShowEmpty(boolean isShowEmpty) {
        this.isShowEmpty = isShowEmpty;
    }

    public void setOnItemClickListener(OnItemClickListener<T> onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }


    public interface OnItemClickListener<T> {
        void onItemClick( int position, T data);
    }

    protected abstract VB createBinding(ViewGroup parent);

    protected abstract void onBindView(VB vb, T t, int position);


    public void setData(List<T> data) {
        this.data .clear();
        this.data.addAll(data);
        notifyDataSetChanged();
    }


    public void addDataList(List<T> data) {
        if (data != null) {
            this.data.addAll(data);
            notifyItemRangeChanged(this.data.size(), data.size());
        }
    }


    public void updateItem(int position, T newData) {
        if (newData != null && position <= data.size() - 1) {
            data.set(position, newData);
            notifyItemChanged(position);
        }
    }


    @NonNull
    @Override
    public BaseViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        context = parent.getContext();
        if (viewType == EMPTY && isShowEmpty) {
            binding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()),
                    R.layout.item_empty_view, parent, false);
            return new BaseViewHolder<>(binding);
        }
        return new BaseViewHolder<>(createBinding(parent));
    }


    @Override
    public void onBindViewHolder(BaseViewHolder<VB> holder, int position) {
        if (!empty) {
            onBindView(holder.binding, data.get(position), position);
        } else {
            if (!NetworkUtils.isConnected()) {
                binding.image.setImageResource(R.mipmap.ic_no_net);
                binding.tvTips.setText(R.string.noNet);
            }
        }
    }


    @Override
    public int getItemCount() {
        empty = data == null || data.size() == 0;
        if (data == null || data.size() == 0) {
            if (isShowEmpty){
                return 1;
            }else {
                return 0;
            }
        } else {
            return data.size();
        }
    }


    @Override
    public int getItemViewType(int position) {
        if (empty) {
            return EMPTY;
        }
        return NO_EMPTY;
    }


    public List<T> getData() {
        return data;
    }


    public void setEmptyBackgroundColor(int color) {
        binding.getRoot().setBackgroundColor(color);
    }


    protected static class BaseViewHolder<T extends ViewDataBinding>
            extends RecyclerView.ViewHolder {

        public final T binding;


        public BaseViewHolder(T binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

}
