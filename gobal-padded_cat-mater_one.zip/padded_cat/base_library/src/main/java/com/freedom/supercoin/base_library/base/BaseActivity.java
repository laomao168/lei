package com.freedom.supercoin.base_library.base;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.databinding.ViewDataBinding;
import android.os.Bundle;
import android.support.annotation.Nullable;

import com.freedom.supercoin.base_library.AppConst;
import com.freedom.supercoin.base_library.utils.KeyboardUtils;
import com.freedom.supercoin.base_library.utils.LanguageUtil;
import com.freedom.supercoin.base_library.utils.SPUtils;
import com.trello.rxlifecycle.components.support.RxAppCompatActivity;


/**
 * Created by jianping on 2018/11/19.
 */

public abstract class BaseActivity<T extends ViewDataBinding> extends RxAppCompatActivity {

    public int language;
    public String selectedLanguage;

    @Override
    protected void attachBaseContext(Context newBase) {
        language = SPUtils.getInstance().getInt(AppConst.Keys.LANGUAGE, 0);

        if (language == 0) {
            selectedLanguage = "zh";
        } else if (language == 1) {
            selectedLanguage = "en";
        }
        super.attachBaseContext(LanguageUtil.attachBaseContext(newBase, selectedLanguage));
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        init();
    }

    public void init() {
        initData();
        initEvent();
    }

    /**
     * 获取资源文件
     */
    protected abstract int layoutResId();


    /**
     * 初始化数据
     */
    protected abstract void initData();

    /**
     * 初始化监听
     */
    protected abstract void initEvent();

    /**
     * 标题栏id
     *
     * @return
     */
    protected  int getTitleBarId(){
        return 0;
    }

    @Override
    public void finish() {
        super.finish();
        // 隐藏软键盘，避免软键盘引发的内存泄露
        KeyboardUtils.hideKeyboard(getCurrentFocus());

    }

    /**
     * 跳转到其他Activity
     *
     * @param cls 目标Activity的Class
     */
    public void startActivity(Class<? extends Activity> cls) {
        startActivity(new Intent(this, cls));
    }

    @Override
    public Resources getResources() {
        Resources res = super.getResources();
        Configuration config=new Configuration();
        config.setToDefaults();
        config.fontScale = 1.0f;
        res.updateConfiguration(config,res.getDisplayMetrics() );
        return res;
    }

}
