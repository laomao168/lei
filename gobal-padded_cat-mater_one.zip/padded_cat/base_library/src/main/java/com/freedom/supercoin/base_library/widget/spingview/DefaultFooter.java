package com.freedom.supercoin.base_library.widget.spingview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.freedom.supercoin.base_library.R;


public class DefaultFooter extends BaseFooter {
    private Context context;
    private int rotationSrc;

    public DefaultFooter(Context context){
        this(context, R.drawable.progress_small);
    }

    public DefaultFooter(Context context, int rotationSrc){
        this.context = context;
        this.rotationSrc = rotationSrc;
    }

    @Override
    public View getView(LayoutInflater inflater, ViewGroup viewGroup) {
        View view = inflater.inflate(R.layout.spring_default_footer, viewGroup, true);
        return view;
    }

    @Override
    public void onPreDrag(View rootView) {
    }

    @Override
    public void onDropAnim(View rootView, int dy) {
    }

    @Override
    public void onLimitDes(View rootView, boolean upORdown) {
    }

    @Override
    public void onStartAnim() {
    }

    @Override
    public void onFinishAnim() {
    }
}