package com.freedom.supercoin.base_library.widget.spingview;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;

import com.freedom.supercoin.base_library.R;


/**
 * Created by xiexuan on 2018/1/16.
 */
public class WheelHeader extends BaseHeader {
    private Context context;
    private int rotationSrc;
    private int arrowSrc;


//    private TextView headerTitle;
    private ImageView headerArrow;
    private ImageView headerRotate;

    private ProgressBar headerProgressbar;

    public WheelHeader(Context context){
        this(context, R.drawable.progress_wheel, R.mipmap.ic_spring_head_wheel_one);
    }

    public WheelHeader(Context context, int rotationSrc, int arrowSrc){
        this.context = context;
        this.rotationSrc = rotationSrc;
        this.arrowSrc = arrowSrc;

    }

    @Override
    public View getView(LayoutInflater inflater, ViewGroup viewGroup) {
        View view = inflater.inflate(R.layout.spring_wheel_header, viewGroup, true);
//        headerTitle = (TextView) view.findViewById(R.id.default_header_title);
        headerArrow = (ImageView) view.findViewById(R.id.default_header_arrow);
        headerRotate = (ImageView) view.findViewById(R.id.default_header_rotate);

        headerArrow.setImageResource(arrowSrc);
        headerRotate.setImageResource(R.mipmap.ic_spring_head_wheel_three);

        headerProgressbar = (ProgressBar) view.findViewById(R.id.default_header_progressbar);
        headerProgressbar.setIndeterminateDrawable(ContextCompat.getDrawable(context, rotationSrc));
        return view;
    }

    @Override
    public void onPreDrag(View rootView) {
    }

    @Override
    public void onDropAnim(View rootView, int dy) {
        if(dy < 360){
            headerArrow.setRotation(dy);
        }else{
            headerArrow.setRotation(dy%360);
        }
        headerArrow.setRotation(((float)dy));
        if(dy < 150){
            float percent = ((float)dy)/((float)150);
            headerArrow.setAlpha(percent);
        }else{
            headerArrow.setAlpha(1f);
        }
    }

    @Override
    public void onLimitDes(View rootView, boolean upORdown) {
        if (!upORdown){
//            headerTitle.setText("松开刷新数据");
        }else {
//            headerTitle.setText("下拉刷新");
        }
    }

    @Override
    public void onStartAnim() {
//        headerTitle.setText("正在刷新");
        if (listener!=null){
            listener.onAnimStart();
        }
        headerArrow.setVisibility(View.INVISIBLE);
        headerArrow.clearAnimation();

        headerProgressbar.setVisibility(View.VISIBLE);
        ValueAnimator anim = ValueAnimator.ofFloat(0f, 0.5f ,3f);
        anim.setDuration(2000);
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                float currentValue = (float) animation.getAnimatedValue();
                if(currentValue <= 0.5f){
                    headerProgressbar.setAlpha(currentValue*2);
                }
                if(currentValue == 3f){
                    headerProgressbar.setVisibility(View.INVISIBLE);
                    //开启另一个动画
                    headerRotate.setVisibility(View.VISIBLE);
                    ObjectAnimator animator = ObjectAnimator.ofFloat(headerRotate, "alpha", 0f, 1f);
                    animator.setDuration(300);
                    animator.start();
                }
            }
        });
        anim.start();
    }

    @Override
    public void onFinishAnim() {
        headerArrow.setVisibility(View.VISIBLE);
        headerRotate.setVisibility(View.INVISIBLE);
        headerProgressbar.setVisibility(View.INVISIBLE);
    }

    public interface HeaderAnimListener {

        void onAnimStart();
    }

    private HeaderAnimListener listener;

    public void setAnimListener(HeaderAnimListener listener) {
        this.listener = listener;
    }

}