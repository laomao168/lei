package com.freedom.supercoin.base_library.base;


public interface BasePresenter {

}
