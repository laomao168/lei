package com.freedom.supercoin.base_library.utils;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;

import com.freedom.supercoin.base_library.R;
import com.hjq.toast.ToastUtils;

import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.text.DecimalFormat;
import java.util.Arrays;

import javax.crypto.Cipher;

/**
 * Created by zzq on 2018/4/4.
 * 数值转换类
 */

public class StrUtils {

    public static String hideAccount(String account) {

        if (!StringUtils.isEmpty(account) && account.length() >= 10) {
            try {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(account.substring(0, account.length() / 3));
                for (int i = 0; i < account.length() - account.length() * 2 / 3; i++) {
                    stringBuilder.append("*");
                }
                stringBuilder.append(account.substring(account.length() * 2 / 3));
                return stringBuilder.toString();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return account;
    }


    public static String hideIDCard(String idCard) {

        if (!StringUtils.isEmpty(idCard)) {
            try {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(idCard.substring(0, 2));
                for (int i = 0; i < idCard.length() - 4; i++) {
                    stringBuilder.append("*");
                }
                stringBuilder.append(idCard.substring(idCard.length() - 2));
                return stringBuilder.toString();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return idCard;
    }


    public static String imgPath2Base64(String imagePath) {
        Bitmap bm = BitmapFactory.decodeFile(imagePath);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.JPEG, 60, baos);
        byte[] bytes = baos.toByteArray();
        //data:image/jpeg;base64,
        return "data:image/jpeg;base64," + Base64.encodeToString(bytes, Base64.DEFAULT);
    }


    // 保留8位小数
    public static String scale8(String value) {
        try {
            BigDecimal bigDecimal = new BigDecimal(value);
            return bigDecimal.setScale(8, BigDecimal.ROUND_DOWN).stripTrailingZeros()
                    .toPlainString();
        } catch (Exception e) {
        }
        return "";

    }


    // 去小数点后6位
    public static String scale6(String value) {
        try {
            BigDecimal bigDecimal = new BigDecimal(value);
            return bigDecimal.setScale(6, BigDecimal.ROUND_DOWN).stripTrailingZeros()
                    .toPlainString();
        } catch (Exception e) {
        }
        return "";
    }


    public static String scale(String value, int scale) {
        try {
            BigDecimal bigDecimal = new BigDecimal(value);
            return bigDecimal.setScale(scale, BigDecimal.ROUND_DOWN).stripTrailingZeros()
                    .toPlainString();
        } catch (Exception e) {
        }
        return "";
    }

    public static String scaleWithZeros(double value, int scale) {
        try {
            BigDecimal bigDecimal = new BigDecimal(Double2String(value));
            return bigDecimal.setScale(scale, BigDecimal.ROUND_DOWN).toPlainString();
        } catch (Exception e) {
        }
        return "";
    }

    public static String scale(double value, int scale) {
        try {
            BigDecimal bigDecimal = new BigDecimal(Double2String(value));
            return bigDecimal.setScale(scale, BigDecimal.ROUND_DOWN).stripTrailingZeros()
                    .toPlainString();
        } catch (Exception e) {
        }
        return "";
    }

    public static String scale5In(double value, int scale) {
        try {
            BigDecimal bigDecimal = new BigDecimal(Double2String(value));
            return bigDecimal.setScale(scale, BigDecimal.ROUND_HALF_UP).stripTrailingZeros()
                    .toPlainString();
        } catch (Exception e) {
        }
        return "";
    }

    //double to string 不科学计数法
    public static String Double2String(String value) {
        try {
            BigDecimal bigDecimal = new BigDecimal(value);
            return bigDecimal.stripTrailingZeros().toPlainString();
        } catch (Exception e) {
            return "";
        }
    }

    //double to string 不科学计数法
    public static String Double2String(Double value) {
        try {
            BigDecimal bigDecimal = new BigDecimal(Double.toString(value));
            return bigDecimal.stripTrailingZeros().toPlainString();
        } catch (Exception e) {
            return "";
        }
    }

    //double to string 不科学计数法
    public static String Double2String(float value) {
        try {
            BigDecimal bigDecimal = new BigDecimal(Float.toString(value));
            return bigDecimal.stripTrailingZeros().toPlainString();
        } catch (Exception e) {
            return "";
        }
    }

    public static String fixExchangePairName(String origin) {
        return origin.replace("/", "").toLowerCase();
    }

    public static String scale(double value) {
        try {
            if (value >= 1) {
                BigDecimal bigDecimal = new BigDecimal(Double.toString(value));
                return bigDecimal.setScale(0, BigDecimal.ROUND_DOWN).toPlainString();
            } else {
                return value + "";
            }
        } catch (Exception e) {
            return "";
        }
    }

    public static String changeValue(double value) {
        try {
            if (value > 10000 && value <= 100000000) {
                double v = value / 10000;
                return scale(v, 2) + "万";
            } else if (value > 100000000) {
                double v = value / 100000000;
                return scale(v, 2) + "亿";
            }
        } catch (Exception e) {
            e.printStackTrace();
            return value + "";
        }
        return scale(value, 2);
    }

    public static String changeValue(String value) {
        try {
            double v1 = Double.parseDouble(value);
            if (v1 > 10000 && v1 <= 100000000) {
                double v = v1 / 10000;
                return scale(v, 2) + "万";
            } else if (v1 > 100000000) {
                double v = v1 / 100000000;
                return scale(v, 2) + "亿";
            }
        } catch (Exception e) {
//            e.printStackTrace();
            return value;
        }
        return scale(value, 2);
    }

    public static void copy(String str, Context context) {
        ClipboardManager clipboardManager =
                (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboardManager == null) return;
        clipboardManager.setPrimaryClip(ClipData.newPlainText(null, str));
        ToastUtils.show(context.getResources().getString(R.string.copySuccess));
    }

    public static String getRemoveZreoNum(double num) {
        DecimalFormat df = new DecimalFormat("##.##");
        return df.format(num);
    }


}
