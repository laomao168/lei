package com.freedom.supercoin.base_library.utils;

import android.content.Context;
import android.os.Environment;
import android.text.TextUtils;
import android.util.Log;

import java.io.File;
import java.io.FileNotFoundException;

/**
 * Created by chenjy on 2016/9/20.
 * <p>
 * 文件管理器
 */
public class FileManager {

    public static final String DIR_NAME_MAIN = "SuperCoin";
    public static final String DIR_NAME_NOTES = "notes";
    public static final String DIR_NAME_IMGS = "imgs";
    public static final String DIR_NAME_ARP = "arp";
    public static final String DIR_DOWNLOAD_APK_PATH = "downloads";
    public static final String DIR_SCREENSHOT_PATH = "screenshot";
    public static final String DIR_NAME_AD = "ad";
    public static final String DIR_NAME_AD_SPLASH = "splash";
    public static final String DIR_NAME_TAB = "tab";
    public static final String DIR_NAME_SEARCH = "search";
    public final static String DIR_FATAL_OUTPUT = "fatal_result.txt";
    public final static String DIR_RECORD_OUTPUT = "record_result.txt";
    public final static String DIR_YDY_OUTPUT = "ydy_result.txt";
    public final static String FILE_TXT_CONN_MAC = "ConnMacs.txt";

    public final static long MAX_FILE_SIZE = 2 * 1024 *1024;

    public static final String DIR_PATH_NOTES = DIR_NAME_MAIN + File.separator + DIR_NAME_NOTES +
            File.separator;
    public static final String DIR_PATH_ARP_NOTES = DIR_NAME_MAIN + File.separator +
            DIR_NAME_NOTES + File.separator + DIR_NAME_ARP + File.separator;
    public static final String DIR_PATH_IMGS = DIR_NAME_MAIN + File.separator + DIR_NAME_IMGS +
            File.separator;
    public static final String DIR_PATH_AD_SPLASH = DIR_NAME_MAIN + File.separator + DIR_NAME_AD
            + File.separator + DIR_NAME_AD_SPLASH + File.separator;
    public static final String DIR_PATH_TAB = DIR_NAME_MAIN + File.separator + DIR_NAME_TAB + File.separator;

    public static final String DIR_PATH_SEARCH = DIR_NAME_MAIN + File.separator + DIR_NAME_SEARCH
            + File.separator;

    public static final String DIR_PATH_DOWNLOAD = DIR_NAME_MAIN + File.separator + DIR_DOWNLOAD_APK_PATH
            + File.separator;
    public static final String DIR_PATH_SCREENSHOT = DIR_NAME_MAIN + File.separator + DIR_SCREENSHOT_PATH
            + File.separator;


    private static String getRootSdPath() throws FileNotFoundException {
        if (!isSdcardAvalible()) {
            throw new FileNotFoundException("无效Sd卡");
        }
        String path = null;
        String state = Environment.getExternalStorageState();
        if (state.equals(Environment.MEDIA_MOUNTED)) {
            path = Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator;

        }
        if (TextUtils.isEmpty(path)) {
            throw new FileNotFoundException("无效Sd卡");
        }
        return path;
    }

    /**
     * mounted and writable
     *
     * @return
     */
    public static boolean isSdcardAvalible() {
        boolean avalible = false;
        String state = Environment.getExternalStorageState();
        if (state.equals(Environment.MEDIA_MOUNTED)) {
            boolean writable = Environment.getExternalStorageDirectory().canWrite();
            avalible = writable;
        } else {
            avalible = false;
        }
        return avalible;
    }

    /**
     * 获取下载路径
     */
    public static String getApksDownloadPath(Context context) {
        // String path = getMainPathInSd() + DIR_DOWNLOAD + File.separator + DIR_APKS + File
        // .separator;
        String path = null;
        try {
            path = getRootSdPath() + DIR_PATH_DOWNLOAD;
        } catch (FileNotFoundException e) {
            path = context.getFilesDir().getAbsolutePath();
            e.printStackTrace();
        }
        checkOrMkdirs(path);
        return path;
    }
    public static String getScreenShotPath(Context context) {
        // String path = getMainPathInSd() + DIR_DOWNLOAD + File.separator + DIR_APKS + File
        // .separator;
        String path = null;
        try {
            path = getRootSdPath() + DIR_PATH_SCREENSHOT;
        } catch (FileNotFoundException e) {
            path = context.getFilesDir().getAbsolutePath();
            e.printStackTrace();
        }
        checkOrMkdirs(path);
        return path;
    }


    private static void checkOrMkdirs(String path) {
        if (TextUtils.isEmpty(path)) {
            throw new RuntimeException("FileManager:  invalid file path");

        } else {
            File dir = new File(path);
            if (!dir.exists()) {
                boolean isSuccess = dir.mkdirs();
                Log.e("FileManager isSuccess", isSuccess + "");
            }
        }
    }

    /**
     * 获取文件记录路径
     *
     * @return
     */
    public static String getDirNotesPath(Context context) {
        String path = null;
        try {
            path = getRootSdPath() + DIR_PATH_NOTES;
        } catch (FileNotFoundException e) {
            path = context.getFilesDir().getAbsolutePath();
            e.printStackTrace();
        }
        checkOrMkdirs(path);
        return path;
    }

    /**
     * 获取arp文件记录路径
     *
     * @return
     */
    public static String getDirArpPath(Context context) {
        String path = null;
        try {
            path = getRootSdPath() + DIR_PATH_ARP_NOTES;
        } catch (FileNotFoundException e) {
            path = context.getFilesDir().getAbsolutePath();
            e.printStackTrace();
        }
        checkOrMkdirs(path);
        return path;
    }

    /**
     * 获取img文件记录路径
     *
     * @return
     */
    public static String getImgsPath(Context context) {
        String path = null;
        try {
            path = getRootSdPath() + DIR_PATH_IMGS;
        } catch (FileNotFoundException e) {
            path = context.getFilesDir().getAbsolutePath();
            e.printStackTrace();
        }
        checkOrMkdirs(path);
        return path;
    }

    /**
     * 获取欢迎页面广告文件路径
     */
    public static String getDirSplashAdPath(Context context) {
        String path = null;
        try {
            path = getRootSdPath() + DIR_PATH_AD_SPLASH;
        } catch (FileNotFoundException e) {
            path = context.getFilesDir().getAbsolutePath();
            e.printStackTrace();
        }
        checkOrMkdirs(path);
        return path;
    }

    /**
     * 获取欢迎页面广告文件路径
     */
    public static String getDirTabPath(Context context) {
        String path = null;
        try {
            path = getRootSdPath() + DIR_PATH_TAB;
        } catch (FileNotFoundException e) {
            path = context.getFilesDir().getAbsolutePath();
            e.printStackTrace();
        }
        checkOrMkdirs(path);
        return path;
    }

    /**
     * 获取欢迎页面广告文件路径
     */
    public static String getDirTestMiPath(Context context) {
        String path = null;
        try {
            path = getRootSdPath() + DIR_NAME_MAIN + File.separator + "testMi" + File.separator;
        } catch (FileNotFoundException e) {
            path = context.getFilesDir().getAbsolutePath();
            e.printStackTrace();
        }
        checkOrMkdirs(path);
        return path;
    }

    public static String getDirSearchPath(Context context) {
        String path = null;
        try {
            path = getRootSdPath() + DIR_PATH_SEARCH;
        } catch (FileNotFoundException e) {
            path = context.getFilesDir().getAbsolutePath();
            e.printStackTrace();
        }
        checkOrMkdirs(path);
        return path;
    }
    /**
     *
     */
    public static String getDirFatalPath(Context context) {
        String path = null;
        try {
            path = getRootSdPath();
        } catch (FileNotFoundException e) {
            path = context.getFilesDir().getAbsolutePath();
            e.printStackTrace();
        }
        checkOrMkdirs(path);
        return path;
    }
    /**
     * 获取用户记录路径
     */
    public static String getDirRecordPath(Context context) {
        String path = null;
        try {
            path = getRootSdPath();
        } catch (FileNotFoundException e) {
            path = context.getFilesDir().getAbsolutePath();
            e.printStackTrace();
        }
        checkOrMkdirs(path);
        return path;
    }
    /**
     *
     */
    public static String getDirYdyPath(Context context) {
        String path = null;
        try {
            path = getRootSdPath();
        } catch (FileNotFoundException e) {
            path = context.getFilesDir().getAbsolutePath();
            e.printStackTrace();
        }
        checkOrMkdirs(path);
        return path;
    }


    /**
     * 获取讯飞插件下载路径
     */
    public static String getSpeechPluginDownloadPath(Context context) {
        String path = context.getFilesDir().getAbsolutePath() + File.separator;
        return path;
    }

}
