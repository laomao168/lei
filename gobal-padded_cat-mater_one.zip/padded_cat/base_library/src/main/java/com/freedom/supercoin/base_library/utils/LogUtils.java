package com.freedom.supercoin.base_library.utils;

import android.util.Log;

import com.freedom.supercoin.base_library.AppConst;

/**
 * Created by jianping on 2018/11/20.
 */

public class LogUtils {

    public static void ShowD(String tag, String msg) {
//        if (AppConst.ISDEBUG) {
            Log.d("cat", tag+" :"+msg);
//        }
    }
    public static void ShowI(String tag, String msg) {
//        if (AppConst.ISDEBUG) {
            Log.i("cat", tag+" :"+msg);
//        }
    }

    public static void ShowE(String tag, String msg) {
//        if (AppConst.ISDEBUG) {
            Log.e("superCoin", tag+" :"+msg);
//        }
    }
}
