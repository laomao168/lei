package com.freedom.supercoin.base_library;


import com.freedom.supercoin.base_library.listener.DataConfig;

/**
 * Created by zzq on 2018/4/3.
 */

public class AppConfig extends DataConfig {



    @Override
    public String getBaseUrl() {
        if (AppConst.ISDEBUG){
            return "https://api.lepai988.cn/api/";
//            return "https://api.oneauct.com/api/";
        }else {
            return "https://api.lepai988.cn/api/";
        }
    }

    @Override
    public String getWebUrl() {
        if (AppConst.ISDEBUG){
            return "wss://websocket.lepai988.cn/api/websocket";
        }else {
            return "wss://websocket.lepai988.cn/api/websocket";
        }
    }
}