package com.freedom.supercoin.base_library.listener;

/**
 * Created by chenjy on 2016/9/6.
 * titlebar 左边按钮回调
 */
public interface OnTitleBarClickListener {

    boolean onTitleBarClicked(int vid);

}
