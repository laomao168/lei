package com.freedom.supercoin.base_library.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class TimeUtil {

    private final static String TIME_UNIT_DAY = "yyyy年MM月dd日";
    private final static String TIME_UNIT_DAY_FULL = "yyyy年MM月dd日 HH:mm";
    private final static String TIME_UNIT_DAY_FULL_EN = "yyyy_MM_dd HH:mm";
    private final static String TIME_UNIT_DAY_SS = "MM-dd HH:mm:ss";
    private final static String TIME_UNIT_COMMENT = "MM-dd HH:mm";
    private final static String TIME_Proxy_DAY_SS = "MM/dd HH:mm";
    private final static String NOTICE_TIME = "yyyy-MM-dd";
    private final static String TIME_UNIT_DAY_FULL_TIME = "yyyy-MM-dd HH:mm:ss";

    public static String getTimeDay(long time, int language) {
        Date date = new Date(time);
        if (language == 0) {
            return new SimpleDateFormat(TIME_UNIT_DAY, Locale.getDefault()).format(date);
        } else {
            return new SimpleDateFormat(NOTICE_TIME, Locale.getDefault()).format(date);
        }
    }

    public static String getCommentTime(long time) {
        Date date = new Date(time);
        return new SimpleDateFormat(TIME_UNIT_COMMENT, Locale.getDefault()).format(date);
    }

    public static String getTimeProxyFull(long time, int language) {
        Date date = new Date(time);
        if (language == 0) {
            return new SimpleDateFormat(TIME_UNIT_DAY_FULL, Locale.getDefault()).format(date);
        } else {
            return new SimpleDateFormat(TIME_UNIT_DAY_FULL_EN, Locale.getDefault()).format(date);
        }
    }

    public static String getTimeDesc(long time) {
        Date date = new Date(time);
        return new SimpleDateFormat(TIME_UNIT_DAY_SS, Locale.getDefault()).format(date);
    }

    public static String getTimeProxy(long time) {
        Date date = new Date(time);
        return new SimpleDateFormat(TIME_Proxy_DAY_SS, Locale.getDefault()).format(date);
    }

    public static long getLongTimes(String dateString) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(TIME_UNIT_DAY_FULL_TIME);
        Date date = new Date();
        try {
            date = dateFormat.parse(dateString);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date.getTime();
    }

    /**
     * 获取输入时间和当前时间差
     *
     * @param startTime
     * @return
     */
    public static int getCurrentTimeDiff(String startTime) {
        long l = System.currentTimeMillis();
        long longTimes = getLongTimes(startTime);
        return (int) (longTimes - l)/1000;
    }
}
