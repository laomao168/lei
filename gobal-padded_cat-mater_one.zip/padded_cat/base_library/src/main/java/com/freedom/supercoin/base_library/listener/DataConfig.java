package com.freedom.supercoin.base_library.listener;


public abstract class DataConfig {


    public abstract String getBaseUrl();
    public abstract String getWebUrl();


}
