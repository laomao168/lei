package com.freedom.supercoin.base_library.base;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.KeyEvent;
import android.view.View;


import java.lang.reflect.Field;

import com.trello.rxlifecycle.components.support.RxFragment;

/**
 * desc   : Fragment懒加载基类
 */
public abstract class BaseFragment extends RxFragment {

    public boolean isLazyLoad = false;//是否已经懒加载
    public Activity mActivity;//Activity对象
    public boolean lazyOrNot = true;

    /**
     * 获得全局的，防止使用getActivity()为空
     */
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.mActivity = getActivity();
    }

    public Activity getSupportActivity() {
        return mActivity;
    }


    protected boolean isLazyLoad() {
        return isLazyLoad;
    }

    /**
     * 是否在Fragment使用沉浸式
     */
    protected boolean isStatusBarEnabled() {
        return false;
    }

    /**
     * 默认开启懒加载 ,返回false 关闭懒加载
     * @return
     */
    protected boolean isLazyOrNot() {
        return lazyOrNot;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mActivity = null;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (isLazyOrNot()) {
            if (isVisibleToUser && !isLazyLoad() && getView() != null) { //判断是否fragment 可见
                isLazyLoad = true;
                init();
            }
        } else {
            init();
        }

    }

    private boolean isVisibleToUser;

    /**
     * fragment 可见时候才加载数据 和UI
     *
     * @param isVisibleToUser
     */
    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        this.isVisibleToUser = isVisibleToUser;
        if (isLazyOrNot()) {
            if (isVisibleToUser && !isLazyLoad() && getView() != null) { //fragment 可见时候再加载一次
                isLazyLoad = true;
                init();
            }
        }
        super.setUserVisibleHint(isVisibleToUser);
    }

    public boolean isVisibleToUser() {
        return isVisibleToUser;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        //解决java.lang.IllegalStateException: Activity has been destroyed 的错误
        try {
            Field childFragmentManager = Fragment.class.getDeclaredField("mChildFragmentManager");
            childFragmentManager.setAccessible(true);
            childFragmentManager.set(this, null);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }


    protected void init() {
        initData();
        initEvent();
    }

    //引入布局
    protected abstract int getLayoutId();

    //标题栏id
    protected  int getTitleBarId(){
        return 0;
    }

    //初始化数据
    protected abstract void initData();

    /**
     * 初始化事件
     */
    protected abstract void initEvent();


    /**
     * 根据资源id获取一个View
     */
    protected <T extends View> T findViewById(@IdRes int id) {
        return (T) getView().findViewById(id);
    }

    /**
     * 跳转到其他Activity
     *
     * @param cls 目标Activity的Class
     */
    public void startActivity(Class<? extends Activity> cls) {
        startActivity(new Intent(mActivity, cls));
    }

    /**
     * Fragment返回键被按下时回调
     */
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        //默认不拦截按键事件，传递给Activity
        return false;
    }
}