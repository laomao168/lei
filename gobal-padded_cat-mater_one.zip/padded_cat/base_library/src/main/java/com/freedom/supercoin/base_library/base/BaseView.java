package com.freedom.supercoin.base_library.base;



import com.trello.rxlifecycle.android.ActivityEvent;
import com.trello.rxlifecycle.android.FragmentEvent;

import rx.Observable;

public interface BaseView {
    void showProgress();

    void hideProgress();

    void showMessage(String msg);
    /**
     * RxFragment/RxActivity 中方法,声明在view中 便于在mvp中的presenter里调用
     * @param <T> T
     * @return
     */
    <T> Observable.Transformer<T, T> bindUntilEvent(ActivityEvent event);
    /**
     * RxFragment/RxActivity 中方法,声明在view中 便于在mvp中的presenter里调用
     * @param <T> T
     * @return
     */
    <T> Observable.Transformer<T, T> bindUntilEvent(FragmentEvent event);

}
