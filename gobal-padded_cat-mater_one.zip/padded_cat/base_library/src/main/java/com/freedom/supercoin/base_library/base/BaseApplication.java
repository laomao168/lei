package com.freedom.supercoin.base_library.base;

import android.app.Application;
import android.content.res.Configuration;
import android.support.multidex.MultiDexApplication;

import com.hjq.toast.ToastUtils;


/**
 * Created by jianping on 2018/11/19.
 */

public class BaseApplication extends MultiDexApplication {

    public  static Application context;

    @Override
    public void onCreate() {
        super.onCreate();
        context = this;
        ToastUtils.init(this);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        /**
         * 设置 当手机字体大小变化时，APP重新设置为默认字体大小，防止不适配
         */
        if (newConfig.fontScale != 1) {
            getResources();
        }
        super.onConfigurationChanged(newConfig);
    }
}
