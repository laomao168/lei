package com.freedom.supercoin.base_library.dialog;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.ColorInt;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;


import com.freedom.supercoin.base_library.AppConst;
import com.freedom.supercoin.base_library.R;
import com.freedom.supercoin.base_library.utils.SPUtils;

import java.io.Serializable;


public class ComDialog extends BaseDialog implements View.OnClickListener {

    private final String LOG_TAG = "ComDialog";
    private TextView mTvTitle, mTvInfo, mTvConfirm, mTvCancel;
    private static final String EXTRA_BUILDER = "extra_builder";

    private OnDialogClickListener l;
    private Builder builder;
    private View view, viewCenter;

    public void setOnDialogClickListener(OnDialogClickListener l) {
        this.l = l;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setCancelable(false);

        int style = DialogFragment.STYLE_NORMAL, theme = 0;
        setStyle(style, theme);
    }

    public interface OnDialogClickListener {
        void onConfirmClick();

        void onCancelClick();
    }

    public static ComDialog newInstance(Builder builder) {

        Bundle args = new Bundle();
        args.putSerializable(EXTRA_BUILDER, builder);
        ComDialog fragment = new ComDialog();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    protected int setContentId() {
        return R.layout.dialog_com;
    }

    @Override
    protected void initView() {
        mTvTitle = findView(R.id.tv_com_title);
        mTvInfo = findView(R.id.tv_com_info);
        mTvConfirm = findView(R.id.tv_com_confirm);
        mTvCancel = findView(R.id.tv_com_cancel);
//        view = findView(R.id.view_split);
        viewCenter = findView(R.id.view_divider_v_com_dialog);
        mTvConfirm.setOnClickListener(this);
        mTvCancel.setOnClickListener(this);
    }

    @Override
    protected void initData() {
        builder = (Builder) getArguments().getSerializable(EXTRA_BUILDER);
        if (builder != null) {
            String title = builder.title;
            String info = builder.info;
            String confirm = builder.confirm;
            String cancel = builder.cancel;
            if (TextUtils.isEmpty(title)) {
                mTvTitle.setVisibility(View.GONE);
//                view.setVisibility(View.GONE);

            } else {
                mTvTitle.setText(title);
                mTvTitle.setVisibility(View.VISIBLE);
//                view.setVisibility(View.VISIBLE);
            }

            if (TextUtils.isEmpty(info)) {
                mTvInfo.setText("");
            } else {
                mTvInfo.setText(info);
            }
            if (builder.isSingle) {
                mTvCancel.setVisibility(View.GONE);
                viewCenter.setVisibility(View.GONE);
            }

            mTvConfirm.setText(confirm);
            mTvCancel.setText(cancel);

            if (builder.cancelColor != -1) {
                mTvCancel.setTextColor(builder.cancelColor);
            }
            if (builder.comFirmColor != -1) {
                mTvConfirm.setTextColor(builder.comFirmColor);
            }
            if (builder.cancelBgColor != -1) {
                mTvCancel.setBackgroundColor(builder.cancelBgColor);
            }
            if (builder.comFirmBgColor != -1) {
                mTvConfirm.setBackgroundColor(builder.comFirmBgColor);
            }
        }

    }

    @Override
    public void onStart() {
        super.onStart();
        if (builder == null) return;
        if (builder.status) {
            //点击外部不消失
            getDialog().setCancelable(false);
        } else {
            getDialog().setCancelable(true);
        }
    }


    @Override
    public void onClick(View v) {
        int i = v.getId();
        if (i == R.id.tv_com_confirm) {
            if (l != null) {
                l.onConfirmClick();
            }

        } else if (i == R.id.tv_com_cancel) {
            if (l != null) {
                l.onCancelClick();
            }
        }
        if (builder != null) {
            if (builder.dismiss) { //点击不消失
                return;
            }
        }
        dismiss();
    }

    public static class Builder implements Serializable {

        private String title;
        private String info = "";
        private String confirm = "确认";
        private String cancel = "取消";
        private boolean status = false;
        private boolean isSingle = false;
        private boolean dismiss = false;
        private int cancelColor = -1;
        private int comFirmColor = -1;
        private int cancelBgColor = -1;
        private int comFirmBgColor = -1;

        public Builder(@NonNull Context context) {
            int language = SPUtils.getInstance().getInt(AppConst.Keys.LANGUAGE, 0);
            if (language == 1) {
                confirm = "Confirm";
                cancel="Cancel";
            }
        }

        public Builder setTitle(String title) {
            this.title = title;
            return this;
        }

        public Builder setInfo(String info) {
            this.info = info;
            return this;
        }

        public Builder setConfirmText(@NonNull String confirm) {
            this.confirm = confirm;
            return this;
        }

        public Builder setCancelText(@NonNull String cancel) {
            this.cancel = cancel;
            return this;
        }

        public ComDialog create() {
            return ComDialog.newInstance(this);
        }

        public Builder setCancelColor(@ColorInt int color) {
            this.cancelColor = color;
            return this;
        }

        public Builder setConFirmColor(@ColorInt int color) {
            this.comFirmColor = color;
            return this;
        }

        public Builder setConFirmBgColor(@ColorInt int color) {
            this.comFirmBgColor = color;
            return this;
        }

        public Builder setCancelBgColor(@ColorInt int color) {
            this.cancelBgColor = color;
            return this;
        }


        /**
         * 点击外部 不消失
         *
         * @param status
         * @return
         */
        public Builder setStatus(boolean status) {
            this.status = status;
            return this;
        }

        /**
         * 单个选项
         *
         * @param isSingle
         * @return
         */
        public Builder setSingle(boolean isSingle) {
            this.isSingle = isSingle;
            return this;
        }

        /**
         * @param dismiss 默认true 点击按钮消失，false 点击不消失
         * @return
         */
        public Builder setDismiss(boolean dismiss) {
            this.dismiss = dismiss;
            return this;
        }
    }
}
