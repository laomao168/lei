package com.freedom.supercoin.base_library.utils;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by ljp on 2018/4/12.
 */
public class DateUtil {

    //当前时间
    //public static  Date DATE_NOW=new Date();


    /**
     * 得到完整的时间戳，格式:yyyyMMddHHmmssSSS(年月日时分秒毫秒)
     *
     * @return 完整的时间戳
     */
    public static String getFullTimeStamp() {
        return new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());
    }


    /**
     * 得到简单的时间戳，格式:yyyyMMdd(年月日)
     *
     * @return 简单的时间戳
     */
    public static String getSimpleTimeStamp() {
        return new SimpleDateFormat("yyyyMMdd").format(new Date());
    }

    /**
     * 根据指定的格式得到时间戳
     *
     * @param pattern 指定的格式
     * @return 指定格式的时间戳
     */
    public static String getTimeStampByPattern(String pattern) {
        return new SimpleDateFormat(pattern).format(new Date());
    }

    /**
     * 得到当前日期格式化后的字符串，格式：yyyy-MM-dd(年-月-日)
     *
     * @return 当前日期格式化后的字符串
     */
    public static String getTodayStr() {
        return new SimpleDateFormat("yyyy-MM-dd").format(new Date());
    }
    /**
     * 得到当前月第一天格式化后的字符串，格式：yyyy-MM-dd(年-月-日)
     *
     * @return 当前日期格式化后的字符串
     */
    public static String getMonthFirstDayStr() {

        String format = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        return format.substring(0, 8) + "01";
    }

    /**
     * 时间戳，格式:yyyy-MM-dd HH:mm:ss(年-月-日  时：分：秒)
     *
     * @return 简单的时间戳
     */
    public static String getDateTimeStamp(Date date) {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);
    }
    /**
     * 时间戳，格式:yyyy-MM-dd HH:mm:ss(年-月-日  时：分：秒)
     *
     * @return 简单的时间戳
     */
    public static String getDateTimeStamp(long time) {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(time);
    }

    public static Date getDateByString(String str) {
        SimpleDateFormat sim = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        Date dateTime = null;
        try {
            dateTime = sim.parse(str);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return dateTime;
    }

    /**
     * 秒转时分秒
     *
     * @param second
     * @return
     */
    public static String getTime(int second) {
        StringBuffer backTime = new StringBuffer();
        int h = 0;
        int d = 0;
        int s = 0;
        int temp = second % 3600;
        if (second > 3600) {
            h = second / 3600;
            if (temp != 0) {
                if (temp > 60) {
                    d = temp / 60;
                    if (temp % 60 != 0) {
                        s = temp % 60;
                    }
                } else {
                    s = temp;
                }
            }
        } else {
            d = second / 60;
            if (second % 60 != 0) {
                s = second % 60;
            }
        }
        if (h < 10) {
            backTime.append("0" + h + ":");
        } else {
            backTime.append(h + ":");
        }
        if (d < 10) {
            backTime.append("0" + d + ":");
        } else {
            backTime.append(d + ":");
        }
        if (s < 10) {
            backTime.append("0" + s + ":");
        } else {
            backTime.append(s + ":");
        }
        return backTime.toString();
    }

}