package com.freedom.supercoin.base_library.utils;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;

import java.util.ArrayList;

/**
 * Created by ljp on 2018/5/8.
 */

public class PermissionUtils {
    public static final  int PERMISSION_REQUEST_CODE =4;
    /**
     * 检查单个权限 ,无权限并申请
     * @param activity
     * @param permission
     * @return
     */
    public static boolean checkPermission(Activity activity, String permission) {
        if (ContextCompat.checkSelfPermission(activity, permission) ==
                PackageManager.PERMISSION_GRANTED) {
            return true;
        }else {
            String[] permissions = new String[1];
            permissions[0]=permission;
            ActivityCompat.requestPermissions(activity, permissions, PERMISSION_REQUEST_CODE);
            return false;
        }
    }

    /**
     * 批量权限申请
     * @param activity
     * @param mListPermissions
     * @return
     */
    public static boolean checkPermission(Activity activity, ArrayList<String> mListPermissions) {

        if (ContextCompat.checkSelfPermission(activity, Manifest.permission.READ_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED) {
            mListPermissions.remove(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (ContextCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED) {
            mListPermissions.remove(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (ContextCompat.checkSelfPermission(activity, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED) {
            mListPermissions.remove(Manifest.permission.CAMERA);
        }
        if (mListPermissions.size() == 0) {
            //权限通过
            return true;
        } else {
            String[] permissions = new String[mListPermissions.size()];
            for (int i = 0; i < mListPermissions.size(); i++) {
                permissions[i] = mListPermissions.get(i);
            }
            ActivityCompat.requestPermissions(activity, permissions, PERMISSION_REQUEST_CODE);
            return false;
        }
    }
}
