package com.freedom.supercoin.base_library;

import android.app.Activity;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;


public class AppConst {
    // 6-15的数字或字母
    public static boolean ISDEBUG = true;
    public static boolean ISLOGIN = false;
    public static int REQUESTCODE = 165;
    public static List<Activity> activityList = new ArrayList<>();

    public static void AddActivity(Activity activity) {
        activityList.add(activity);
    }

    public static void finishActivity() {
        for (Activity activity : activityList) {
            if (activity != null) {
                activity.finish();
            }
        }
    }

    public interface Keys {
        String LOGIN_TOKEN = "login_token";//token
        String INVITATION_CODE = "invitationcode";
        String AVATAR = "avatar";
        String NICKNAME = "nickname";
        String LANGUAGE = "LANGUAGE";
        String PHONE = "phone"; //手机
        String USER_ID = "user_id"; //用户ID
        String DEVICE_ID = "device_id";
        String TITLE = "title";
        String WEB_URL = "web_url";
        String AUCTIONID = "auctionid";
        String INTEGRAL = "integral";
        String ORDER_ID = "order_id";
        String GOODS_ID = "goods_id";
    }


    public interface Values {

        //测试
//        String IMAGE_HOST = "http://192.168.3.108:8101/";
        // 正式
        String AUCTION_RULES = " https://h5.lepai988.cn/rule.html";
        String USER_KONW = " https://h5.lepai988.cn/rule2.html";
        String COSTOM_SERVICE = "https://h5.lepai988.cn/kefu.html";
        String HELP = "https://h5.lepai988.cn/help.html";

    }
}
