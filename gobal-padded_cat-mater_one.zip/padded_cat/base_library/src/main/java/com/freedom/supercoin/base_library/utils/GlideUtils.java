package com.freedom.supercoin.base_library.utils;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;
import com.bumptech.glide.util.Util;
import com.hjq.toast.ToastUtils;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 *
 */
public class GlideUtils {


    /**
     * 加载指定大小图片
     * 其他默认设置
     *
     * @param context
     * @param path
     * @param width
     * @param height
     * @param imageView
     */
    public static void loadImage(Context context, String path, int width, int height, ImageView
            imageView) {
        RequestOptions requestOptions = new RequestOptions().override(width, height);
        if (checkContext(context)) return;
        Glide.with(context)
                .load(path)
                .apply(requestOptions)
                .into(imageView);
    }

    /**
     * 检查context  防止类似错误
     * You cannot start a load for a destroyed activity
     * You cannot start a load on a null Context
     *
     * @param context
     * @return
     */
    private static boolean checkContext(Context context) {
        if (context == null) return true;
        if (Util.isOnMainThread() && !(context instanceof Application)) {
            if (context instanceof FragmentActivity) {
                if (((FragmentActivity) context).isDestroyed()) return true;
            } else if (context instanceof Activity) {
                if (((Activity) context).isDestroyed()) return true;
            }
        }
        return false;
    }

    /**
     * 加载指定大小 带错误图片
     *
     * @param context
     * @param path
     * @param width
     * @param height
     * @param imageView
     * @param errorImageView
     */

    public static void loadImage(Context context, String path, int width, int height, ImageView
            imageView, int errorImageView) {
        RequestOptions requestOptions = new RequestOptions().override(width, height).error
                (errorImageView);
        if (checkContext(context)) return;
        Glide.with(context)
                .load(path)
                .apply(requestOptions)
                .into(imageView);
    }


    /**
     * 加载图片
     *
     * @param context
     * @param path
     * @param imageView
     */
    public static void loadImage(Context context, String path, ImageView imageView) {
        if (checkContext(context)) return;
        Glide.with(context)
                .load(path)
                .into(imageView);
    }

    /**
     * 加载图片,带加载错误图片
     *
     * @param context
     * @param path
     * @param imageView
     * @param errorImageView
     */
    public static void loadImage(Context context, String path, ImageView imageView, int
            errorImageView) {
        RequestOptions requestOptions = new RequestOptions().error(errorImageView);
        if (checkContext(context)) return;
        Glide.with(context)
                .load(path)
                .apply(requestOptions)
                .into(imageView);
    }

    /**
     * 加载图片回调bitmap
     *
     * @param context
     * @param path
     * @param imageView
     * @param listener
     */
    public static void loadImage(Context context, String path, ImageView imageView,
                                 RequestListener<Drawable> listener) {
        if (checkContext(context)) return;
        Glide.with(context)
                .load(path)
                .listener(listener)
                .into(imageView);

    }


    //设置加载中以及加载失败图片
    public static void loadImage(Context context, String path, ImageView imageView, int
            loadingImage, int errorImageView) {
        RequestOptions requestOptions = new RequestOptions().error(errorImageView).placeholder
                (loadingImage);
        if (checkContext(context)) return;
        Glide.with(context)
                .load(path)
                .apply(requestOptions)
                .into(imageView);

    }

    /**
     * 清理理磁盘缓存
     *
     * @param context
     */
    public static void clearDiskCache(final Context context) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                Glide.get(context).clearDiskCache();
            }
        }).start();
    }


    /**
     * 清理内存和磁盘缓存
     *
     * @param context
     */
    public static void clear(Context context) {
        clearDiskCache(context);
        Glide.get(context).clearMemory();
    }


    public static void loadImage(Activity activity, Uri uri, int ic_default_image, int
            ic_default_image1, ImageView imageView) {
        RequestOptions requestOptions = new RequestOptions().placeholder(ic_default_image).error
                (ic_default_image1);
        if (checkContext(activity)) return;
        Glide.with(activity).load(uri).apply(requestOptions).into(imageView);
    }

    public static void loadImage(Activity activity, Uri uri, ImageView imageView) {
        if (checkContext(activity)) return;
        Glide.with(activity).load(uri).into(imageView);
    }

    /**
     * 加载圆形图片
     *
     * @param context
     * @param url
     * @param iv
     * @param radus   dp
     */
    public static void loadRound(Context context, String url, ImageView iv, int radus) {
        RequestOptions requestOptions = new RequestOptions().transform(new GlideRoundTransform
                (context, radus));
        if (checkContext(context)) return;
        Glide.with(context)
                .load(url)
                .apply(requestOptions)
                .into(iv);
    }

    /**
     * 加载图片并保存到本地
     *
     * @param mContext
     * @param url
     * @param imageView2
     */
    public static void loadImageToLocal(Context mContext, String url, final ImageView imageView2,
                                        String path) {
        if (checkContext(mContext)) return;
        final File file = new File(path);
        if (file.exists()) {
            file.delete();
        }
        Glide.with(mContext).asBitmap().load(url).into(new SimpleTarget<Bitmap>() {
            @Override
            public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<?
                    super Bitmap> transition) {
                imageView2.setImageBitmap(resource);
                BufferedOutputStream bos = null;
                try {
                    bos = new BufferedOutputStream(new FileOutputStream(file));
                    resource.compress(Bitmap.CompressFormat.JPEG, 100, bos);
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    if (bos != null) {
                        try {
                            bos.flush();
                            bos.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });
    }

    public static String saveImageToLocal(Bitmap bmp) {
        // 首先保存图片
        String storePath = Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + "dearxy";
        File appDir = new File(storePath);
        if (!appDir.exists()) {
            appDir.mkdir();
        }
        String fileName = System.currentTimeMillis() + ".jpg";
        File file = new File(appDir, fileName);
        try {
            FileOutputStream fos = new FileOutputStream(file);
            //通过io流的方式来压缩保存图片
            bmp.compress(Bitmap.CompressFormat.JPEG, 60, fos);
            fos.flush();
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return storePath + "/" + fileName;
    }
    /*
     * 保存文件，文件名为当前日期
     */
    public static void saveImageToGallery(Context context, Bitmap bitmap) {
        String fileName;
        File file;
        if (Build.BRAND.equals("xiaomi")) { // 小米手机
            fileName =
                    Environment.getExternalStorageDirectory().getPath() + "/DCIM/Camera/" + System.currentTimeMillis();
        } else if (Build.BRAND.equals("Huawei")) {
            fileName =
                    Environment.getExternalStorageDirectory().getPath() + "/DCIM/Camera/" +  System.currentTimeMillis();
        } else { // Meizu 、Oppo
            fileName = Environment.getExternalStorageDirectory().getPath() + "/DCIM/" +  System.currentTimeMillis();
        }
        file = new File(fileName);

        if (file.exists()) {
            file.delete();
        }
        FileOutputStream out;
        try {
            out = new FileOutputStream(file);
// 格式为 JPEG，照相机拍出的图片为JPEG格式的，PNG格式的不能显示在相册中
            if (bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)) {
                out.flush();
                out.close();
// 插入图库
                MediaStore.Images.Media.insertImage(context.getContentResolver(),
                        file.getAbsolutePath(),  System.currentTimeMillis()+"", null);

            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
// 发送广播，通知刷新图库的显示
        context.sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.parse("file" +
                "://" + fileName)));


    }


}
