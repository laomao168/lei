package com.freedom.supercoin.base_library.widget.spingview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.freedom.supercoin.base_library.R;


public class DefaultHeader extends BaseHeader {
    private Context context;
    private int rotationSrc;
    private int arrowSrc;

    private TextView headerTitle;

    public DefaultHeader(Context context){
        this(context, R.drawable.progress_small, R.mipmap.ic_arrow_down);
    }

    public DefaultHeader(Context context, int rotationSrc, int arrowSrc){
        this.context = context;
        this.rotationSrc = rotationSrc;
        this.arrowSrc = arrowSrc;

    }

    @Override
    public View getView(LayoutInflater inflater, ViewGroup viewGroup) {
        View view = inflater.inflate(R.layout.spring_default_header, viewGroup, true);
        headerTitle = (TextView) view.findViewById(R.id.default_header_title);
        return view;
    }

    @Override
    public void onPreDrag(View rootView) {
    }

    @Override
    public void onDropAnim(View rootView, int dy) {
    }

    @Override
    public void onLimitDes(View rootView, boolean upORdown) {
        if (!upORdown){
            headerTitle.setText("松手,我要刷新啦~");
        }
        else {
            headerTitle.setText("下拉可以刷新~");
        }
    }

    @Override
    public void onStartAnim() {
        headerTitle.setText("洗刷刷洗刷刷,刷新中~");
    }

    @Override
    public void onFinishAnim() {
        headerTitle.setText("下拉可刷新~");
    }
}