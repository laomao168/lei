package com.freedom.supercoin.base_library.utils;


import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public class StringUtils {

    public static boolean isEmpty(String text) {
        return null == text || "".equals(text) || " ".equals(text) || "null".equals(text) || text.length() == 0;
    }

    /**
     * 是否是手机号码
     *
     * @return true是 false不是
     */
    public static boolean isTel(String str) {
        Pattern p = Pattern
                .compile("^((13[0-9])|(14[[0-9]])|(17[0-9])||(15[0-9])|(16[0-9])|(18[0-9]))\\d{8}$");
        Matcher m = p.matcher(str);
        return m.matches();
    }

    /**
     * 隐藏手机号码
     * @param str
     * @return
     */
    public static String hideTel(String str) {
       return str.replaceAll("(\\d{3})\\d{4}(\\d{4})", "$1****$2");
    }

    /**
     * 隐藏手机号码
     * @param str
     * @return
     */
    public static String hideEmail(String str) {
        return str.replaceAll("(\\w?)(\\w+)(\\w)(@\\w+\\.[a-z]+(\\.[a-z]+)?)", "$1****$3$4");
    }

    public static boolean isAllNum(String str) {
        Pattern pattern = Pattern.compile("[0-9]*");
        return pattern.matcher(str).matches();
    }

    public static boolean isAllChar(String str) {
        return str.matches("^[a-zA-Z]*");
    }

    /**
     * 验证邮箱格式是否正确
     */
    public static boolean isEmail(String email) {
        String regex = "\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*";
        return email.matches(regex);
    }

    /**
     * 比较图形验证码是相同
     *
     * @param code0
     * @param code1
     * @return
     */
    public static boolean isAuthCodeSame(String code0, String code1) {
        if (isEmpty(code0) || isEmpty(code1)) return false;
        String lowerCode0 = code0.toLowerCase();
        String lowerCode1 = code1.toLowerCase();
        return lowerCode0.equals(lowerCode1);
    }

    /**
     * 字符串的压缩
     *
     * @param str
     *            待压缩的字符串
     * @return    返回压缩后的字符串
     * @throws IOException
     */
    public static String compress(String str) {
        if (null == str || str.length() <= 0) {
            return str;
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        GZIPOutputStream gzip;
        try {
            gzip = new GZIPOutputStream(out);
            gzip.write(str.getBytes());
            gzip.close();
            return out.toString("ISO-8859-1");
        } catch (IOException e) {
            e.printStackTrace();
            return "500"; //返回错误
        }
    }

    /**
     * 字符串的解压
     * @param str
     *            对字符串解压
     * @return    返回解压缩后的字符串
     */
    public static String unCompress(String str){
        if (null == str || str.length() <= 0) {
            return str;
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ByteArrayInputStream in;
        try {
            in = new ByteArrayInputStream(str
                    .getBytes("ISO-8859-1"));
            // 使用默认缓冲区大小创建新的输入流
            GZIPInputStream gzip = new GZIPInputStream(in);
            byte[] buffer = new byte[256];
            int n = 0;
            while ((n = gzip.read(buffer)) >= 0) {
                out.write(buffer, 0, n);
            }
            return out.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return "500";//错误
        }
    }

}
