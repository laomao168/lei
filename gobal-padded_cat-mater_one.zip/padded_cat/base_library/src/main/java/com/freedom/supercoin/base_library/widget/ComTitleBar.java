package com.freedom.supercoin.base_library.widget;

import android.content.Context;
import android.graphics.Color;
import android.support.v4.app.FragmentActivity;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.freedom.supercoin.base_library.R;
import com.freedom.supercoin.base_library.listener.OnTitleBarClickListener;

import java.util.ArrayList;
import java.util.List;

public class ComTitleBar extends RelativeLayout implements View.OnClickListener {

    /**
     * 文本TextView 类型
     **/
    public static final String TYPE_TEXTVIEW = "TV";

    private RelativeLayout mRootView;
    private ImageView iv_Left;
    private TextView tv_title;

    private Context mContext;
    private List<View> list_view = new ArrayList<>();

    /*private ImageView iv_conn;*/
    private int colorBg;

    private final int BASE_VIEW_ID = 100;
    public static final int TITLE_LEFT = 50 + 3;
    public static final int TITLE_RIGHT_ONE = 100;
    public static final int TITLE_RIGHT_TWO = 101;
    public static final int TITLE_RIGHT_THREE = 102;
    public static final int TITLE_RIGHT_FOUR = 103;
    public static final int TITLE_RIGHT_FIVE = 104;

    private OnTitleBarClickListener mOnTitleBarClickListener;
    private LinearLayout mRightRoot;
    private RelativeLayout mRlRoot;

    public ComTitleBar(Context context) {
        this(context, null);
    }

    public ComTitleBar(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public ComTitleBar(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.mContext = context;
        initView(context);
    }


    private void initView(Context context) {

        mRootView = (RelativeLayout) View.inflate(context, R.layout.titlebar, this);
        mRightRoot = findViewById(R.id.ll_right_root_title);
        mRlRoot = findViewById(R.id.rl_root);
        iv_Left = findViewById(R.id.iv_break_new_titleBar);
        iv_Left.setId(TITLE_LEFT);
        iv_Left.setOnClickListener(this);
        iv_Left.setImageResource(R.mipmap.ic_titlebar_back);
        tv_title = findViewById(R.id.tv_title_new_titleBar);

    }

    public static int dip2px(Context context, float dipValue) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (dipValue * scale + 0.5f);
    }


    /**
     * 设置title文字
     *
     * @param title 显示文字
     */
    public void setTitle(String title) {
        if (tv_title != null) {
            tv_title.setText(title);
        }
    }

    /**
     * 设置title 颜色
     *
     * @param color 标题颜色
     */
    public void setTextColor(String color) {
        if (tv_title != null) {
            tv_title.setTextColor(Color.parseColor(color));
        }
    }

    /**
     * 设置title 背景
     *
     * @param color 标题颜色
     */
    public void setBgColor(String color) {
        if (mRlRoot != null) {
            mRlRoot.setBackgroundColor(Color.parseColor(color));
        }
    }
    /**
     * 获取右边的view
     *
     * @param position
     * @return
     */
    public View getRightView(int position) {
        if (list_view.size() > position && position >= 0) {
            return list_view.get(position);
        }
        return null;
    }

    /**
     * 添加右边 单个
     *
     * @param view
     */
    public void addRightView(View view) {
        this.list_view.add(view);
        addRight();
    }

    /**
     * 添加右边 多个
     *
     * @param list_view
     */
    public void addRightView(List<View> list_view) {
        this.list_view = list_view;
        addRight();
    }

    /**
     * 添加右边
     */
    private void addRight() {
        for (int i = list_view.size() - 1; i > -1; i--) {
            LayoutParams lp;
            if (TYPE_TEXTVIEW.equals(list_view.get(i).getTag())) {
                lp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.MATCH_PARENT);
            } else {
                lp = new LayoutParams(dip2px(mContext, 28), LayoutParams.MATCH_PARENT);
            }
            View view = list_view.get(i);
            view.setPadding(dip2px(mContext, 6), 0, dip2px(mContext, 6), 0);
            view.setId(BASE_VIEW_ID + i);
            view.setOnClickListener(this);
            mRightRoot.addView(view, lp);
        }
    }

    public void hintTitle() {
        if (tv_title != null) {
            tv_title.setVisibility(View.GONE);
        }
    }


    /**
     * 设置左边按钮图片样式
     *
     * @param resId 资源id
     */
    public void setLeftImage(int resId) {
        iv_Left.setImageResource(resId);
    }

    /**
     * 隐藏返回按钮
     */
    public void hideLeft() {
        iv_Left.setVisibility(View.GONE);
    }

    @Override
    public void onClick(View v) {
        if (mOnTitleBarClickListener != null) {
            boolean b = mOnTitleBarClickListener.onTitleBarClicked(v.getId());
            if (!b) {
                return;
            }
        }
        switch (v.getId()) {
            case TITLE_LEFT:
                ((FragmentActivity) mContext).finish();
                break;
        }
    }

    public void setBreakVisibility(int visibility) {
        if (iv_Left == null) return;
        iv_Left.setVisibility(visibility);
    }

    public void setRightVisibility(int position, int visibility) {
        if (position >= list_view.size()) return;
        list_view.get(position).setVisibility(visibility);
    }

    public void setOnTitleBarClickListener(OnTitleBarClickListener onTitleBarClickListener) {
        this.mOnTitleBarClickListener = onTitleBarClickListener;
    }
}
