package com.ycbjie.ycupdatelib;


import android.support.v4.content.FileProvider;
/**
 * <pre>
 *     @author yangchong
 *     blog  : https://github.com/yangchong211
 *     time  : 2017/05/29
 *     desc  : 版本更新弹窗
 *     revise:
 * </pre>
 */
public class VersionFileProvider extends FileProvider{

}
