package com.lepai;

import android.app.Activity;

import com.tencent.mm.opensdk.openapi.IWXAPI;

/**
 * Created by ljp on 2018/5/10.
 */

public class WXEntryActivity extends Activity   {

    private String TAG="WXEntryActivity";
    private IWXAPI api;


}
