package com.lepai;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import com.freedom.supercoin.activity.PaySuccessActivity;
import com.freedom.supercoin.base_library.utils.LogUtils;
import com.hjq.toast.ToastUtils;
import com.tencent.mm.opensdk.constants.ConstantsAPI;
import com.tencent.mm.opensdk.modelbase.BaseReq;
import com.tencent.mm.opensdk.modelbase.BaseResp;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.IWXAPIEventHandler;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;


public class WXPayEntryActivity extends Activity implements IWXAPIEventHandler {

    private static final String TAG = "WXPayEntryActivity";

    private IWXAPI api;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        api = WXAPIFactory.createWXAPI(this, "wx056415a7b3423b5e");
        api.handleIntent(getIntent(), this);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        api.handleIntent(intent, this);
    }

    @Override
    public void onReq(BaseReq req) {
    }

    @Override
    public void onResp(BaseResp resp) {
        LogUtils.ShowD(TAG, "onPayFinish, errCode = " + resp.errCode);
        if (resp.getType() == ConstantsAPI.COMMAND_PAY_BY_WX) {
            switch (resp.errCode) {
                case 0:
                    ToastUtils.show( "支付成功");
                    LogUtils.ShowD(TAG,"支付成功");
                    startActivity(new Intent(this,PaySuccessActivity.class));
                    finish();
                    break;
                case -1:
                    LogUtils.ShowD(TAG,"支付失败");
                    finish();
                    break;
                case -2:
                    LogUtils.ShowD(TAG,"支付失败");
                    finish();
                    break;
            }
        }
    }
}