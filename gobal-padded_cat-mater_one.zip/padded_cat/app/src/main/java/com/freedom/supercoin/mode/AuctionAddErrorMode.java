package com.freedom.supercoin.mode;

public class AuctionAddErrorMode {

    /**
     * code : 1
     * count : null
     * data :
     * error : true
     * msg : 哎呀!出价又慢了!
     * result : false
     * success : false
     */

    public String code;
    public String count;
    public String data;
    public boolean error;
    public String msg;
    public boolean result;
    public boolean success;
}
