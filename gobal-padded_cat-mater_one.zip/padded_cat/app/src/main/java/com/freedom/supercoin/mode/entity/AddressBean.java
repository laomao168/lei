package com.freedom.supercoin.mode.entity;

public class AddressBean {
    public String consignee;
    public String mobile;
    public int addressId;
    public int tolerant;
    public int province;
    public int city;
    public int district;
    public int street;
    public String address;

//    addressEdit(addressId: Int, consignee: String, mobile: String, province: Int, city: Int,
//    district: Int, street: Int, address: String, tolerant: Int)
}
