package com.freedom.supercoin.popwindow;

import android.content.Context;
import android.view.View;
import android.widget.PopupWindow;

import java.util.List;

public class SelectTradePop {

    private final Context context;
    private final View view;
    private View rootView;
    private PopupWindow mPopupWindow;
    private List<String> list;

    public SelectTradePop(Context context, View view) {

        this.context = context;
        this.view = view;
        init();
    }

    private void init() {
//        rootView = LayoutInflater.from(context).inflate(R.layout.pop_select_trade_pop, null);

    }



    /**
     * 显示popupwindow
     */
    public void show() {
        if (!mPopupWindow.isShowing()) {
            mPopupWindow.showAsDropDown(view);
        }
    }

    public boolean isShow() {
        return mPopupWindow.isShowing();
    }

    /**
     * 显示popupwindow
     *
     * @param view
     */
    public void show(View view) {
        if (mPopupWindow.isShowing()) {
            mPopupWindow.dismiss();
        } else {
            mPopupWindow.showAsDropDown(view);
        }
    }

    /**
     * 关闭popupwindow
     */
    public void dismiss() {
        if (mPopupWindow.isShowing()) mPopupWindow.dismiss();
    }


    public interface OnItemClickListener{
        void onPopItemClick(int position,String bean);
    }

    private OnItemClickListener onItemClickListener;

    public void setOnItemClickListener( OnItemClickListener onItemClickListener) {

        this.onItemClickListener = onItemClickListener;
    }

}
