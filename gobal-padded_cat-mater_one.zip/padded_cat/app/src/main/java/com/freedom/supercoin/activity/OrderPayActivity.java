package com.freedom.supercoin.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.View;

import com.freedom.supercoin.R;
import com.freedom.supercoin.base_library.AppConst;
import com.freedom.supercoin.base_library.utils.GlideUtils;
import com.freedom.supercoin.base_library.utils.StrUtils;
import com.freedom.supercoin.common.UiActivity;
import com.freedom.supercoin.contract.OrderPayContact;
import com.freedom.supercoin.databinding.ActivityABinding;
import com.freedom.supercoin.databinding.ActivityOrderPayBinding;
import com.freedom.supercoin.mode.AddressListMode;
import com.freedom.supercoin.mode.BalanceDetailMode;
import com.freedom.supercoin.mode.ChargeTypeMode;
import com.freedom.supercoin.mode.OrderDetailMode;
import com.freedom.supercoin.mode.PayAlipayRes;
import com.freedom.supercoin.mode.PayReq;
import com.freedom.supercoin.mode.PayRes;
import com.freedom.supercoin.persenter.OrderPayPresenter;
import com.freedom.supercoin.persenter.OrderPresenter;
import com.freedom.supercoin.utils.AliPayAPI;
import com.freedom.supercoin.utils.RSAUtils;
import com.freedom.supercoin.utils.WXPayUtils;

import java.util.List;

/**
 * @author : lijianping
 * @date : Created on 2019/7/11.
 * des:
 */
public class OrderPayActivity extends UiActivity<ActivityOrderPayBinding> implements OrderPayContact.View, AliPayAPI.OnAliPayListener {

    private OrderPayPresenter presenter;
    private int orderId;
    private int paytype;
    private boolean hasGetDetail;
    private double orderPrice;
    private int addressId;
    private int type = 0;
    private int goodsId;

    @Override
    protected int layoutResId() {
        return R.layout.activity_order_pay;
    }

    @Override
    protected void initData() {
        binding.titleBar.setTextColor("#ffffff");
        binding.titleBar.setLeftImage(R.mipmap.ic_back_white);
        binding.titleBar.setTitle("支付");
        presenter = new OrderPayPresenter(this);
        orderId = getIntent().getIntExtra(AppConst.Keys.ORDER_ID, 0);
        presenter.getOrderDetail(orderId);
        presenter.getAddress();
        presenter.getBalance();
        paytype = 1;
        binding.ivCardStatus.setImageResource(R.mipmap.ic_address_select);
        binding.rlPayPwd.setVisibility(View.VISIBLE);
    }

    @Override
    protected void initEvent() {
        binding.setClick(v -> {
            switch (v.getId()) {
                //1余额2微信3支付宝4.积分
                case R.id.ll_alipay:
                    paytype = 3;
                    binding.rlPayPwd.setVisibility(View.GONE);
                    binding.ivCardStatus.setImageResource(R.mipmap.btn_pay_style_normal);
                    binding.ivWechatStatus.setImageResource(R.mipmap.btn_pay_style_normal);
                    binding.ivAlipayStatus.setImageResource(R.mipmap.ic_address_select);
                    break;
                case R.id.ll_wechat:
                    paytype = 2;
                    binding.rlPayPwd.setVisibility(View.GONE);
                    binding.ivCardStatus.setImageResource(R.mipmap.btn_pay_style_normal);
                    binding.ivWechatStatus.setImageResource(R.mipmap.ic_address_select);
                    binding.ivAlipayStatus.setImageResource(R.mipmap.btn_pay_style_normal);
                    break;
                case R.id.ll_card:
                    binding.rlPayPwd.setVisibility(View.VISIBLE);
                    paytype = 1;
                    binding.ivCardStatus.setImageResource(R.mipmap.ic_address_select);
                    binding.ivWechatStatus.setImageResource(R.mipmap.btn_pay_style_normal);
                    binding.ivAlipayStatus.setImageResource(R.mipmap.btn_pay_style_normal);
                    break;
                case R.id.tv_to_pay:
                    if (hasGetDetail) {
                        toPay();
                    } else {
                        showMessage("请稍后");
                    }
                    break;
                case R.id.rl_receiver:
                    getOperation().addParameter(AppConst.Keys.ORDER_ID, orderId);
                    getOperation().forwardForResult(AddressActivity.class, AppConst.REQUESTCODE);
                    break;
            }
        });
    }

    private void toPay() {
        PayReq payReq = new PayReq();
        if (paytype == 0) {
            showMessage("请选择支付方式");
            return;
        }
        payReq.payType = paytype;
        if (paytype == 1) {//余额
            String pwd = binding.etPwd.getText().toString();
            if (TextUtils.isEmpty(pwd)) {
                showMessage("请输入6位数字支付密码");
                return;
            }
            payReq.payPassWord = RSAUtils.publicEncrypt(pwd);
        }
        payReq.orderType = 1;
        payReq.type = 1;
        payReq.addressId = addressId;
        payReq.orderId = orderId;
        payReq.goodsId = goodsId;
        presenter.getPayInfo(payReq);
    }

    @Override
    public void onLoadChargeTypeSuccess(ChargeTypeMode mode) {
        if (!mode.success) return;
        if (mode.data == null) return;
        try {
            type = Integer.parseInt(mode.data);
        } catch (Exception e) {
            e.printStackTrace();
        }
//        1微信，2原生支付宝，3 第三方支付宝，4微信，原生支付宝5微信，第三方支付宝
        switch (type) {
            case 1:
//                binding.llCard.setVisibility(View.GONE);
                binding.llAlipay.setVisibility(View.GONE);
                break;

            case 2:
//                binding.llCard.setVisibility(View.GONE);
                binding.llWechat.setVisibility(View.GONE);
                break;
            case 3:
                binding.llAlipay.setVisibility(View.GONE);
                binding.llWechat.setVisibility(View.GONE);
                break;
            case 4:
//                binding.llCard.setVisibility(View.GONE);
                break;
            case 5:
                binding.llAlipay.setVisibility(View.GONE);
                break;

        }
    }

    @Override
    public void onLoadPayResWechatSuccess(PayRes payRes, int payType) {
        WXPayUtils.getInstance().toWXPay(this, payRes.data);
    }

    @Override
    public void getBalanceSuccess(BalanceDetailMode mode) {
        binding.tvBalance.setText("账户余额( ¥" + StrUtils.getRemoveZreoNum(mode.amount) + ")");
    }

    @Override
    public void onLoadPayResAlipaySuccess(PayAlipayRes payAlipayRes, int payType) {
        AliPayAPI.getInstance(this).startPay(this, payAlipayRes.data.order);
    }

    @Override
    public void getOrderDetailSuccess(OrderDetailMode mode) {
        hasGetDetail = true;
        addressId = mode.addressId;
        goodsId = mode.goodsId;
        binding.tvGoodsName.setText(mode.goodsName);
        binding.tvPrice.setText("¥ " + StrUtils.getRemoveZreoNum(mode.orderPrice));
        GlideUtils.loadImage(this, mode.logo, binding.ivGoodsImage);
        binding.tvNeedPay.setText("¥ " + StrUtils.getRemoveZreoNum(mode.orderPrice));
    }

    @Override
    public void getAddressListSuccess(AddressListMode mode) {
        if (mode != null && mode.success) {
            List<AddressListMode.DataBeanX.DataBean> list = mode.data.data;
            for (int i = 0; i < list.size(); i++) {
                AddressListMode.DataBeanX.DataBean bean = list.get(i);
                if (bean.tolerant == 0) {
                    addressId = bean.addressId;
                    binding.tvReceiver.setText("收货人：" + bean.consignee);
                    binding.tvContacts.setText("联系方式：" + bean.mobile);
                    binding.tvAddress.setText("收货地址：" + bean.provinceText + bean.cityText + bean.districtText + bean.streetText + bean.address);
                }
            }
        }
    }

    @Override
    public void onLoadPayResBalanceSuccess() {
        showMessage("支付成功");
        PaySuccessActivity.type=0;
        getOperation().forward(PaySuccessActivity.class);
        finish();
    }

    @Override
    public void onAliPaySuccess() {
        showMessage("支付成功");
        PaySuccessActivity.type=0;
        getOperation().forward(PaySuccessActivity.class);
        finish();
    }

    @Override
    public void onAliPayFailure() {

    }

    @Override
    public void onAliPayConfirming() {

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == AppConst.REQUESTCODE) {
            if (data == null) return;
            Bundle bundle = data.getExtras();
            String address = bundle.getString("address");
            String name = bundle.getString("name");
            String mobile = bundle.getString(AppConst.Keys.PHONE);
            addressId = bundle.getInt("addressId");
            binding.tvReceiver.setText("收货人：" + name);
            binding.tvContacts.setText("联系方式：" + mobile);
            binding.tvAddress.setText("收货地址：" + address);
        }
    }
}
