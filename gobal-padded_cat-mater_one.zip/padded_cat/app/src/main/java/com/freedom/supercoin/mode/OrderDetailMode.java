package com.freedom.supercoin.mode;

public class OrderDetailMode {

    /**
     * acceptTime : null
     * address : 浙江省台州市温岭市城东街道百丈北路5号国药控股台州有限公司
     * addressId : 333
     * applyTime : 2019-12-29 23:34:53
     * applyed : false
     * avatar : https://wx.qlogo
     * .cn/mmopen/vi_32
     * /Q0j4TwGTfTLYyLV7SOA7bktRxq5cYXmtoare2D9RDY5oFeibBkQEBBqLl2ibicwBiamWawIesEvnxuLmesyqQccIFw/132
     * buyerNamePhone :
     * carrierId : null
     * channelId :
     * clicked : false
     * complete : 0
     * consignee : 钟尧君
     * contract : 1
     * contractUrl : https://images.oneauct.com/42b2104ca2db497c8d5e4d950447ff68
     * costPrice : 100.0
     * createBy : 君君
     * createTime : 2019-12-29 22:02:10
     * createTimeString :
     * deleted : 0
     * deliverTime : null
     * deliverTimeString :
     * desc : desc
     * deviceCode :
     * deviceType :
     * endCreateTime :
     * endTime : null
     * endTimes : 1577714530000
     * fallReasons :
     * goodsId : 80
     * goodsName : J-特级普洱茶桔普洱茶
     * goodsNameId :
     * goodsType : 1
     * integral : 2800.0
     * logisticsCode :
     * logisticsName :
     * logisticsNo :
     * logo : https://images.fmallnet.com/ba6d6e0938914ebba482b2a7ed99a38a
     * mallOrderId : 4076
     * mobile : 15167618995
     * orderField :
     * orderNo : LPOM191229220210988516
     * orderPrice : null
     * orderStatus : 1
     * orderType : 1
     * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,"pageStr":"",
     * "totalPage":0,"totalResult":0}
     * params : null
     * payStatus : 1
     * payTime : 2019-12-29 22:02:10
     * payTimeString :
     * phone : 15167618995
     * pledgePrice : null
     * price : 280.0
     * priceType : 2
     * reasonRemark :
     * receivingGoodsTime : null
     * remark :
     * searchValue :
     * startCreateTime :
     * startTime : null
     * statusText :
     * supplier : 1688
     * supplierId : 7
     * transactionPrice : null
     * type : 1
     * updateBy : 君君
     * updateTime : 2019-12-29 23:34:53
     * updateTimeString :
     * userId : 490
     * userName : 君君
     *
     */

    public Object acceptTime;
    public String address;
    public int addressId;
    public String applyTime;
    public boolean applyed;
    public String avatar;
    public String buyerNamePhone;
    public Object carrierId;
    public String channelId;
    public boolean clicked;
    public int complete;
    public String consignee;
    public int contract;
    public String contractUrl;
    public double costPrice;
    public String createBy;
    public String createTime;
    public String createTimeString;
    public int deleted;
    public Object deliverTime;
    public String deliverTimeString;
    public String desc;
    public String deviceCode;
    public String deviceType;
    public String endCreateTime;
    public Object endTime;
    public long endTimes;
    public String fallReasons;
    public int goodsId;
    public String goodsName;
    public String goodsNameId;
    public int goodsType;
    public double integral;
    public String logisticsCode;
    public String logisticsName;
    public String logisticsNo;
    public String logo;
    public int mallOrderId;
    public String mobile;
    public String orderField;
    public String orderNo;
    public double orderPrice;
    public int orderStatus;
    public int orderType;
    public PageBean page;
    public Object params;
    public int payStatus;
    public String payTime;
    public String payTimeString;
    public String phone;
    public Object pledgePrice;
    public double price;
    public int priceType;
    public String reasonRemark;
    public Object receivingGoodsTime;
    public String remark;
    public String searchValue;
    public String startCreateTime;
    public Object startTime;
    public String statusText;
    public String supplier;
    public int supplierId;
    public Object transactionPrice;
    public int type;
    public String updateBy;
    public String updateTime;
    public String updateTimeString;
    public int userId;
    public String userName;
    public String endDate;

    public static class PageBean {
        /**
         * currentResult : 0
         * entityOrField : false
         * pageNumber : 1
         * pageSize : 10
         * pageStr :
         * totalPage : 0
         * totalResult : 0
         */

        public int currentResult;
        public boolean entityOrField;
        public int pageNumber;
        public int pageSize;
        public String pageStr;
        public int totalPage;
        public int totalResult;
    }
}
