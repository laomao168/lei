package com.freedom.supercoin.mode;

public class BalanceDetailMode {

    /**
     * amount : 99894.0
     * lockAmount : 0
     * todayIncome : 0
     * totalIncome : 2.0
     * userId : 1178
     * yesterdayProfit : 0.0
     */

    public double amount;
    public double lockAmount;
    public double todayIncome;
    public double totalIncome;
    public int userId;
    public double yesterdayProfit;
}
