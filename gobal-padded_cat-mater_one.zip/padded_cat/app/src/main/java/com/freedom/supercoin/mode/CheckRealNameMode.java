package com.freedom.supercoin.mode;

public class CheckRealNameMode {

    /**
     * code :
     * count : null
     * data : null
     * error : true
     * msg : 用户还未实名！
     * result : false
     * success : false
     */

    public String code;
    public Object count;
    public Object data;
    public boolean error;
    public String msg;
    public boolean result;
    public boolean success;
}
