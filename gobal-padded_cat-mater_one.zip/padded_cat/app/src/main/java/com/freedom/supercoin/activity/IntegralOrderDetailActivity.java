package com.freedom.supercoin.activity;

import android.view.View;

import com.freedom.supercoin.R;
import com.freedom.supercoin.base_library.AppConst;
import com.freedom.supercoin.base_library.utils.GlideUtils;
import com.freedom.supercoin.base_library.utils.SPUtils;
import com.freedom.supercoin.base_library.utils.StrUtils;
import com.freedom.supercoin.common.UiActivity;
import com.freedom.supercoin.contract.IntegralGoodsDetailContact;
import com.freedom.supercoin.contract.IntegralOrderDetailContact;
import com.freedom.supercoin.contract.OrderDetailContact;
import com.freedom.supercoin.databinding.ActivityOrderDetailBinding;
import com.freedom.supercoin.mode.IntegralGoodsDetailBean;
import com.freedom.supercoin.mode.IntegralOrderBean;
import com.freedom.supercoin.mode.OrderDetailMode;
import com.freedom.supercoin.persenter.IntegralGoodsDetailPresenter;
import com.freedom.supercoin.persenter.IntegralOrderDetailPresenter;
import com.freedom.supercoin.persenter.OrderDetailPresenter;

/**
 * @author : lijianping
 * @date : Created on 2019/7/11.
 * des:
 */
public class IntegralOrderDetailActivity extends UiActivity<ActivityOrderDetailBinding> implements  IntegralOrderDetailContact.View {

    private int orderId;
    private IntegralOrderDetailPresenter presenter;
    private int orderStatus;
    private OrderDetailMode mode;

    //    mallOrder/closeOrder 取消订单
//    mallOrder/receipt 确认收货
//    mallOrder/orderPayByOrderId 支付
//    mallOrder/applyMailing 签署合同
    @Override
    protected int layoutResId() {
        return R.layout.activity_order_detail;
    }

    @Override
    protected void initData() {
        binding.titleBar.setTextColor("#ffffff");
        binding.titleBar.setTitle("订单详情");
        binding.titleBar.setLeftImage(R.mipmap.ic_back_white);
        orderId = getIntent().getIntExtra(AppConst.Keys.ORDER_ID, 0);
        presenter = new IntegralOrderDetailPresenter(this);
        presenter.getOrderDetail(orderId);
        binding.tvContractStatus.setVisibility(View.VISIBLE);
    }

    @Override
    protected void initEvent() {
        binding.rlConfirm.setOnClickListener(v -> {
            //确认收货
            switch (orderStatus) {
                case 0: //去付款页面
                    getOperation().addParameter(AppConst.Keys.ORDER_ID,orderId);
                    getOperation().forward(OrderPayActivity.class);

                case 3: //待签署合同 查看合同
                case 1:
                    String url = "https://h5.lepai988.cn/contract.html?orderId="+orderId+"&token="+ SPUtils.getInstance().getString(AppConst.Keys.LOGIN_TOKEN);
                    getOperation().addParameter(AppConst.Keys.WEB_URL,url);
                    getOperation().addParameter(AppConst.Keys.TITLE,"签署合同");
                    getOperation().forward(WebActivity.class);
                    break;
                case 2://确认收货
                        presenter.receiptOrder(orderId);
                    break;
                case 4:
                    break;
            }
        });
    }

    @Override
    public void getOrderDetailSuccess(OrderDetailMode mode) {
        this.mode = mode;
        binding.tvOrderTime.setText("下单时间：" + mode.createTime);
        binding.tvGoodsName.setText(mode.goodsName);
        binding.tvPrice.setText("¥ "+StrUtils.getRemoveZreoNum(mode.orderPrice));
        GlideUtils.loadImage(this, mode.logo, binding.ivGoodsImage);
        binding.tvGoodsNum.setText("x1");
        orderStatus = mode.orderStatus;
        binding.tvEndMoney.setVisibility(View.GONE);
//        0待付款1待发货2待收货3交易完成5交易取消
//        订单状态 0待付款1待发货2待收货3交易完成4交易失败
        switch (mode.orderStatus) {
            case 0:
                binding.tvOrderStatus.setText("交易状态：待付款");
                binding.tvConfirm.setText("去支付");
                binding.rlReceiver.setVisibility(View.GONE);
                binding.llDeliver.setVisibility(View.GONE);
                binding.tvPayTime.setVisibility(View.GONE);
                binding.tvDeliverTime.setVisibility(View.VISIBLE);
                binding.tvDeliverTime.setText("支付截止时间:"+mode.endDate);
                binding.tvEndMoney.setVisibility(View.VISIBLE);
                binding.tvEndMoney.setText("(尾款¥"+mode.orderPrice+")");
                break;
            case 1:
                binding.tvOrderStatus.setText("交易状态：待发货");
                binding.tvDeliverTime.setVisibility(View.GONE);
                binding.llDeliver.setVisibility(View.GONE);
                binding.tvPayTime.setText("支付时间：" + mode.payTime);
                binding.tvReceiver.setText("收货人：" + mode.consignee);
                binding.tvContacts.setText("联系方式：" + mode.mobile);
                binding.tvAddress.setText("收货地址：" + mode.address);
                if(mode.contract!=0){
                    binding.rlConfirm.setVisibility(View.VISIBLE);
                    binding.tvContractStatus.setText("寄拍合同:已签署");
                    binding.tvConfirm.setText("查看合同");
                }else {
                    binding.tvConfirm.setText("签署合同");
                    binding.tvContractStatus.setText("寄拍合同:未签署");
                }
                break;
            case 2:
                binding.tvOrderStatus.setText("交易状态：待收货");
                binding.tvPayTime.setText("支付时间：" + mode.payTime);
                binding.tvDeliverTime.setText("发货时间："+mode.deliverTime);
                binding.tvReceiver.setText("收货人：" + mode.consignee);
                binding.tvContacts.setText("联系方式：" + mode.mobile);
                binding.tvAddress.setText("收货地址：" + mode.address);
                binding.tvDeliver.setText("快递公司："+mode.logisticsName);
                binding.tvExpressNumber.setText("快递单号："+mode.logisticsNo);
                binding.tvConfirm.setText("确认收货");
                break;
            case 3:
                binding.tvOrderStatus.setText("交易状态：交易完成");
                binding.rlConfirm.setVisibility(View.VISIBLE);
                binding.tvPayTime.setText("支付时间：" + mode.payTime);
                binding.tvDeliverTime.setText("发货时间："+mode.deliverTime);
                binding.tvReceiver.setText("收货人：" + mode.consignee);
                binding.tvContacts.setText("联系方式：" + mode.mobile);
                binding.tvAddress.setText("收货地址：" + mode.address);
                binding.tvDeliver.setText("快递公司："+mode.logisticsName);
                binding.tvExpressNumber.setText("快递单号："+mode.logisticsNo);
                binding.tvConfirm.setText("查看合同");
            case 4:
            case 5:
            case 6:
                if (mode.orderStatus==4){
                    binding.tvOrderStatus.setText("交易状态：交易失败");
                }else if (mode.orderStatus==5){
                    binding.tvOrderStatus.setText("交易状态：已取消");
                }else {
                    binding.tvOrderStatus.setText("交易状态：关闭订单（免单）");
                }
                binding.rlConfirm.setVisibility(View.GONE);
                binding.tvPayTime.setText("支付时间：" + mode.payTime);
                binding.tvReceiver.setText("收货人：" + mode.consignee);
                binding.tvContacts.setText("联系方式：" + mode.mobile);
                binding.tvAddress.setText("收货地址：" + mode.address);
                binding.rlReceiver.setVisibility(View.GONE);
                binding.llDeliver.setVisibility(View.GONE);
                binding.tvPayTime.setVisibility(View.GONE);
                binding.tvDeliverTime.setVisibility(View.GONE);
                break;
        }
    }

    @Override
    public void onCancelOrderSuccess() {

    }

    @Override
    public void onReceiptOrderSuccess() {

    }


}
