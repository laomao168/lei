package com.freedom.supercoin.mode;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2020/1/11.
 * @desc :
 */
public class UpdateMode {
    /**
     * code :
     * count : null
     * data : {"appVersionId":53,"applyed":false,"channelId":"","clicked":false,"createBy":"",
     * "createTime":"2020-01-05 15:58:46","deleted":null,"desc":"desc","deviceCode":"",
     * "deviceType":"","downloadUrl":"https://bajiu.cn/ip/","endTime":null,"orderField":"",
     * "page":{"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,"pageStr":"",
     * "totalPage":0,"totalResult":0},"params":null,"remark":"","searchValue":"",
     * "source":"android","startTime":null,"state":0,"type":1,"typeText":"","updateBy":"",
     * "updateTime":"2020-01-05 16:10:28","updateTip":"rtest","versionCode":2,"versionCoded":"1.0
     * .2","versionName":"test2"}
     * error : false
     * msg : 查询成功!
     * result : true
     * success : true
     */

    public String code;
    public Object count;
    public DataBean data;
    public boolean error;
    public String msg;
    public boolean result;
    public boolean success;

    public static class DataBean {
//        `versionCode` int(10) NOT NULL COMMENT '版本号',
//                `versionName` varchar(32) NOT NULL COMMENT '版本名称',
//                `updateTip` varchar(32) DEFAULT NULL COMMENT '更新内容(描述',
//                `downloadUrl` varchar(256) DEFAULT NULL COMMENT '下载地址url() ',
//                `state` tinyint(4) DEFAULT NULL COMMENT '是否强制升级(0:否;1:是) ',
//                `type` tinyint(4) DEFAULT NULL COMMENT '是否提示更新(默认0:否;1:是) ',
//                `source` varchar(32) DEFAULT NULL COMMENT '来源()',
//                `create_by` varchar(32) DEFAULT NULL COMMENT '创建人',
//                `create_time` datetime DEFAULT NULL COMMENT '创建时间',
//                `update_by` varchar(32) DEFAULT NULL COMMENT '更新人',
//                `update_time` datetime DEFAULT NULL COMMENT '更新时间',
//                `versionCoded` varchar(255) DEFAULT NULL COMMENT '审核版本号',
        /**
         * appVersionId : 53
         * applyed : false
         * channelId :
         * clicked : false
         * createBy :
         * createTime : 2020-01-05 15:58:46
         * deleted : null
         * desc : desc
         * deviceCode :
         * deviceType :
         * downloadUrl : https://bajiu.cn/ip/
         * endTime : null
         * orderField :
         * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,
         * "pageStr":"","totalPage":0,"totalResult":0}
         * params : null
         * remark :
         * searchValue :
         * source : android
         * startTime : null
         * state : 0
         * type : 1
         * typeText :
         * updateBy :
         * updateTime : 2020-01-05 16:10:28
         * updateTip : rtest
         * versionCode : 2
         * versionCoded : 1.0.2
         * versionName : test2
         */

        public int appVersionId;
        public boolean applyed;
        public String channelId;
        public boolean clicked;
        public String createBy;
        public String createTime;
        public Object deleted;
        public String desc;
        public String deviceCode;
        public String deviceType;
        public String downloadUrl;
        public Object endTime;
        public String orderField;
        public PageBean page;
        public Object params;
        public String remark;
        public String searchValue;
        public String source;
        public Object startTime;
        public int state;
        public int type;
        public String typeText;
        public String updateBy;
        public String updateTime;
        public String updateTip;
        public int versionCode;
        public String versionCoded;
        public String versionName;

        public static class PageBean {
            /**
             * currentResult : 0
             * entityOrField : false
             * pageNumber : 1
             * pageSize : 10
             * pageStr :
             * totalPage : 0
             * totalResult : 0
             */

            public int currentResult;
            public boolean entityOrField;
            public int pageNumber;
            public int pageSize;
            public String pageStr;
            public int totalPage;
            public int totalResult;
        }
    }
}
