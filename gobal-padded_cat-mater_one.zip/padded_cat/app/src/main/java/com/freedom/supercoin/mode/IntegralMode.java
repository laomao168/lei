package com.freedom.supercoin.mode;

import java.util.List;

public class IntegralMode {

    /**
     * code : 0
     * count : null
     * data : {"data":[{"applyed":false,"channelId":"","clicked":false,"createBy":"lepai",
     * "createTime":"2019-12-29 16:57:55","deleted":0,"desc":"desc","deviceCode":"",
     * "deviceType":"","endTime":null,"id":1809,"integralAmount":100,"orderField":"","page":{
     * "currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,"pageStr":"",
     * "totalPage":0,"totalResult":0},"params":null,"remark":"","searchValue":"",
     * "startTime":null,"title":"测试用","tradeNo":"1178","tradeType":1,"type":1,"updateBy":"",
     * "updateTime":null,"userId":1178}],"page":{"currentResult":0,"entityOrField":false,
     * "pageNumber":1,"pageSize":10,"pageStr":"","totalPage":1,"totalResult":1}}
     * error : false
     * msg : 查询成功
     * result : true
     * success : true
     */

    public String code;
    public Object count;
    public DataBeanX data;
    public boolean error;
    public String msg;
    public boolean result;
    public boolean success;

    public static class DataBeanX {
        /**
         * data : [{"applyed":false,"channelId":"","clicked":false,"createBy":"lepai",
         * "createTime":"2019-12-29 16:57:55","deleted":0,"desc":"desc","deviceCode":"",
         * "deviceType":"","endTime":null,"id":1809,"integralAmount":100,"orderField":"","page":{
         * "currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,"pageStr":"",
         * "totalPage":0,"totalResult":0},"params":null,"remark":"","searchValue":"",
         * "startTime":null,"title":"测试用","tradeNo":"1178","tradeType":1,"type":1,"updateBy":"",
         * "updateTime":null,"userId":1178}]
         * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,
         * "pageStr":"","totalPage":1,"totalResult":1}
         */

        public PageBean page;
        public List<DataBean> data;

        public static class PageBean {
            /**
             * currentResult : 0
             * entityOrField : false
             * pageNumber : 1
             * pageSize : 10
             * pageStr :
             * totalPage : 1
             * totalResult : 1
             */

            public int currentResult;
            public boolean entityOrField;
            public int pageNumber;
            public int pageSize;
            public String pageStr;
            public int totalPage;
            public int totalResult;
        }

        public static class DataBean {
            /**
             * applyed : false
             * channelId :
             * clicked : false
             * createBy : lepai
             * createTime : 2019-12-29 16:57:55
             * deleted : 0
             * desc : desc
             * deviceCode :
             * deviceType :
             * endTime : null
             * id : 1809
             * integralAmount : 100
             * orderField :
             * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,
             * "pageStr":"","totalPage":0,"totalResult":0}
             * params : null
             * remark :
             * searchValue :
             * startTime : null
             * title : 测试用
             * tradeNo : 1178
             * tradeType : 1
             * type : 1
             * updateBy :
             * updateTime : null
             * userId : 1178
             */

            public boolean applyed;
            public String channelId;
            public boolean clicked;
            public String createBy;
            public String createTime;
            public int deleted;
            public String desc;
            public String deviceCode;
            public String deviceType;
            public Object endTime;
            public int id;
            public int integralAmount;
            public String orderField;
            public PageBeanX page;
            public Object params;
            public String remark;
            public String searchValue;
            public Object startTime;
            public String title;
            public String tradeNo;
            public int tradeType;
            public int type;
            public String updateBy;
            public Object updateTime;
            public int userId;

            public static class PageBeanX {
                /**
                 * currentResult : 0
                 * entityOrField : false
                 * pageNumber : 1
                 * pageSize : 10
                 * pageStr :
                 * totalPage : 0
                 * totalResult : 0
                 */

                public int currentResult;
                public boolean entityOrField;
                public int pageNumber;
                public int pageSize;
                public String pageStr;
                public int totalPage;
                public int totalResult;
            }
        }
    }
}
