package com.freedom.supercoin.contract;


import com.freedom.supercoin.base_library.base.BasePresenter;
import com.freedom.supercoin.base_library.base.BaseView;
import com.freedom.supercoin.mode.OrderStatisticsMode;
import com.freedom.supercoin.mode.UserInfoMode;


public class MeContact {

    public interface View extends BaseView {

        void onLoadUserInfoSuccess(UserInfoMode userInfoMode);

        void onLoadOrderStaticsSuccess(OrderStatisticsMode orderStatisticsMode);
    }


    public interface Presenter extends BasePresenter {
        void getUserInfo();
        void getOrderInfo();
    }
}

