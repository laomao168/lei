package com.freedom.supercoin.persenter;

import com.freedom.supercoin.contract.BalanceDetailContact;
import com.freedom.supercoin.mode.BalanceListMode;
import com.freedom.supercoin.network.DataManager;
import com.freedom.supercoin.network.ResponseErrorFunc;
import com.freedom.supercoin.network.RxUtils;

import rx.Subscriber;


public class BalanceDetaiPresenter implements BalanceDetailContact.Presenter {

    private final BalanceDetailContact.View view;

    public BalanceDetaiPresenter(BalanceDetailContact.View view) {
        this.view = view;
    }

    @Override
    public void getBalanceDetail(int pageNumber) {
        DataManager.getInstance()
                .getBalanceDetail(pageNumber)
                .compose(RxUtils.applyIOSchedulers())
//                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<BalanceListMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(BalanceListMode mode) {
                        view.getBalanceListSuccess(mode);
                        view.hideProgress();
                    }
                });
    }
}
