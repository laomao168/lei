package com.freedom.supercoin.contract;


import com.freedom.supercoin.base_library.base.BasePresenter;
import com.freedom.supercoin.base_library.base.BaseView;
import com.freedom.supercoin.mode.ChargeDetailMode;
import com.freedom.supercoin.mode.entity.Page;


public class ChargeDetailContact {

    public interface View extends BaseView {

        void onLoadChargeListSuccess(ChargeDetailMode mode);
    }


    public interface Presenter extends BasePresenter {
        void getChargeList(Page page);
    }
}

