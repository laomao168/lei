package com.freedom.supercoin.mode;

import java.util.List;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2020/4/10.
 * @desc :
 */
public class IntegralOrderMode {

    /**
     * code :
     * count : null
     * data : {"data":[{"acceptTime":null,"address":"浙江省杭州市滨江区西兴街道丹枫路","addressId":5,
     * "applyTime":null,"applyed":false,"avatar":"http://q828p1g31.bkt.clouddn.com/logo.jpg",
     * "buyerNamePhone":"","carrierId":null,"channelId":"","clicked":false,"complete":0,
     * "consignee":"李剑平","contract":0,"contractUrl":"","costPrice":95,"createBy":"185***8679",
     * "createTime":"2020-04-10 16:47:44","createTimeString":"","deleted":0,"deliverTime":null,
     * "deliverTimeString":"","desc":"desc","deviceCode":"","deviceType":"","endCreateTime":"",
     * "endTime":null,"endTimes":null,"fallReasons":"","goodsId":127,
     * "goodsName":"小米无线充电器通用快充版Qi无线标准20W","goodsNameId":"","goodsType":1,"integral":360,
     * "logisticsCode":"","logisticsName":"","logisticsNo":"","logo":"https://images.fmallnet
     * .com/0426fa7e3d1f47d8b1f4c06ca7763a7e","mallOrderId":6,"mobile":"18566398679",
     * "orderField":"","orderNo":"LPOM200410164744796166","orderPrice":null,"orderStatus":0,
     * "orderType":0,"page":{"currentResult":0,"entityOrField":false,"pageNumber":1,
     * "pageSize":10,"pageStr":"","totalPage":0,"totalResult":0},"params":null,"payStatus":0,
     * "payTime":"2020-04-10 16:47:45","payTimeString":"","phone":"18566398679",
     * "pledgePrice":null,"price":36,"priceType":2,"reasonRemark":"","receivingGoodsTime":null,
     * "remark":"","searchValue":"","startCreateTime":"","startTime":null,"statusText":"",
     * "supplier":"已删除","supplierId":7,"transactionPrice":null,"type":2,"updateBy":"185***8679",
     * "updateTime":"2020-04-10 16:47:45","updateTimeString":"","userId":1760,
     * "userName":"185***8679"},{"acceptTime":null,"address":"浙江省杭州市滨江区西兴街道丹枫路","addressId":5,
     * "applyTime":null,"applyed":false,"avatar":"http://q828p1g31.bkt.clouddn.com/logo.jpg",
     * "buyerNamePhone":"","carrierId":null,"channelId":"","clicked":false,"complete":0,
     * "consignee":"李剑平","contract":0,"contractUrl":"","costPrice":200,"createBy":"185***8679",
     * "createTime":"2020-04-10 16:42:46","createTimeString":"","deleted":0,"deliverTime":null,
     * "deliverTimeString":"","desc":"desc","deviceCode":"","deviceType":"","endCreateTime":"",
     * "endTime":null,"endTimes":null,"fallReasons":"","goodsId":9999,"goodsName":"测试7天回来",
     * "goodsNameId":"","goodsType":1,"integral":2,"logisticsCode":"","logisticsName":"",
     * "logisticsNo":"","logo":"https://images.test.fmallnet
     * .com/4066f89c36b2428d8faa86dd94d8bb72","mallOrderId":5,"mobile":"18566398679",
     * "orderField":"","orderNo":"LPOM200410164246367220","orderPrice":null,"orderStatus":1,
     * "orderType":1,"page":{"currentResult":0,"entityOrField":false,"pageNumber":1,
     * "pageSize":10,"pageStr":"","totalPage":0,"totalResult":0},"params":null,"payStatus":1,
     * "payTime":"2020-04-10 16:42:47","payTimeString":"","phone":"18566398679",
     * "pledgePrice":null,"price":2,"priceType":2,"reasonRemark":"","receivingGoodsTime":null,
     * "remark":"","searchValue":"","startCreateTime":"","startTime":null,"statusText":"",
     * "supplier":"已删除","supplierId":9,"transactionPrice":null,"type":1,"updateBy":"185***8679",
     * "updateTime":"2020-04-10 16:42:47","updateTimeString":"","userId":1760,
     * "userName":"185***8679"}]}
     */

    public String code;
    public Object count;
    public DataBeanX data;
    public boolean error;
    public String msg;
    public boolean result;
    public boolean success;
    public static class DataBeanX {
        public List<DataBean> data;

        public static class DataBean {
            /**
             * acceptTime : null
             * address : 浙江省杭州市滨江区西兴街道丹枫路
             * addressId : 5
             * applyTime : null
             * applyed : false
             * avatar : http://q828p1g31.bkt.clouddn.com/logo.jpg
             * buyerNamePhone :
             * carrierId : null
             * channelId :
             * clicked : false
             * complete : 0
             * consignee : 李剑平
             * contract : 0
             * contractUrl :
             * costPrice : 95.0
             * createBy : 185***8679
             * createTime : 2020-04-10 16:47:44
             * createTimeString :
             * deleted : 0
             * deliverTime : null
             * deliverTimeString :
             * desc : desc
             * deviceCode :
             * deviceType :
             * endCreateTime :
             * endTime : null
             * endTimes : null
             * fallReasons :
             * goodsId : 127
             * goodsName : 小米无线充电器通用快充版Qi无线标准20W
             * goodsNameId :
             * goodsType : 1
             * integral : 360.0
             * logisticsCode :
             * logisticsName :
             * logisticsNo :
             * logo : https://images.fmallnet.com/0426fa7e3d1f47d8b1f4c06ca7763a7e
             * mallOrderId : 6
             * mobile : 18566398679
             * orderField :
             * orderNo : LPOM200410164744796166
             * orderPrice : null
             * orderStatus : 0
             * orderType : 0
             * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,
             * "pageStr":"","totalPage":0,"totalResult":0}
             * params : null
             * payStatus : 0
             * payTime : 2020-04-10 16:47:45
             * payTimeString :
             * phone : 18566398679
             * pledgePrice : null
             * price : 36.0
             * priceType : 2
             * reasonRemark :
             * receivingGoodsTime : null
             * remark :
             * searchValue :
             * startCreateTime :
             * startTime : null
             * statusText :
             * supplier : 已删除
             * supplierId : 7
             * transactionPrice : null
             * type : 2
             * updateBy : 185***8679
             * updateTime : 2020-04-10 16:47:45
             * updateTimeString :
             * userId : 1760
             * userName : 185***8679
             */

            public Object acceptTime;
            public String address;
            public int addressId;
            public Object applyTime;
            public boolean applyed;
            public String avatar;
            public String buyerNamePhone;
            public Object carrierId;
            public String channelId;
            public boolean clicked;
            public int complete;
            public String consignee;
            public int contract;
            public String contractUrl;
            public double costPrice;
            public String createBy;
            public String createTime;
            public String createTimeString;
            public int deleted;
            public Object deliverTime;
            public String deliverTimeString;
            public String desc;
            public String deviceCode;
            public String deviceType;
            public String endCreateTime;
            public Object endTime;
            public Object endTimes;
            public String fallReasons;
            public int goodsId;
            public String goodsName;
            public String goodsNameId;
            public int goodsType;
            public double integral;
            public String logisticsCode;
            public String logisticsName;
            public String logisticsNo;
            public String logo;
            public int mallOrderId;
            public String mobile;
            public String orderField;
            public String orderNo;
            public Object orderPrice;
            public int orderStatus;
            public int orderType;
            public PageBean page;
            public Object params;
            public int payStatus;
            public String payTime;
            public String payTimeString;
            public String phone;
            public Object pledgePrice;
            public double price;
            public int priceType;
            public String reasonRemark;
            public Object receivingGoodsTime;
            public String remark;
            public String searchValue;
            public String startCreateTime;
            public Object startTime;
            public String statusText;
            public String supplier;
            public int supplierId;
            public Object transactionPrice;
            public int type;
            public String updateBy;
            public String updateTime;
            public String updateTimeString;
            public int userId;
            public String userName;

            public static class PageBean {
                /**
                 * currentResult : 0
                 * entityOrField : false
                 * pageNumber : 1
                 * pageSize : 10
                 * pageStr :
                 * totalPage : 0
                 * totalResult : 0
                 */

                public int currentResult;
                public boolean entityOrField;
                public int pageNumber;
                public int pageSize;
                public String pageStr;
                public int totalPage;
                public int totalResult;
            }
        }
    }
}
