package com.freedom.supercoin.persenter;

import com.freedom.supercoin.contract.IntegralFragmentContact;
import com.freedom.supercoin.mode.HomeBannerMode;
import com.freedom.supercoin.mode.IntegralFragmentMode;
import com.freedom.supercoin.mode.entity.Page;
import com.freedom.supercoin.network.DataManager;
import com.freedom.supercoin.network.ResponseErrorFunc;
import com.freedom.supercoin.network.RxUtils;

import java.util.List;

import rx.Subscriber;


public class IntegralFragmentPresenter implements IntegralFragmentContact.Presenter {

    private final IntegralFragmentContact.View view;

    public IntegralFragmentPresenter(IntegralFragmentContact.View view) {
        this.view = view;
    }

    @Override
    public void onLoadBanner() {
        DataManager.getInstance()
                .getIntegralBannerList()
                .compose(RxUtils.applyIOSchedulers())
                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<List<HomeBannerMode>>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                        view.onLoadError();
                    }


                    @Override
                    public void onNext(List<HomeBannerMode> list) {
                        view.hideProgress();
                        view.onLoadBannerSuccess(list);
                    }
                });
    }

    @Override
    public void loadIntegralList(Page page) {
        DataManager.getInstance()
                .loadIntegralList(page.pageNumber,page.pageSize)
                .compose(RxUtils.applyIOSchedulers())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<IntegralFragmentMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                        view.onLoadError();
                    }


                    @Override
                    public void onNext(IntegralFragmentMode mode) {
                        view.hideProgress();
                        if (mode!=null&&mode.success){
                            view.onLoadGoodsListSuccess(mode.data.data);
                        }

                    }
                });
    }


}
