package com.freedom.supercoin.mode;

import com.google.gson.annotations.SerializedName;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2020/1/10.
 * @desc :
 */
public class PayRes {


    /**
     * code :
     * count : null
     * data : {"timeStamp":"1578641870","package":"Sign=WXPay","appId":"wx10eb27bde7ae5089",
     * "sign":"A2A88C457A2905517E0633C1B30DFC28","partnerId":"1566772371",
     * "prepayId":"wx1015375020023518be6f9f471441955000",
     * "nonceStr":"b91f4f4d36fa98a94ac5584af95594a0"}
     * error : false
     * msg : 创建订单成功!
     * result : true
     * success : true
     */

    public String code;
    public Object count;
    public DataBean data;
    public boolean error;
    public String msg;
    public boolean result;
    public boolean success;

    public static class DataBean {
        /**
         * timeStamp : 1578641870
         * package : Sign=WXPay
         * appId : wx10eb27bde7ae5089
         * sign : A2A88C457A2905517E0633C1B30DFC28
         * partnerId : 1566772371
         * prepayId : wx1015375020023518be6f9f471441955000
         * nonceStr : b91f4f4d36fa98a94ac5584af95594a0
         */

        public String timeStamp;
        public String appId;
        public String sign;
        public String partnerId;
        public String prepayId;
        public String nonceStr;
    }
}
