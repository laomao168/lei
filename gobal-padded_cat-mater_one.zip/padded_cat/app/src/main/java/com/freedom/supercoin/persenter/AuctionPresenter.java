package com.freedom.supercoin.persenter;

import com.freedom.supercoin.base_library.utils.GsonUtils;
import com.freedom.supercoin.base_library.utils.LogUtils;
import com.freedom.supercoin.contract.AuctionContact;
import com.freedom.supercoin.mode.AuctionAddErrorMode;
import com.freedom.supercoin.mode.AuctionAddMode;
import com.freedom.supercoin.mode.GoodBidMode;
import com.freedom.supercoin.mode.GoodDetailsMode;
import com.freedom.supercoin.network.DataManager;
import com.freedom.supercoin.network.ResponseErrorFunc;
import com.freedom.supercoin.network.RxUtils;

import okhttp3.ResponseBody;
import rx.Subscriber;


public class AuctionPresenter implements AuctionContact.Presenter {

    private final AuctionContact.View view;

    public AuctionPresenter(AuctionContact.View view) {
        this.view = view;
    }

    @Override
    public void getGoodDetails(int auctionId) {
        DataManager.getInstance()
                .getGoodDetails(auctionId)
                .compose(RxUtils.applyIOSchedulers())
                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<GoodDetailsMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(GoodDetailsMode mode) {
                        view.getGoodsDetailSuccess(mode);
                        view.hideProgress();
                    }
                });
    }
    @Override
    public void getBidList(int auctionId) {
        DataManager.getInstance()
                .getBidList(auctionId)
                .compose(RxUtils.applyIOSchedulers())
//                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<GoodBidMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(GoodBidMode mode) {
                        view.getGoodsBidModeSuccess(mode);
                        view.hideProgress();
                    }
                });
    }

    @Override
    public void bidGoods(int auctionId, double price) {
        DataManager.getInstance()
                .bidGoods(auctionId, price)
                .compose(RxUtils.applyIOSchedulers())
//                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();

                    }


                    @Override
                    public void onNext(ResponseBody responseBody) {

                        try {
                            String string = responseBody.string().trim();
                            LogUtils.ShowD("string",string);
                            if (string.contains("成功")) {
                                AuctionAddMode auctionAddMode = GsonUtils.fromJson(string,
                                        AuctionAddMode.class);
                                view.onAuctionAddSuccess(auctionAddMode);
                            } else {
                                AuctionAddErrorMode auctionAddErrorMode = GsonUtils.fromJson(string,
                                        AuctionAddErrorMode.class);
                                view.getAuctionAddError(auctionAddErrorMode.msg);
                            }
                            view.hideProgress();
                        } catch (Exception e) {
                            e.printStackTrace();

                        }
                    }
                });
    }


}
