package com.freedom.supercoin.mode.entity;

/**
 * Created by jianping on 2019/1/2.
 */

public class ShareInfo {
    /**
     * share_title : test
     * share_desc : test
     * share_pic :
     * share_url :
     */

    public String share_title;
    public String share_desc;
    public String share_pic;
    public String share_url;

}
