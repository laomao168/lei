package com.freedom.supercoin.activity;

import android.Manifest;
import android.content.pm.PackageManager;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.view.MenuItem;

import com.freedom.supercoin.R;
import com.freedom.supercoin.adapter.FragmentAdapter;
import com.freedom.supercoin.base_library.AppConst;
import com.freedom.supercoin.base_library.BuildConfig;
import com.freedom.supercoin.base_library.utils.PermissionUtils;
import com.freedom.supercoin.base_library.utils.SPUtils;
import com.freedom.supercoin.common.UiActivity;
import com.freedom.supercoin.contract.MainActivityContact;
import com.freedom.supercoin.databinding.ActivityMainBinding;
import com.freedom.supercoin.fragment.HomeFragment;
import com.freedom.supercoin.fragment.IntegralFragment;
import com.freedom.supercoin.fragment.MeFragment;
import com.freedom.supercoin.fragment.RuleFragment;
import com.freedom.supercoin.mode.UpdateMode;
import com.freedom.supercoin.persenter.MainActivityPresenter;
import com.freedom.supercoin.utils.UpdateManager;
import com.hjq.toast.ToastUtils;
import com.ycbjie.ycupdatelib.UpdateFragment;
import com.ycbjie.ycupdatelib.UpdateUtils;

import java.io.File;
import java.util.ArrayList;

/**
 * @author :
 * @date : Created on 2019/7/11.
 * des:
 */
public class MainActivity extends UiActivity<ActivityMainBinding> implements BottomNavigationView.OnNavigationItemSelectedListener, MainActivityContact.View {
    private long lastTime;
    private ArrayList<Fragment> fragments;
    private FragmentAdapter fragmentAdapter;
    private MainActivityPresenter presenter;

    @Override
    protected int layoutResId() {
        return R.layout.activity_main;
    }

    @Override
    protected void initData() {
        fragments = new ArrayList<>();
        HomeFragment marketFragment = new HomeFragment();
        IntegralFragment integralFragment = new IntegralFragment();
        MeFragment meFragment = new MeFragment();
        RuleFragment ruleFragment = new RuleFragment();
        fragments.add(marketFragment);
        fragments.add(integralFragment);
        fragments.add(ruleFragment);
        fragments.add(meFragment);
        fragmentAdapter = new FragmentAdapter(getSupportFragmentManager(), fragments);
        binding.vpMain.setAdapter(fragmentAdapter);
        binding.vpMain.setOffscreenPageLimit(fragments.size());
        // 不使用图标默认变色
        binding.bvHomeNavigation.setItemIconTintList(null);
        binding.bvHomeNavigation.setOnNavigationItemSelectedListener(this);
        if (TextUtils.isEmpty(SPUtils.getInstance().getString(AppConst.Keys.LOGIN_TOKEN))) {
            AppConst.ISLOGIN = false;
        } else {
            AppConst.ISLOGIN = true;
        }
        presenter = new MainActivityPresenter(this);
        getPermissions();
        presenter.CheckUpdate();
    }
    private void getPermissions() {
        String[] permissions = new String[1];
        permissions[0] = Manifest.permission.WRITE_EXTERNAL_STORAGE;
        ActivityCompat.requestPermissions(this, permissions, 1);
    }
    @Override
    protected void initEvent() {

//        EventBus.getDefault().register(this);
        binding.vpMain.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {

            }

            @Override
            public void onPageSelected(int i) {
                setSelectTable(i);
            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.home_main:
                binding.vpMain.setCurrentItem(0);
                return true;
            case R.id.home_integral:
                binding.vpMain.setCurrentItem(1);
                return true;
            case R.id.home_rule:
                binding.vpMain.setCurrentItem(2);
                return true;
            case R.id.home_me:
                if (AppConst.ISLOGIN) {
                    binding.vpMain.setCurrentItem(3);
                } else {
                    getOperation().forward(LoginTipsActivity.class);
                }
                return true;
        }
        return false;
    }

    /**
     * 选择table
     *
     * @param position
     */
    private void setSelectTable(int position) {
        switch (position) {
            case 0:
                binding.bvHomeNavigation.setSelectedItemId(R.id.home_main);
                break;
            case 1:
                binding.bvHomeNavigation.setSelectedItemId(R.id.home_integral);
                break;
            case 2:
                binding.bvHomeNavigation.setSelectedItemId(R.id.home_rule);
                break;
            case 3:
                if (AppConst.ISLOGIN) {
                    binding.bvHomeNavigation.setSelectedItemId(R.id.home_me);
                } else {
                    getOperation().forward(LoginTipsActivity.class);
                }
                break;
        }
    }

    @Override
    public void onBackPressed() {
        if (System.currentTimeMillis() - lastTime < 2 * 1000) {
            AppConst.finishActivity();
            System.exit(0);
        } else {
            lastTime = System.currentTimeMillis();
            ToastUtils.show(getString(R.string.exAgain));
        }
    }

    @Override
    public void onLoadUpdateInfoSuccess(UpdateMode mode) {
        if (mode == null || !mode.success) return;
        if (UpdateManager.getInstance().checkVersion(mode.data.versionCode, this)) {
            String apkName = "yongjiancheng_" + mode.data.versionCode;
            /*
             * @param isForceUpdate             是否强制更新
             * @param desc                      更新文案
             * @param url                       下载链接
             * @param apkFileName               apk下载文件路径名称
             * @param packName                  包名
             */
            UpdateFragment.showFragment(this,
                    mode.data.state != 0, mode.data.downloadUrl, apkName,
                    mode.data.updateTip, BuildConfig.APPLICATION_ID);
        } else {
            if (PermissionUtils.checkPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                String localApkDownDirPath = UpdateUtils.getLocalApkDownDirPath();
                UpdateManager.getInstance().deleteFile(new File(localApkDownDirPath));
            }
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PermissionUtils.PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                UpdateManager.getInstance().startUpdate(this);
            } else {
                ToastUtils.show("权限被禁止无法更新");
            }
        }
    }


//    @Override
//    public void onDestroy() {
//        super.onDestroy();
//        EventBus.getDefault().unregister(this);
//    }
//    @Subscribe(threadMode = ThreadMode.MAIN)
//    public void setHomeEvent(HomeBus homeBus) {
//        binding.vpMain.setCurrentItem(homeBus.index);
//    }

}
