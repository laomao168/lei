package com.freedom.supercoin.mode;

import java.util.List;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2020/1/5.
 * @desc :
 */
public class MyAuctionMode {


    /**
     * code : 0
     * count : null
     * data : {"data":[{"addPriceRuleId":43,"applyed":false,"assessPrice":1110,"auctionId":12187,
     * "brokerage":5,"categoryId":1015,"categoryName":"","channelId":"","clicked":false,
     * "costPrice":158,"createBy":"admin","createTime":"2020-01-05 16:35:59","deleted":0,
     * "desc":"desc","deviceCode":"","deviceType":"","displayArea":1,"endEndTime":"",
     * "endStartPrice":null,"endStartTime":"","endTime":"2020-01-05 17:10:00","endTimes":446649,
     * "fatherCategoryId":null,"goodsDetail":"<p><span><img src=\"https://images.oneauct
     * .com/5315200f87474a759ca86799ea4c27a1\"><img src=\"https://images.oneauct
     * .com/99c539539685421ba6ea95a6da38b8a5\"><img src=\"https://images.oneauct
     * .com/839cfae74e3e4b2e805f5ac77c760894\"><img src=\"https://images.oneauct
     * .com/78be13931c484a92b27fb91830f4466d\"><img src=\"https://images.oneauct
     * .com/81a182669407416eb2b14005727be17c\"><img src=\"https://images.oneauct
     * .com/d6e8c6f8f6a64fc691f0c9cebb340084\"><\/span><br><\/p>","goodsId":2619,
     * "goodsName":"Miss rudolf 魔幻星辰魅惑眼影","headImage":"[\"https://images.oneauct
     * .com/a8ee41a5342246e988afb35fcb6aad32\",\"https://images.oneauct
     * .com/687319f3823b4748b8bb4921339fbdf1\"]","list":[],"logo":"https://images.oneauct
     * .com/7490a1dc121c44d694eb1e6f5f891575","mailingUserId":null,"mallGoodsId":null,
     * "markupNum":15,"markupPrice":50,"maxProtectPrice":10000,"openRobot":1,
     * "openRobotPrecent":0,"orderField":"","page":{"currentResult":0,"entityOrField":false,
     * "pageNumber":1,"pageSize":10,"pageStr":"","totalPage":0,"totalResult":0},"params":null,
     * "passTitle":"","platformGoodsId":null,"protectPrice":790,"remark":"","robotPrecent":60,
     * "searchValue":"","sort":null,"source":2,"startEndTime":"","startPrice":126,
     * "startStartPrice":null,"startStartTime":"","startTime":"2020-01-05 17:00:00",
     * "startTimes":-153351,"status":3,"supplier":"其他","supplierId":8,"topPrice":876,
     * "transactionPrice":null,"type":null,"updateBy":"","updateTime":"2020-01-05 16:36:00",
     * "userId":null,"username":"","viewCount":19}],"page":{"currentResult":0,
     * "entityOrField":false,"pageNumber":1,"pageSize":10,"pageStr":"","totalPage":1,
     * "totalResult":1}}
     * error : false
     * msg : success
     * result : true
     * success : true
     */

    public String code;
    public Object count;
    public DataBeanX data;
    public boolean error;
    public String msg;
    public boolean result;
    public boolean success;

    public static class DataBeanX {
        /**
         * data : [{"addPriceRuleId":43,"applyed":false,"assessPrice":1110,"auctionId":12187,
         * "brokerage":5,"categoryId":1015,"categoryName":"","channelId":"","clicked":false,
         * "costPrice":158,"createBy":"admin","createTime":"2020-01-05 16:35:59","deleted":0,
         * "desc":"desc","deviceCode":"","deviceType":"","displayArea":1,"endEndTime":"",
         * "endStartPrice":null,"endStartTime":"","endTime":"2020-01-05 17:10:00",
         * "endTimes":446649,"fatherCategoryId":null,"goodsDetail":"<p><span><img
         * src=\"https://images.oneauct.com/5315200f87474a759ca86799ea4c27a1\"><img
         * src=\"https://images.oneauct.com/99c539539685421ba6ea95a6da38b8a5\"><img
         * src=\"https://images.oneauct.com/839cfae74e3e4b2e805f5ac77c760894\"><img
         * src=\"https://images.oneauct.com/78be13931c484a92b27fb91830f4466d\"><img
         * src=\"https://images.oneauct.com/81a182669407416eb2b14005727be17c\"><img
         * src=\"https://images.oneauct.com/d6e8c6f8f6a64fc691f0c9cebb340084\"><\/span><br><\/p
         * >","goodsId":2619,"goodsName":"Miss rudolf 魔幻星辰魅惑眼影","headImage":"[\"https://images
         * .oneauct.com/a8ee41a5342246e988afb35fcb6aad32\",\"https://images.oneauct
         * .com/687319f3823b4748b8bb4921339fbdf1\"]","list":[],"logo":"https://images.oneauct
         * .com/7490a1dc121c44d694eb1e6f5f891575","mailingUserId":null,"mallGoodsId":null,
         * "markupNum":15,"markupPrice":50,"maxProtectPrice":10000,"openRobot":1,
         * "openRobotPrecent":0,"orderField":"","page":{"currentResult":0,"entityOrField":false,
         * "pageNumber":1,"pageSize":10,"pageStr":"","totalPage":0,"totalResult":0},"params
         * ":null,"passTitle":"","platformGoodsId":null,"protectPrice":790,"remark":"",
         * "robotPrecent":60,"searchValue":"","sort":null,"source":2,"startEndTime":"",
         * "startPrice":126,"startStartPrice":null,"startStartTime":"","startTime":"2020-01-05
         * 17:00:00","startTimes":-153351,"status":3,"supplier":"其他","supplierId":8,
         * "topPrice":876,"transactionPrice":null,"type":null,"updateBy":"",
         * "updateTime":"2020-01-05 16:36:00","userId":null,"username":"","viewCount":19}]
         * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,
         * "pageStr":"","totalPage":1,"totalResult":1}
         */

        public PageBean page;
        public List<DataBean> data;

        public static class PageBean {
            /**
             * currentResult : 0
             * entityOrField : false
             * pageNumber : 1
             * pageSize : 10
             * pageStr :
             * totalPage : 1
             * totalResult : 1
             */

            public int currentResult;
            public boolean entityOrField;
            public int pageNumber;
            public int pageSize;
            public String pageStr;
            public int totalPage;
            public int totalResult;
        }

        public static class DataBean {
            /**
             * addPriceRuleId : 43
             * applyed : false
             * assessPrice : 1110.0
             * auctionId : 12187
             * brokerage : 5.0
             * categoryId : 1015
             * categoryName :
             * channelId :
             * clicked : false
             * costPrice : 158.0
             * createBy : admin
             * createTime : 2020-01-05 16:35:59
             * deleted : 0
             * desc : desc
             * deviceCode :
             * deviceType :
             * displayArea : 1
             * endEndTime :
             * endStartPrice : null
             * endStartTime :
             * endTime : 2020-01-05 17:10:00
             * endTimes : 446649
             * fatherCategoryId : null
             * goodsDetail : <p><span><img src="https://images.oneauct
             * .com/5315200f87474a759ca86799ea4c27a1"><img src="https://images.oneauct
             * .com/99c539539685421ba6ea95a6da38b8a5"><img src="https://images.oneauct
             * .com/839cfae74e3e4b2e805f5ac77c760894"><img src="https://images.oneauct
             * .com/78be13931c484a92b27fb91830f4466d"><img src="https://images.oneauct
             * .com/81a182669407416eb2b14005727be17c"><img src="https://images.oneauct
             * .com/d6e8c6f8f6a64fc691f0c9cebb340084"></span><br></p>
             * goodsId : 2619
             * goodsName : Miss rudolf 魔幻星辰魅惑眼影
             * headImage : ["https://images.oneauct.com/a8ee41a5342246e988afb35fcb6aad32",
             * "https://images.oneauct.com/687319f3823b4748b8bb4921339fbdf1"]
             * list : []
             * logo : https://images.oneauct.com/7490a1dc121c44d694eb1e6f5f891575
             * mailingUserId : null
             * mallGoodsId : null
             * markupNum : 15
             * markupPrice : 50.0
             * maxProtectPrice : 10000.0
             * openRobot : 1
             * openRobotPrecent : 0
             * orderField :
             * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,
             * "pageStr":"","totalPage":0,"totalResult":0}
             * params : null
             * passTitle :
             * platformGoodsId : null
             * protectPrice : 790.0
             * remark :
             * robotPrecent : 60
             * searchValue :
             * sort : null
             * source : 2
             * startEndTime :
             * startPrice : 126.0
             * startStartPrice : null
             * startStartTime :
             * startTime : 2020-01-05 17:00:00
             * startTimes : -153351
             * status : 3
             * supplier : 其他
             * supplierId : 8
             * topPrice : 876.0
             * transactionPrice : null
             * type : null
             * updateBy :
             * updateTime : 2020-01-05 16:36:00
             * userId : null
             * username :
             * viewCount : 19
             */

            public int addPriceRuleId;
            public boolean applyed;
            public double assessPrice;
            public int auctionId;
            public double brokerage;
            public int categoryId;
            public String categoryName;
            public String channelId;
            public boolean clicked;
            public double costPrice;
            public String createBy;
            public String createTime;
            public int deleted;
            public String desc;
            public String deviceCode;
            public String deviceType;
            public int displayArea;
            public String endEndTime;
            public Object endStartPrice;
            public String endStartTime;
            public String endTime;
            public int endTimes;
            public Object fatherCategoryId;
            public String goodsDetail;
            public int goodsId;
            public String goodsName;
            public String headImage;
            public String logo;
            public Object mailingUserId;
            public Object mallGoodsId;
            public int markupNum;
            public double markupPrice;
            public double maxProtectPrice;
            public int openRobot;
            public int openRobotPrecent;
            public String orderField;
            public PageBeanX page;
            public Object params;
            public String passTitle;
            public Object platformGoodsId;
            public double protectPrice;
            public String remark;
            public int robotPrecent;
            public String searchValue;
            public Object sort;
            public int source;
            public String startEndTime;
            public double startPrice;
            public Object startStartPrice;
            public String startStartTime;
            public String startTime;
            public int startTimes;
            public int status;
            public String supplier;
            public int supplierId;
            public double topPrice;
            public Object transactionPrice;
            public Object type;
            public String updateBy;
            public String updateTime;
            public Object userId;
            public String username;
            public int viewCount;
            public List<?> list;

            public static class PageBeanX {
                /**
                 * currentResult : 0
                 * entityOrField : false
                 * pageNumber : 1
                 * pageSize : 10
                 * pageStr :
                 * totalPage : 0
                 * totalResult : 0
                 */

                public int currentResult;
                public boolean entityOrField;
                public int pageNumber;
                public int pageSize;
                public String pageStr;
                public int totalPage;
                public int totalResult;
            }
        }
    }
}
