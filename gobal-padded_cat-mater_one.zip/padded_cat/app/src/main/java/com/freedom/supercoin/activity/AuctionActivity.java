package com.freedom.supercoin.activity;

import android.os.Handler;
import android.os.Message;
import android.support.v7.widget.LinearLayoutManager;
import android.view.View;

import com.freedom.supercoin.R;
import com.freedom.supercoin.adapter.GoodsBidAdapter;
import com.freedom.supercoin.base_library.AppConst;
import com.freedom.supercoin.base_library.utils.GlideUtils;
import com.freedom.supercoin.base_library.utils.GsonUtils;
import com.freedom.supercoin.base_library.utils.LogUtils;
import com.freedom.supercoin.base_library.utils.StrUtils;
import com.freedom.supercoin.common.UiActivity;
import com.freedom.supercoin.contract.AuctionContact;
import com.freedom.supercoin.databinding.ActivityAuctionBinding;
import com.freedom.supercoin.mode.AuctionAddMode;
import com.freedom.supercoin.mode.GoodBidMode;
import com.freedom.supercoin.mode.GoodDetailsMode;
import com.freedom.supercoin.network.DataManager;
import com.freedom.supercoin.persenter.AuctionPresenter;
import com.freedom.supercoin.websocket.base.SimpleWebSocketManager;
import com.freedom.supercoin.websocket.base.listener.WebSocketMsgInterface;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import okhttp3.OkHttpClient;

/**
 * @author : lijianping
 * @date : Created on 2019/7/11.
 * des: 拍卖
 */
public class AuctionActivity extends UiActivity<ActivityAuctionBinding> implements AuctionContact.View, WebSocketMsgInterface {

    private String title;
    private AuctionPresenter presenter;
    private int auctionId;
    private double brokerage;
    private GoodsBidAdapter adapter;
    private double markupPrice;
    private double cashDepositScale;
    private SimpleWebSocketManager webSocketManager;
    private List<AuctionAddMode> dataList;
    private int currentStatus;
    private int currentTimeDiff;
    private boolean hasCalculationEnd;
    private long endTime;

    private double payPrice;
    private double startPrice;
    private int type;
    private Handler handler;


    @Override
    protected int layoutResId() {
        return R.layout.activity_auction;
    }

    @Override
    protected void initData() {
        title = getIntent().getStringExtra(AppConst.Keys.TITLE);
        auctionId = getIntent().getIntExtra(AppConst.Keys.AUCTIONID, 0);
        brokerage = getIntent().getDoubleExtra("brokerage", 0);
        markupPrice = getIntent().getDoubleExtra("markupPrice", 0);
        cashDepositScale = getIntent().getDoubleExtra("cashDepositScale", 0);
        currentStatus = getIntent().getIntExtra("status", 0);
        type = getIntent().getIntExtra("type", 0);
        endTime = getIntent().getLongExtra("endTime", 0);
        startPrice = getIntent().getDoubleExtra("startPrice", 0);
        payPrice = startPrice;
        binding.titleBar.setTitle(title);
        binding.titleBar.setBgColor("#000000");
        binding.titleBar.setTextColor("#ffffff");
        binding.titleBar.setLeftImage(R.mipmap.ic_back_white);
        presenter = new AuctionPresenter(this);
        if (currentStatus > 3) {//已经结束
            binding.tvStatus.setVisibility(View.VISIBLE);
            binding.rlTopStatus.setVisibility(View.GONE);
            binding.tvBottomStatus.setVisibility(View.VISIBLE);
            binding.rlOfferNow.setVisibility(View.GONE);
        } else {
            binding.tvStatus.setVisibility(View.GONE);
            binding.rlTopStatus.setVisibility(View.VISIBLE);
            binding.tvBottomStatus.setVisibility(View.GONE);
            binding.rlOfferNow.setVisibility(View.VISIBLE);
        }
        binding.recycleView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new GoodsBidAdapter();
        adapter.setBrokerage(brokerage);
        binding.recycleView.setAdapter(adapter);
        if (type != 1) {//立即出价
            presenter.bidGoods(auctionId, payPrice);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        initHandler();
        hasCalculationEnd=false;
        presenter.getGoodDetails(auctionId);
        presenter.getBidList(auctionId);

    }

    private void initHandler() {
        if (handler!=null){
            handler.removeCallbacksAndMessages(null);
            handler=null;
        }
        handler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(Message msg) {
                if (msg.what == 3) {//正在拍卖
                    if (!hasCalculationEnd) {
                        currentTimeDiff = (int) (endTime / 1000);
                        hasCalculationEnd = true;
                    }
                    if (--currentTimeDiff >= 0) {
                        //计算时分秒
                        binding.tvTime.setText(getTime());
                        handler.sendEmptyMessageDelayed(3, 1000);
                    } else {
                        handler.sendEmptyMessage(5);
                    }
                } else {//结束
                    binding.tvStatus.setVisibility(View.VISIBLE);
                    binding.rlTopStatus.setVisibility(View.GONE);
                    binding.tvBottomStatus.setVisibility(View.VISIBLE);
                    binding.rlOfferNow.setVisibility(View.GONE);
                }
                return false;
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (webSocketManager == null) return;
        webSocketManager.close();
        webSocketManager = null;
        if (handler == null) return;
        handler.removeCallbacksAndMessages(null);
        handler = null;
        hasCalculationEnd=false;
    }

    @Override
    protected void initEvent() {
        binding.setClick(v -> {
            switch (v.getId()) {
                case R.id.tv_share:
                    getOperation().forward(InviteFriendActivity.class);
                    break;
                case R.id.rl_offer_now:
                    presenter.bidGoods(auctionId, payPrice);
                    break;
            }
        });
    }

    /**
     * 计算倒计时
     *
     * @return
     */
    private String getTime() {
        if (currentTimeDiff >= 3600) {
            return currentTimeDiff / 3600 + "时" + currentTimeDiff / 60 % 60 + "分" + currentTimeDiff % 60 + "秒";
        } else if (currentTimeDiff >= 60) {
            return currentTimeDiff / 60 % 60 + "分" + currentTimeDiff % 60 + "秒";
        }
        return currentTimeDiff + "秒";
    }

    @Override
    public void getGoodsBidModeSuccess(GoodBidMode mode) {

        if (mode == null || !mode.success || mode.data.data.size() == 0) return;
        dataList = mode.data.data;
        Collections.reverse(dataList);
        AuctionAddMode dataBean = dataList.get(dataList.size() - 1);
        adapter.setData(dataList);
        GlideUtils.loadRound(this, dataBean.avatar.trim(), binding.ivUserImage, 20);
        binding.tvNikeName.setText(dataBean.userName);
        payPrice = dataBean.payPrice;
        binding.tvPrice.setText(StrUtils.getRemoveZreoNum(dataBean.payPrice));
        double v = dataBean.payPrice + markupPrice;
        double v1 = v * cashDepositScale;
        binding.tvOfferNow.setText("我出价¥ " + StrUtils.getRemoveZreoNum(dataBean.payPrice)
                + "(含保证金¥" + StrUtils.getRemoveZreoNum(dataBean.guarantyPrice) + ")");
        if (currentStatus != 4) { //正在拍卖
            OkHttpClient okHttpClient = new OkHttpClient();
            webSocketManager = new SimpleWebSocketManager(DataManager.webUrl, okHttpClient, this);
            webSocketManager.connect();
//            倒计时
            handler.sendEmptyMessage(3);
        }
        binding.recycleView.smoothScrollToPosition(dataList.size() - 1);
    }

    @Override
    public void onAuctionAddSuccess(AuctionAddMode mode) {
//        ArrayList<AuctionAddMode> list = new ArrayList<>();
//        list.add(mode);
//        adapter.addDataList(list);
//        binding.recycleView.smoothScrollToPosition(list.size() - 1);
    }

    @Override
    public void getAuctionAddError(String message) {
        showMessage(message);
    }

    @Override
    public void getGoodsDetailSuccess(GoodDetailsMode mode) {
        endTime = mode.endTimes;
    }

    @Override
    public void onMessage(String msg) {
        LogUtils.ShowD("auction", msg);
        runOnUiThread(() -> {
            try {
                AuctionAddMode auctionAddMode = GsonUtils.fromJson(msg, AuctionAddMode.class);
                ArrayList<AuctionAddMode> list = new ArrayList<>();
                auctionAddMode.markupTime = auctionAddMode.markupTimeString;
                list.add(auctionAddMode);
                adapter.addDataList(list);
                payPrice = auctionAddMode.payPrice;
                binding.recycleView.smoothScrollToPosition(adapter.getData().size() - 1);
                binding.tvOfferNow.setText("我出价¥ " + StrUtils.getRemoveZreoNum(auctionAddMode.payPrice)
                        + "(含保证金¥" + StrUtils.getRemoveZreoNum(auctionAddMode.guarantyPrice) + ")");

                GlideUtils.loadRound(this, auctionAddMode.avatar.trim(), binding.ivUserImage, 20);
                binding.tvNikeName.setText(auctionAddMode.userName);
                payPrice = auctionAddMode.payPrice;
                binding.tvPrice.setText(StrUtils.getRemoveZreoNum(auctionAddMode.payPrice));
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

    }

    @Override
    public void onConnectSuc() {
        webSocketManager.subscribe(auctionId + "");
    }

}
