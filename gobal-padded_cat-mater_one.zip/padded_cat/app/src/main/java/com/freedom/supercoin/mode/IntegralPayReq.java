package com.freedom.supercoin.mode;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2020/1/10.
 * @desc :
 */
public class IntegralPayReq {
    //订单类型 3充值 1拍卖 2商场
    public int orderType;
    //1订单 2商品 除了订单都传2
    public int type;
    //商品id
    public int goodsId;
    //订单id
    public int orderId;
    //地址id
    public int addressId;
    //1余额2微信3支付宝4.积分
    public int payType;
    //支付密码（余额支付使用）
    public String payPassWord;
    //充值额度
    public String amount;
}
