package com.freedom.supercoin.mode;

import java.util.List;

public class GoodBidMode {


    /**
     * code : 0
     * count : null
     * data : {"data":[{"applyed":false,"auctionDetailId":308967,"auctionId":9472,
     * "avatar":"https://wx.qlogo
     * .cn/mmopen/vi_32
     * /Q0j4TwGTfTIrv7dxNswV4RddxvgxvHI2UlG4Rib30EoWj3rP97wnLLBWs66HRzjLEJXmTicCzkC2ATFaaeLk9png
     * /132","channelId":"","clicked":false,"createBy":"","createTime":null,"deleted":null,
     * "desc":"desc","deviceCode":"","deviceType":"","endTime":null,"guarantyPrice":610,
     * "markupTime":"2019-12-28 22:03","orderField":"","page":{"currentResult":0,
     * "entityOrField":false,"pageNumber":1,"pageSize":10,"pageStr":"","totalPage":0,
     * "totalResult":0},"params":null,"payPrice":3050,"payType":1,"remark":"","searchValue":"",
     * "startTime":null,"updateBy":"","updateTime":null,"userId":1437,"userName":"残渊",
     * "userType":1}]}
     */

    public String code;
    public int count;
    public DataBeanX data;
    public Boolean success;
    public static class DataBeanX {
        public List<AuctionAddMode> data;

//        public static class DataBean {
//            /**
//             * applyed : false
//             * auctionDetailId : 308967
//             * auctionId : 9472
//             * avatar : https://wx.qlogo
//             * .cn/mmopen/vi_32
//             * /Q0j4TwGTfTIrv7dxNswV4RddxvgxvHI2UlG4Rib30EoWj3rP97wnLLBWs66HRzjLEJXmTicCzkC2ATFaaeLk9png/132
//             * channelId :
//             * clicked : false
//             * createBy :
//             * createTime : null
//             * deleted : null
//             * desc : desc
//             * deviceCode :
//             * deviceType :
//             * endTime : null
//             * guarantyPrice : 610.0
//             * markupTime : 2019-12-28 22:03
//             * orderField :
//             * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,
//             * "pageStr":"","totalPage":0,"totalResult":0}
//             * params : null
//             * payPrice : 3050.0
//             * payType : 1
//             * remark :
//             * searchValue :
//             * startTime : null
//             * updateBy :
//             * updateTime : null
//             * userId : 1437
//             * userName : 残渊
//             * userType : 1
//             */
//
//            public boolean applyed;
//            public int auctionDetailId;
//            public int auctionId;
//            public String avatar;
//            public String channelId;
//            public boolean clicked;
//            public String createBy;
//            public Object createTime;
//            public Object deleted;
//            public String desc;
//            public String deviceCode;
//            public String deviceType;
//            public Object endTime;
//            public double guarantyPrice;
//            public String markupTime;
//            public String orderField;
//            public PageBean page;
//            public Object params;
//            public double payPrice;
//            public int payType;
//            public String remark;
//            public String searchValue;
//            public Object startTime;
//            public String updateBy;
//            public Object updateTime;
//            public int userId;
//            public String userName;
//            public int userType;
//
//            public static class PageBean {
//                /**
//                 * currentResult : 0
//                 * entityOrField : false
//                 * pageNumber : 1
//                 * pageSize : 10
//                 * pageStr :
//                 * totalPage : 0
//                 * totalResult : 0
//                 */
//
//                public int currentResult;
//                public boolean entityOrField;
//                public int pageNumber;
//                public int pageSize;
//                public String pageStr;
//                public int totalPage;
//                public int totalResult;
//            }
//        }
    }
}
