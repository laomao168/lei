package com.freedom.supercoin.obserber;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.widget.NestedScrollView;
import android.util.AttributeSet;
import android.view.View;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2020/2/20.
 * @desc :
 */
public class ObservableNestScrollView extends NestedScrollView {
    public ObservableNestScrollView(@NonNull Context context) {
        super(context);
    }

    public ObservableNestScrollView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public ObservableNestScrollView(@NonNull Context context, @Nullable AttributeSet attrs,
                                    int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onScrollChanged(int l, int t, int oldl, int oldt) {
        super.onScrollChanged(l, t, oldl, oldt);
        if (scrollViewListener != null) {
            scrollViewListener.onScrollChange(this, l, t, oldl, oldt);
        }
    }
    public interface  ScrollViewListener{
        void onScrollChange(ObservableNestScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY);
    }
    public ScrollViewListener scrollViewListener;
    public void setScrollViewListener(ScrollViewListener scrollViewListener){

        this.scrollViewListener = scrollViewListener;
    }
}
