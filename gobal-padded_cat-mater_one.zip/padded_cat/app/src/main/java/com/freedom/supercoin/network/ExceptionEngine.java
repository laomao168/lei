package com.freedom.supercoin.network;

import android.app.Application;
import android.content.ComponentName;
import android.content.Intent;
import android.net.ParseException;

import com.freedom.supercoin.base_library.AppConst;
import com.freedom.supercoin.base_library.base.BaseApplication;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializer;

import org.json.JSONException;

import java.io.NotSerializableException;
import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

import retrofit2.HttpException;

public class ExceptionEngine {

    //对应HTTP的状态码
    private static final int UNAUTHORIZED = 401;
    private static final int FORBIDDEN = 403;
    private static final int NOT_FOUND = 404;
    private static final int REQUEST_TIMEOUT = 408;
    private static final int INTERNAL_SERVER_ERROR = 500;
    private static final int BAD_GATEWAY = 502;
    private static final int SERVICE_UNAVAILABLE = 503;
    private static final int GATEWAY_TIMEOUT = 504;

    private static long lastTime;


    public static RuntimeException handleException(Throwable e) {
        e.printStackTrace();
//        if (e instanceof ClientException) {
//            if ("401".equals(((ClientException) e).getStatusCode())) {
//
//            }
//            return ((ClientException) e);
//        }
        String message;
        if (e instanceof HttpException) {             //HTTP错误
            HttpException httpException = (HttpException) e;
            switch (httpException.code()) {
                case UNAUTHORIZED:
                    if (System.currentTimeMillis() - lastTime > 2 * 1000) {
                        Intent intent = new Intent(Intent.ACTION_VIEW);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        intent.setComponent(new ComponentName("com.lepai", "com.freedom.supercoin.activity.LoginActivity"));
                        BaseApplication.context.startActivity(intent);
                        lastTime = System.currentTimeMillis();
                    }
                    message = "请重新登录";
                    break;
                case FORBIDDEN:
                case NOT_FOUND:
                case REQUEST_TIMEOUT:
                case GATEWAY_TIMEOUT:
                case INTERNAL_SERVER_ERROR:
                case BAD_GATEWAY:
                case SERVICE_UNAVAILABLE:
                default:
                    message = "服务器异常";  //均视为网络错误
                    break;
            }
        } else if (e instanceof JsonParseException || e instanceof JSONException ||
                e instanceof JsonSerializer || e instanceof NotSerializableException ||
                e instanceof ParseException) {
            message = "解析错误"; //均视为解析错误
        } else if (e instanceof ConnectException) {
            message = "连接失败";  //均视为网络错误
        } else if (e instanceof SocketTimeoutException) {
            message = "连接超时";  //均视为连接时间为60s
        } else if (e instanceof ClassCastException) {
            message = "类型转换错误";
        } else if (e instanceof javax.net.ssl.SSLHandshakeException) {
            message = "证书验证失败";
        } else if (e instanceof UnknownHostException) {
            message = "无法解析该域名";
        } else if (e instanceof NullPointerException) {
            message = "NullPointerException";
        } else {
            message = e.getMessage();  //未知错误
        }
        return new ServerException(message);
    }
}
