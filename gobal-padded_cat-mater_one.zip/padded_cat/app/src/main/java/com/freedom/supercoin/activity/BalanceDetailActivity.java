package com.freedom.supercoin.activity;

import android.support.v7.widget.LinearLayoutManager;
import android.text.TextUtils;
import android.view.View;

import com.freedom.supercoin.R;
import com.freedom.supercoin.adapter.BalanceAdapter;
import com.freedom.supercoin.base_library.widget.spingview.DefaultFooter;
import com.freedom.supercoin.base_library.widget.spingview.SpringView;
import com.freedom.supercoin.common.UiActivity;
import com.freedom.supercoin.contract.BalanceDetailContact;
import com.freedom.supercoin.databinding.ActivityBalanceDetailBinding;
import com.freedom.supercoin.mode.BalanceListMode;
import com.freedom.supercoin.persenter.BalanceDetaiPresenter;

/**
 * @author : lijianping
 * @date : Created on 2019/7/11.
 * des:  余额明细
 */
public class BalanceDetailActivity extends UiActivity<ActivityBalanceDetailBinding> implements BalanceDetailContact.View {


    private BalanceDetaiPresenter presenter;
    private BalanceAdapter adapter;
    private int currentPageNumber;

    @Override
    protected int layoutResId() {
        return R.layout.activity_balance_detail;
    }

    @Override
    protected void initData() {

        presenter = new BalanceDetaiPresenter(this);
        binding.recycleView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new BalanceAdapter();
        binding.recycleView.setAdapter(adapter);
        initSpringView();
        currentPageNumber = 1;
        presenter.getBalanceDetail(currentPageNumber);
    }

    @Override
    protected void initEvent() {
        binding.ivBack.setOnClickListener(v -> finish());
    }

    private void initSpringView() {
        binding.springView.setType(SpringView.Type.FOLLOW);
        binding.springView.setListener(new SpringView.OnFreshListener() {
            @Override
            public void onRefresh() {
            }

            @Override
            public void onLoadMore() {
                currentPageNumber = currentPageNumber + 1;
                presenter.getBalanceDetail(currentPageNumber);
            }

        });
        binding.springView.setFooter(new DefaultFooter(this));
    }

    @Override
    public void getBalanceListSuccess(BalanceListMode mode) {
        binding.springView.onFinishFreshAndLoad();
        if (!TextUtils.equals(mode.code, "0") || !mode.success) return;
        if (currentPageNumber==1){
            adapter.setData(mode.data.data);
        }else {
            adapter.addDataList(mode.data.data);
        }
    }
}
