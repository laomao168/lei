package com.freedom.supercoin.persenter;

import android.text.TextUtils;

import com.freedom.supercoin.base_library.AppConst;
import com.freedom.supercoin.base_library.utils.SPUtils;
import com.freedom.supercoin.contract.LoginContact;
import com.freedom.supercoin.mode.CodeMode;
import com.freedom.supercoin.mode.LoginMode;
import com.freedom.supercoin.mode.entity.CodeReq;
import com.freedom.supercoin.mode.entity.LoginBean;
import com.freedom.supercoin.network.DataManager;
import com.freedom.supercoin.network.ResponseErrorFunc;
import com.freedom.supercoin.network.RxUtils;

import rx.Subscriber;


public class LoginPresenter implements LoginContact.Presenter {

    private final LoginContact.View view;

    public LoginPresenter(LoginContact.View view) {
        this.view = view;
    }

    @Override
    public void toLogin(LoginBean loginBean) {
        DataManager.getInstance()
                .login(loginBean)
                .compose(RxUtils.applyIOSchedulers())
                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<LoginMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                        view.showMessage(e.getMessage());
                    }


                    @Override
                    public void onNext(LoginMode mode) {
                        view.hideProgress();
                        view.onLoginSuccess();
                        AppConst.ISLOGIN=true;
                        SPUtils.getInstance().put(AppConst.Keys.LOGIN_TOKEN, mode.token);
                        SPUtils.getInstance().put(AppConst.Keys.INVITATION_CODE,mode.invitationCode);
                        SPUtils.getInstance().put(AppConst.Keys.AVATAR,mode.avatar);
                        SPUtils.getInstance().put(AppConst.Keys.NICKNAME,mode.nickname);
                        SPUtils.getInstance().put(AppConst.Keys.PHONE,mode.phone);
                        SPUtils.getInstance().put(AppConst.Keys.USER_ID,mode.userId);
                    }
                });
    }

    @Override
    public void getCode(CodeReq codeReq) {
        DataManager.getInstance()
                .getCode(codeReq)
                .compose(RxUtils.applyIOSchedulers())
//                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<CodeMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(CodeMode mode) {
                        view.hideProgress();
                        if (TextUtils.equals(mode.code, "0")) {
                            view.onGetCodeSuccess();
                        }

                    }
                });
    }


}
