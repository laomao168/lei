package com.freedom.supercoin.fragment;

import android.view.View;

import com.freedom.supercoin.R;
import com.freedom.supercoin.activity.AddressActivity;
import com.freedom.supercoin.activity.BalanceActivity;
import com.freedom.supercoin.activity.FriendActivity;
import com.freedom.supercoin.activity.IntegralActivity;
import com.freedom.supercoin.activity.InviteFriendActivity;
import com.freedom.supercoin.activity.LoginTipsActivity;
import com.freedom.supercoin.activity.MyAuctionActivity;
import com.freedom.supercoin.activity.OrderActivity;
import com.freedom.supercoin.activity.PersonalCenterActivity;
import com.freedom.supercoin.activity.SecurityActivity;
import com.freedom.supercoin.activity.WebActivity;
import com.freedom.supercoin.base_library.AppConst;
import com.freedom.supercoin.base_library.utils.GlideUtils;
import com.freedom.supercoin.base_library.utils.SPUtils;
import com.freedom.supercoin.base_library.utils.StrUtils;
import com.freedom.supercoin.common.UILazyFragment;
import com.freedom.supercoin.contract.MeContact;
import com.freedom.supercoin.databinding.FragmentMeBinding;
import com.freedom.supercoin.mode.OrderStatisticsMode;
import com.freedom.supercoin.mode.UserInfoMode;
import com.freedom.supercoin.persenter.MePresenter;


/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2019/7/18.
 */

public class MeFragment extends UILazyFragment<FragmentMeBinding> implements MeContact.View {

    private MePresenter presenter;

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_me;
    }

    @Override
    protected boolean isLazyOrNot() {
        return false;
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser && presenter != null) {
            if (AppConst.ISLOGIN) {
                presenter.getUserInfo();
                presenter.getOrderInfo();
                if (binding == null) return;
                GlideUtils.loadRound(mActivity,
                        SPUtils.getInstance().getString(AppConst.Keys.AVATAR)
                        , binding.ivMeIcon, 15);
                binding.tvNikeName.setText(SPUtils.getInstance().getString(AppConst.Keys.NICKNAME));
            } else {
                binding.ivMeIcon.setImageResource(R.mipmap.img_goodsdetails_head2);
                binding.tvNikeName.setText("请登录");
                binding.tvIntegral.setText("0");
                binding.tvBalance.setText("0");
                binding.tvFriend.setText("0");
            }

        }
    }

    @Override
    protected void initData() {
        presenter = new MePresenter(this);
    }

    @Override
    public void onStart() {
        super.onStart();
        presenter.getUserInfo();
        presenter.getOrderInfo();
    }

    @Override
    protected void initEvent() {
        binding.setClick(v -> {
            switch (v.getId()) {
                case R.id.iv_me_icon:
                case R.id.tv_nike_name:
                case R.id.tv_invite_code:
                case R.id.iv_to_person:
                    if (AppConst.ISLOGIN) {
                        getOperation().forward(PersonalCenterActivity.class);
                    }
                    break;
                case R.id.ll_integral://积分
                    getOperation().forward(IntegralActivity.class);
                    break;
                case R.id.ll_balance://余额
                    getOperation().forward(BalanceActivity.class);
                    break;
                case R.id.ll_friend://我的好友
                    getOperation().forward(FriendActivity.class);
                    break;
                case R.id.rl_order://全部订单
                    getOperation().addParameter(OrderFragment.INDEX, 0);
                    getOperation().forward(OrderActivity.class);
                    break;
                case R.id.ll_pending_payment://代付款
                    getOperation().addParameter(OrderFragment.INDEX, 1);
                    getOperation().forward(OrderActivity.class);
                    break;
                case R.id.ll_delivery_need://待发货
                    getOperation().addParameter(OrderFragment.INDEX, 2);
                    getOperation().forward(OrderActivity.class);
                    break;
                case R.id.ll_receiving://待收货
                    getOperation().addParameter(OrderFragment.INDEX, 3);
                    getOperation().forward(OrderActivity.class);
                    break;
                case R.id.ll_complete://交易完成
                    getOperation().addParameter(OrderFragment.INDEX, 4);
                    getOperation().forward(OrderActivity.class);
                    break;
                case R.id.rl_account://账户与安全
                    getOperation().forward(SecurityActivity.class);
                    break;
                case R.id.rl_location://地址管理
                    getOperation().forward(AddressActivity.class);
                    break;
                case R.id.rl_invite://邀请好友
                    getOperation().forward(InviteFriendActivity.class);
                    break;
                case R.id.rl_user_need://用户须知
                    getOperation().addParameter(AppConst.Keys.TITLE, "用户须知");
                    getOperation().addParameter(AppConst.Keys.WEB_URL,
                            AppConst.Values.USER_KONW);
                    getOperation().forward(WebActivity.class);
                    break;
                case R.id.rl_customer://专属客服
                    getOperation().addParameter(AppConst.Keys.TITLE, "专属客服");
                    getOperation().addParameter(AppConst.Keys.WEB_URL,
                            AppConst.Values.COSTOM_SERVICE);
                    getOperation().forward(WebActivity.class);
                    break;
                case R.id.rl_help:
                    getOperation().addParameter(AppConst.Keys.TITLE, "帮助中心");
                    getOperation().addParameter(AppConst.Keys.WEB_URL,
                            AppConst.Values.HELP);
                    getOperation().forward(WebActivity.class);
                    break;
                case R.id.tv_loin_out://退出登录
                    SPUtils.getInstance().put(AppConst.Keys.INVITATION_CODE, "");
                    SPUtils.getInstance().put(AppConst.Keys.NICKNAME, "");
                    SPUtils.getInstance().put(AppConst.Keys.LOGIN_TOKEN, "");
                    SPUtils.getInstance().put(AppConst.Keys.AVATAR, "");
                    SPUtils.getInstance().put(AppConst.Keys.PHONE, "");
                    SPUtils.getInstance().put(AppConst.Keys.USER_ID, "");
                    AppConst.ISLOGIN = false;
                    startActivity(LoginTipsActivity.class);
                    break;

            }
        });
    }

    @Override
    public void onLoadUserInfoSuccess(UserInfoMode userInfoMode) {
        SPUtils.getInstance().put(AppConst.Keys.INTEGRAL, userInfoMode.integralAmount + "");
        binding.tvNikeName.setText(userInfoMode.nickname);
        binding.tvBalance.setText(StrUtils.getRemoveZreoNum(userInfoMode.amount));
        binding.tvIntegral.setText(userInfoMode.integralAmount + "");
        binding.tvInviteCode.setText("邀请码:  " + userInfoMode.invitationCode);
        binding.tvFriend.setText(userInfoMode.fanNums + "");
        SPUtils.getInstance().put(AppConst.Keys.INVITATION_CODE, userInfoMode.invitationCode);
        SPUtils.getInstance().put(AppConst.Keys.NICKNAME, userInfoMode.nickname);
    }

    @Override
    public void onLoadOrderStaticsSuccess(OrderStatisticsMode orderStatisticsMode) {
        if (orderStatisticsMode.waitPay == 0) {
            binding.tvOrderNumPay.setVisibility(View.GONE);
        } else {
            binding.tvOrderNumPay.setVisibility(View.VISIBLE);
            binding.tvOrderNumPay.setText(orderStatisticsMode.waitPay + "");
        }
        if (orderStatisticsMode.waitDeliverGoods == 0) {
            binding.tvDeliveryNeed.setVisibility(View.GONE);
        } else {
            binding.tvDeliveryNeed.setVisibility(View.VISIBLE);
            binding.tvDeliveryNeed.setText(orderStatisticsMode.waitDeliverGoods + "");
        }

        if (orderStatisticsMode.waitReceivingGoods == 0) {
            binding.tvReceiving.setVisibility(View.GONE);
        } else {
            binding.tvReceiving.setVisibility(View.VISIBLE);
            binding.tvReceiving.setText(orderStatisticsMode.waitReceivingGoods + "");
        }
    }
}
