package com.freedom.supercoin.persenter;

import com.freedom.supercoin.contract.GoodsCategoryContact;
import com.freedom.supercoin.mode.HomeAuctionRes;
import com.freedom.supercoin.mode.IntegralFragmentMode;
import com.freedom.supercoin.network.DataManager;
import com.freedom.supercoin.network.ResponseErrorFunc;
import com.freedom.supercoin.network.RxUtils;

import rx.Subscriber;


public class GoodsCategoryPresenter implements GoodsCategoryContact.Presenter {

    private final GoodsCategoryContact.View view;

    public GoodsCategoryPresenter(GoodsCategoryContact.View view) {
        this.view = view;
    }

    @Override
    public void getGoodsCategoryData(int fatherCategoryId, int pageNumber) {

        DataManager.getInstance()
                .getGoodsCategoryData(fatherCategoryId,pageNumber)
                .compose(RxUtils.applyIOSchedulers())
//                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<HomeAuctionRes>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(HomeAuctionRes res) {
                        view.loadCategorySuccess(res);
                        view.hideProgress();
                    }
                });
    }

    @Override
    public void loadIntegralList(int fatherCategoryId, int pageNumber) {
        DataManager.getInstance()
                .loadIntegralListByGoodstype(fatherCategoryId,pageNumber)
                .compose(RxUtils.applyIOSchedulers())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<IntegralFragmentMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(IntegralFragmentMode body) {
                        view.hideProgress();
                        view.IntegralListSuccess(body);
                    }
                });
    }

}
