package com.freedom.supercoin.persenter;

import com.freedom.supercoin.base_library.utils.LogUtils;
import com.freedom.supercoin.contract.PersonalContact;
import com.freedom.supercoin.mode.ImageUploadMode;
import com.freedom.supercoin.mode.PersonalMode;
import com.freedom.supercoin.mode.UpdateNikeNameMode;
import com.freedom.supercoin.network.DataManager;
import com.freedom.supercoin.network.ResponseErrorFunc;
import com.freedom.supercoin.network.RxUtils;

import java.io.IOException;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import rx.Subscriber;


public class PersonalPresenter implements PersonalContact.Presenter {

    private final PersonalContact.View view;

    public PersonalPresenter(PersonalContact.View view) {
        this.view = view;
    }


    @Override
    public void saveInviteCode(String inviteCode) {
        DataManager.getInstance()
                .saveInviteCode(inviteCode)
                .compose(RxUtils.applyIOSchedulers())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<PersonalMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(PersonalMode mode) {
                        view.hideProgress();
                       if (mode.success){
                           view.onSuccess();
                       }else {
                           view.showMessage(mode.msg);
                       }
                    }
                });
    }

    @Override
    public void uploadImage(RequestBody requetBody, MultipartBody.Part file) {
        DataManager.getInstance()
                .uploadImage(requetBody,file)
                .compose(RxUtils.applyIOSchedulers())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<ImageUploadMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(ImageUploadMode mode) {
                        view.hideProgress();
                        view.onUploadImageSuccess(mode);
                    }
                });
    }

    @Override
    public void updateNikeName(String nikeName, String avatar) {
        DataManager.getInstance()
                .updateNikeName(nikeName,avatar)
                .compose(RxUtils.applyIOSchedulers())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<UpdateNikeNameMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(UpdateNikeNameMode mode) {
                        view.hideProgress();
                        view.onUpdateNikeNameSuccess(mode);
                    }
                });
    }
}
