package com.freedom.supercoin.fragment;

import android.graphics.Bitmap;
import android.net.http.SslError;
import android.os.Message;
import android.view.View;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.freedom.supercoin.R;
import com.freedom.supercoin.base_library.AppConst;
import com.freedom.supercoin.common.UILazyFragment;
import com.freedom.supercoin.databinding.FragmentRuleBinding;
import com.freedom.supercoin.utils.WebViewUtils;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2019/7/18.
 */

public class RuleFragment extends UILazyFragment<FragmentRuleBinding> {
    @Override
    protected int getLayoutId() {
        return R.layout.fragment_rule;
    }




    @Override
    public void initData() {

        WebViewUtils.initWebView(mActivity, binding.webView);
        binding.webView.setWebViewClient(new MyWebViewClient());
        binding.webView.setWebChromeClient(new MyWebChromeClient());
        binding.webView.loadUrl(AppConst.Values.AUCTION_RULES);
    }

    @Override
    protected void initEvent() {

    }


    private class MyWebViewClient extends WebViewClient {

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);

        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return super.shouldOverrideUrlLoading(view, request);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return super.shouldOverrideUrlLoading(view, url);
        }

        @Override
        public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
            super.onReceivedSslError(view, handler, error);
            if (handler != null) {
                // handler.cancel();// Android默认的处理方式
                handler.proceed();// 接受所有网站的证书
                // handleMessage(Message msg); //进行其他处理
            }
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
        }
    }

    private class MyWebChromeClient extends WebChromeClient {

        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            super.onProgressChanged(view, newProgress);
            if (newProgress == 100) {
                binding.progressBar.setVisibility(View.GONE);//加载完网页进度条消失
            } else {
                binding.progressBar.setVisibility(View.VISIBLE);//开始加载网页时显示进度条
                binding.progressBar.setProgress(newProgress);//设置进度值
            }
        }

        @Override
        public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture,
                                      Message resultMsg) {
            WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
            transport.setWebView(binding.webView);
            resultMsg.sendToTarget();
            return true;
        }

        @Override
        public void onReceivedTitle(WebView view, String title) {
            super.onReceivedTitle(view, title);
        }

    }
}
