package com.freedom.supercoin.persenter;

import com.freedom.supercoin.contract.InviteFriendContact;
import com.freedom.supercoin.mode.InviteFriendMode;
import com.freedom.supercoin.network.DataManager;
import com.freedom.supercoin.network.ResponseErrorFunc;
import com.freedom.supercoin.network.RxUtils;

import rx.Subscriber;


public class InviteFriendPresenter implements InviteFriendContact.Presenter {

    private final InviteFriendContact.View view;

    public InviteFriendPresenter(InviteFriendContact.View view) {
        this.view = view;
    }

    @Override
    public void loadQrCode() {
        DataManager.getInstance()
                .loadQrCode()
                .compose(RxUtils.applyIOSchedulers())
//                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<InviteFriendMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(InviteFriendMode mode) {
                        view.onGetQrCodeSuccess(mode);
                        view.hideProgress();
                    }
                });
    }



}
