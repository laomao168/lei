package com.freedom.supercoin.dialog;

import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.Window;
import android.widget.EditText;
import android.widget.TextView;

import com.freedom.supercoin.R;
import com.freedom.supercoin.base_library.dialog.BaseDialog;
import com.freedom.supercoin.base_library.utils.KeyboardUtils;


/**
 * Created by jianping on 2018/10/22.
 */

public class FundDialog extends BaseDialog {

    private EditText etCode;
    private TextView tvConFirm,tvCancel;
    private OnDialogClickListener l;

    @Override
    protected int setContentId() {
        return R.layout.dialog_fund;
    }

    public void setOnDialogClickListener(OnDialogClickListener l) {
        this.l = l;
    }

    public interface OnDialogClickListener {
        void onConfirmClick(String pwd);
    }

    @Override
    protected void initView() {
        etCode = findView(R.id.code);
        tvConFirm = findView(R.id.confirm);
        tvCancel = findView(R.id.cancel);

    }

    @Override
    protected void initData() {
        tvConFirm.setOnClickListener(v -> {
            String pwd = etCode.getText().toString();
            if (pwd.isEmpty()) return;
            if (l != null) {
                KeyboardUtils.hideKeyboard(getDialog().getCurrentFocus());
                l.onConfirmClick(pwd);
            }
        });
        tvCancel.setOnClickListener(v -> dismiss());
    }

    /**
     * @param status 0关闭dialog  1   提示错误
     */
    public void setStatus(int status) {
        if (status == 0) {
            dismiss();
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        DisplayMetrics dm = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics( dm );
        Window window = getDialog().getWindow();
        window.setLayout( dm.widthPixels, window.getAttributes().height);
        window.setGravity(Gravity.BOTTOM);
    }
}
