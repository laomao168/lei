package com.freedom.supercoin.persenter;

import com.freedom.supercoin.base_library.utils.GsonUtils;
import com.freedom.supercoin.base_library.utils.LogUtils;
import com.freedom.supercoin.contract.IntegralPayContact;
import com.freedom.supercoin.contract.OrderPayContact;
import com.freedom.supercoin.mode.AddressListMode;
import com.freedom.supercoin.mode.BalanceDetailMode;
import com.freedom.supercoin.mode.ChargeTypeMode;
import com.freedom.supercoin.mode.IntegralGoodsDetailBean;
import com.freedom.supercoin.mode.OrderDetailMode;
import com.freedom.supercoin.mode.PayAlipayRes;
import com.freedom.supercoin.mode.PayErrorRes;
import com.freedom.supercoin.mode.PayReq;
import com.freedom.supercoin.mode.PayRes;
import com.freedom.supercoin.network.DataManager;
import com.freedom.supercoin.network.ResponseErrorFunc;
import com.freedom.supercoin.network.RxUtils;

import okhttp3.ResponseBody;
import rx.Subscriber;


public class IntegralPayPresenter implements IntegralPayContact.Presenter {

    private final IntegralPayContact.View view;

    public IntegralPayPresenter(IntegralPayContact.View view) {
        this.view = view;
    }

    @Override
    public void getBalance() {
        DataManager.getInstance()
                .getBalance()
                .compose(RxUtils.applyIOSchedulers())
                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<BalanceDetailMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(BalanceDetailMode mode) {
                        view.getBalanceSuccess(mode);
                        view.hideProgress();
                    }
                });
    }

    @Override
    public void getOrderDetail(int orderId) {
        DataManager.getInstance()
                .getOrderDetail(orderId)
                .compose(RxUtils.applyIOSchedulers())
                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<OrderDetailMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(OrderDetailMode mode) {
                        view.getOrderDetailSuccess(mode);
                        view.hideProgress();
                    }
                });
    }

    @Override
    public void getAddress() {
        DataManager.getInstance()
                .getAddressList()
                .compose(RxUtils.applyIOSchedulers())
//                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<AddressListMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(AddressListMode mode) {
                        view.getAddressListSuccess(mode);
                        view.hideProgress();
                    }
                });

    }

    @Override
    public void loadIntegralGoodsDetail(int goodId) {
        DataManager.getInstance()
                .getIntegralDetail(goodId)
                .compose(RxUtils.applyIOSchedulers())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(ResponseBody responseBody) {
                        view.hideProgress();
                        try {
                            String string = responseBody.string().trim();
                            LogUtils.ShowD("string", string);
                            if (string.contains("成功")) {
                                IntegralGoodsDetailBean integralGoodsDetailBean =
                                        GsonUtils.fromJson(string, IntegralGoodsDetailBean.class);
                                view.onLoadIntegralGoodsDetailSuccess(integralGoodsDetailBean);
                            } else {
                                PayErrorRes errorRes = GsonUtils.fromJson(string,
                                        PayErrorRes.class);
                                view.showMessage(errorRes.msg);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();

                        }
                    }
                });
    }

    @Override
    public void getPaytype() {

    }

    @Override
    public void getChargeType() {
        DataManager.getInstance()
                .getChargeType()
                .compose(RxUtils.applyIOSchedulers())
//                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<ChargeTypeMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(ChargeTypeMode mode) {
                        view.onLoadChargeTypeSuccess(mode);
                        view.hideProgress();
                    }
                });
    }

    @Override
    public void getPayInfo(PayReq payReq) {
        DataManager.getInstance()
                .integralPayOrder(payReq)
                .compose(RxUtils.applyIOSchedulers())
//                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(ResponseBody body) {
                        view.hideProgress();
                        try {
                            String string = body.string().trim();
                            LogUtils.ShowD("string", string);
                            if (string.contains("成功")) {
                                //1余额2微信3支付宝4.积分
                                if (payReq.payType == 2) {
                                    PayRes auctionAddMode = GsonUtils.fromJson(string, PayRes.class);
                                    view.onLoadPayResWechatSuccess(auctionAddMode, payReq.payType);
                                }else if (payReq.payType==3) {
                                    PayAlipayRes payAlipayRes = GsonUtils.fromJson(string,
                                            PayAlipayRes.class);
                                    view.onLoadPayResAlipaySuccess(payAlipayRes, payReq.payType);
                                }else {
                                  view.onLoadPayResBalanceSuccess();
                                }
                            } else {
                                PayErrorRes errorRes = GsonUtils.fromJson(string,
                                        PayErrorRes.class);
                                if (errorRes.success){
                                    view.onLoadPayResBalanceSuccess();
                                }else {
                                    view.showMessage(errorRes.msg);
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();

                        }

                    }
                });
    }


}
