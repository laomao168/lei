package com.freedom.supercoin.persenter;

import com.freedom.supercoin.contract.IntegralOrderDetailContact;
import com.freedom.supercoin.contract.OrderDetailContact;
import com.freedom.supercoin.mode.OrderDetailMode;
import com.freedom.supercoin.network.DataManager;
import com.freedom.supercoin.network.ResponseErrorFunc;
import com.freedom.supercoin.network.RxUtils;

import rx.Subscriber;


public class IntegralOrderDetailPresenter implements IntegralOrderDetailContact.Presenter {

    private final IntegralOrderDetailContact.View view;

    public IntegralOrderDetailPresenter(IntegralOrderDetailContact.View view) {
        this.view = view;
    }

    @Override
    public void getOrderDetail(int orderId) {
        DataManager.getInstance()
                .getMallOrderDetail(orderId)
                .compose(RxUtils.applyIOSchedulers())
                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<OrderDetailMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(OrderDetailMode mode) {
                        view.getOrderDetailSuccess(mode);
                        view.hideProgress();
                    }
                });
    }

    @Override
    public void cancelOrder(int orderId) {
        DataManager.getInstance()
                .cancelMallOrder(orderId)
                .compose(RxUtils.applyIOSchedulers())
                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<OrderDetailMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(OrderDetailMode mode) {
                        view.onCancelOrderSuccess();
                        view.hideProgress();
                    }
                });
    }

    @Override
    public void receiptOrder(int orderId) {
        DataManager.getInstance()
                .receiptMallOrder(orderId)
                .compose(RxUtils.applyIOSchedulers())
                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<OrderDetailMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(OrderDetailMode mode) {
                        view.onReceiptOrderSuccess();
                        view.hideProgress();
                    }
                });
    }


}
