package com.freedom.supercoin.contract;


import com.freedom.supercoin.base_library.base.BasePresenter;
import com.freedom.supercoin.base_library.base.BaseView;
import com.freedom.supercoin.mode.OrderDetailMode;


public class OrderDetailContact {

    public interface View extends BaseView {

        void getOrderDetailSuccess(OrderDetailMode mode);

        void onCancelOrderSuccess();

        void onReceiptOrderSuccess();
    }


    public interface Presenter extends BasePresenter {
        void getOrderDetail(int orderId);

        void cancelOrder(int orderId);

        void receiptOrder(int orderId);
    }
}

