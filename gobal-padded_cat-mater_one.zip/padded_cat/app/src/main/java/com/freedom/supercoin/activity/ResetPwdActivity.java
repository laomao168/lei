package com.freedom.supercoin.activity;

import android.text.TextUtils;

import com.freedom.supercoin.R;
import com.freedom.supercoin.common.UiActivity;
import com.freedom.supercoin.contract.RealNameContact;
import com.freedom.supercoin.databinding.ActivityABinding;
import com.freedom.supercoin.databinding.ActivityResetPwdBinding;
import com.freedom.supercoin.mode.RealNameMode;
import com.freedom.supercoin.persenter.ResetPwdPresenter;

/**
 * @author : lijianping
 * @date : Created on 2019/7/11.
 * des:
 */
public class ResetPwdActivity extends UiActivity<ActivityResetPwdBinding> implements RealNameContact.View {

    private ResetPwdPresenter presenter;

    @Override
    protected int layoutResId() {
        return R.layout.activity_reset_pwd;
    }

    @Override
    protected void initData() {
        binding.titleBar.setTextColor("#ffffff");
        binding.titleBar.setLeftImage(R.mipmap.ic_back_white);
        binding.titleBar.setTitle("重置密码");
    }

    @Override
    protected void initEvent() {
        binding.tvSub.setOnClickListener(v -> {
            checkAndSub();
        });
        presenter = new ResetPwdPresenter(this);
    }

    private void checkAndSub() {
        String old = binding.etOldPwd.getText().toString();
        String newPwd = binding.etNewPwd.getText().toString();
        String pwdAgain = binding.etPwdAgain.getText().toString();
        if (TextUtils.isEmpty(old)) {
            showMessage("请输入旧密码");
            return;
        }

        if (TextUtils.isEmpty(newPwd)) {
            showMessage("请输入新密码");
            return;
        }

        if (TextUtils.isEmpty(pwdAgain)) {
            showMessage("请再次输入密码");
            return;
        }
//        presenter.toIdentity(name,alipay,idCard);
    }

    @Override
    public void onSubSuccess(RealNameMode mode) {

    }
}
