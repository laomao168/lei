package com.freedom.supercoin.adapter;

import android.databinding.DataBindingUtil;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.freedom.supercoin.R;
import com.freedom.supercoin.base_library.base.BaseEmptyAdapter;
import com.freedom.supercoin.databinding.ItemIntegralBinding;
import com.freedom.supercoin.databinding.ItemProductBinding;
import com.freedom.supercoin.mode.IntegralMode;

public class IntegralAdapter extends BaseEmptyAdapter<IntegralMode.DataBeanX.DataBean,
        ItemIntegralBinding> {
    @Override
    protected ItemIntegralBinding createBinding(ViewGroup parent) {
        return DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()),
                R.layout.item_integral, parent, false);
    }

    @Override
    protected void onBindView(ItemIntegralBinding binding,
                              IntegralMode.DataBeanX.DataBean bean, int position) {
        if (position == data.size() - 1) {
            binding.viewSplit.setVisibility(View.GONE);
        } else {
            binding.viewSplit.setVisibility(View.VISIBLE);
        }
        if (bean.tradeType == 1) {
            binding.ivIntegralAction.setImageResource(R.mipmap.ic_integral_add);
        } else {
            binding.ivIntegralAction.setImageResource(R.mipmap.ic_integral_reduce);
        }
//        订单类型（ 0 订单赠送积分， 1 平台赠送，2，积分兑换， 3，取消订单退还积分 4寄拍取消退还积分）
        switch (bean.type) {
            case 0:
//                binding.tvIntegralTitle.setText(bean.title);
                binding.tvIntegralTitle.setText("订单赠送积分");
                break;
            case 1:
                binding.tvIntegralTitle.setText("平台赠送");
                break;
            case 2:
                binding.tvIntegralTitle.setText("积分兑换");
                break;
            case 3:
                binding.tvIntegralTitle.setText("取消订单退还积分");
                break;
            case 4:
                binding.tvIntegralTitle.setText("寄拍取消退还积分");
                break;
            default:
                binding.tvIntegralTitle.setText("其他");
                break;
        }
//        收支类型 0 支出 1收入
        if (bean.type == 0) {
            binding.tvIntegralNum.setText("-" + bean.integralAmount);
        } else {
            binding.tvIntegralNum.setText("+" + bean.integralAmount);
        }
        binding.tvIntegralTime.setText(bean.createTime);

    }
}
