package com.freedom.supercoin.activity;

import android.content.Intent;
import android.os.Handler;

import com.freedom.supercoin.R;
import com.freedom.supercoin.common.UiActivity;
import com.freedom.supercoin.databinding.ActivityABinding;

/**
 * @author : lijianping
 * @date : Created on 2019/7/11.
 * des:
 */
public class SplashActivity extends UiActivity <ActivityABinding>{
    @Override
    protected int layoutResId() {
        return R.layout.activity_splash;
    }

    @Override
    protected void initData() {
        new Handler().postDelayed(() -> {
            startActivity(new Intent(SplashActivity.this,MainActivity.class));
            finish();
        }, 1500);
    }

    @Override
    protected void initEvent() {

    }

}
