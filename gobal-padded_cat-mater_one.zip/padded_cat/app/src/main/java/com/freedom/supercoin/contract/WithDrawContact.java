package com.freedom.supercoin.contract;


import com.freedom.supercoin.base_library.base.BasePresenter;
import com.freedom.supercoin.base_library.base.BaseView;
import com.freedom.supercoin.mode.BalanceDetailMode;
import com.freedom.supercoin.mode.WithDrawListMode;
import com.freedom.supercoin.mode.WithDrawMode;
import com.freedom.supercoin.mode.entity.Page;


public class WithDrawContact {

    public interface View extends BaseView {
        void getBalanceSuccess(BalanceDetailMode mode);

        void onLoadWithDrawSuccess(WithDrawMode mode);

        void onLoadWithDrawSuccessList(WithDrawListMode mode);

        void onCancelDrawSuccess();
    }


    public interface Presenter extends BasePresenter {
        void getBalance();

        void WithDraw(String pwd, String money);
        void getWithDrawList(Page page);
        void cancelDraw(String id);
    }
}

