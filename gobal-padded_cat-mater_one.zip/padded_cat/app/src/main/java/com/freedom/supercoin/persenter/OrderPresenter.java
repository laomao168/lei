package com.freedom.supercoin.persenter;

import com.freedom.supercoin.contract.OrderContact;
import com.freedom.supercoin.mode.OrderMode;
import com.freedom.supercoin.network.DataManager;
import com.freedom.supercoin.network.ResponseErrorFunc;
import com.freedom.supercoin.network.RxUtils;

import rx.Subscriber;


public class OrderPresenter implements OrderContact.Presenter {

    private final OrderContact.View view;

    public OrderPresenter(OrderContact.View view) {
        this.view = view;
    }


    @Override
    public void getOrderList(int currentIndex, int type) {
        DataManager.getInstance()
                .getOrderList(currentIndex,type)
                .compose(RxUtils.applyIOSchedulers())
//                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<OrderMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(OrderMode mode) {
                        view.hideProgress();
                        view.getOrderListSuccess(mode);
                    }
                });
    }



}
