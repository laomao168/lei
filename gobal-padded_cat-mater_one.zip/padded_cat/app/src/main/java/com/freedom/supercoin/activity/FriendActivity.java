package com.freedom.supercoin.activity;

import android.graphics.Color;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.View;

import com.freedom.supercoin.R;
import com.freedom.supercoin.adapter.FragmentAdapter;
import com.freedom.supercoin.common.UiActivity;
import com.freedom.supercoin.contract.FriendContact;
import com.freedom.supercoin.databinding.ActivityABinding;
import com.freedom.supercoin.databinding.ActivityFriendBinding;
import com.freedom.supercoin.fragment.FriendFragment;
import com.freedom.supercoin.mode.FriendMode;
import com.freedom.supercoin.mode.MyFansMode;
import com.freedom.supercoin.mode.MySuperiorMode;
import com.freedom.supercoin.persenter.FriendPresenter;

import java.util.ArrayList;

/**
 * @author : lijianping
 * @date : Created on 2019/7/11.
 * des: 好友页面
 */
public class FriendActivity extends UiActivity<ActivityFriendBinding> implements FriendContact.View {

    private ArrayList<Fragment> fragments;
    private FragmentAdapter fragmentAdapter;
    private FriendPresenter friendPresenter;

    @Override
    protected int layoutResId() {
        return R.layout.activity_friend;
    }

    @Override
    protected void initData() {
        binding.titleBar.setLeftImage(R.mipmap.ic_back_white);
        fragments = new ArrayList<>();
        FriendFragment myFriendFragment = FriendFragment.newInstance(0);
        FriendFragment allFriendFragment = FriendFragment.newInstance(1);
        fragments.add(myFriendFragment);
        fragments.add(allFriendFragment);
        fragmentAdapter = new FragmentAdapter(getSupportFragmentManager(), fragments);
        binding.viewpager.setAdapter(fragmentAdapter);
        binding.viewpager.setOffscreenPageLimit(fragments.size());
        friendPresenter = new FriendPresenter(this);
        friendPresenter.getMySuperior();
        friendPresenter.getMyFans();
    }

    @Override
    protected void initEvent() {
        binding.setClick(v -> {
            switch (v.getId()) {
                case R.id.rl_my_friend:
                    showMyFriendUI();
                    binding.viewpager.setCurrentItem(0);
                    break;
                case R.id.rl_all_friend:
                    showAllFriendUI();

                    binding.viewpager.setCurrentItem(1);
                    break;
            }
        });
        binding.viewpager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {

            }

            @Override
            public void onPageSelected(int i) {
                if (i == 0) {
                    showMyFriendUI();
                } else {
                    showAllFriendUI();
                }
            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });
    }

    private void showAllFriendUI() {
        binding.tvMyFriend.setTextColor(Color.parseColor("#333333"));
        binding.tvAllFriend.setTextColor(Color.parseColor("#FA5723"));
        binding.viewMyFriend.setVisibility(View.GONE);
        binding.viewAllFriend.setVisibility(View.VISIBLE);
    }

    private void showMyFriendUI() {
        binding.tvMyFriend.setTextColor(Color.parseColor("#FA5723"));
        binding.tvAllFriend.setTextColor(Color.parseColor("#333333"));
        binding.viewMyFriend.setVisibility(View.VISIBLE);
        binding.viewAllFriend.setVisibility(View.GONE);
    }

    @Override
    public void loadFriendSuccess(FriendMode friendMode) {

    }

    @Override
    public void loadFriendError() {

    }

    @Override
    public void getMyFansSuccess(MyFansMode mode) {
        binding.tvInviteNum.setText(mode.fanNums+"");
    }

    @Override
    public void getMySuperiorSuccess(MySuperiorMode mode) {
        binding.tvMySuperior.setText("我的上级: "+mode.username);
    }
}
