package com.freedom.supercoin.mode.entity;

public class HomeAuctionReq {
    public  int type=2;
    public  int pageSize =10;
    public  int pageNumber =1;
}
