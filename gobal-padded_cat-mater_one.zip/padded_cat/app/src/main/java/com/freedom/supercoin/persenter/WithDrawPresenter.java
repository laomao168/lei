package com.freedom.supercoin.persenter;

import com.freedom.supercoin.contract.WithDrawContact;
import com.freedom.supercoin.mode.BalanceDetailMode;
import com.freedom.supercoin.mode.ChargeTypeMode;
import com.freedom.supercoin.mode.WithDrawListMode;
import com.freedom.supercoin.mode.WithDrawMode;
import com.freedom.supercoin.mode.entity.Page;
import com.freedom.supercoin.network.DataManager;
import com.freedom.supercoin.network.ResponseErrorFunc;
import com.freedom.supercoin.network.RxUtils;

import rx.Subscriber;


public class WithDrawPresenter implements WithDrawContact.Presenter {

    private final WithDrawContact.View view;

    public WithDrawPresenter(WithDrawContact.View view) {
        this.view = view;
    }

    @Override
    public void getBalance() {
        DataManager.getInstance()
                .getBalance()
                .compose(RxUtils.applyIOSchedulers())
                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<BalanceDetailMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(BalanceDetailMode mode) {
                        view.getBalanceSuccess(mode);
                        view.hideProgress();
                    }
                });
    }

    @Override
    public void WithDraw(String pwd, String money) {
        DataManager.getInstance()
                .WithDraw(pwd,money)
                .compose(RxUtils.applyIOSchedulers())
//                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<WithDrawMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(WithDrawMode mode) {
                        view.hideProgress();
                        view.onLoadWithDrawSuccess(mode);
                    }
                });
    }

    @Override
    public void getWithDrawList(Page page) {
        DataManager.getInstance()
                .getWithDrawList(page)
                .compose(RxUtils.applyIOSchedulers())
//                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<WithDrawListMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(WithDrawListMode mode) {
                        view.hideProgress();
                        view.onLoadWithDrawSuccessList(mode);
                    }
                });
    }

    @Override
    public void cancelDraw(String id) {
        DataManager.getInstance()
                .cancelDraw(id)
                .compose(RxUtils.applyIOSchedulers())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<ChargeTypeMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(ChargeTypeMode mode) {
                        view.hideProgress();
                        view.showMessage(mode.msg);
                        if (mode.success){
                            view.onCancelDrawSuccess();
                        }
                    }
                });
    }


}
