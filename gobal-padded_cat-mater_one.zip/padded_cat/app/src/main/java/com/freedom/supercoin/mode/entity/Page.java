package com.freedom.supercoin.mode.entity;

public class Page {
    public  int pageSize =10;
    public  int pageNumber =1;
}
