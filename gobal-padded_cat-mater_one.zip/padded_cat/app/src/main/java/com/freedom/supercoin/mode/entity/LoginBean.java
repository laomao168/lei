package com.freedom.supercoin.mode.entity;

public class LoginBean {
    public String phone;
    public String verifyCode;

}
