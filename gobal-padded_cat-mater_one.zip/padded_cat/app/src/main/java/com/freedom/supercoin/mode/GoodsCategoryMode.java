package com.freedom.supercoin.mode;


public class GoodsCategoryMode {

    /**
     * applyed : false
     * categoryId : 1016
     * channelId :
     * clicked : false
     * createBy : admin
     * createTime : 2019-10-29 15:35:15
     * deleted : 0
     * desc : desc
     * deviceCode :
     * deviceType :
     * endTime : null
     * id : null
     * isRecommend : 1
     * levelText :
     * name : 试玩区
     * orderField :
     * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,
     * "pageStr":"","totalPage":0,"totalResult":0}
     * params : null
     * parentId : 0
     * parentName :
     * pic : https://images.oneauct.com/5fcffcf2d6074f45a091b598fc581cf7
     * remark :
     * searchValue :
     * sort : 10
     * startTime : null
     * status : 0
     * type : 1
     * updateBy : admin
     * updateTime : 2019-12-09 22:36:32
     */

    public boolean applyed;
    public int categoryId;
    public String channelId;
    public boolean clicked;
    public String createBy;
    public String createTime;
    public int deleted;
    public String desc;
    public String deviceCode;
    public String deviceType;
    public Object endTime;
    public Object id;
    public int isRecommend;
    public String levelText;
    public String name;
    public String orderField;
    public Object params;
    public int parentId;
    public String parentName;
    public String pic;
    public String remark;
    public String searchValue;
    public int sort;
    public Object startTime;
    public int status;
    public int type;
    public String updateBy;
    public String updateTime;

}
