package com.freedom.supercoin.adapter;

import android.databinding.DataBindingUtil;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.freedom.supercoin.R;
import com.freedom.supercoin.base_library.base.BaseEmptyAdapter;
import com.freedom.supercoin.databinding.ItemAddressBinding;
import com.freedom.supercoin.databinding.ItemMyAuctionBinding;
import com.freedom.supercoin.mode.AddressListMode;
import com.freedom.supercoin.mode.OrderMode;


public class AddressAdapter extends BaseEmptyAdapter<AddressListMode.DataBeanX.DataBean,
        ItemAddressBinding> {

    @Override
    protected ItemAddressBinding createBinding(ViewGroup parent) {
        return DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()),
                R.layout.item_address, parent, false);
    }

    @Override
    protected void onBindView(ItemAddressBinding binding, AddressListMode.DataBeanX.DataBean bean,
                              int position) {
        binding.tvName.setText(bean.consignee);
        binding.tvAddress.setText(bean.provinceText+bean.cityText+bean.districtText+bean.streetText+bean.address);
        binding.tvPhone.setText(bean.mobile);
        binding.rlRoot.setOnClickListener(v -> {
            if (onItemClickListener != null) {
                onItemClickListener.onItemClick(position, bean);
            }
        });
        if (bean.tolerant==0){
            binding.tvDefault.setVisibility(View.VISIBLE);
        }else {
            binding.tvDefault.setVisibility(View.GONE);
        }
    }

}
