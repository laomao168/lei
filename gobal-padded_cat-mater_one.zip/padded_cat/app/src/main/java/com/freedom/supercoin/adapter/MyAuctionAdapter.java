package com.freedom.supercoin.adapter;

import android.databinding.DataBindingUtil;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.freedom.supercoin.R;
import com.freedom.supercoin.base_library.base.BaseEmptyAdapter;
import com.freedom.supercoin.base_library.utils.GlideUtils;
import com.freedom.supercoin.base_library.utils.StrUtils;
import com.freedom.supercoin.databinding.ItemMyAuctionBinding;
import com.freedom.supercoin.databinding.ItemOrderBinding;
import com.freedom.supercoin.mode.MyAuctionMode;
import com.freedom.supercoin.mode.OrderMode;


public class MyAuctionAdapter extends BaseEmptyAdapter<MyAuctionMode.DataBeanX.DataBean,
        ItemMyAuctionBinding> {

    @Override
    protected ItemMyAuctionBinding createBinding(ViewGroup parent) {
        return DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()),
                R.layout.item_my_auction, parent, false);
    }

    @Override
    protected void onBindView(ItemMyAuctionBinding binding, MyAuctionMode.DataBeanX.DataBean bean,
                              int position) {
        binding.tvTime.setText(bean.createTime);
        binding.tvPrice.setText(StrUtils.getRemoveZreoNum(bean.topPrice));
        GlideUtils.loadRound(context,bean.logo,binding.ivGoodsImage,20);
        binding.tvGoodsName.setText(bean.goodsName);
        binding.rlRoot.setOnClickListener(v -> {
            if (onItemClickListener!=null){
                onItemClickListener.onItemClick(position,bean);
            }
        });

    }

    public interface OnItemClickListener {
        void onItemClick(int position, MyAuctionMode.DataBeanX.DataBean bean);

    }

    public OnItemClickListener onItemClickListener;

    public void setOnItemListener(OnItemClickListener onItemClickListener) {

        this.onItemClickListener = onItemClickListener;
    }
}
