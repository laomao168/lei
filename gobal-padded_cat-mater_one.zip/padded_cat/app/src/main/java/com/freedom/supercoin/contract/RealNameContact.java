package com.freedom.supercoin.contract;


import com.freedom.supercoin.base_library.base.BasePresenter;
import com.freedom.supercoin.base_library.base.BaseView;
import com.freedom.supercoin.mode.RealNameMode;


public class RealNameContact {

    public interface View extends BaseView {

        void onSubSuccess(RealNameMode mode);
    }


    public interface Presenter extends BasePresenter {
        void toIdentity(String bankName, String bank, String bankCard, String userName, String alipay, String idCard);
    }
}

