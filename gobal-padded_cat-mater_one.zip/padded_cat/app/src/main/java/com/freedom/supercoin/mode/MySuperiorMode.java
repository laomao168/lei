package com.freedom.supercoin.mode;

import java.util.List;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2020/1/5.
 * @desc :
 */
public class MySuperiorMode {

    /**
     * accountDetailType : null
     * alipay :
     * amount : null
     * applyed : false
     * avatar : https://thirdwx.qlogo
     * .cn/mmopen/vi_32
     * /PiajxSqBRaEJwSsiaAOEn3st4EqesDOhiajLJbynkDJGOn9LibQvjE7dTRA3zSwTBh8DKfWRZ6Ezj6dqmna8N72PlQ/132
     * backDeposit : null
     * beginTime :
     * birthday : null
     * blacklist : 0
     * cardNo :
     * channelId :
     * chargeMoney : null
     * clicked : false
     * createBy :
     * createIp :
     * createTime : 2019-11-16 16:54:18
     * deleted : 0
     * desc : desc
     * deviceCode :
     * deviceType :
     * directNum : null
     * endTime : null
     * failMoney : null
     * fanNums : null
     * gender : 0
     * indirectNum : null
     * inhibited : 0
     * integralAmount : null
     * integralDetailType : null
     * invitationCode : K40630
     * isEarnings : null
     * isSendMsg : null
     * lastLoginIp :
     * lastLoginTime : 2019-11-16 16:54:19
     * lockAmount : null
     * money : null
     * name :
     * newPeople : null
     * nickname : 请叫我女王大人
     * openid : oQr774lBj1rMOCSCHDBfAA6Ql5f4
     * orderField :
     * orderMoney : null
     * outWithdraw : null
     * overTime :
     * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,"pageStr":"",
     * "totalPage":0,"totalResult":0}
     * params : null
     * parentId : 285
     * parentIdList : []
     * parentInvitationCode :
     * parentNickname :
     * parentTime : 2019-11-16 16:54:19
     * partnerIncome : null
     * password :
     * payPassword : 41a70905850724192fa21520114d7b010431456d8457769d
     * phone : 13501287653
     * positMoney : null
     * qrcodeUrl :
     * remark :
     * searchValue :
     * secondInviterId : 231
     * sjnickname :
     * smsCode :
     * startTime : null
     * status : 0
     * token :
     * totalIncome : null
     * tradeType : null
     * type : 0
     * unionid :
     * updateBy : 336
     * updateInviteCode : 1
     * updateTime : null
     * userId : 336
     * username : X一只柚子B?.
     * verifyCode :
     */

    public Object accountDetailType;
    public String alipay;
    public Object amount;
    public boolean applyed;
    public String avatar;
    public Object backDeposit;
    public String beginTime;
    public Object birthday;
    public int blacklist;
    public String cardNo;
    public String channelId;
    public Object chargeMoney;
    public boolean clicked;
    public String createBy;
    public String createIp;
    public String createTime;
    public int deleted;
    public String desc;
    public String deviceCode;
    public String deviceType;
    public Object directNum;
    public Object endTime;
    public Object failMoney;
    public Object fanNums;
    public int gender;
    public Object indirectNum;
    public int inhibited;
    public Object integralAmount;
    public Object integralDetailType;
    public String invitationCode;
    public Object isEarnings;
    public Object isSendMsg;
    public String lastLoginIp;
    public String lastLoginTime;
    public Object lockAmount;
    public Object money;
    public String name;
    public Object newPeople;
    public String nickname;
    public String openid;
    public String orderField;
    public Object orderMoney;
    public Object outWithdraw;
    public String overTime;
    public PageBean page;
    public Object params;
    public int parentId;
    public String parentInvitationCode;
    public String parentNickname;
    public String parentTime;
    public Object partnerIncome;
    public String password;
    public String payPassword;
    public String phone;
    public Object positMoney;
    public String qrcodeUrl;
    public String remark;
    public String searchValue;
    public int secondInviterId;
    public String sjnickname;
    public String smsCode;
    public Object startTime;
    public int status;
    public String token;
    public Object totalIncome;
    public Object tradeType;
    public int type;
    public String unionid;
    public String updateBy;
    public int updateInviteCode;
    public Object updateTime;
    public int userId;
    public String username;
    public String verifyCode;
    public List<?> parentIdList;

    public static class PageBean {
        /**
         * currentResult : 0
         * entityOrField : false
         * pageNumber : 1
         * pageSize : 10
         * pageStr :
         * totalPage : 0
         * totalResult : 0
         */

        public int currentResult;
        public boolean entityOrField;
        public int pageNumber;
        public int pageSize;
        public String pageStr;
        public int totalPage;
        public int totalResult;
    }
}
