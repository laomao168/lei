package com.freedom.supercoin.mode;

public class InviteFriendMode {

    /**
     * code : 0
     * count : null
     * data : https://images.oneauct.com/dd431102d9794305b952ebd97561c890
     * error : false
     * msg : 生成成功！
     * result : true
     * success : true
     */

    public String code;
    public Object count;
    public String data;
    public boolean error;
    public String msg;
    public boolean result;
    public boolean success;
}
