package com.freedom.supercoin.persenter;

import com.freedom.supercoin.contract.SecurityContact;
import com.freedom.supercoin.mode.CheckPwdMode;
import com.freedom.supercoin.mode.CheckRealNameMode;
import com.freedom.supercoin.network.DataManager;
import com.freedom.supercoin.network.ResponseErrorFunc;
import com.freedom.supercoin.network.RxUtils;

import rx.Subscriber;


public class SecurityPresenter implements SecurityContact.Presenter {

    private final SecurityContact.View view;

    public SecurityPresenter(SecurityContact.View view) {
        this.view = view;
    }

    @Override
    public void checkPwd() {
        DataManager.getInstance()
                .checkPwd()
                .compose(RxUtils.applyIOSchedulers())
//                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<CheckPwdMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(CheckPwdMode mode) {
                        view.getCheckPwdSuccess(mode);
                        view.hideProgress();
                    }
                });
    }
    @Override
    public void checkRealName() {
        DataManager.getInstance()
                .checkRealName()
                .compose(RxUtils.applyIOSchedulers())
//                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<CheckRealNameMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(CheckRealNameMode mode) {
                        view.getRealNameSuccess(mode);
                        view.hideProgress();
                    }
                });

    }
}
