package com.freedom.supercoin.contract;


import com.freedom.supercoin.base_library.base.BasePresenter;
import com.freedom.supercoin.base_library.base.BaseView;
import com.freedom.supercoin.mode.BalanceListMode;


public class BalanceDetailContact {

    public interface View extends BaseView {

        void getBalanceListSuccess(BalanceListMode mode);
    }


    public interface Presenter extends BasePresenter {
        void getBalanceDetail(int pageNumber);
    }
}

