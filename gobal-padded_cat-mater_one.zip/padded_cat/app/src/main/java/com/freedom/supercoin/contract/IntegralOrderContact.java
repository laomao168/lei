package com.freedom.supercoin.contract;


import com.freedom.supercoin.base_library.base.BasePresenter;
import com.freedom.supercoin.base_library.base.BaseView;
import com.freedom.supercoin.mode.IntegralOrderMode;


public class IntegralOrderContact {

    public interface View extends BaseView {

        void getOrderListSuccess(IntegralOrderMode mode);
    }


    public interface Presenter extends BasePresenter {

        void getOrderList(int currentIndex, int index,int goodsType);
    }
}

