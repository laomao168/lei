package com.freedom.supercoin.mode;

import java.util.List;

public class HomeBannerMode {

    /**
     * applyed : false
     * bannerType : 1
     * channelId :
     * clicked : false
     * content :
     * createBy :
     * createTime : 2019-11-19 02:58:14
     * deleted : 0
     * desc : desc
     * deviceCode :
     * deviceType :
     * endTime : null
     * id : 26
     * image : https://images.fmallnet.com/bbcb4b08d50a40cbbda3865a1943b4f6
     * linkId : 1016
     * name : 新手福利
     * orderField :
     * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,
     * "pageStr":"","totalPage":0,"totalResult":0}
     * params : null
     * remark :
     * searchValue :
     * sort : 2
     * startTime : null
     * status : 0
     * themeImage :
     * type : 3
     * updateBy :
     * updateTime : 2019-11-29 21:29:03
     * validity : 1
     */

    public boolean applyed;
    public int bannerType;
    public String channelId;
    public boolean clicked;
    public String content;
    public String createBy;
    public String createTime;
    public int deleted;
    public String desc;
    public String deviceCode;
    public String deviceType;
    public Object endTime;
    public int id;
    public String image;
    public String linkId;
    public String name;
    public String orderField;
    public PageBean page;
    public Object params;
    public String remark;
    public String searchValue;
    public int sort;
    public Object startTime;
    public int status;
    public String themeImage;
    public int type;
    public String updateBy;
    public String updateTime;
    public int validity;

    public static class PageBean {
        /**
         * currentResult : 0
         * entityOrField : false
         * pageNumber : 1
         * pageSize : 10
         * pageStr :
         * totalPage : 0
         * totalResult : 0
         */

        public int currentResult;
        public boolean entityOrField;
        public int pageNumber;
        public int pageSize;
        public String pageStr;
        public int totalPage;
        public int totalResult;
    }

}
