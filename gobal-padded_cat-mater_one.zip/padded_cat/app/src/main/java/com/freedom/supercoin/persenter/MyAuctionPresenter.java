package com.freedom.supercoin.persenter;

import com.freedom.supercoin.contract.MyAuctionContact;
import com.freedom.supercoin.mode.MyAuctionMode;
import com.freedom.supercoin.network.DataManager;
import com.freedom.supercoin.network.ResponseErrorFunc;
import com.freedom.supercoin.network.RxUtils;

import rx.Subscriber;


public class MyAuctionPresenter implements MyAuctionContact.Presenter {

    private final MyAuctionContact.View view;

    public MyAuctionPresenter(MyAuctionContact.View view) {
        this.view = view;
    }

    @Override
    public void getMyAuctionList() {
        DataManager.getInstance()
                .getMyAuctionList()
                .compose(RxUtils.applyIOSchedulers())
//                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<MyAuctionMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(MyAuctionMode myAuctionMode) {
                        view.onLoadMyAuctionSuccess(myAuctionMode);
                        view.hideProgress();
                    }
                });

    }


}
