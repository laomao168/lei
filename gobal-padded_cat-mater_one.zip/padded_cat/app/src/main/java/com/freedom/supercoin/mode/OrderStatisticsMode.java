package com.freedom.supercoin.mode;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2020/1/5.
 * @desc :
 */
public class OrderStatisticsMode {

    /**
     * waitReceivingGoods : 0
     * waitDeliverGoods : 0
     * waitPay : 2
     */

    public int waitReceivingGoods;
    public int waitDeliverGoods;
    public int waitPay;
}
