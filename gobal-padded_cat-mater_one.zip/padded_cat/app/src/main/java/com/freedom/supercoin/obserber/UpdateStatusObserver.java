package com.freedom.supercoin.obserber;


import java.util.ArrayList;

/**
 * Created by ljp on 2018/5/15.
 */

public class UpdateStatusObserver {


    private static UpdateStatusObserver mIntance;

    private UpdateStatusObserver() {
    }

    public static UpdateStatusObserver getIntance() {
        if (mIntance == null) {
            mIntance = new UpdateStatusObserver();
        }
        return mIntance;
    }


    private final Object object = new Object();

    protected final ArrayList<ObserverUpdateStatus> mObservers = new ArrayList<>();

    public void notifyChanged(boolean status) {
        synchronized (object) {
            for (ObserverUpdateStatus observer : mObservers) {
                observer.notifyPayState(status);
            }
        }
    }
    public void notifyChangedProgress(float v) {
        synchronized (object) {
            for (ObserverUpdateStatus observer : mObservers) {
                observer.notifyChangedProgress(v);
            }
        }
    }
    public void unregisterObserver(ObserverUpdateStatus observer) {
        if (observer == null) {
            return;
        }
        synchronized (object) {
            int index = mObservers.indexOf(observer);
            if (index == -1) {
                return;
            }
            mObservers.remove(index);
        }
    }

    public void registerObserver(ObserverUpdateStatus observer) {
        if (observer == null) {
            throw new IllegalArgumentException("The observer is null.");
        }
        synchronized (object) {
            if (mObservers.contains(observer)) {
                return;
            }
            mObservers.add(observer);
        }
    }


}
