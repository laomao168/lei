package com.freedom.supercoin.persenter;

import com.freedom.supercoin.contract.AddressDetailContact;
import com.freedom.supercoin.mode.AddAddressMode;
import com.freedom.supercoin.mode.StreetMode;
import com.freedom.supercoin.mode.entity.AddressBean;
import com.freedom.supercoin.network.DataManager;
import com.freedom.supercoin.network.ResponseErrorFunc;
import com.freedom.supercoin.network.RxUtils;

import java.util.List;

import rx.Subscriber;


public class AddressDetailPresenter implements AddressDetailContact.Presenter {

    private final AddressDetailContact.View view;

    public AddressDetailPresenter(AddressDetailContact.View view) {
        this.view = view;
    }


    @Override
    public void addAddress(AddressBean bean) {
        DataManager.getInstance()
                .addAddress(bean)
                .compose(RxUtils.applyIOSchedulers())
//                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<AddAddressMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(AddAddressMode mode) {
                        view.hideProgress();
                        view.showMessage(mode.msg);
                        if (mode.success) {
                            view.onSuccess();
                        }

                    }
                });
    }

    @Override
    public void editAddress(AddressBean bean) {
        DataManager.getInstance()
                .editAddress(bean)
                .compose(RxUtils.applyIOSchedulers())
//                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<AddAddressMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(AddAddressMode mode) {
                        view.hideProgress();
                        view.showMessage(mode.msg);
                        if (mode.success) {
                            view.onSuccess();
                        }
                    }
                });
    }

    @Override
    public void getAllAddressList(int parentId, int type) {
        DataManager.getInstance()
                .getAllList(parentId)
                .compose(RxUtils.applyIOSchedulers())
                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<List<StreetMode>>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(List<StreetMode> list) {
                        view.onLoadStreetModeSuccess(list, type);
                        view.hideProgress();
                    }
                });
    }
}
