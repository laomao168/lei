package com.freedom.supercoin.adapter;

import android.databinding.DataBindingUtil;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.freedom.supercoin.R;
import com.freedom.supercoin.base_library.base.BaseEmptyAdapter;
import com.freedom.supercoin.base_library.utils.GlideUtils;
import com.freedom.supercoin.databinding.ItemIntegralGoodsBinding;
import com.freedom.supercoin.mode.IntegralFragmentMode;


public class IntegralGoodsAdapter extends BaseEmptyAdapter<IntegralFragmentMode.DataBeanX.DataBean,
        ItemIntegralGoodsBinding> {


    @Override
    protected ItemIntegralGoodsBinding createBinding(ViewGroup parent) {
        return DataBindingUtil.inflate(LayoutInflater.from(context),
                R.layout.item_integral_goods, parent, false);
    }

    @Override
    protected void onBindView(ItemIntegralGoodsBinding binding, IntegralFragmentMode.DataBeanX.DataBean bean,
                              int position) {
        GlideUtils.loadImage(context,bean.logo.trim(),binding.ivImage);
        binding.tvGoodsName.setText(bean.goodsName);
        String totalPrice;
        if (bean.priceType==1){
            totalPrice=bean.integral+"积分";
        }else if (bean.priceType==2){
            totalPrice=bean.integral+" 积分+¥ "+bean.price;
        }else {
            totalPrice="¥ "+bean.price;
        }
        binding.tvGoodsPrice.setText(totalPrice);
        binding.root.setOnClickListener(v -> {
            if (onItemClickListener!=null){
                onItemClickListener.onItemClick(position,bean);
            }
        });
    }

}
