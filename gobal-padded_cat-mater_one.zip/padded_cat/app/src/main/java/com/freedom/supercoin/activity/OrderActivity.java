package com.freedom.supercoin.activity;

import android.content.res.Resources;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;
import android.util.TypedValue;
import android.view.View;
import android.widget.LinearLayout;

import com.freedom.supercoin.R;
import com.freedom.supercoin.common.UiActivity;
import com.freedom.supercoin.databinding.ActivityOrderBinding;
import com.freedom.supercoin.fragment.OrderFragment;

import java.lang.reflect.Field;
import java.util.ArrayList;

/**
 * @author : lijianping
 * @date : Created on 2019/7/11.
 * des:
 */
public class OrderActivity extends UiActivity<ActivityOrderBinding> {
    private ArrayList<Fragment> fragments;
    private String tabTitles[] = new String[]{"全部", "待付款", "待发货", "待收货", "已完成",};
    private FragmentPagerAdapter pagerAdapter;
    private int index;

    @Override
    protected int layoutResId() {
        return R.layout.activity_order;
    }

    @Override
    protected void initData() {
        binding.titleBar.setTextColor("#ffffff");
        binding.titleBar.setLeftImage(R.mipmap.ic_back_white);
        binding.titleBar.setTitle("我的订单");
        fragments = new ArrayList<>();
        index = getIntent().getIntExtra(OrderFragment.INDEX, 0);
        initTabs();
        // 修改tablayout的下划线宽度
        //我们在这里对TabLayout的宽度进行修改。。数值越大表示宽度越小。
//        binding.tabs.post(() -> setIndicator(binding.tabs, 44, 44));
        binding.viewpager.setCurrentItem(index);
    }

    private void initTabs() {
        fragments.clear();
        binding.tabs.removeAllTabs();

        for (int i = 0; i < tabTitles.length; i++) {
            TabLayout.Tab tab = binding.tabs.newTab()
                    .setText(tabTitles[i]);
            binding.tabs.addTab(tab);
            fragments.add(OrderFragment.newInstance(i));
        }
        pagerAdapter = new FragmentPagerAdapter(getSupportFragmentManager()) {
            @Override
            public Fragment getItem(int position) {
                return fragments.get(position);
            }


            @Override
            public int getCount() {
                return fragments.size();
            }

            @Nullable
            @Override
            public CharSequence getPageTitle(int position) {
                return tabTitles[position];
            }
        };
        binding.viewpager.setAdapter(pagerAdapter);
        binding.viewpager.setCurrentItem(0, false);
        binding.viewpager.setOffscreenPageLimit(fragments.size());
        binding.tabs.setupWithViewPager(binding.viewpager);
    }

    @Override
    protected void initEvent() {

    }

    /**
     * 设置tablayout的宽度
     *
     * @param tabs     tab控件
     * @param leftDip  左边距
     * @param rightDip 右边距
     */
    public void setIndicator(TabLayout tabs, int leftDip, int rightDip) {
        Class<?> tabLayout = tabs.getClass();
        Field tabStrip = null;
        try {
            tabStrip = tabLayout.getDeclaredField("slidingTabIndicator");
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        }

        tabStrip.setAccessible(true);
        LinearLayout llTab = null;
        try {
            llTab = (LinearLayout) tabStrip.get(tabs);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }

        int left = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, leftDip,
                Resources.getSystem().getDisplayMetrics());
        int right = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, rightDip,
                Resources.getSystem().getDisplayMetrics());

        for (int i = 0; i < llTab.getChildCount(); i++) {
            View child = llTab.getChildAt(i);
            child.setPadding(0, 0, 0, 0);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.MATCH_PARENT, 1);
            params.leftMargin = left;
            params.rightMargin = right;
            child.setLayoutParams(params);
            child.invalidate();
        }
    }

}
