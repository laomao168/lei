package com.freedom.supercoin.adapter;

import android.databinding.DataBindingUtil;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.freedom.supercoin.R;
import com.freedom.supercoin.base_library.base.BaseEmptyAdapter;
import com.freedom.supercoin.base_library.utils.GlideUtils;
import com.freedom.supercoin.base_library.utils.StrUtils;
import com.freedom.supercoin.databinding.ItemOrderBinding;
import com.freedom.supercoin.mode.IntegralOrderMode;


public class IntegralOrderAdapter extends BaseEmptyAdapter<IntegralOrderMode.DataBeanX.DataBean,
        ItemOrderBinding> {

    private int goodsType;

    @Override
    protected ItemOrderBinding createBinding(ViewGroup parent) {
        return DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()),
                R.layout.item_order, parent, false);
    }

    @Override
    protected void onBindView(ItemOrderBinding binding, IntegralOrderMode.DataBeanX.DataBean bean,
                              int position) {
        binding.tvTime.setText(bean.createTime);
        binding.tvGoodsName.setText(bean.goodsName);
//        订单状态 0待付款1待发货2待收货3交易完成4交易失败
//        1待接拍，2.寄拍中，3.寄拍成功，4.寄拍失败，5.拒绝
        if (goodsType == 1) {
            binding.tvPay.setVisibility(View.GONE);
            switch (bean.orderStatus) {
                case 0:
                    binding.tvPay.setVisibility(View.VISIBLE);
                    binding.tvPay.setText("立即付款");
                    binding.tvStatus.setText("代付款");
                    break;
                case 1:
                    binding.tvStatus.setText("待处理");
                    binding.tvPay.setVisibility(View.VISIBLE);
                    if (bean.contract != 0) {
                        binding.tvPay.setText("查看合同");
                    } else {
                        binding.tvPay.setText("签署合同");
                    }
                    break;
                case 2:
                    binding.tvStatus.setText("寄拍中");
                    binding.tvPay.setVisibility(View.VISIBLE);
                    binding.tvPay.setText("查看合同");
                    break;
                case 3:
                    binding.tvStatus.setText("寄拍成功");
                    binding.tvPay.setVisibility(View.VISIBLE);
                    binding.tvPay.setText("查看合同");
                    break;
                case 4:
                    binding.tvStatus.setText("寄拍失败");
                    break;
                case 5:
                    binding.tvStatus.setText("拒绝");
                    break;
            }
        } else {
            switch (bean.orderStatus) {
                case 0:
                    binding.tvStatus.setText("待付款");
                    binding.tvPay.setVisibility(View.VISIBLE);
                    binding.tvPay.setText("立即付款");

                    break;
                case 1:
                    binding.tvStatus.setText("待发货");
                    binding.tvPay.setVisibility(View.GONE);
                    binding.tvToDetail.setVisibility(View.GONE);
                    break;
                case 2:
                    binding.tvStatus.setText("待收货");
                    binding.tvPay.setVisibility(View.VISIBLE);
                    binding.tvPay.setText("确认收货");
                    break;
                case 3:
                    binding.tvStatus.setText("交易完成");
                    binding.tvPay.setVisibility(View.GONE);
                    break;
                case 4:
                    binding.tvStatus.setText("交易失败");
                    binding.tvPay.setVisibility(View.GONE);
                    break;
            }
        }

        GlideUtils.loadImage(context, bean.logo.trim(), binding.ivGoodsImage);
        if (bean.priceType == 1) {
            binding.tvPrice.setText(StrUtils.getRemoveZreoNum(bean.integral) + " 积分");
        } else if (bean.priceType == 2) {
            binding.tvPrice.setText(StrUtils.getRemoveZreoNum(bean.integral) + " 积分+" + " ¥" + StrUtils.getRemoveZreoNum(bean.price));
        } else {
            binding.tvPrice.setText(" ¥" + StrUtils.getRemoveZreoNum(bean.price));
        }
        binding.setClick(v ->

        {
            switch (v.getId()) {
                case R.id.tv_to_detail:
                    if (onItemClickListener != null) {
                        onItemClickListener.onItemDetailClick(position, bean);
                    }
                    break;
                case R.id.tv_pay:

                    if (onItemClickListener != null) {
                        if (goodsType == 1){
                            if (bean.orderStatus==0){
                                onItemClickListener.onItemPayClick(position, bean);
                            }else {
                                onItemClickListener.onItemContractClick(position, bean);
                            }
                        }else {
                            onItemClickListener.onItemPayClick(position, bean);
                        }
                    }
                    break;

            }
        });
    }

    public void setGoodsType(int goodsType) {

        this.goodsType = goodsType;
    }

    public interface OnItemClickListener {
        void onItemDetailClick(int position, IntegralOrderMode.DataBeanX.DataBean bean);

        void onItemPayClick(int position, IntegralOrderMode.DataBeanX.DataBean bean);

        void onItemContractClick(int position, IntegralOrderMode.DataBeanX.DataBean bean);

    }

    public OnItemClickListener onItemClickListener;

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {

        this.onItemClickListener = onItemClickListener;
    }
}
