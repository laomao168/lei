package com.freedom.supercoin.persenter;

import com.freedom.supercoin.contract.IntegralPresenterContact;
import com.freedom.supercoin.mode.IntegralMode;
import com.freedom.supercoin.network.DataManager;
import com.freedom.supercoin.network.ResponseErrorFunc;
import com.freedom.supercoin.network.RxUtils;

import rx.Subscriber;


public class IntegralPresenter implements IntegralPresenterContact.Presenter {

    private final IntegralPresenterContact.View view;

    public IntegralPresenter(IntegralPresenterContact.View view) {
        this.view = view;
    }

    @Override
    public void getIntegralList() {
        DataManager.getInstance()
                .getIntegralList()
                .compose(RxUtils.applyIOSchedulers())
//                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<IntegralMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(IntegralMode mode) {
                        view.hideProgress();
                        view.getIntegralSuccess(mode);
                    }
                });
    }



}
