package com.freedom.supercoin.contract;


import com.freedom.supercoin.base_library.base.BasePresenter;
import com.freedom.supercoin.base_library.base.BaseView;
import com.freedom.supercoin.mode.UpdateMode;


public class MainActivityContact {

    public interface View extends BaseView {

        void onLoadUpdateInfoSuccess(UpdateMode mode);
    }


    public interface Presenter extends BasePresenter {
        void CheckUpdate();
    }
}

