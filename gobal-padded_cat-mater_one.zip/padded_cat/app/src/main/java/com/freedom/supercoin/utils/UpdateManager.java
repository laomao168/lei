package com.freedom.supercoin.utils;

import android.content.Context;

import java.io.File;

/**
 * Created by ljp on 2018/4/8.
 * 更新相关
 */

public class UpdateManager {

    private static UpdateManager updateManager;

    private UpdateManager() {
    }

    public static UpdateManager getInstance() {
        if (updateManager == null) {
            updateManager = new UpdateManager();
        }
        return updateManager;
    }






    /**
     * 对比版本号
     *
     * @param version
     */
    public  boolean checkVersion(int version, Context context) {
        if (version > AppUtil.getAppVersionCode(context)) {
            return true;
        } else {
            return false;
        }
    }
    public  void deleteFile(File file) {
        if (file.isDirectory()) {
            File[] files = file.listFiles();
            for (int i = 0; i < files.length; i++) {
                File f = files[i];
                deleteFile(f);
            }
//            file.delete();//如要保留文件夹，只删除文件，请注释这行
        } else if (file.exists()) {
            file.delete();
        }};

}
