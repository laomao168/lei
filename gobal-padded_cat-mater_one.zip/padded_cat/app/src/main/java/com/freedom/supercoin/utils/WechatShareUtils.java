package com.freedom.supercoin.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;

import com.freedom.supercoin.R;
import com.freedom.supercoin.base_library.utils.LogUtils;
import com.freedom.supercoin.mode.entity.ShareInfo;
import com.tencent.mm.opensdk.modelmsg.SendMessageToWX;
import com.tencent.mm.opensdk.modelmsg.WXImageObject;
import com.tencent.mm.opensdk.modelmsg.WXMediaMessage;
import com.tencent.mm.opensdk.modelmsg.WXWebpageObject;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URL;

/**
 * Created by ljp on 2018/5/23.
 */

public class WechatShareUtils {
    public static String WXCHATAPPID = "wx66b75f6e5ea97bac";
    /**
     * 会话 界面
     */
    public static final int WEIXIN_SHARE_TYPE_TALK = SendMessageToWX.Req.WXSceneSession;
    /**
     * 朋友圈
     */
    public static final int WEIXIN_SHARE_TYPE_FRENDS = SendMessageToWX.Req.WXSceneTimeline;

    private static WechatShareUtils instance;
    private IWXAPI iwxapi;

    private WechatShareUtils() {
    }

    public static WechatShareUtils getInstance() {
        if (instance == null) {
            instance = new WechatShareUtils();
        }
        return instance;
    }

    /**
     * @param shareInfoResponse
     * @param shareType
     */
    public void share(Context context, final ShareInfo shareInfoResponse, final int shareType) {
        iwxapi = WXAPIFactory.createWXAPI(context, null); //初始化微信api
        iwxapi.registerApp(WXCHATAPPID);//注册appid  appid可以在开发平台获取

        WXWebpageObject webpage = new WXWebpageObject();
        webpage.webpageUrl = shareInfoResponse.share_url;
        final WXMediaMessage msg = new WXMediaMessage(webpage);
        msg.title = shareInfoResponse.share_title;
        msg.description = shareInfoResponse.share_desc;
        new Thread(() -> {
            Bitmap bitmap = BitmapFactory.decodeResource(context.getResources(), R.mipmap
                    .ic_launcher);
            LogUtils.ShowD("share url ", shareInfoResponse.share_pic);
            byte[] bytes = bmpToByteArray(bitmap, true);
            if (bytes == null) return;
            msg.thumbData = bytes;
            SendMessageToWX.Req req = new SendMessageToWX.Req();
            req.transaction = buildTransaction("webpage");
            req.message = msg;
            //朋友圈还是 发送到聊天界面
            req.scene = shareType;
            iwxapi.sendReq(req);
        }).start();
    }

    /**
     * 分享图片
     *
     * @param shareType
     */
    public void shareImage(Context context, Bitmap bitmap, final int shareType) {
        try {

            iwxapi = WXAPIFactory.createWXAPI(context, null); //初始化微信api
            iwxapi.registerApp(WXCHATAPPID);//注册appid  appid可以在开发平台获取

            WXImageObject imgObj = new WXImageObject(bitmap);
            WXMediaMessage msg = new WXMediaMessage();
//                    imgObj.setImagePath(path);
            msg.mediaObject = imgObj;
            //设置缩略图
            Bitmap thumbBmp = Bitmap.createScaledBitmap(bitmap, 200, 170, true);
            byte[] bytes = bmpToByteArray(thumbBmp, true);
            if (bytes == null) return;
            msg.thumbData = bytes;

            SendMessageToWX.Req req = new SendMessageToWX.Req();
            req.transaction = buildTransaction("img");
            req.message = msg;
            //朋友圈还是 发送到聊天界面
            req.scene = shareType;
            iwxapi.sendReq(req);
            bitmap.recycle();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 分享图片
     *
     * @param shareInfoResponse
     * @param shareType
     */
    public void shareImage(Context context, final ShareInfo shareInfoResponse,
                           final int shareType) {
        iwxapi = WXAPIFactory.createWXAPI(context, null); //初始化微信api
        iwxapi.registerApp(WXCHATAPPID);//注册appid  appid可以在开发平台获取
        new Thread(() -> {
            try {
                Bitmap thumb =
                        BitmapFactory.decodeStream(new URL(shareInfoResponse.share_pic).openStream());
                //注意下面的这句压缩，120，150是长宽。
                // 一定要压缩，不然会分享失败
                Bitmap thumbBmp = Bitmap.createScaledBitmap(thumb, 200, 170, true);
//            Bitmap回收

                WXImageObject imgObj = new WXImageObject(thumb);
                WXMediaMessage msg = new WXMediaMessage();
//                    imgObj.setImagePath(path);
                msg.mediaObject = imgObj;
                //设置缩略图
                byte[] bytes = bmpToByteArray(thumbBmp, true);
                if (bytes == null) return;
                msg.thumbData = bytes;

                SendMessageToWX.Req req = new SendMessageToWX.Req();
                req.transaction = buildTransaction("img");
                req.message = msg;
                //朋友圈还是 发送到聊天界面
                req.scene = shareType;
                iwxapi.sendReq(req);
                thumb.recycle();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();
    }


    private byte[] bmpToByteArray(final Bitmap bmp, final boolean needRecycle) {
        int i;
        int j;
        if (bmp.getHeight() > bmp.getWidth()) {
            i = bmp.getWidth();
            j = bmp.getWidth();
        } else {
            i = bmp.getHeight();
            j = bmp.getHeight();
        }

        Bitmap localBitmap = Bitmap.createBitmap(i, j, Bitmap.Config.RGB_565);
        Canvas localCanvas = new Canvas(localBitmap);

        while (true) {
            localCanvas.drawBitmap(bmp, new Rect(0, 0, i, j), new Rect(0, 0, i,
                    j), null);
            if (needRecycle)
                bmp.recycle();
            ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
            localBitmap.compress(Bitmap.CompressFormat.JPEG, 100,
                    localByteArrayOutputStream);
            localBitmap.recycle();
            byte[] arrayOfByte = localByteArrayOutputStream.toByteArray();
            try {
                localByteArrayOutputStream.close();
                return arrayOfByte;
            } catch (Exception e) {
                // F.out(e);
                return null;
            }
        }

    }

    private String buildTransaction(final String type) {
        return (type == null) ? String.valueOf(System.currentTimeMillis()) : type + System
                .currentTimeMillis();
    }
}
