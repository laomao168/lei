package com.freedom.supercoin.adapter;

import android.databinding.DataBindingUtil;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.freedom.supercoin.R;
import com.freedom.supercoin.base_library.base.BaseEmptyAdapter;
import com.freedom.supercoin.base_library.utils.GlideUtils;
import com.freedom.supercoin.base_library.utils.StrUtils;
import com.freedom.supercoin.databinding.ItemGoodsRankBinding;
import com.freedom.supercoin.mode.GoodsRankListMode;


public class GoodsRankAdapter extends BaseEmptyAdapter<GoodsRankListMode, ItemGoodsRankBinding> {
    @Override
    protected ItemGoodsRankBinding createBinding(ViewGroup parent) {
        return DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()),
                R.layout.item_goods_rank, parent, false);
    }

    @Override
    protected void onBindView(ItemGoodsRankBinding binding,
                              GoodsRankListMode bean, int position) {
        GlideUtils.loadImage(context,bean.avatar,binding.ivUserImage,R.mipmap.img_goodsdetails_head2);
        binding.tvNikeName.setText(bean.userName);
        binding.tvOfferTimes.setText(bean.num+"");
        binding.tvProfit.setText(StrUtils.getRemoveZreoNum(bean.totalPrice));
    }
}
