package com.freedom.supercoin.activity;

import android.text.TextUtils;
import android.view.View;

import com.freedom.supercoin.R;
import com.freedom.supercoin.base_library.AppConst;
import com.freedom.supercoin.base_library.utils.SPUtils;
import com.freedom.supercoin.common.UiActivity;
import com.freedom.supercoin.contract.SecurityContact;
import com.freedom.supercoin.databinding.ActivityABinding;
import com.freedom.supercoin.databinding.ActivitySecurityBinding;
import com.freedom.supercoin.mode.CheckPwdMode;
import com.freedom.supercoin.mode.CheckRealNameMode;
import com.freedom.supercoin.persenter.SecurityPresenter;

/**
 * @author : lijianping
 * @date : Created on 2019/7/11.
 * des:
 */
public class SecurityActivity extends UiActivity<ActivitySecurityBinding> implements SecurityContact.View {

    private SecurityPresenter presenter;
    private boolean isSetPwd;
    private boolean isRealName;

    @Override
    protected int layoutResId() {
        return R.layout.activity_security;
    }

    @Override
    protected void initData() {
        binding.titleBar.setTextColor("#ffffff");
        binding.titleBar.setTitle("账户与安全");
        binding.titleBar.setLeftImage(R.mipmap.ic_back_white);
        presenter = new SecurityPresenter(this);
        isRealName=true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        presenter.checkPwd();
        presenter.checkRealName();
    }

    @Override
    protected void initEvent() {
        binding.setClick(v -> {
            switch (v.getId()) {
                case R.id.rl_real_name: //去实名
                if (!isRealName)getOperation().forward(RealNameActivity.class);
                    break;

                case R.id.rl_pay_pwd: //设置 /修改密码
                    getOperation().addParameter(AppConst.Keys.PHONE, SPUtils.getInstance().getString(AppConst.Keys.PHONE));
                    getOperation().forward(SetPwdActivity.class);
//                    if (isSetPwd) { //修改
//
//                    } else { //设置
//
//                    }
                    break;

            }
        });
    }

    @Override
    public void getCheckPwdSuccess(CheckPwdMode mode) {
        if (TextUtils.equals(mode.code, "0") || mode.success) {
            if (mode.data) {
                binding.tvPayPwdStatus.setText("修改");
                isSetPwd = true;
            }
        }
    }

    @Override
    public void getRealNameSuccess(CheckRealNameMode mode) {
        //{"code":"","count":null,"data":1,"error":false,"msg":"查询用户实名！","result":true,"success":true}
//        {"code":"","count":null,"data":null,"error":true,"msg":"用户还未实名！","result":false,"success":false}
        if (mode.success) {
            isRealName = true;
            binding.tvRealNameStatus.setText("已实名");
        } else {
            binding.tvRealNameStatus.setText("未认证");
            isRealName = false;
        }
    }
}
