package com.freedom.supercoin.activity;

import android.text.TextUtils;

import com.freedom.supercoin.R;
import com.freedom.supercoin.base_library.utils.StrUtils;
import com.freedom.supercoin.common.UiActivity;
import com.freedom.supercoin.contract.WithDrawContact;
import com.freedom.supercoin.databinding.ActivityWithDrawBinding;
import com.freedom.supercoin.dialog.FundDialog;
import com.freedom.supercoin.mode.BalanceDetailMode;
import com.freedom.supercoin.mode.WithDrawListMode;
import com.freedom.supercoin.mode.WithDrawMode;
import com.freedom.supercoin.persenter.WithDrawPresenter;
import com.freedom.supercoin.utils.RSAUtils;

/**
 * @author : lijianping
 * @date : Created on 2019/7/11.
 * des:
 */
public class WithDrawActivity extends UiActivity<ActivityWithDrawBinding> implements WithDrawContact.View {

    private WithDrawPresenter presenter;
    private double amount;
    private String money;

    @Override
    protected int layoutResId() {
        return R.layout.activity_with_draw;
    }

    @Override
    protected void initData() {
        presenter = new WithDrawPresenter(this);
        presenter.getBalance();
    }

    @Override
    protected void initEvent() {
        binding.setClick(v -> {
            switch (v.getId()) {
                case R.id.tv_with_draw:
                    checkAndDraw();
                    break;
                case R.id.iv_back:
                    finish();
                    break;
                case R.id.rl_to_charge_detail:
                    getOperation().forward(WithDrawDetailActivity.class);
                    break;
                case R.id.ll_balance:
                    binding.etAmount.setText(StrUtils.getRemoveZreoNum(amount));
                    break;

            }
        });
    }

    private void checkAndDraw() {
        money = binding.etAmount.getText().toString().trim();
        if (TextUtils.isEmpty(money)) {
            showMessage("请输入提现金额");
            return;
        }
        try {
            double v = Double.parseDouble(money);
            if (v > amount) {
                showMessage("提现金额不可大于可以余额");
                return;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }

        FundDialog fundDialog = new FundDialog();
        fundDialog.setOnDialogClickListener(pwd -> {
            presenter.WithDraw(RSAUtils.publicEncrypt(pwd), money);
            fundDialog.dismiss();
        });
        fundDialog.show(getSupportFragmentManager(), "");
    }

    @Override
    public void getBalanceSuccess(BalanceDetailMode mode) {
        amount = mode.amount;
        binding.tvBalance.setText("¥" + amount + "全部提现");
    }

    @Override
    public void onLoadWithDrawSuccess(WithDrawMode mode) {
        showMessage(mode.msg);
        finish();
    }

    @Override
    public void onLoadWithDrawSuccessList(WithDrawListMode mode) {

    }

    @Override
    public void onCancelDrawSuccess() {

    }
}
