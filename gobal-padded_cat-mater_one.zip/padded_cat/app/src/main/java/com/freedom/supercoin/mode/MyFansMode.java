package com.freedom.supercoin.mode;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2020/1/5.
 * @desc :
 */
public class MyFansMode {

    /**
     * amount : 18793.57
     * fanNums : 135
     * integralAmount : 32978
     * invitationCode : H16674
     * nickname : 豆豆
     * phone : 13807832530
     */

    public double amount;
    public int fanNums;
    public int integralAmount;
    public String invitationCode;
    public String nickname;
    public String phone;
}
