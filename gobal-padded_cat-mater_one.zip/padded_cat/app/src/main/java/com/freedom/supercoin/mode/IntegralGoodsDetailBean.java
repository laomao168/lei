package com.freedom.supercoin.mode;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2020/4/10.
 * @desc :
 */
public class IntegralGoodsDetailBean {

    /**
     * code : 0
     * count : null
     * data : {"applyed":false,"assessPrice":8000,"boutique":2,"categoryId":1,"categoryName":"",
     * "channelId":"","clicked":false,"content":"","costPrice":5800,"createBy":"admin",
     * "createTime":"2019-11-29 15:19:49","deleted":0,"desc":"desc","description":"Apple iPhone
     * 11 (A2223) 128GB 颜色可选","deviceCode":"","deviceType":"","eendTime":"","endTime":null,
     * "goodsDetail":"<p><span><\/span><\/p>\n<p><\/p>\n<p><br><\/p>\n<p><br><\/p>\n<p><br><\/p
     * >\n<p><span><strong>用户须知：<\/strong><\/span>本商品，每一位用户每1个月内仅可兑换1次（如多兑换，商场将不予退还哦）<\/p>\n<p
     * >用户委托本商场寄卖后，商品一旦寄卖成功，用户将直接收到9000RMB。如有疑问，可详情咨询团队长。或客服哦。<\/p>\n<p><img src=\"https://images
     * .fmallnet.com/0820e2fbac984195ae43fd50a82d0dc4\"><img src=\"https://images.fmallnet
     * .com/0803ad3b711b4b2ea6e21f9d517af44a\"><img src=\"https://images.fmallnet
     * .com/621f24b17d1a49b8b946f8031e84c4b2\"><img src=\"https://images.fmallnet
     * .com/dfadc925638343a1b2b34277be47babd\"><img src=\"https://images.fmallnet
     * .com/5f0b563af92940c989f273a820844595\"><img src=\"https://images.fmallnet
     * .com/6c92a0ebd24244968b5b93b952cd5501\"><img src=\"https://images.fmallnet
     * .com/0e478870b0f84a2292fda2fad9090300\"><img src=\"https://images.fmallnet
     * .com/c2b17db22ae2461b8112516a61f6e714\"><\/p>\n<p><br><\/p>\n<p><br><\/p>\n<p><br><\/p>\n
     * <p><br><\/p>\n<p><br><\/p>\n<p><span><\/span><br><\/p>","goodsId":179,"goodsName":"Apple
     * iPhone 11 (A2223) 128GB 颜色可选","goodsSubType":null,"goodsType":1,
     * "headImage":"[\"https://images.fmallnet.com/81f4a385971442be81dd5a0587534371\",
     * \"https://images.fmallnet.com/f2d1a83784374d6d8a5b1050955e684f\",\"https://images.fmallnet
     * .com/e9d9acfc00134ea8b74d172f1fe6921e\"]","integral":8000,"inventory":3,
     * "logo":"https://images.fmallnet.com/4e7aee2860cc4901bc1cfa30a881dfe6","orderField":"",
     * "page":{"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,"pageStr":"",
     * "totalPage":0,"totalResult":0},"params":null,"price":2000,"priceType":2,"remark":"",
     * "searchValue":"","soldNum":2,"sort":99999,"sstartTime":"","startTime":null,"status":2,
     * "supplier":"JD","supplierId":4,"updateBy":"cyz2019","updateTime":"2019-12-27 10:50:40",
     * "upperTime":null,"url5":"","url6":"","url7":"","url8":"","url9":""}
     * error : false
     * msg : 查询成功
     * result : true
     * success : true
     */

    public String code;
    public Object count;
    public DataBean data;
    public boolean error;
    public String msg;
    public boolean result;
    public boolean success;

    public static class DataBean {
        /**
         * applyed : false
         * assessPrice : 8000.0
         * boutique : 2
         * categoryId : 1
         * categoryName :
         * channelId :
         * clicked : false
         * content :
         * costPrice : 5800.0
         * createBy : admin
         * createTime : 2019-11-29 15:19:49
         * deleted : 0
         * desc : desc
         * description : Apple iPhone 11 (A2223) 128GB 颜色可选
         * deviceCode :
         * deviceType :
         * eendTime :
         * endTime : null
         * goodsDetail : <p><span></span></p>
         <p></p>
         <p><br></p>
         <p><br></p>
         <p><br></p>
         <p><span><strong>用户须知：</strong></span>本商品，每一位用户每1个月内仅可兑换1次（如多兑换，商场将不予退还哦）</p>
         <p>用户委托本商场寄卖后，商品一旦寄卖成功，用户将直接收到9000RMB。如有疑问，可详情咨询团队长。或客服哦。</p>
         <p><img src="https://images.fmallnet.com/0820e2fbac984195ae43fd50a82d0dc4"><img
         src="https://images.fmallnet.com/0803ad3b711b4b2ea6e21f9d517af44a"><img
         src="https://images.fmallnet.com/621f24b17d1a49b8b946f8031e84c4b2"><img
         src="https://images.fmallnet.com/dfadc925638343a1b2b34277be47babd"><img
         src="https://images.fmallnet.com/5f0b563af92940c989f273a820844595"><img
         src="https://images.fmallnet.com/6c92a0ebd24244968b5b93b952cd5501"><img
         src="https://images.fmallnet.com/0e478870b0f84a2292fda2fad9090300"><img
         src="https://images.fmallnet.com/c2b17db22ae2461b8112516a61f6e714"></p>
         <p><br></p>
         <p><br></p>
         <p><br></p>
         <p><br></p>
         <p><br></p>
         <p><span></span><br></p>
         * goodsId : 179
         * goodsName : Apple iPhone 11 (A2223) 128GB 颜色可选
         * goodsSubType : null
         * goodsType : 1
         * headImage : ["https://images.fmallnet.com/81f4a385971442be81dd5a0587534371",
         * "https://images.fmallnet.com/f2d1a83784374d6d8a5b1050955e684f","https://images
         * .fmallnet.com/e9d9acfc00134ea8b74d172f1fe6921e"]
         * integral : 8000.0
         * inventory : 3
         * logo : https://images.fmallnet.com/4e7aee2860cc4901bc1cfa30a881dfe6
         * orderField :
         * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,
         * "pageStr":"","totalPage":0,"totalResult":0}
         * params : null
         * price : 2000.0
         * priceType : 2
         * remark :
         * searchValue :
         * soldNum : 2
         * sort : 99999
         * sstartTime :
         * startTime : null
         * status : 2
         * supplier : JD
         * supplierId : 4
         * updateBy : cyz2019
         * updateTime : 2019-12-27 10:50:40
         * upperTime : null
         * url5 :
         * url6 :
         * url7 :
         * url8 :
         * url9 :
         */

        public boolean applyed;
        public double assessPrice;
        public int boutique;
        public int categoryId;
        public String categoryName;
        public String channelId;
        public boolean clicked;
        public String content;
        public double costPrice;
        public String createBy;
        public String createTime;
        public int deleted;
        public String desc;
        public String description;
        public String deviceCode;
        public String deviceType;
        public String eendTime;
        public Object endTime;
        public String goodsDetail;
        public int goodsId;
        public String goodsName;
        public Object goodsSubType;
        public int goodsType;
        public String headImage;
        public double integral;
        public int inventory;
        public String logo;
        public String orderField;
        public PageBean page;
        public Object params;
        public double price;
        public int priceType;
        public String remark;
        public String searchValue;
        public int soldNum;
        public int sort;
        public String sstartTime;
        public Object startTime;
        public int status;
        public String supplier;
        public int supplierId;
        public String updateBy;
        public String updateTime;
        public Object upperTime;
        public String url5;
        public String url6;
        public String url7;
        public String url8;
        public String url9;

        public static class PageBean {
            /**
             * currentResult : 0
             * entityOrField : false
             * pageNumber : 1
             * pageSize : 10
             * pageStr :
             * totalPage : 0
             * totalResult : 0
             */

            public int currentResult;
            public boolean entityOrField;
            public int pageNumber;
            public int pageSize;
            public String pageStr;
            public int totalPage;
            public int totalResult;
        }
    }
}
