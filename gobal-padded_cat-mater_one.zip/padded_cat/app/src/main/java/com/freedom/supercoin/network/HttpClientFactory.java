package com.freedom.supercoin.network;


import com.freedom.supercoin.base_library.utils.LogUtils;

import java.util.HashMap;

import okhttp3.OkHttpClient;


public class HttpClientFactory {
    private static final String NORMAL = "normal";
    private final OkHttpClient httpClient;
    private final HashMap<String, OkHttpClient> httpClients;


    public HttpClientFactory() {
        this.httpClient = new OkHttpClient.Builder().build();
        this.httpClients = new HashMap<>();
    }


    private static class SingletonHolder {
        private static final HttpClientFactory INSTANCE = new HttpClientFactory();


        private SingletonHolder() {

        }
    }


    public static HttpClientFactory getInstance() {
        return SingletonHolder.INSTANCE;
    }


    public OkHttpClient getHttpClient() {
        OkHttpClient okHttpClient = this.httpClients.get(NORMAL);
        if (okHttpClient != null) {
            return okHttpClient;
        }
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor(message -> {
            LogUtils.ShowI("okhttp:",message);
        });
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        okHttpClient = this.httpClient.newBuilder()
            .addInterceptor(interceptor)
            .addInterceptor(new TokenInterceptor())
            .build();
        httpClients.put(NORMAL, okHttpClient);
        return okHttpClient;
    }
}
