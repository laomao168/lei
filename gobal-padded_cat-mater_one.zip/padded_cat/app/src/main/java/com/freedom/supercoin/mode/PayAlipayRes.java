package com.freedom.supercoin.mode;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2020/1/10.
 * @desc :
 */
public class PayAlipayRes {

    /**
     * code :
     * count : null
     * data : {"order":"alipay_sdk=alipay-sdk-java-dynamicVersionNo&app_id=2019121569969151
     * &biz_content=%7B%22goods_type%22%3A%223%22%2C%22out_trade_no%22%3A%22LPR200110165051795124
     * %22%2C%22passback_params%22%3A%22alipay%22%2C%22product_code%22%3A%22QUICK_MSECURITY_PAY
     * %22%2C%22subject%22%3A%22%E4%BD%99%E9%A2%9D%E5%85%85%E5%80%BC%22%2C%22timeout_express%22
     * %3A%221c%22%2C%22total_amount%22%3A%2210%22%7D&charset=UTF-8&format=json&method=alipay
     * .trade.app.pay&notify_url=http%3A%2F%2F39.104.111
     * .147%3A21000%2Fapi%2Fcallback%2Fvalidate&sign=chnKbV8g%2BctWIMukBaIN%2B2pJVQpON0v
     * %2Bxos1h97msq1v4lqcQzG46rzI0dh%2B6ZOWNIZqnOUE89E1pIcd1iXmEGf
     * %2BfigtraG5Zj93RpmbuWED9hYaRFlFE%2Fx4y%2Bd2Ocw9%2FM6yoLmkb
     * %2Bz6EqL8gkOjjazCWicWCI6TsFJfBdmQSQvCZ%2BLU5Zn
     * %2FCGYr3A76FcknaoTw9pwZyBBUMxtEHuaUTJz5eKiTbu65evsJZfKrusxVmJzcvwaWUR1mEyRmvcLSpdcwoUEKsk5LeHf7S465VIfISKPrUPmMFfV97jjm0UEmY56W6WTgGENNupfJIDCPc0MMx4z%2BerC%2Fp5jw6T4jCw%3D%3D&sign_type=RSA2&timestamp=2020-01-10+16%3A50%3A51&version=1.0"}
     * error : false
     * msg : 订单创建成功！
     * result : true
     * success : true
     */

    public String code;
    public Object count;
    public DataBean data;
    public boolean error;
    public String msg;
    public boolean result;
    public boolean success;

    public static class DataBean {
        /**
         * order : alipay_sdk=alipay-sdk-java-dynamicVersionNo&app_id=2019121569969151
         * &biz_content=%7B%22goods_type%22%3A%223%22%2C%22out_trade_no%22%3A
         * %22LPR200110165051795124%22%2C%22passback_params%22%3A%22alipay%22%2C%22product_code
         * %22%3A%22QUICK_MSECURITY_PAY%22%2C%22subject%22%3A%22%E4%BD%99%E9%A2%9D%E5%85%85%E5%80
         * %BC%22%2C%22timeout_express%22%3A%221c%22%2C%22total_amount%22%3A%2210%22%7D&charset
         * =UTF-8&format=json&method=alipay.trade.app.pay&notify_url=http%3A%2F%2F39.104.111
         * .147%3A21000%2Fapi%2Fcallback%2Fvalidate&sign=chnKbV8g%2BctWIMukBaIN%2B2pJVQpON0v
         * %2Bxos1h97msq1v4lqcQzG46rzI0dh%2B6ZOWNIZqnOUE89E1pIcd1iXmEGf
         * %2BfigtraG5Zj93RpmbuWED9hYaRFlFE%2Fx4y%2Bd2Ocw9%2FM6yoLmkb
         * %2Bz6EqL8gkOjjazCWicWCI6TsFJfBdmQSQvCZ%2BLU5Zn
         * %2FCGYr3A76FcknaoTw9pwZyBBUMxtEHuaUTJz5eKiTbu65evsJZfKrusxVmJzcvwaWUR1mEyRmvcLSpdcwoUEKsk5LeHf7S465VIfISKPrUPmMFfV97jjm0UEmY56W6WTgGENNupfJIDCPc0MMx4z%2BerC%2Fp5jw6T4jCw%3D%3D&sign_type=RSA2&timestamp=2020-01-10+16%3A50%3A51&version=1.0
         */

        public String order;
    }
}
