package com.freedom.supercoin.fragment;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;

import com.freedom.supercoin.R;
import com.freedom.supercoin.activity.IntegralOrderDetailActivity;
import com.freedom.supercoin.activity.IntegralPayActivity;
import com.freedom.supercoin.activity.WebActivity;
import com.freedom.supercoin.adapter.IntegralOrderAdapter;
import com.freedom.supercoin.base_library.AppConst;
import com.freedom.supercoin.base_library.utils.SPUtils;
import com.freedom.supercoin.base_library.widget.spingview.DefaultFooter;
import com.freedom.supercoin.base_library.widget.spingview.SpringView;
import com.freedom.supercoin.common.UILazyFragment;
import com.freedom.supercoin.contract.IntegralOrderContact;
import com.freedom.supercoin.databinding.FragmentOrderBinding;
import com.freedom.supercoin.mode.IntegralOrderMode;
import com.freedom.supercoin.persenter.IntegralOrderPresenter;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2019/7/18.
 */

public class IntegralOrderFragment extends UILazyFragment<FragmentOrderBinding> implements IntegralOrderContact.View {
    public static String INDEX = "INDEX";
    public static String GOODSTYPE = "goodsType";
    private IntegralOrderAdapter adapter;
    private IntegralOrderPresenter presenter;
    private int currentIndex;
    private int index;
    private int goodsType;

    /**
     * @param index 0全部,1 代付款,2待发货,3 待收货,4已完成
     * @return
     */
    public static IntegralOrderFragment newInstance(int index, int goodsType) {
        IntegralOrderFragment fragment = new IntegralOrderFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(INDEX, index);
        bundle.putInt(GOODSTYPE, goodsType);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected boolean isLazyOrNot() {
        return  false;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_order;
    }

    @Override
    protected void initEvent() {
        adapter.setOnItemClickListener(new IntegralOrderAdapter.OnItemClickListener() {
            @Override
            public void onItemDetailClick(int position, IntegralOrderMode.DataBeanX.DataBean bean) {
                getOperation().addParameter(AppConst.Keys.ORDER_ID, bean.mallOrderId);
                getOperation().forward(IntegralOrderDetailActivity.class);
            }

            @Override
            public void onItemPayClick(int position, IntegralOrderMode.DataBeanX.DataBean bean) {
                    //付款
                    getOperation().addParameter(AppConst.Keys.GOODS_ID, bean.goodsId);
                    getOperation().forward(IntegralPayActivity.class);

            }

            @Override
            public void onItemContractClick(int position, IntegralOrderMode.DataBeanX.DataBean bean) {
                String url = "https://h5.lepai988.cn/contract.html?orderId="+bean.mallOrderId+"&token="+ SPUtils.getInstance().getString(AppConst.Keys.LOGIN_TOKEN);
                getOperation().addParameter(AppConst.Keys.WEB_URL,url);
                getOperation().addParameter(AppConst.Keys.TITLE,"签署合同");
                getOperation().forward(WebActivity.class);
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        loadOrderList();
    }

    @Override
    protected void initData() {
        initSpringView();
        index = getArguments().getInt(INDEX, 0);
        goodsType = getArguments().getInt(GOODSTYPE, 0);
        binding.recycleView.setLayoutManager(new LinearLayoutManager(mActivity));
        adapter = new IntegralOrderAdapter();
        adapter.setGoodsType(goodsType);
        binding.recycleView.setAdapter(adapter);
        presenter = new IntegralOrderPresenter(this);
        currentIndex = 1;
    }

    private void initSpringView() {
        binding.springView.setType(SpringView.Type.FOLLOW);
        binding.springView.setListener(new SpringView.OnFreshListener() {
            @Override
            public void onRefresh() {
                currentIndex = 1;
                loadOrderList();
            }

            @Override
            public void onLoadMore() {
                currentIndex++;
                loadOrderList();
            }
        });
//        binding.springView.setHeader(new WheelHeader(this));
        binding.springView.setFooter(new DefaultFooter(mActivity));
    }

    private void loadOrderList() {
        int type;
        if (goodsType == 1) {
            type = index;
            if (type == 0) type = -1;
        } else {
            type = index - 1;
        }
        presenter.getOrderList(currentIndex, type, goodsType);
    }

    @Override
    public void getOrderListSuccess(IntegralOrderMode mode) {
        binding.springView.onFinishFreshAndLoad();
        if (!mode.success && mode.data == null) return;
        if (currentIndex == 1) {
            adapter.setData(mode.data.data);
        } else {
            adapter.addDataList(mode.data.data);
        }
    }
}


