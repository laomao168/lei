package com.freedom.supercoin.mode.entity;

public class CodeReq {
    public String mobile;
    public String use;
}
