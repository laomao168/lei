package com.freedom.supercoin.persenter;

import com.freedom.supercoin.contract.HomeFragmentContact;
import com.freedom.supercoin.mode.GoodsCategoryMode;
import com.freedom.supercoin.mode.HomeAuctionRes;
import com.freedom.supercoin.mode.HomeBannerMode;
import com.freedom.supercoin.mode.entity.HomeAuctionReq;
import com.freedom.supercoin.mode.entity.Page;
import com.freedom.supercoin.network.DataManager;
import com.freedom.supercoin.network.ResponseErrorFunc;
import com.freedom.supercoin.network.RxUtils;

import java.util.ArrayList;
import java.util.List;

import rx.Subscriber;


public class HomeFragmentPresenter implements HomeFragmentContact.Presenter {

    private final HomeFragmentContact.View view;

    public HomeFragmentPresenter(HomeFragmentContact.View view) {
        this.view = view;
    }

    @Override
    public void getHomeBannerList() {
        DataManager.getInstance()
                .getHomeBannerList()
                .compose(RxUtils.applyIOSchedulers())
                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<List<HomeBannerMode>>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(List<HomeBannerMode> list) {
                        view.hideProgress();
                        view.getHomeBannerListSuccess(list);
                    }
                });
    }

    @Override
    public void getAuctionRecordInfoToday(Page page) {
//        view.showProgress();
        DataManager.getInstance()
                .getAuctionRecordInfoToday(page)
                .compose(RxUtils.applyIOSchedulers())
//                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<HomeAuctionRes>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
//                        view.hideProgress();
                        view.onLoadListError();
                    }


                    @Override
                    public void onNext(HomeAuctionRes res) {
//                        view.hideProgress();
                        view.getTodayListSuccess(res);
                    }
                });
    }

    @Override
    public void getAuctionRecordInfoPreview(HomeAuctionReq homeAuctionReq) {
//        view.showProgress();
        DataManager.getInstance()
                .getAuctionRecordInfoPreview(homeAuctionReq)
                .compose(RxUtils.applyIOSchedulers())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<HomeAuctionRes>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
//                        view.hideProgress();
                        view.onLoadListError();
                    }


                    @Override
                    public void onNext(HomeAuctionRes res) {
//                        view.hideProgress();
                        view.getPreviewList(res);
                    }
                });
    }

    @Override
    public void getGoodsCategoryList() {
        DataManager.getInstance()
                .getGoodsCategoryList()
                .compose(RxUtils.applyIOSchedulers())
                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<List<GoodsCategoryMode>>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
//                        view.hideProgress();
                        view.onLoadGoodsCategorySuccess(new ArrayList<>());
                    }


                    @Override
                    public void onNext(List<GoodsCategoryMode> list) {
//                        view.hideProgress();
                        view.onLoadGoodsCategorySuccess(list);
                    }
                });
    }


}
