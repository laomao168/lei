package com.freedom.supercoin.adapter;

import android.databinding.DataBindingUtil;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.freedom.supercoin.R;
import com.freedom.supercoin.base_library.base.BaseEmptyAdapter;
import com.freedom.supercoin.base_library.utils.GlideUtils;
import com.freedom.supercoin.base_library.utils.StrUtils;
import com.freedom.supercoin.databinding.ItemGoodsBidBinding;
import com.freedom.supercoin.databinding.ItemOrderBinding;
import com.freedom.supercoin.mode.GoodBidMode;
import com.freedom.supercoin.mode.OrderMode;


public class OrderAdapter extends BaseEmptyAdapter<OrderMode.DataBeanX.DataBean, ItemOrderBinding> {

    @Override
    protected ItemOrderBinding createBinding(ViewGroup parent) {
        return DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()),
                R.layout.item_order, parent, false);
    }

    @Override
    protected void onBindView(ItemOrderBinding binding, OrderMode.DataBeanX.DataBean bean,
                              int position) {
        binding.tvTime.setText(bean.createTime);
        binding.tvGoodsName.setText(bean.goodsName);
//        订单状态 0待付款1待发货2待收货3交易完成4交易失败
        switch (bean.orderStatus) {
            case 0:
                binding.tvStatus.setText("待付款");
                binding.tvPay.setVisibility(View.VISIBLE);
                binding.tvPay.setText("立即付款");
                break;
            case 1:
                binding.tvStatus.setText("待发货");
                binding.tvPay.setVisibility(View.GONE);
                break;
            case 2:
                binding.tvStatus.setText("待收货");
                binding.tvPay.setVisibility(View.VISIBLE);
                binding.tvPay.setText("确认收货");
                break;
            case 3:
                binding.tvStatus.setText("交易完成");
                binding.tvPay.setVisibility(View.GONE);
                break;
            case 4:
                binding.tvStatus.setText("交易失败");
                binding.tvPay.setVisibility(View.GONE);
                break;
        }
        GlideUtils.loadImage(context, bean.logo.trim(), binding.ivGoodsImage);
        binding.tvPrice.setText("¥" + StrUtils.getRemoveZreoNum(bean.orderPrice));
        binding.setClick(v -> {
            switch (v.getId()) {
                case R.id.tv_to_detail:
                    if (onItemClickListener != null) {
                        onItemClickListener.onItemDetailClick(position, bean);
                    }
                    break;
                case R.id.tv_pay:
                    if (onItemClickListener != null) {
                        onItemClickListener.onItemPayClick(position, bean);
                    }
                    break;

            }
        });
    }

    public interface OnItemClickListener {
        void onItemDetailClick(int position, OrderMode.DataBeanX.DataBean bean);

        void onItemPayClick(int position, OrderMode.DataBeanX.DataBean bean);
    }

    public OnItemClickListener onItemClickListener;

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {

        this.onItemClickListener = onItemClickListener;
    }
}
