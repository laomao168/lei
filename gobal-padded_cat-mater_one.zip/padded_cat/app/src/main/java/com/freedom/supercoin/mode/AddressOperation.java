package com.freedom.supercoin.mode;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2020/1/10.
 * @desc :
 */
public class AddressOperation {

    /**
     * code :
     * count : null
     * data : null
     * error : false
     * msg : 操作成功
     * result : true
     * success : true
     */

    public String code;
    public Object count;
    public Object data;
    public boolean error;
    public String msg;
    public boolean result;
    public boolean success;
}
