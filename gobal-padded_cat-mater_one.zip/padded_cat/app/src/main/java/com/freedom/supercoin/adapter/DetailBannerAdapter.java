package com.freedom.supercoin.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.freedom.supercoin.R;
import com.freedom.supercoin.base_library.utils.GlideUtils;
import com.freedom.supercoin.mode.HomeBannerMode;

import java.util.List;

/**
 * Created by jianping on 2018/11/23.
 */

public class DetailBannerAdapter extends PagerAdapter {
    private Context context;
    private List<String> list;

    public DetailBannerAdapter(Context context, List<String> list) {

        this.context = context;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list == null ? 1 : list.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object o) {
        return view == o;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        View view = View.inflate(context, R.layout.item_home_banner, null);
        ImageView imageView = view.findViewById(R.id.iv_banner_image);
        if (list != null) {
            GlideUtils.loadImage(context, list.get(position), imageView);
        }
        imageView.setOnClickListener(v -> {
            if (onItemClickListener != null) {
                onItemClickListener.onItemClick(position);
            }
        });
        container.addView(view);
        return view;
    }

    @Override
    public int getItemPosition(Object object) {
        return POSITION_NONE;
    }

    public void setData(List<String> pageBanner) {
        list = pageBanner;
        notifyDataSetChanged();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public OnItemClickListener onItemClickListener;

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {

        this.onItemClickListener = onItemClickListener;
    }
}
