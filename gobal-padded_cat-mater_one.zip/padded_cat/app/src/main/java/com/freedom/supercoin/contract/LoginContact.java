package com.freedom.supercoin.contract;


import com.freedom.supercoin.base_library.base.BasePresenter;
import com.freedom.supercoin.base_library.base.BaseView;
import com.freedom.supercoin.mode.entity.CodeReq;
import com.freedom.supercoin.mode.entity.LoginBean;


public class LoginContact {

    public interface View extends BaseView {
        void onLoginSuccess( );

        void onGetCodeSuccess();
    }


    public interface Presenter extends BasePresenter {
        void toLogin(LoginBean loginBean);
        void  getCode(CodeReq codeReq);
    }
}

