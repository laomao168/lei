package com.freedom.supercoin.activity;

import android.support.v7.widget.LinearLayoutManager;
import android.text.TextUtils;
import android.view.View;

import com.freedom.supercoin.R;
import com.freedom.supercoin.adapter.IntegralAdapter;
import com.freedom.supercoin.base_library.AppConst;
import com.freedom.supercoin.base_library.utils.SPUtils;
import com.freedom.supercoin.common.UiActivity;
import com.freedom.supercoin.contract.IntegralPresenterContact;
import com.freedom.supercoin.databinding.ActivityIntegralBinding;
import com.freedom.supercoin.mode.IntegralMode;
import com.freedom.supercoin.persenter.IntegralPresenter;

/**
 * @author : lijianping
 * @date : Created on 2019/7/11.
 * des:积分
 */
public class IntegralActivity extends UiActivity<ActivityIntegralBinding> implements IntegralPresenterContact.View {

    private IntegralAdapter integralAdapter;
    private IntegralPresenter presenter;

    @Override
    protected int layoutResId() {
        return R.layout.activity_integral;
    }

    @Override
    protected void initData() {

        binding.tvIntegral.setText(SPUtils.getInstance().getString(AppConst.Keys.INTEGRAL));
        integralAdapter = new IntegralAdapter();
        binding.recycleView.setLayoutManager(new LinearLayoutManager(this));
        binding.recycleView.setAdapter(integralAdapter);
        presenter = new IntegralPresenter(this);
        presenter.getIntegralList();
    }

    @Override
    protected void initEvent() {
        binding.ivBack.setOnClickListener(v -> finish());
    }


    @Override
    public void getIntegralSuccess(IntegralMode mode) {
        if (!mode.success || !TextUtils.equals(mode.code, "0")) return;
        integralAdapter.setData(mode.data.data);
    }
}
