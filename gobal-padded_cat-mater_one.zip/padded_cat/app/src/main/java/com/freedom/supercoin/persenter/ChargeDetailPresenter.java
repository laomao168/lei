package com.freedom.supercoin.persenter;

import com.freedom.supercoin.contract.ChargeDetailContact;
import com.freedom.supercoin.mode.ChargeDetailMode;
import com.freedom.supercoin.mode.entity.Page;
import com.freedom.supercoin.network.DataManager;
import com.freedom.supercoin.network.ResponseErrorFunc;
import com.freedom.supercoin.network.RxUtils;

import rx.Subscriber;


public class ChargeDetailPresenter implements ChargeDetailContact.Presenter {

    private final ChargeDetailContact.View view;

    public ChargeDetailPresenter(ChargeDetailContact.View view) {
        this.view = view;
    }

    @Override
    public void getChargeList(Page page) {
        DataManager.getInstance()
                .getChargeList(page)
                .compose(RxUtils.applyIOSchedulers())
//                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<ChargeDetailMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(ChargeDetailMode mode) {
                        view.hideProgress();
                        view.onLoadChargeListSuccess(mode);
                    }
                });

    }


}
