package com.freedom.supercoin.persenter;

import android.text.TextUtils;

import com.freedom.supercoin.contract.SetPwdContact;
import com.freedom.supercoin.mode.CodeMode;
import com.freedom.supercoin.mode.SetPwdMode;
import com.freedom.supercoin.mode.entity.CodeReq;
import com.freedom.supercoin.network.DataManager;
import com.freedom.supercoin.network.ResponseErrorFunc;
import com.freedom.supercoin.network.RxUtils;

import rx.Subscriber;


public class SetPwdPresenter implements SetPwdContact.Presenter {

    private final SetPwdContact.View view;

    public SetPwdPresenter(SetPwdContact.View view) {
        this.view = view;
    }


    @Override
    public void getCode(CodeReq codeReq) {
        DataManager.getInstance()
                .getCode(codeReq)
                .compose(RxUtils.applyIOSchedulers())
//                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<CodeMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(CodeMode mode) {
                        view.hideProgress();
                        if (TextUtils.equals(mode.code, "0")) {
                            view.onGetCodeSuccess();
                        }

                    }
                });
    }

    @Override
    public void setPwd(String payPass, String code) {
        DataManager.getInstance()
                .setPwd(payPass,code)
                .compose(RxUtils.applyIOSchedulers())
//                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<SetPwdMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                        view.showMessage(e.getMessage());
                    }


                    @Override
                    public void onNext(SetPwdMode mode) {
                        view.hideProgress();
                        if (TextUtils.equals(mode.msg,"设置成功")){
                            view.onSetPwdSuccess();
                        }
                    }
                });
    }
}
