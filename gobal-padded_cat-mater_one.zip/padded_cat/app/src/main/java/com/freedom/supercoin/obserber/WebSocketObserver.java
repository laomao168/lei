package com.freedom.supercoin.obserber;


import java.util.ArrayList;

/**
 * Created by ljp on 2018/5/15.
 */

public class WebSocketObserver {


    private static WebSocketObserver instance;

    private WebSocketObserver() {
    }

    public static WebSocketObserver getIntance() {
        if (instance == null) {
            instance = new WebSocketObserver();
        }
        return instance;
    }


    private final Object object = new Object();

    protected final ArrayList<ObserverWebSocket> mObservers = new ArrayList<>();

    public void notifyChanged(String message) {
        synchronized (object) {
            for (ObserverWebSocket observer : mObservers) {
                observer.notifyWebMessage(message);
            }
        }
    }

    public void unregisterObserver(ObserverWebSocket observer) {
        if (observer == null) {
            return;
        }
        synchronized (object) {
            int index = mObservers.indexOf(observer);
            if (index == -1) {
                return;
            }
            mObservers.remove(index);
        }
    }

    public void registerObserver(ObserverWebSocket observer) {
        if (observer == null) {
            throw new IllegalArgumentException("The observer is null.");
        }
        synchronized (object) {
            if (mObservers.contains(observer)) {
                return;
            }
            mObservers.add(observer);
        }
    }
}

