package com.freedom.supercoin.mode;

import java.util.List;

public class AddressListMode {

    /**
     * code :
     * count : null
     * data : {"data":[{"address":"大大大大大","addressId":670,"applyed":false,"channelId":"",
     * "city":"330100","cityText":"杭州市","clicked":false,"consignee":"姜平","createBy":"",
     * "createTime":"2019-12-27 18:15:50","deleted":0,"desc":"desc","deviceCode":"",
     * "deviceType":"","district":"330110","districtText":"余杭区","endTime":null,
     * "mobile":"17794559973","orderField":"","page":{"currentResult":0,"entityOrField":false,
     * "pageNumber":1,"pageSize":10,"pageStr":"","totalPage":0,"totalResult":0},"params":null,
     * "province":"330000","provinceText":"浙江省","remark":"","searchValue":"","startTime":null,
     * "street":"330110005","streetText":"五常街道","tolerant":0,"updateBy":"","updateTime":null,
     * "userId":15}],"page":{"currentResult":0,"entityOrField":false,"pageNumber":1,
     * "pageSize":10,"pageStr":"","totalPage":1,"totalResult":1}}
     * error : false
     * msg : 查询成功
     * result : true
     * success : true
     */

    public String code;
    public Object count;
    public DataBeanX data;
    public boolean error;
    public String msg;
    public boolean result;
    public boolean success;

    public static class DataBeanX {
        /**
         * data : [{"address":"大大大大大","addressId":670,"applyed":false,"channelId":"",
         * "city":"330100","cityText":"杭州市","clicked":false,"consignee":"姜平","createBy":"",
         * "createTime":"2019-12-27 18:15:50","deleted":0,"desc":"desc","deviceCode":"",
         * "deviceType":"","district":"330110","districtText":"余杭区","endTime":null,
         * "mobile":"17794559973","orderField":"","page":{"currentResult":0,
         * "entityOrField":false,"pageNumber":1,"pageSize":10,"pageStr":"","totalPage":0,
         * "totalResult":0},"params":null,"province":"330000","provinceText":"浙江省","remark":"",
         * "searchValue":"","startTime":null,"street":"330110005","streetText":"五常街道",
         * "tolerant":0,"updateBy":"","updateTime":null,"userId":15}]
         * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,
         * "pageStr":"","totalPage":1,"totalResult":1}
         */

        public PageBean page;
        public List<DataBean> data;

        public static class PageBean {
            /**
             * currentResult : 0
             * entityOrField : false
             * pageNumber : 1
             * pageSize : 10
             * pageStr :
             * totalPage : 1
             * totalResult : 1
             */

            public int currentResult;
            public boolean entityOrField;
            public int pageNumber;
            public int pageSize;
            public String pageStr;
            public int totalPage;
            public int totalResult;
        }

        public static class DataBean {
            /**
             * address : 大大大大大
             * addressId : 670
             * applyed : false
             * channelId :
             * city : 330100
             * cityText : 杭州市
             * clicked : false
             * consignee : 姜平
             * createBy :
             * createTime : 2019-12-27 18:15:50
             * deleted : 0
             * desc : desc
             * deviceCode :
             * deviceType :
             * district : 330110
             * districtText : 余杭区
             * endTime : null
             * mobile : 17794559973
             * orderField :
             * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,
             * "pageStr":"","totalPage":0,"totalResult":0}
             * params : null
             * province : 330000
             * provinceText : 浙江省
             * remark :
             * searchValue :
             * startTime : null
             * street : 330110005
             * streetText : 五常街道
             * tolerant : 0
             * updateBy :
             * updateTime : null
             * userId : 15
             */

            public String address;
            public int addressId;
            public boolean applyed;
            public String channelId;
            public int city;
            public String cityText;
            public boolean clicked;
            public String consignee;
            public String createBy;
            public String createTime;
            public int deleted;
            public String desc;
            public String deviceCode;
            public String deviceType;
            public int district;
            public String districtText;
            public Object endTime;
            public String mobile;
            public String orderField;
            public PageBeanX page;
            public Object params;
            public int province;
            public String provinceText;
            public String remark;
            public String searchValue;
            public Object startTime;
            public int street;
            public String streetText;
            public int tolerant;
            public String updateBy;
            public Object updateTime;
            public int userId;

            public static class PageBeanX {
                /**
                 * currentResult : 0
                 * entityOrField : false
                 * pageNumber : 1
                 * pageSize : 10
                 * pageStr :
                 * totalPage : 0
                 * totalResult : 0
                 */

                public int currentResult;
                public boolean entityOrField;
                public int pageNumber;
                public int pageSize;
                public String pageStr;
                public int totalPage;
                public int totalResult;
            }
        }
    }
}
