package com.freedom.supercoin.mode;

import java.util.List;

public class PersonalMode {

    /**
     * code : 1
     * count : null
     * data : {"accountDetailType":null,"alipay":"","amount":null,"applyed":false,
     * "avatar":"https://wx.qlogo
     * .cn/mmopen/vi_32
     * /d5TeNFwscHKuspTDLYmibwYSMAcknrJtX7vpoJI1Fich3l0d9l0E33Ne2iaPXYmfhKHVoBZ11bKw3oTZsxs2ibe7Fg/132","backDeposit":null,"beginTime":"","birthday":null,"blacklist":0,"cardNo":"","channelId":"","chargeMoney":null,"clicked":false,"createBy":"","createIp":"","createTime":"2020-06-06 13:45:13","deleted":0,"desc":"desc","deviceCode":"","deviceType":"","directNum":null,"endTime":null,"failMoney":null,"fanNums":null,"gender":0,"indirectNum":null,"inhibited":0,"integralAmount":null,"integralDetailType":null,"invitationCode":"J21248","isEarnings":null,"isSendMsg":null,"lastLoginIp":"","lastLoginTime":"2020-06-06 13:45:13","lockAmount":null,"money":null,"name":"","newPeople":null,"nickname":"乐拍_40864456","openid":"","orderField":"","orderMoney":null,"outWithdraw":null,"overTime":"","page":{"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,"pageStr":"","totalPage":0,"totalResult":0},"params":null,"parentId":0,"parentIdList":[],"parentInvitationCode":"","parentNickname":"","parentTime":null,"partnerIncome":null,"password":"","payPassword":"456a95935a42929c26f97094d1ca51e1ea92c3bf08845842","phone":"18566398679","positMoney":null,"qrcodeUrl":"https://image.lepai988.cn/2bca4bbe4c254ea4a25e8274b7cd1d59","qrcodeUrlApp":"https://api.lepai988.cn/J21248qrCodeUrl.png","remark":"","searchValue":"","secondInviterId":0,"sjnickname":"","smsCode":"","startTime":null,"status":0,"token":"","totalIncome":null,"tradeType":null,"type":1,"unionid":"","updateBy":"2773","updateInviteCode":0,"updateTime":"2020-06-06 14:28:33","userId":2773,"userIdList":[],"username":"乐拍_40864456","userzfb":"","verifyCode":""}
     * error : true
     * msg : 邀请码填写错误
     * result : false
     * success : false
     */

    public String code;
    public Object count;
    public DataBean data;
    public boolean error;
    public String msg;
    public boolean result;
    public boolean success;

    public static class DataBean {
        /**
         * accountDetailType : null
         * alipay :
         * amount : null
         * applyed : false
         * avatar : https://wx.qlogo
         * .cn/mmopen/vi_32
         * /d5TeNFwscHKuspTDLYmibwYSMAcknrJtX7vpoJI1Fich3l0d9l0E33Ne2iaPXYmfhKHVoBZ11bKw3oTZsxs2ibe7Fg/132
         * backDeposit : null
         * beginTime :
         * birthday : null
         * blacklist : 0
         * cardNo :
         * channelId :
         * chargeMoney : null
         * clicked : false
         * createBy :
         * createIp :
         * createTime : 2020-06-06 13:45:13
         * deleted : 0
         * desc : desc
         * deviceCode :
         * deviceType :
         * directNum : null
         * endTime : null
         * failMoney : null
         * fanNums : null
         * gender : 0
         * indirectNum : null
         * inhibited : 0
         * integralAmount : null
         * integralDetailType : null
         * invitationCode : J21248
         * isEarnings : null
         * isSendMsg : null
         * lastLoginIp :
         * lastLoginTime : 2020-06-06 13:45:13
         * lockAmount : null
         * money : null
         * name :
         * newPeople : null
         * nickname : 乐拍_40864456
         * openid :
         * orderField :
         * orderMoney : null
         * outWithdraw : null
         * overTime :
         * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,
         * "pageStr":"","totalPage":0,"totalResult":0}
         * params : null
         * parentId : 0
         * parentIdList : []
         * parentInvitationCode :
         * parentNickname :
         * parentTime : null
         * partnerIncome : null
         * password :
         * payPassword : 456a95935a42929c26f97094d1ca51e1ea92c3bf08845842
         * phone : 18566398679
         * positMoney : null
         * qrcodeUrl : https://image.lepai988.cn/2bca4bbe4c254ea4a25e8274b7cd1d59
         * qrcodeUrlApp : https://api.lepai988.cn/J21248qrCodeUrl.png
         * remark :
         * searchValue :
         * secondInviterId : 0
         * sjnickname :
         * smsCode :
         * startTime : null
         * status : 0
         * token :
         * totalIncome : null
         * tradeType : null
         * type : 1
         * unionid :
         * updateBy : 2773
         * updateInviteCode : 0
         * updateTime : 2020-06-06 14:28:33
         * userId : 2773
         * userIdList : []
         * username : 乐拍_40864456
         * userzfb :
         * verifyCode :
         */

        public Object accountDetailType;
        public String alipay;
        public Object amount;
        public boolean applyed;
        public String avatar;
        public Object backDeposit;
        public String beginTime;
        public Object birthday;
        public int blacklist;
        public String cardNo;
        public String channelId;
        public Object chargeMoney;
        public boolean clicked;
        public String createBy;
        public String createIp;
        public String createTime;
        public int deleted;
        public String desc;
        public String deviceCode;
        public String deviceType;
        public Object directNum;
        public Object endTime;
        public Object failMoney;
        public Object fanNums;
        public int gender;
        public Object indirectNum;
        public int inhibited;
        public Object integralAmount;
        public Object integralDetailType;
        public String invitationCode;
        public Object isEarnings;
        public Object isSendMsg;
        public String lastLoginIp;
        public String lastLoginTime;
        public Object lockAmount;
        public Object money;
        public String name;
        public Object newPeople;
        public String nickname;
        public String openid;
        public String orderField;
        public Object orderMoney;
        public Object outWithdraw;
        public String overTime;
        public PageBean page;
        public Object params;
        public int parentId;
        public String parentInvitationCode;
        public String parentNickname;
        public Object parentTime;
        public Object partnerIncome;
        public String password;
        public String payPassword;
        public String phone;
        public Object positMoney;
        public String qrcodeUrl;
        public String qrcodeUrlApp;
        public String remark;
        public String searchValue;
        public int secondInviterId;
        public String sjnickname;
        public String smsCode;
        public Object startTime;
        public int status;
        public String token;
        public Object totalIncome;
        public Object tradeType;
        public int type;
        public String unionid;
        public String updateBy;
        public int updateInviteCode;
        public String updateTime;
        public int userId;
        public String username;
        public String userzfb;
        public String verifyCode;
        public List<?> parentIdList;
        public List<?> userIdList;

        public static class PageBean {
            /**
             * currentResult : 0
             * entityOrField : false
             * pageNumber : 1
             * pageSize : 10
             * pageStr :
             * totalPage : 0
             * totalResult : 0
             */

            public int currentResult;
            public boolean entityOrField;
            public int pageNumber;
            public int pageSize;
            public String pageStr;
            public int totalPage;
            public int totalResult;
        }
    }
}
