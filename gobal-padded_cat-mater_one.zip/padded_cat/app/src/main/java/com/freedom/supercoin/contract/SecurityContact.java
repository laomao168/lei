package com.freedom.supercoin.contract;


import com.freedom.supercoin.base_library.base.BasePresenter;
import com.freedom.supercoin.base_library.base.BaseView;
import com.freedom.supercoin.mode.CheckPwdMode;
import com.freedom.supercoin.mode.CheckRealNameMode;


public class SecurityContact {

    public interface View extends BaseView {

        void getCheckPwdSuccess(CheckPwdMode mode);

        void getRealNameSuccess(CheckRealNameMode mode);
    }


    public interface Presenter extends BasePresenter {
        void checkPwd();
        void checkRealName();
    }
}

