package com.freedom.supercoin.mode;

import java.util.List;

public class BalanceListMode {

    /**
     * code : 0
     * count : null
     * data : {"data":[{"amount":2,"applyed":false,"channelId":"","clicked":false,
     * "createBy":"1178","createTime":"2019-12-29 16:53:30","currentMoney":99894,"deleted":0,
     * "desc":"desc","deviceCode":"","deviceType":"","endTime":null,"id":160085,"orderField":"",
     * "page":{"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,"pageStr":"",
     * "totalPage":0,"totalResult":0},"params":null,"remark":"您在\u2018新手体验活动 首次充值用户活动 全额退款
     * 老用户禁止参与体验\u2019的拍卖中出价540.00，出价成功，获取佣金2.00。","searchValue":"","startTime":null,
     * "tradeNo":"157270","tradeType":5,"tradeTypeText":"","type":1,"typeText":"",
     * "updateBy":"1178","updateTime":"2019-12-29 16:53:31","userId":1178},{"amount":108,
     * "applyed":false,"channelId":"","clicked":false,"createBy":"1178","createTime":"2019-12-29
     * 16:53:30","currentMoney":99892,"deleted":0,"desc":"desc","deviceCode":"","deviceType":"",
     * "endTime":null,"id":160084,"orderField":"","page":{"currentResult":0,
     * "entityOrField":false,"pageNumber":1,"pageSize":10,"pageStr":"","totalPage":0,
     * "totalResult":0},"params":null,"remark":"您在\u2018新手体验活动 首次充值用户活动 全额退款
     * 老用户禁止参与体验\u2019的拍卖中出价540.00，出价成功，扣除保证金108.000。","searchValue":"","startTime":null,
     * "tradeNo":"157270","tradeType":1,"tradeTypeText":"","type":0,"typeText":"",
     * "updateBy":"1178","updateTime":"2019-12-29 16:53:31","userId":1178},{"amount":100000,
     * "applyed":false,"channelId":"","clicked":false,"createBy":"1178","createTime":"2019-12-29
     * 16:50:54","currentMoney":100000,"deleted":0,"desc":"desc","deviceCode":"","deviceType":"",
     * "endTime":null,"id":160083,"orderField":"","page":{"currentResult":0,
     * "entityOrField":false,"pageNumber":1,"pageSize":10,"pageStr":"","totalPage":0,
     * "totalResult":0},"params":null,"remark":"测试用","searchValue":"","startTime":null,
     * "tradeNo":"1178","tradeType":7,"tradeTypeText":"","type":1,"typeText":"",
     * "updateBy":"1178","updateTime":"2019-12-29 16:50:55","userId":1178}],"page":{
     * "currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,"pageStr":"",
     * "totalPage":1,"totalResult":3}}
     * error : false
     * msg : 查询成功
     * result : true
     * success : true
     */

    public String code;
    public Object count;
    public DataBeanX data;
    public boolean error;
    public String msg;
    public boolean result;
    public boolean success;

    public static class DataBeanX {
        /**
         * data : [{"amount":2,"applyed":false,"channelId":"","clicked":false,"createBy":"1178",
         * "createTime":"2019-12-29 16:53:30","currentMoney":99894,"deleted":0,"desc":"desc",
         * "deviceCode":"","deviceType":"","endTime":null,"id":160085,"orderField":"","page":{
         * "currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,"pageStr":"",
         * "totalPage":0,"totalResult":0},"params":null,"remark":"您在\u2018新手体验活动 首次充值用户活动 全额退款
         * 老用户禁止参与体验\u2019的拍卖中出价540.00，出价成功，获取佣金2.00。","searchValue":"","startTime":null,
         * "tradeNo":"157270","tradeType":5,"tradeTypeText":"","type":1,"typeText":"",
         * "updateBy":"1178","updateTime":"2019-12-29 16:53:31","userId":1178},{"amount":108,
         * "applyed":false,"channelId":"","clicked":false,"createBy":"1178",
         * "createTime":"2019-12-29 16:53:30","currentMoney":99892,"deleted":0,"desc":"desc",
         * "deviceCode":"","deviceType":"","endTime":null,"id":160084,"orderField":"","page":{
         * "currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,"pageStr":"",
         * "totalPage":0,"totalResult":0},"params":null,"remark":"您在\u2018新手体验活动 首次充值用户活动 全额退款
         * 老用户禁止参与体验\u2019的拍卖中出价540.00，出价成功，扣除保证金108.000。","searchValue":"","startTime":null,
         * "tradeNo":"157270","tradeType":1,"tradeTypeText":"","type":0,"typeText":"",
         * "updateBy":"1178","updateTime":"2019-12-29 16:53:31","userId":1178},{"amount":100000,
         * "applyed":false,"channelId":"","clicked":false,"createBy":"1178",
         * "createTime":"2019-12-29 16:50:54","currentMoney":100000,"deleted":0,"desc":"desc",
         * "deviceCode":"","deviceType":"","endTime":null,"id":160083,"orderField":"","page":{
         * "currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,"pageStr":"",
         * "totalPage":0,"totalResult":0},"params":null,"remark":"测试用","searchValue":"",
         * "startTime":null,"tradeNo":"1178","tradeType":7,"tradeTypeText":"","type":1,
         * "typeText":"","updateBy":"1178","updateTime":"2019-12-29 16:50:55","userId":1178}]
         * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,
         * "pageStr":"","totalPage":1,"totalResult":3}
         */

        public PageBean page;
        public List<DataBean> data;

        public static class PageBean {
            /**
             * currentResult : 0
             * entityOrField : false
             * pageNumber : 1
             * pageSize : 10
             * pageStr :
             * totalPage : 1
             * totalResult : 3
             */

            public int currentResult;
            public boolean entityOrField;
            public int pageNumber;
            public int pageSize;
            public String pageStr;
            public int totalPage;
            public int totalResult;
        }

        public static class DataBean {
            /**
             * amount : 2.0
             * applyed : false
             * channelId :
             * clicked : false
             * createBy : 1178
             * createTime : 2019-12-29 16:53:30
             * currentMoney : 99894.0
             * deleted : 0
             * desc : desc
             * deviceCode :
             * deviceType :
             * endTime : null
             * id : 160085
             * orderField :
             * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,
             * "pageStr":"","totalPage":0,"totalResult":0}
             * params : null
             * remark : 您在‘新手体验活动 首次充值用户活动 全额退款 老用户禁止参与体验’的拍卖中出价540.00，出价成功，获取佣金2.00。
             * searchValue :
             * startTime : null
             * tradeNo : 157270
             * tradeType : 5
             * tradeTypeText :
             * type : 1
             * typeText :
             * updateBy : 1178
             * updateTime : 2019-12-29 16:53:31
             * userId : 1178
             */

            public double amount;
            public boolean applyed;
            public String channelId;
            public boolean clicked;
            public String createBy;
            public String createTime;
            public double currentMoney;
            public int deleted;
            public String desc;
            public String deviceCode;
            public String deviceType;
            public Object endTime;
            public int id;
            public String orderField;
            public PageBeanX page;
            public Object params;
            public String remark;
            public String searchValue;
            public Object startTime;
            public String tradeNo;
            public int tradeType;
            public String tradeTypeText;
            public int type;
            public String typeText;
            public String updateBy;
            public String updateTime;
            public int userId;

            public static class PageBeanX {
                /**
                 * currentResult : 0
                 * entityOrField : false
                 * pageNumber : 1
                 * pageSize : 10
                 * pageStr :
                 * totalPage : 0
                 * totalResult : 0
                 */

                public int currentResult;
                public boolean entityOrField;
                public int pageNumber;
                public int pageSize;
                public String pageStr;
                public int totalPage;
                public int totalResult;
            }
        }
    }
}
