package com.freedom.supercoin.contract;


import android.content.Context;

import com.freedom.supercoin.base_library.base.BasePresenter;
import com.freedom.supercoin.base_library.base.BaseView;
import com.freedom.supercoin.mode.AuctionAddMode;
import com.freedom.supercoin.mode.GoodBidMode;
import com.freedom.supercoin.mode.GoodDetailsMode;

import java.util.List;


public class AuctionContact {

    public interface View extends BaseView {

        void getGoodsBidModeSuccess(GoodBidMode mode);

        void onAuctionAddSuccess(AuctionAddMode mode);

        void getAuctionAddError(String message);

        void getGoodsDetailSuccess(GoodDetailsMode mode);
    }


    public interface Presenter extends BasePresenter {
        void getBidList(int auctionId);
        void bidGoods(int auction, double price);
        void getGoodDetails(int auctionId);
    }
}

