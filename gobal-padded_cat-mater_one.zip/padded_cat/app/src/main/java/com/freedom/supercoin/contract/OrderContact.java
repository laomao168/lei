package com.freedom.supercoin.contract;


import com.freedom.supercoin.base_library.base.BasePresenter;
import com.freedom.supercoin.base_library.base.BaseView;
import com.freedom.supercoin.mode.OrderMode;
import com.freedom.supercoin.mode.entity.Page;


public class OrderContact {

    public interface View extends BaseView {

        void getOrderListSuccess(OrderMode mode);
    }


    public interface Presenter extends BasePresenter {

        void getOrderList(int currentIndex, int type);
    }
}

