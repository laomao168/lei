package com.freedom.supercoin.utils;

import android.content.Context;
import android.text.TextUtils;

import com.freedom.supercoin.base_library.utils.LogUtils;
import com.freedom.supercoin.mode.PayRes;
import com.freedom.supercoin.mode.entity.WeChatRequest;
import com.tencent.mm.opensdk.modelpay.PayReq;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;

/**
 * Created by chaohx on 2017/7/5.
 */

public class WXPayUtils {



    private String TAG = "WXPayUtils";
    private static WXPayUtils instance;

    private WXPayUtils() {
    }

    public static WXPayUtils getInstance() {
        if (instance == null) {
            instance = new WXPayUtils();
        }
        return instance;
    }

    /**
     * 调起微信支付的方法
     **/
    public void toWXPay(Context context, final PayRes.DataBean weChatRequest) {
        final IWXAPI  iwxapi = WXAPIFactory.createWXAPI(context, null); //初始化微信api
        iwxapi.registerApp(weChatRequest.appId);//注册appid  appid可以在开发平台获取

        Runnable payRunnable = new Runnable() {  //这里注意要放在子线程
            @Override
            public void run() {
                if (TextUtils.isEmpty(weChatRequest.appId)
                        || TextUtils.isEmpty(weChatRequest.prepayId)
                        || TextUtils.isEmpty(weChatRequest.partnerId)) {
                    LogUtils.ShowD(TAG, "toWXPayAndSign: " + "" +
                            "必须在builder中设置appId、PartnerId、PrepayId");
                    return;
                }
                PayReq request = new PayReq(); //调起微信APP的对象
                //下面是设置必要的参数，也就是前面说的参数,这几个参数从何而来请看上面说明
                request.appId = weChatRequest.appId;
                request.partnerId = weChatRequest.partnerId;
                request.prepayId = weChatRequest.prepayId;
                request.packageValue = "Sign=WXPay";
                request.nonceStr = weChatRequest.nonceStr;
                request.timeStamp = weChatRequest.timeStamp;
                request.sign = weChatRequest.sign;
                iwxapi.sendReq(request);//发送调起微信的请求
            }
        };
        Thread payThread = new Thread(payRunnable);
        payThread.start();
    }

}
