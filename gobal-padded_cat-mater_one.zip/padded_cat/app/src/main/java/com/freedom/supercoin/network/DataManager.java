package com.freedom.supercoin.network;

import android.app.Application;

import com.freedom.supercoin.base_library.listener.DataConfig;
import com.freedom.supercoin.mode.AddAddressMode;
import com.freedom.supercoin.mode.AddressListMode;
import com.freedom.supercoin.mode.BalanceDetailMode;
import com.freedom.supercoin.mode.BalanceListMode;
import com.freedom.supercoin.mode.ChargeDetailMode;
import com.freedom.supercoin.mode.ChargeTypeMode;
import com.freedom.supercoin.mode.CheckPwdMode;
import com.freedom.supercoin.mode.CheckRealNameMode;
import com.freedom.supercoin.mode.CodeMode;
import com.freedom.supercoin.mode.FriendMode;
import com.freedom.supercoin.mode.GoodBidMode;
import com.freedom.supercoin.mode.GoodDetailsMode;
import com.freedom.supercoin.mode.GoodsCategoryMode;
import com.freedom.supercoin.mode.GoodsRankListMode;
import com.freedom.supercoin.mode.HomeBannerMode;
import com.freedom.supercoin.mode.HomeAuctionRes;
import com.freedom.supercoin.mode.ImageUploadMode;
import com.freedom.supercoin.mode.IntegralFragmentMode;
import com.freedom.supercoin.mode.IntegralMode;
import com.freedom.supercoin.mode.IntegralOrderMode;
import com.freedom.supercoin.mode.InviteFriendMode;
import com.freedom.supercoin.mode.LoginMode;
import com.freedom.supercoin.mode.MyAuctionMode;
import com.freedom.supercoin.mode.MyFansMode;
import com.freedom.supercoin.mode.MySuperiorMode;
import com.freedom.supercoin.mode.OrderDetailMode;
import com.freedom.supercoin.mode.OrderMode;
import com.freedom.supercoin.mode.OrderStatisticsMode;
import com.freedom.supercoin.mode.PayReq;
import com.freedom.supercoin.mode.PersonalMode;
import com.freedom.supercoin.mode.RealNameMode;
import com.freedom.supercoin.mode.SetPwdMode;
import com.freedom.supercoin.mode.StreetMode;
import com.freedom.supercoin.mode.TodayIncomeMode;
import com.freedom.supercoin.mode.UpdateMode;
import com.freedom.supercoin.mode.UpdateNikeNameMode;
import com.freedom.supercoin.mode.UserInfoMode;
import com.freedom.supercoin.mode.WithDrawListMode;
import com.freedom.supercoin.mode.WithDrawMode;
import com.freedom.supercoin.mode.entity.AddressBean;
import com.freedom.supercoin.mode.entity.CodeReq;
import com.freedom.supercoin.mode.entity.HomeAuctionReq;
import com.freedom.supercoin.mode.entity.LoginBean;
import com.freedom.supercoin.mode.entity.Page;

import java.util.List;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import rx.Observable;


/**
 * Created by zzq on 2018/4/3.
 */

public class DataManager {

    private static volatile DataManager ourInstance;
    private ApiService.NetService netService;
    private DataConfig dataConfig;
    public static String webUrl;

    private DataManager() {
    }

    /**
     * 首页banner
     *
     * @return
     */
    public Observable<Result<List<HomeBannerMode>>> getHomeBannerList() {
        return netService.getHomeBannerList(1);
    }
    /**商城
     *积分banner
     *
     * @return
     */
    public Observable<Result<List<HomeBannerMode>>> getIntegralBannerList() {
        return netService.getHomeBannerList(2);
    }

    /**
     * 积分商城列表
     * @return
     */
    public Observable<IntegralFragmentMode> loadIntegralList(int pageNumber, int pageSize) {
        return netService.loadIntegralList(pageNumber,pageSize);
    }

    /**
     * 积分商城分类列表
     * @param type
     * @param pageNumber
     * @return
     */
    public Observable<IntegralFragmentMode> loadIntegralListByGoodstype(int type, int pageNumber) {
        return netService.loadIntegralListByGoodstype(pageNumber,10,type);
    }

    /**
     * 近日拍卖列表
     *
     * @return
     */
    public Observable<HomeAuctionRes> getAuctionRecordInfoToday(Page page) {

        return netService.getAuctionRecordInfoToday(page.pageNumber, page.pageSize);
    }

    /**
     * 分类列表数据
     *
     * @return
     */
    public Observable<HomeAuctionRes> getGoodsCategoryData(int fatherCategoryId, int pageNumber) {

        return netService.getGoodsCategoryData(pageNumber, 10, fatherCategoryId);
    }

    /**
     * 预展拍卖列表
     *
     * @return
     */
    public Observable<HomeAuctionRes> getAuctionRecordInfoPreview(HomeAuctionReq homeAuctionReq) {
        return netService.getAuctionRecordInfoPreview(homeAuctionReq.pageNumber,
                homeAuctionReq.type, homeAuctionReq.pageSize);
    }


    /**
     * 商品详情
     *
     * @return
     */
    public Observable<Result<GoodDetailsMode>> getGoodDetails(int auctionId) {
        return netService.getGoodDetails(auctionId);
    }


    /**
     * 商品收益排行
     *
     * @return
     */
    public Observable<Result<List<GoodsRankListMode>>> getGoodRankList(int auctionId) {
        return netService.getGoodRankList(auctionId);
    }

    /**
     * 商品出价列表
     *
     * @return
     */
    public Observable<GoodBidMode> getBidList(int auctionId) {
        return netService.getBidList(auctionId, 1, 20);
    }

    /**
     * 出价
     *
     * @param auctionId
     * @return
     */
    public Observable<ResponseBody> bidGoods(int auctionId, double price) {
        return netService.getBidList(auctionId, price);
    }

    /**
     * 登录
     *
     * @param loginBean
     * @return
     */
    public Observable<Result<LoginMode>> login(LoginBean loginBean) {
        return netService.login(loginBean.phone, loginBean.verifyCode);
    }

    /**
     * 获取验证码
     *
     * @param codeReq
     * @return
     */
    public Observable<CodeMode> getCode(CodeReq codeReq) {
        return netService.getCode(codeReq.mobile, codeReq.use);
    }

    /**
     * 我的个人信息
     *
     * @return
     */
    public Observable<Result<UserInfoMode>> getUserInfo() {
        return netService.getUserInfo();
    }

    /**
     * 我的订单信息
     *
     * @return
     */
    public Observable<Result<OrderStatisticsMode>> getOrderInfo() {
        return netService.getOrderInfo();
    }

    /**
     * 积分明细
     *
     * @return
     */
    public Observable<IntegralMode> getIntegralList() {
        return netService.getIntegralList(1, 100);
    }

    /**
     * 查询余额
     *
     * @return
     */
    public Observable<Result<BalanceDetailMode>> getBalance() {
        return netService.getBalance();
    }

    /**
     * 今日收益
     *
     * @return
     */
    public Observable<TodayIncomeMode> getTodayIncome() {
        return netService.getTodayIncome();
    }

    /**
     * 检查实名
     *
     * @return
     */
    public Observable<CheckRealNameMode> checkRealName() {
        return netService.checkRealName();
    }

    /**
     * 检查pwd
     *
     * @return
     */
    public Observable<CheckPwdMode> checkPwd() {
        return netService.checkPwd();
    }

    /**
     * 余额明细
     *
     * @return
     */
    public Observable<BalanceListMode> getBalanceDetail(int pageNumber) {
        return netService.getBalanceDetail(pageNumber, 20);
    }

    /**
     * 实名认证
     *
     * @return
     */
    public Observable<RealNameMode> toIdentity(String bankName, String bank, String bankCard, String userName, String alipay, String idCard) {
        return netService.toIdentity(userName,alipay,idCard,bankName, bank, bankCard);
    }

    /**
     * 设置密码
     *
     * @return
     */
    public Observable<SetPwdMode> setPwd(String payPass, String code) {
        return netService.setPwd(payPass, code);
    }

    /**
     * 订单详情
     *
     * @return
     */
    public Observable<Result<OrderDetailMode>> getOrderDetail(int orderId) {
        return netService.getOrderDetail(orderId);
    }
    /**
     * 商城订单详情
     *
     * @return
     */
    public Observable<Result<OrderDetailMode>> getMallOrderDetail(int orderId) {
        return netService.getMallOrderDetail(orderId);
    }

    /**
     * 取消订单
     *
     * @param orderId
     * @return
     */
    public Observable<Result<OrderDetailMode>> cancelOrder(int orderId) {
        return netService.cancelOrder(orderId);
    }
    /**
     * 商城取消订单
     *
     * @param orderId
     * @return
     */
    public Observable<Result<OrderDetailMode>> cancelMallOrder(int orderId) {
        return netService.cancelMallOrder(orderId);
    }

    /**
     * 确认收货
     *
     * @param orderId
     * @return
     */
    public Observable<Result<OrderDetailMode>> receiptOrder(int orderId) {
        return netService.receiptOrder(orderId);
    }
    /**
     * 商城确认收货
     *
     * @param orderId
     * @return
     */
    public Observable<Result<OrderDetailMode>> receiptMallOrder(int orderId) {
        return netService.receiptMallOrder(orderId);
    }

    public Observable<MyAuctionMode> getMyAuctionList() {
        return netService.getMyAuctionList();
    }

    /**
     * 订单列表
     *
     * @return
     */
    public Observable<OrderMode> getOrderList(int currentIndex, int type) {
        if (type >= 0) {
            return netService.getOrderList(currentIndex, 10, type);
        } else {
            return netService.getOrderList(currentIndex, 10);
        }
    }

    /**
     * 地址列表
     *
     * @return
     */
    public Observable<AddressListMode> getAddressList() {
        return netService.getAddressList();
    }


    /**
     * 我的好友
     *
     * @return
     */
    public Observable<FriendMode> getMyFriend(int pageNumer) {
        return netService.getMyFriend(pageNumer, 10);
    }

    /**
     * 提现
     * @param pwd
     * @param money
     * @return
     */
    public Observable<WithDrawMode> WithDraw(String pwd, String money) {
        return netService.WithDraw(pwd, money);
    }

    /**
     * 全部好友
     *
     * @return
     */
    public Observable<FriendMode> getAllFriend(int pageNumber) {
        return netService.getAllFriend(pageNumber, 10);
    }

    /**
     * 我的上级
     *
     * @return
     */
    public Observable<Result<MySuperiorMode>> getMySuperior() {
        return netService.getMySuperior();
    }

    /**
     * 我的粉丝
     *
     * @return
     */
    public Observable<Result<MyFansMode>> getMyFans() {
        return netService.getMyFans();
    }

    /**
     * 获取邀请二维码
     *
     * @return
     */
    public Observable<InviteFriendMode> loadQrCode() {
        return netService.loadQrCode();
    }

    /**
     * 充值列表
     *
     * @return
     */
    public Observable<ChargeDetailMode> getChargeList(Page page) {
        return netService.getChargeList(page.pageNumber, page.pageSize);
    }

    /**
     * 提现列表
     * @param page
     * @return
     */
    public Observable<WithDrawListMode> getWithDrawList(Page page) {
        return netService.getWithDrawList(page.pageNumber, page.pageSize);
    }
    public Observable<ChargeTypeMode> cancelDraw(String id) {
        return netService.cancelDraw(id);
    }

    /**
     * 商城订单列表
     * @return
     */
    public Observable<IntegralOrderMode> getMallOrderList(int currentIndex, int type,int goodsType) {
        if (type >= 0) {
            return netService.getMallOrderList(currentIndex, 10, type, goodsType);
        } else {
            return netService.getMallOrderList(currentIndex, 10, goodsType);
        }

    }

    /**
     * 获取充值类型
     *
     * @return
     */
    public Observable<ChargeTypeMode> getChargeType() {
        return netService.getChargeType("rechargeType");
    }

    /**
     * 充值
     *
     * @param payReq
     * @return
     */
    public Observable<ResponseBody> getPayInfo(PayReq payReq) {
        return netService.getPayInfo(payReq.orderType, payReq.type, payReq.payType, payReq.amount);
    }
    public Observable<ResponseBody> getPayInfoNew(PayReq payReq) {
        return netService.getPayInfoNew(payReq.amount);
    }

    /**
     * 订单支付
     *
     * @param payReq
     * @return
     */
    public Observable<ResponseBody> payOrder(PayReq payReq) {
        return netService.payOrder(payReq.orderType, payReq.type, payReq.payType,
                payReq.payPassWord, payReq.addressId, payReq.orderId, payReq.goodsId);
    }
    public Observable<ResponseBody> integralPayOrder(PayReq payReq) {
        return netService.payOrder(payReq.orderType, payReq.type, payReq.payType,
                payReq.payPassWord, payReq.addressId, payReq.goodsId);
    }

    /**
     * 积分商城预支付
     * @param goodsId
     * @return
     */
    public Observable<ResponseBody> prePayIntegralOrder(int goodsId) {
        return netService.prePayIntegralOrder(goodsId);
    }

    public Observable<ResponseBody> getIntegralDetail(int goodsId) {
        return netService.getIntegralDetail(goodsId);
    }
  public Observable<PersonalMode> saveInviteCode(String inviteCode) {
        return netService.saveInviteCode(inviteCode);
    }

    public Observable<ImageUploadMode> uploadImage(RequestBody requestBody, MultipartBody.Part file) {
        return netService.uploadImage(requestBody,file);
    }

    public Observable<UpdateNikeNameMode> updateNikeName(String nikeName, String avatar) {
        return netService.updateNikeName(nikeName,avatar);
    }

    /**
     * 首页分类
     *
     * @return
     */
    public Observable<Result<List<GoodsCategoryMode>>> getGoodsCategoryList() {
        return netService.getGoodsCategoryList(1);
    }

    /**
     * CheckUpdate
     * @return
     */
    public Observable<UpdateMode> CheckUpdate() {
        return netService.CheckUpdate("android");
    }

    /**
     * 添加地址
     *
     * @return
     */
    public Observable<AddAddressMode> addAddress(AddressBean bean) {
        return netService.addAddress(bean.address, bean.city, bean.consignee, bean.district,
                bean.mobile, bean.province, bean.tolerant, bean.addressId, bean.street);
    }

    /**
     * 修改地址
     *
     * @return
     */
    public Observable<AddAddressMode> editAddress(AddressBean bean) {
        return netService.editAddress(bean.address, bean.city, bean.consignee, bean.district,
                bean.mobile, bean.province, bean.tolerant, bean.addressId, bean.street);
    }

    /**
     * 查询地址
     *
     * @return
     */
    public Observable<Result<List<StreetMode>>> getAllList(int parentId) {
        return netService.getAllAddressList(parentId);
    }


    public static DataManager getInstance() {
        if (ourInstance == null) {
            synchronized (DataManager.class) {
                if (ourInstance == null) {
                    ourInstance = new DataManager();
                }
            }
        }
        return ourInstance;
    }

    /**
     * 初始化网络请求
     *
     * @param appContext
     * @param dataConfig
     */
    public void init(Application appContext, DataConfig dataConfig) {
        if (dataConfig == null) {
            throw new RuntimeException("Data Config can not be NULL");
        }
        this.dataConfig = dataConfig;
        webUrl = dataConfig.getWebUrl();
        ApiService apiService = new ApiService(dataConfig.getBaseUrl());
        this.netService = apiService.getNetService();
    }


}
