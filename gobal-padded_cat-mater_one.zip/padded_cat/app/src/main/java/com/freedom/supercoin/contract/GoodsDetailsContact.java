package com.freedom.supercoin.contract;


import com.freedom.supercoin.base_library.base.BasePresenter;
import com.freedom.supercoin.base_library.base.BaseView;
import com.freedom.supercoin.mode.GoodDetailsMode;
import com.freedom.supercoin.mode.GoodsRankListMode;

import java.util.List;


public class GoodsDetailsContact {

    public interface View extends BaseView {

        void getGoodsDetailSuccess(GoodDetailsMode mode);

        void getGoodsRankListSuccess(List<GoodsRankListMode> list);
    }


    public interface Presenter extends BasePresenter {
        void getGoodDetails(int auctionId);
        void getGoodRankList(int auctionId);
    }
}

