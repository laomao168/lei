package com.freedom.supercoin.mode;

import java.util.List;

public class FriendMode {

    /**
     * code :
     * count : null
     * data : {"data":[{"accountDetailType":null,"alipay":"","amount":null,"applyed":false,
     * "avatar":"https://wx.qlogo
     * .cn/mmopen/vi_32
     * /YicLNcChzGe4OXxTOVeQ4XwaCvf8rJJVu0uRjqcnJDHXVBfIGwsiatzmBv3BgiaSxL4fuqVyfcH2gLWSy8Jq0jzGw
     * /132","backDeposit":null,"beginTime":"","birthday":null,"blacklist":0,"cardNo":"",
     * "channelId":"","chargeMoney":null,"clicked":false,"createBy":"","createIp":"",
     * "createTime":"2019-12-26 22:22:06","deleted":0,"desc":"desc","deviceCode":"",
     * "deviceType":"","directNum":0,"endTime":null,"failMoney":null,"fanNums":null,"gender":0,
     * "indirectNum":0,"inhibited":0,"integralAmount":null,"integralDetailType":null,
     * "invitationCode":"I63890","isEarnings":null,"isSendMsg":null,"lastLoginIp":"",
     * "lastLoginTime":"2019-12-26 22:22:06","lockAmount":null,"money":null,"name":"",
     * "newPeople":null,"nickname":"Wendy","openid":"oQr774pGYj_meQF1bA1GTG4HgcC0",
     * "orderField":"","orderMoney":null,"outWithdraw":null,"overTime":"","page":{"currentResult
     * ":0,"entityOrField":false,"pageNumber":1,"pageSize":10,"pageStr":"","totalPage":0,
     * "totalResult":0},"params":null,"parentId":15,"parentIdList":[],"parentInvitationCode":"",
     * "parentNickname":"","parentTime":"2019-12-26 22:22:06","partnerIncome":null,"password":"",
     * "payPassword":"","phone":"13554770456","positMoney":null,"qrcodeUrl":"","remark":"",
     * "searchValue":"","secondInviterId":1,"sjnickname":"","smsCode":"","startTime":null,
     * "status":0,"token":"","totalIncome":null,"tradeType":null,"type":0,"unionid":"",
     * "updateBy":"","updateInviteCode":0,"updateTime":null,"userId":2279,"username":"Wendy",
     * "verifyCode":""}]}
     */

    public String code;
    public Object count;
    public DataBeanX data;
    public String msg;
    public boolean result;
    public boolean success;
    public static class DataBeanX {
        public List<DataBean> data;

        public static class DataBean {
            /**
             * accountDetailType : null
             * alipay :
             * amount : null
             * applyed : false
             * avatar : https://wx.qlogo
             * .cn/mmopen/vi_32
             * /YicLNcChzGe4OXxTOVeQ4XwaCvf8rJJVu0uRjqcnJDHXVBfIGwsiatzmBv3BgiaSxL4fuqVyfcH2gLWSy8Jq0jzGw/132
             * backDeposit : null
             * beginTime :
             * birthday : null
             * blacklist : 0
             * cardNo :
             * channelId :
             * chargeMoney : null
             * clicked : false
             * createBy :
             * createIp :
             * createTime : 2019-12-26 22:22:06
             * deleted : 0
             * desc : desc
             * deviceCode :
             * deviceType :
             * directNum : 0
             * endTime : null
             * failMoney : null
             * fanNums : null
             * gender : 0
             * indirectNum : 0
             * inhibited : 0
             * integralAmount : null
             * integralDetailType : null
             * invitationCode : I63890
             * isEarnings : null
             * isSendMsg : null
             * lastLoginIp :
             * lastLoginTime : 2019-12-26 22:22:06
             * lockAmount : null
             * money : null
             * name :
             * newPeople : null
             * nickname : Wendy
             * openid : oQr774pGYj_meQF1bA1GTG4HgcC0
             * orderField :
             * orderMoney : null
             * outWithdraw : null
             * overTime :
             * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,
             * "pageStr":"","totalPage":0,"totalResult":0}
             * params : null
             * parentId : 15
             * parentIdList : []
             * parentInvitationCode :
             * parentNickname :
             * parentTime : 2019-12-26 22:22:06
             * partnerIncome : null
             * password :
             * payPassword :
             * phone : 13554770456
             * positMoney : null
             * qrcodeUrl :
             * remark :
             * searchValue :
             * secondInviterId : 1
             * sjnickname :
             * smsCode :
             * startTime : null
             * status : 0
             * token :
             * totalIncome : null
             * tradeType : null
             * type : 0
             * unionid :
             * updateBy :
             * updateInviteCode : 0
             * updateTime : null
             * userId : 2279
             * username : Wendy
             * verifyCode :
             */

            public Object accountDetailType;
            public String alipay;
            public Object amount;
            public boolean applyed;
            public String avatar;
            public Object backDeposit;
            public String beginTime;
            public Object birthday;
            public int blacklist;
            public String cardNo;
            public String channelId;
            public Object chargeMoney;
            public boolean clicked;
            public String createBy;
            public String createIp;
            public String createTime;
            public int deleted;
            public String desc;
            public String deviceCode;
            public String deviceType;
            public int directNum;
            public Object endTime;
            public Object failMoney;
            public Object fanNums;
            public int gender;
            public int indirectNum;
            public int inhibited;
            public Object integralAmount;
            public Object integralDetailType;
            public String invitationCode;
            public Object isEarnings;
            public Object isSendMsg;
            public String lastLoginIp;
            public String lastLoginTime;
            public Object lockAmount;
            public Object money;
            public String name;
            public Object newPeople;
            public String nickname;
            public String openid;
            public String orderField;
            public Object orderMoney;
            public Object outWithdraw;
            public String overTime;
            public PageBean page;
            public Object params;
            public int parentId;
            public String parentInvitationCode;
            public String parentNickname;
            public String parentTime;
            public Object partnerIncome;
            public String password;
            public String payPassword;
            public String phone;
            public Object positMoney;
            public String qrcodeUrl;
            public String remark;
            public String searchValue;
            public int secondInviterId;
            public String sjnickname;
            public String smsCode;
            public Object startTime;
            public int status;
            public String token;
            public Object totalIncome;
            public Object tradeType;
            public int type;
            public String unionid;
            public String updateBy;
            public int updateInviteCode;
            public Object updateTime;
            public int userId;
            public String username;
            public String verifyCode;
            public List<?> parentIdList;

            public static class PageBean {
                /**
                 * currentResult : 0
                 * entityOrField : false
                 * pageNumber : 1
                 * pageSize : 10
                 * pageStr :
                 * totalPage : 0
                 * totalResult : 0
                 */

                public int currentResult;
                public boolean entityOrField;
                public int pageNumber;
                public int pageSize;
                public String pageStr;
                public int totalPage;
                public int totalResult;
            }
        }
    }
}
