package com.freedom.supercoin.mode;

import java.util.List;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2020/2/20.
 * @desc :
 */
public class IntegralFragmentMode {

    /**
     * code : 0
     * count : null
     * data : {"data":[{"applyed":false,"assessPrice":128,"boutique":2,"categoryId":10,
     * "categoryName":"美妆护肤","channelId":"","clicked":false,"content":"","costPrice":40,
     * "createBy":"admin","createTime":"2019-11-22 02:34:38","deleted":0,"desc":"desc",
     * "description":"空气加湿器家用静音小型空调喷雾","deviceCode":"","deviceType":"","eendTime":"",
     * "endTime":null,"goodsDetail":"","goodsId":76,"goodsName":"空气加湿器家用静音小型空调喷雾",
     * "goodsSubType":null,"goodsType":2,"headImage":"[\"https://images.fmallnet
     * .com/b481880829074ae2a6942e67ac5fc019\",\"https://images.fmallnet
     * .com/5d571c1cfab247e8978b1928f9d9047e\",\"https://images.fmallnet
     * .com/b7cc91a6fa9943d793750527ea0f0614\",\"https://images.fmallnet
     * .com/f25914d9aee24ef4bc7dbd664131edb4\"]","integral":108,"inventory":1000,
     * "logo":"https://images.fmallnet.com/7cde79d6832947efbc80ac0d9f57026d","orderField":"",
     * "page":{"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,"pageStr":"",
     * "totalPage":0,"totalResult":0},"params":null,"price":null,"priceType":1,"remark":"",
     * "searchValue":"","soldNum":18,"sort":99999,"sstartTime":"","startTime":null,"status":2,
     * "supplier":"1688","supplierId":7,"updateBy":"cyz2019","updateTime":"2020-01-13 23:34:34",
     * "upperTime":null,"url5":"","url6":"","url7":"","url8":"","url9":""}],"page":{
     * "currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":1,"pageStr":"",
     * "totalPage":21,"totalResult":21}}
     * error : false
     * msg : 查询成功
     * result : true
     * success : true
     */

    public String code;
    public Object count;
    public DataBeanX data;
    public boolean error;
    public String msg;
    public boolean result;
    public boolean success;

    public static class DataBeanX {
        /**
         * data : [{"applyed":false,"assessPrice":128,"boutique":2,"categoryId":10,
         * "categoryName":"美妆护肤","channelId":"","clicked":false,"content":"","costPrice":40,
         * "createBy":"admin","createTime":"2019-11-22 02:34:38","deleted":0,"desc":"desc",
         * "description":"空气加湿器家用静音小型空调喷雾","deviceCode":"","deviceType":"","eendTime":"",
         * "endTime":null,"goodsDetail":"","goodsId":76,"goodsName":"空气加湿器家用静音小型空调喷雾",
         * "goodsSubType":null,"goodsType":2,"headImage":"[\"https://images.fmallnet
         * .com/b481880829074ae2a6942e67ac5fc019\",\"https://images.fmallnet
         * .com/5d571c1cfab247e8978b1928f9d9047e\",\"https://images.fmallnet
         * .com/b7cc91a6fa9943d793750527ea0f0614\",\"https://images.fmallnet
         * .com/f25914d9aee24ef4bc7dbd664131edb4\"]","integral":108,"inventory":1000,
         * "logo":"https://images.fmallnet.com/7cde79d6832947efbc80ac0d9f57026d","orderField":"",
         * "page":{"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,
         * "pageStr":"","totalPage":0,"totalResult":0},"params":null,"price":null,"priceType":1,
         * "remark":"","searchValue":"","soldNum":18,"sort":99999,"sstartTime":"",
         * "startTime":null,"status":2,"supplier":"1688","supplierId":7,"updateBy":"cyz2019",
         * "updateTime":"2020-01-13 23:34:34","upperTime":null,"url5":"","url6":"","url7":"",
         * "url8":"","url9":""}]
         * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":1,
         * "pageStr":"","totalPage":21,"totalResult":21}
         */

        public PageBean page;
        public List<DataBean> data;

        public static class PageBean {
            /**
             * currentResult : 0
             * entityOrField : false
             * pageNumber : 1
             * pageSize : 1
             * pageStr :
             * totalPage : 21
             * totalResult : 21
             */

            public int currentResult;
            public boolean entityOrField;
            public int pageNumber;
            public int pageSize;
            public String pageStr;
            public int totalPage;
            public int totalResult;
        }

        public static class DataBean {
            /**
             * applyed : false
             * assessPrice : 128.0
             * boutique : 2
             * categoryId : 10
             * categoryName : 美妆护肤
             * channelId :
             * clicked : false
             * content :
             * costPrice : 40.0
             * createBy : admin
             * createTime : 2019-11-22 02:34:38
             * deleted : 0
             * desc : desc
             * description : 空气加湿器家用静音小型空调喷雾
             * deviceCode :
             * deviceType :
             * eendTime :
             * endTime : null
             * goodsDetail :
             * goodsId : 76
             * goodsName : 空气加湿器家用静音小型空调喷雾
             * goodsSubType : null
             * goodsType : 2
             * headImage : ["https://images.fmallnet.com/b481880829074ae2a6942e67ac5fc019",
             * "https://images.fmallnet.com/5d571c1cfab247e8978b1928f9d9047e","https://images
             * .fmallnet.com/b7cc91a6fa9943d793750527ea0f0614","https://images.fmallnet
             * .com/f25914d9aee24ef4bc7dbd664131edb4"]
             * integral : 108.0
             * inventory : 1000
             * logo : https://images.fmallnet.com/7cde79d6832947efbc80ac0d9f57026d
             * orderField :
             * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,
             * "pageStr":"","totalPage":0,"totalResult":0}
             * params : null
             * price : null
             * priceType : 1
             * remark :
             * searchValue :
             * soldNum : 18
             * sort : 99999
             * sstartTime :
             * startTime : null
             * status : 2
             * supplier : 1688
             * supplierId : 7
             * updateBy : cyz2019
             * updateTime : 2020-01-13 23:34:34
             * upperTime : null
             * url5 :
             * url6 :
             * url7 :
             * url8 :
             * url9 :
             */

            public boolean applyed;
            public double assessPrice;
            public int boutique;
            public int categoryId;
            public String categoryName;
            public String channelId;
            public boolean clicked;
            public String content;
            public double costPrice;
            public String createBy;
            public String createTime;
            public int deleted;
            public String desc;
            public String description;
            public String deviceCode;
            public String deviceType;
            public String eendTime;
            public Object endTime;
            public String goodsDetail;
            public int goodsId;
            public String goodsName;
            public Object goodsSubType;
            public int goodsType;
            public String headImage;
            public double integral;
            public int inventory;
            public String logo;
            public String orderField;
            public PageBeanX page;
            public Object params;
            public Object price;
            public int priceType;
            public String remark;
            public String searchValue;
            public int soldNum;
            public int sort;
            public String sstartTime;
            public Object startTime;
            public int status;
            public String supplier;
            public int supplierId;
            public String updateBy;
            public String updateTime;
            public Object upperTime;
            public String url5;
            public String url6;
            public String url7;
            public String url8;
            public String url9;

            public static class PageBeanX {
                /**
                 * currentResult : 0
                 * entityOrField : false
                 * pageNumber : 1
                 * pageSize : 10
                 * pageStr :
                 * totalPage : 0
                 * totalResult : 0
                 */

                public int currentResult;
                public boolean entityOrField;
                public int pageNumber;
                public int pageSize;
                public String pageStr;
                public int totalPage;
                public int totalResult;
            }
        }
    }
}
