package com.freedom.supercoin.mode;

import java.util.List;

public class HomeAuctionRes {


    /**
     * code : 0
     * count : null
     * data : {"data":[{"addPriceRuleId":null,"applyed":false,"assessPrice":null,
     * "auctionId":8562,"brokerage":null,"categoryId":null,"categoryName":"","channelId":"",
     * "clicked":false,"costPrice":null,"createBy":"","createTime":null,"deleted":null,
     * "desc":"desc","deviceCode":"","deviceType":"","displayArea":null,"endEndTime":"",
     * "endStartPrice":null,"endStartTime":"","endTime":"2019-12-25 22:15:00","endTimes":null,
     * "fatherCategoryId":null,"goodsDetail":"","goodsId":null,"goodsName":"百雀羚三生花 小王子护肤化妆品套装
     * （玫瑰水乳+彩盘+化妆刷+玫瑰水小样*6+卸妆水+贴纸）","headImage":"","list":[],"logo":"https://images.fmallnet
     * .com/e8d8683692c74c09b48e9da06a3bd4fd","mailingUserId":null,"mallGoodsId":null,
     * "markupNum":44,"markupPrice":null,"maxProtectPrice":null,"openRobot":null,
     * "openRobotPrecent":null,"orderField":"","page":{"currentResult":0,"entityOrField":false,
     * "pageNumber":1,"pageSize":10,"pageStr":"","totalPage":0,"totalResult":0},"params":null,
     * "passTitle":"","platformGoodsId":null,"protectPrice":null,"remark":"","robotPrecent":null,
     * "searchValue":"","sort":null,"source":null,"startEndTime":"","startPrice":200,
     * "startStartPrice":null,"startStartTime":"","startTime":"2019-12-25 22:00:00",
     * "startTimes":null,"status":4,"supplier":"","supplierId":null,"topPrice":3280,
     * "transactionPrice":3280,"type":null,"updateBy":"","updateTime":null,"userId":null,
     * "username":"","viewCount":984}]}
     */

    public int code;
    public Boolean success;
    public Object count;
    public DataBeanX data;
    public String msg;
    public boolean result;
    public static class DataBeanX {
        public List<DataBean> data;

        public static class DataBean {
            /**
             * addPriceRuleId : null
             * applyed : false
             * assessPrice : null
             * auctionId : 8562
             * brokerage : null
             * categoryId : null
             * categoryName :
             * channelId :
             * clicked : false
             * costPrice : null
             * createBy :
             * createTime : null
             * deleted : null
             * desc : desc
             * deviceCode :
             * deviceType :
             * displayArea : null
             * endEndTime :
             * endStartPrice : null
             * endStartTime :
             * endTime : 2019-12-25 22:15:00
             * endTimes : null
             * fatherCategoryId : null
             * goodsDetail :
             * goodsId : null
             * goodsName : 百雀羚三生花 小王子护肤化妆品套装 （玫瑰水乳+彩盘+化妆刷+玫瑰水小样*6+卸妆水+贴纸）
             * headImage :
             * list : []
             * logo : https://images.fmallnet.com/e8d8683692c74c09b48e9da06a3bd4fd
             * mailingUserId : null
             * mallGoodsId : null
             * markupNum : 44
             * markupPrice : null
             * maxProtectPrice : null
             * openRobot : null
             * openRobotPrecent : null
             * orderField :
             * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,
             * "pageStr":"","totalPage":0,"totalResult":0}
             * params : null
             * passTitle :
             * platformGoodsId : null
             * protectPrice : null
             * remark :
             * robotPrecent : null
             * searchValue :
             * sort : null
             * source : null
             * startEndTime :
             * startPrice : 200.0
             * startStartPrice : null
             * startStartTime :
             * startTime : 2019-12-25 22:00:00
             * startTimes : null
             * status : 4
             * supplier :
             * supplierId : null
             * topPrice : 3280.0
             * transactionPrice : 3280.0
             * type : null
             * updateBy :
             * updateTime : null
             * userId : null
             * username :
             * viewCount : 984
             */

            public Object addPriceRuleId;
            public boolean applyed;
            public Object assessPrice;
            public int auctionId;
            public Object brokerage;
            public Object categoryId;
            public String categoryName;
            public String channelId;
            public boolean clicked;
            public Object costPrice;
            public String createBy;
            public Object createTime;
            public Object deleted;
            public String desc;
            public String deviceCode;
            public String deviceType;
            public Object displayArea;
            public String endEndTime;
            public Object endStartPrice;
            public String endStartTime;
            public String endTime;
            public Object endTimes;
            public Object fatherCategoryId;
            public String goodsDetail;
            public Object goodsId;
            public String goodsName;
            public String headImage;
            public String logo;
            public Object mailingUserId;
            public Object mallGoodsId;
            public int markupNum;
            public Object markupPrice;
            public Object maxProtectPrice;
            public Object openRobot;
            public Object openRobotPrecent;
            public String orderField;
            public PageBean page;
            public Object params;
            public String passTitle;
            public Object platformGoodsId;
            public Object protectPrice;
            public String remark;
            public Object robotPrecent;
            public String searchValue;
            public Object sort;
            public Object source;
            public String startEndTime;
            public double startPrice;
            public Object startStartPrice;
            public String startStartTime;
            public String startTime;
            public Object startTimes;
            public int status;
            public String supplier;
            public Object supplierId;
            public double topPrice;
            public double transactionPrice;
            public Object type;
            public String updateBy;
            public Object updateTime;
            public Object userId;
            public String username;
            public int viewCount;
            public List<?> list;

            public static class PageBean {
                /**
                 * currentResult : 0
                 * entityOrField : false
                 * pageNumber : 1
                 * pageSize : 10
                 * pageStr :
                 * totalPage : 0
                 * totalResult : 0
                 */

                public int currentResult;
                public boolean entityOrField;
                public int pageNumber;
                public int pageSize;
                public String pageStr;
                public int totalPage;
                public int totalResult;
            }
        }
    }
}
