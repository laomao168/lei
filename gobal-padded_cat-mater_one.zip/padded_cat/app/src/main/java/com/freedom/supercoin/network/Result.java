package com.freedom.supercoin.network;

public class Result<T> {
    public T data;
    public Boolean success;
    public String errCode;
    public String msg;
    public int size;
    public T body;


    public Result(T data, Boolean success, String errCode, String errMsg, int size) {
        this.data = data;
        this.success = success;
        this.errCode = errCode;
        this.msg = errMsg;
        this.size = size;
    }


    public T getBody() {
        return body;
    }


    public T getData() {
        return data;
    }


    public void setData(T data) {
        this.data = data;
    }


    public void setBody(T body) {
        this.body = body;
    }



    public String getErrCode() {
        return errCode;
    }


    public void setErrCode(String errCode) {
        this.errCode = errCode;
    }


    public String getErrMsg() {
        return msg;
    }


    public void setErrMsg(String errMsg) {
        this.msg = errMsg;
    }


    public int getSize() {
        return size;
    }


    public void setSize(int size) {
        this.size = size;
    }


    public ClientException checkResult() {
        if (msg.contains("成功")||msg.contains("success")||success) {
            return null;
        } else {
            return new ClientException(errCode, this.msg, null);
        }
    }

}
