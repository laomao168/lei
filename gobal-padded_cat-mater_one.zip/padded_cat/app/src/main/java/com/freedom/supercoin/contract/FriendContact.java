package com.freedom.supercoin.contract;


import com.freedom.supercoin.base_library.base.BasePresenter;
import com.freedom.supercoin.base_library.base.BaseView;
import com.freedom.supercoin.mode.FriendMode;
import com.freedom.supercoin.mode.MyFansMode;
import com.freedom.supercoin.mode.MySuperiorMode;


public class FriendContact {

    public interface View extends BaseView {

        void loadFriendSuccess(FriendMode friendMode);

        void loadFriendError();

        void getMyFansSuccess(MyFansMode mode);

        void getMySuperiorSuccess(MySuperiorMode mode);
    }


    public interface Presenter extends BasePresenter {
        void getMyFriend(int pageNumber);
        void getAllFriend(int pageNumber);
        void getMySuperior();
        void getMyFans();
    }
}

