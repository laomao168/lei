package com.freedom.supercoin.contract;


import com.freedom.supercoin.base_library.base.BasePresenter;
import com.freedom.supercoin.base_library.base.BaseView;
import com.freedom.supercoin.mode.BalanceDetailMode;
import com.freedom.supercoin.mode.ChargeTypeMode;
import com.freedom.supercoin.mode.NewPayRes;
import com.freedom.supercoin.mode.PayAlipayRes;
import com.freedom.supercoin.mode.PayReq;
import com.freedom.supercoin.mode.PayRes;


public class ChargeContact {

    public interface View extends BaseView {

        void onLoadChargeTypeSuccess(ChargeTypeMode mode);

        void onLoadPayResWechatSuccess(PayRes payRes, int payType);

        void getBalanceSuccess(BalanceDetailMode mode);

        void onLoadPayResAlipaySuccess(PayAlipayRes payAlipayRes, int payType);

        void onLoadNewAlipaySuccess(NewPayRes newPayRes);
    }


    public interface Presenter extends BasePresenter {
        void getChargeType();
        void  getPayInfo( PayReq payReq);
        void  getPayInfoNew( PayReq payReq);
        void  getBalance();
    }
}

