package com.freedom.supercoin.adapter;

import android.databinding.DataBindingUtil;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.freedom.supercoin.R;
import com.freedom.supercoin.base_library.AppConst;
import com.freedom.supercoin.base_library.base.BaseEmptyAdapter;
import com.freedom.supercoin.base_library.utils.GlideUtils;
import com.freedom.supercoin.base_library.utils.SPUtils;
import com.freedom.supercoin.base_library.utils.StrUtils;
import com.freedom.supercoin.databinding.ItemGoodsBidBinding;
import com.freedom.supercoin.databinding.ItemGoodsRankBinding;
import com.freedom.supercoin.mode.AuctionAddMode;
import com.freedom.supercoin.mode.GoodBidMode;
import com.freedom.supercoin.mode.GoodsRankListMode;


public class GoodsBidAdapter extends BaseEmptyAdapter<AuctionAddMode,
        ItemGoodsBidBinding> {
    private double brokerage;
    private int userId;

    @Override
    protected ItemGoodsBidBinding createBinding(ViewGroup parent) {
        userId = SPUtils.getInstance().getInt(AppConst.Keys.USER_ID, 0);
        return DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()),
                R.layout.item_goods_bid, parent, false);
    }

    @Override
    protected void onBindView(ItemGoodsBidBinding binding, AuctionAddMode bean,
                              int position) {
        if (position == 0) {
            binding.rlOther.setVisibility(View.VISIBLE);
            binding.rlMe.setVisibility(View.GONE);
            binding.tvBidDesOther.setText("欢迎大家参与本场拍卖！请仔细阅读下面的拍前须知。\n" +
                    "1.点击右下角”出价“按钮，即可出价；如账号余额不够，系统会提示您充值保证金。\n" +
                    "2.保证金比例为拍品当前价格的20%，出价即冻结，出价被超越即释放。\n" +
                    "3.如果本次出价被人超越，则可获得一定的拍卖收益红包奖励。\n" +
                    "4.竞买人出价到达保留价或竞拍时间结束，则竞拍成功。\n" +
                    "5.请在24小时内支付尾款，否则系统将自动关闭并扣除保证金。\n" +
                    "6.只显示最近20条拍卖记录\n" +
                    "希望大家能在乐拍享受到拍卖的乐趣。");
            binding.ivUserImageOther.setImageResource(R.mipmap.img_salesroom_logo);
            binding.tvNikeNameOther.setText("乐拍");
            binding.tvTime.setVisibility(View.GONE);
        } else {
            binding.tvTime.setVisibility(View.VISIBLE);
            if (bean.userId!=userId){
                binding.rlOther.setVisibility(View.VISIBLE);
                binding.rlMe.setVisibility(View.GONE);
                GlideUtils.loadRound(context, bean.avatar.trim(), binding.ivUserImageOther,20);
                binding.tvNikeNameOther.setText(bean.userName);
                binding.tvBidDesOther.setText( String.format(context.getString(R.string.bid_content),
                        StrUtils.getRemoveZreoNum(bean.payPrice), StrUtils.getRemoveZreoNum(brokerage)));
                binding.tvTime.setText(bean.markupTime);
            }else {
                binding.rlOther.setVisibility(View.GONE);
                binding.rlMe.setVisibility(View.VISIBLE);
                GlideUtils.loadRound(context, bean.avatar.trim(), binding.ivUserImageMe,20);
                binding.tvNikeNameMe.setText(bean.userName);
                binding.tvBidDesMe.setText( String.format(context.getString(R.string.bid_content),
                        StrUtils.getRemoveZreoNum(bean.payPrice), StrUtils.getRemoveZreoNum(brokerage)));
                binding.tvTime.setText(bean.markupTime);
            }


        }
    }

    public void setBrokerage(double brokerage) {

        this.brokerage = brokerage;
    }
}
