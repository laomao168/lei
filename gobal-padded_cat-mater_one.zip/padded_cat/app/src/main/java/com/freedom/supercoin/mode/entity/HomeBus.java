package com.freedom.supercoin.mode.entity;

public class HomeBus {
    public  int index;
}
