package com.freedom.supercoin.contract;


import com.freedom.supercoin.base_library.base.BasePresenter;
import com.freedom.supercoin.base_library.base.BaseView;
import com.freedom.supercoin.mode.IntegralMode;


public class IntegralPresenterContact {

    public interface View extends BaseView {

        void getIntegralSuccess(IntegralMode mode);
    }


    public interface Presenter extends BasePresenter {
        void  getIntegralList();
    }
}

