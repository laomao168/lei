package com.freedom.supercoin.persenter;

import com.freedom.supercoin.contract.MeContact;
import com.freedom.supercoin.mode.OrderStatisticsMode;
import com.freedom.supercoin.mode.UserInfoMode;
import com.freedom.supercoin.network.DataManager;
import com.freedom.supercoin.network.ResponseErrorFunc;
import com.freedom.supercoin.network.RxUtils;

import rx.Subscriber;


public class MePresenter implements MeContact.Presenter {

    private final MeContact.View view;

    public MePresenter(MeContact.View view) {
        this.view = view;
    }

    @Override
    public void getUserInfo() {
        DataManager.getInstance()
                .getUserInfo()
                .compose(RxUtils.applyIOSchedulers())
                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<UserInfoMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(UserInfoMode userInfoMode) {
                        view.onLoadUserInfoSuccess(userInfoMode);
                        view.hideProgress();
                    }
                });

    }

    @Override
    public void getOrderInfo() {
        DataManager.getInstance()
                .getOrderInfo()
                .compose(RxUtils.applyIOSchedulers())
                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<OrderStatisticsMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(OrderStatisticsMode orderStatisticsMode) {
                        view.onLoadOrderStaticsSuccess(orderStatisticsMode);
                        view.hideProgress();
                    }
                });
    }


}
