package com.freedom.supercoin.activity;

import android.support.v7.widget.LinearLayoutManager;

import com.freedom.supercoin.R;
import com.freedom.supercoin.adapter.ChargeAdapter;
import com.freedom.supercoin.base_library.widget.spingview.DefaultFooter;
import com.freedom.supercoin.base_library.widget.spingview.SpringView;
import com.freedom.supercoin.common.UiActivity;
import com.freedom.supercoin.contract.ChargeDetailContact;
import com.freedom.supercoin.databinding.ActivityChargeDetailBinding;
import com.freedom.supercoin.mode.ChargeDetailMode;
import com.freedom.supercoin.mode.entity.Page;
import com.freedom.supercoin.persenter.ChargeDetailPresenter;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2020/1/10.
 * @desc :
 */
public class ChargeDetailActivity extends UiActivity<ActivityChargeDetailBinding> implements ChargeDetailContact.View {

    private int currentIndex;
    private ChargeAdapter adapter;
    private ChargeDetailPresenter presenter;

    @Override
    protected int layoutResId() {
        return R.layout.activity_charge_detail;
    }

    @Override
    protected void initData() {
        initSpringView();
        binding.recycleView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ChargeAdapter();
        binding.recycleView.setAdapter(adapter);
        presenter = new ChargeDetailPresenter(this);
        currentIndex = 1;
        loadList();
    }

    @Override
    protected void initEvent() {

    }

    private void initSpringView() {
        binding.springView.setType(SpringView.Type.FOLLOW);
        binding.springView.setListener(new SpringView.OnFreshListener() {
            @Override
            public void onRefresh() {
                currentIndex = 1;
                loadList();
            }

            @Override
            public void onLoadMore() {
                currentIndex++;
                loadList();
            }
        });
        binding.springView.setFooter(new DefaultFooter(this));
    }

    private void loadList() {
        Page page = new Page();
        page.pageNumber = currentIndex;
        page.pageSize = 20;
        presenter.getChargeList(page);
    }

    @Override
    public void onLoadChargeListSuccess(ChargeDetailMode mode) {
        if (mode == null || !mode.msg.contains("成功")) return;
        if (currentIndex == 1) {
            adapter.setData(mode.data.data);
        } else {
            adapter.addDataList(mode.data.data);
        }
    }
}
