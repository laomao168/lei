package com.freedom.supercoin.fragment;

import com.freedom.supercoin.common.UILazyFragment;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2019/7/18.
 */

public class aFragment extends UILazyFragment {
    @Override
    protected int getLayoutId() {
        return 0;
    }


    @Override
    protected void initData() {

    }

    @Override
    protected void initEvent() {

    }
}
