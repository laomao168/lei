package com.freedom.supercoin.mode;

import java.util.List;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2019/12/31.
 * @desc :
 */
public class OrderMode {

    /**
     * code :
     * count : null
     * data : {"data":[{"address":"浙江省杭州市余杭区五常街道大大大大大","addressId":670,"applyed":false,
     * "auctionDetailId":297447,"auctionId":9406,"buyerNamePhone":"","carrierId":null,
     * "channelId":"","clicked":false,"consignee":"姜平","contractUrl":"","costPrice":810,
     * "createBy":"system","createTime":"2019-12-27 18:40:01","createTimeString":"","deleted":0,
     * "deliverTime":"2019-12-30 18:02:42","deliverTimeString":"","desc":"desc","deviceCode":"",
     * "deviceType":"","displayArea":1,"endCreateTime":null,"endDate":"","endTime":null,
     * "endTimes":null,"fallReasons":"","goodsId":2330,"goodsName":"雅诗兰黛（Estee
     * Lauder）多效智妍面霜50ml","goodsNameId":"","id":null,"logisticsCode":"","logisticsName":"申通快递",
     * "logisticsNo":"13213213213","logo":"https://images.oneauct
     * .com/343e59e6def7460c8deedad5020fa1a0","mobile":"17794559973","money":null,
     * "orderField":"","orderId":4076,"orderNo":"LP191227184001816577","orderPrice":5080,
     * "orderStatus":3,"orderType":1,"page":{"currentResult":0,"entityOrField":false,
     * "pageNumber":1,"pageSize":10,"pageStr":"","totalPage":0,"totalResult":0},"params":null,
     * "payStatus":1,"payTime":"2019-12-27 18:41:15","payTimeString":"","payType":null,
     * "phone":"17794559973","pledgePrice":1270,"remark":"","searchValue":"",
     * "startCreateTime":null,"startTime":null,"status":null,"statusText":"","supplier":"JD",
     * "supplierId":4,"transactionId":"","transactionPrice":6350,"type":1,"updateBy":"15",
     * "updateTime":"2019-12-30 19:53:17","updateTimeString":"","userId":15,"userName":"痞子",
     * "username":""},{"address":"浙江省杭州市余杭区五常街道大大大大大","addressId":670,"applyed":false,
     * "auctionDetailId":297013,"auctionId":9407,"buyerNamePhone":"","carrierId":null,
     * "channelId":"","clicked":false,"consignee":"姜平","contractUrl":"","costPrice":300,
     * "createBy":"system","createTime":"2019-12-27 18:10:01","createTimeString":"","deleted":0,
     * "deliverTime":"2019-12-30 18:03:05","deliverTimeString":"","desc":"desc","deviceCode":"",
     * "deviceType":"","displayArea":1,"endCreateTime":null,"endDate":"","endTime":null,
     * "endTimes":null,"fallReasons":"","goodsId":609,"goodsName":"babycare儿童餐具套装不锈钢宝宝礼盒套装7件套",
     * "goodsNameId":"","id":null,"logisticsCode":"","logisticsName":"申通快递",
     * "logisticsNo":"434324324","logo":"https://images.fmallnet
     * .com/d3226b82682b4c1eb716f628b5a0ae42","mobile":"17794559973","money":null,
     * "orderField":"","orderId":4069,"orderNo":"LP191227181001659537","orderPrice":2720,
     * "orderStatus":3,"orderType":1,"page":{"currentResult":0,"entityOrField":false,
     * "pageNumber":1,"pageSize":10,"pageStr":"","totalPage":0,"totalResult":0},"params":null,
     * "payStatus":1,"payTime":"2019-12-27 18:16:01","payTimeString":"","payType":null,
     * "phone":"17794559973","pledgePrice":680,"remark":"","searchValue":"",
     * "startCreateTime":null,"startTime":null,"status":null,"statusText":"","supplier":"JD",
     * "supplierId":4,"transactionId":"","transactionPrice":3400,"type":1,"updateBy":"15",
     * "updateTime":"2019-12-30 19:53:23","updateTimeString":"","userId":15,"userName":"痞子",
     * "username":""}],"page":{"currentResult":0,"entityOrField":false,"pageNumber":1,
     * "pageSize":10,"pageStr":"","totalPage":1,"totalResult":2}}
     * error : false
     * msg : 查询成功
     * result : true
     * success : true
     */

    public String code;
    public Object count;
    public DataBeanX data;
    public boolean error;
    public String msg;
    public boolean result;
    public boolean success;

    public static class DataBeanX {
        /**
         * data : [{"address":"浙江省杭州市余杭区五常街道大大大大大","addressId":670,"applyed":false,
         * "auctionDetailId":297447,"auctionId":9406,"buyerNamePhone":"","carrierId":null,
         * "channelId":"","clicked":false,"consignee":"姜平","contractUrl":"","costPrice":810,
         * "createBy":"system","createTime":"2019-12-27 18:40:01","createTimeString":"",
         * "deleted":0,"deliverTime":"2019-12-30 18:02:42","deliverTimeString":"","desc":"desc",
         * "deviceCode":"","deviceType":"","displayArea":1,"endCreateTime":null,"endDate":"",
         * "endTime":null,"endTimes":null,"fallReasons":"","goodsId":2330,"goodsName":"雅诗兰黛（Estee
         * Lauder）多效智妍面霜50ml","goodsNameId":"","id":null,"logisticsCode":"",
         * "logisticsName":"申通快递","logisticsNo":"13213213213","logo":"https://images.oneauct
         * .com/343e59e6def7460c8deedad5020fa1a0","mobile":"17794559973","money":null,
         * "orderField":"","orderId":4076,"orderNo":"LP191227184001816577","orderPrice":5080,
         * "orderStatus":3,"orderType":1,"page":{"currentResult":0,"entityOrField":false,
         * "pageNumber":1,"pageSize":10,"pageStr":"","totalPage":0,"totalResult":0},"params
         * ":null,"payStatus":1,"payTime":"2019-12-27 18:41:15","payTimeString":"",
         * "payType":null,"phone":"17794559973","pledgePrice":1270,"remark":"","searchValue":"",
         * "startCreateTime":null,"startTime":null,"status":null,"statusText":"","supplier":"JD",
         * "supplierId":4,"transactionId":"","transactionPrice":6350,"type":1,"updateBy":"15",
         * "updateTime":"2019-12-30 19:53:17","updateTimeString":"","userId":15,"userName":"痞子",
         * "username":""},{"address":"浙江省杭州市余杭区五常街道大大大大大","addressId":670,"applyed":false,
         * "auctionDetailId":297013,"auctionId":9407,"buyerNamePhone":"","carrierId":null,
         * "channelId":"","clicked":false,"consignee":"姜平","contractUrl":"","costPrice":300,
         * "createBy":"system","createTime":"2019-12-27 18:10:01","createTimeString":"",
         * "deleted":0,"deliverTime":"2019-12-30 18:03:05","deliverTimeString":"","desc":"desc",
         * "deviceCode":"","deviceType":"","displayArea":1,"endCreateTime":null,"endDate":"",
         * "endTime":null,"endTimes":null,"fallReasons":"","goodsId":609,
         * "goodsName":"babycare儿童餐具套装不锈钢宝宝礼盒套装7件套","goodsNameId":"","id":null,
         * "logisticsCode":"","logisticsName":"申通快递","logisticsNo":"434324324",
         * "logo":"https://images.fmallnet.com/d3226b82682b4c1eb716f628b5a0ae42",
         * "mobile":"17794559973","money":null,"orderField":"","orderId":4069,
         * "orderNo":"LP191227181001659537","orderPrice":2720,"orderStatus":3,"orderType":1,
         * "page":{"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,
         * "pageStr":"","totalPage":0,"totalResult":0},"params":null,"payStatus":1,
         * "payTime":"2019-12-27 18:16:01","payTimeString":"","payType":null,
         * "phone":"17794559973","pledgePrice":680,"remark":"","searchValue":"",
         * "startCreateTime":null,"startTime":null,"status":null,"statusText":"","supplier":"JD",
         * "supplierId":4,"transactionId":"","transactionPrice":3400,"type":1,"updateBy":"15",
         * "updateTime":"2019-12-30 19:53:23","updateTimeString":"","userId":15,"userName":"痞子",
         * "username":""}]
         * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,
         * "pageStr":"","totalPage":1,"totalResult":2}
         */

        public PageBean page;
        public List<DataBean> data;

        public static class PageBean {
            /**
             * currentResult : 0
             * entityOrField : false
             * pageNumber : 1
             * pageSize : 10
             * pageStr :
             * totalPage : 1
             * totalResult : 2
             */

            public int currentResult;
            public boolean entityOrField;
            public int pageNumber;
            public int pageSize;
            public String pageStr;
            public int totalPage;
            public int totalResult;
        }

        public static class DataBean {
            /**
             * address : 浙江省杭州市余杭区五常街道大大大大大
             * addressId : 670
             * applyed : false
             * auctionDetailId : 297447
             * auctionId : 9406
             * buyerNamePhone :
             * carrierId : null
             * channelId :
             * clicked : false
             * consignee : 姜平
             * contractUrl :
             * costPrice : 810.0
             * createBy : system
             * createTime : 2019-12-27 18:40:01
             * createTimeString :
             * deleted : 0
             * deliverTime : 2019-12-30 18:02:42
             * deliverTimeString :
             * desc : desc
             * deviceCode :
             * deviceType :
             * displayArea : 1
             * endCreateTime : null
             * endDate :
             * endTime : null
             * endTimes : null
             * fallReasons :
             * goodsId : 2330
             * goodsName : 雅诗兰黛（Estee Lauder）多效智妍面霜50ml
             * goodsNameId :
             * id : null
             * logisticsCode :
             * logisticsName : 申通快递
             * logisticsNo : 13213213213
             * logo : https://images.oneauct.com/343e59e6def7460c8deedad5020fa1a0
             * mobile : 17794559973
             * money : null
             * orderField :
             * orderId : 4076
             * orderNo : LP191227184001816577
             * orderPrice : 5080.0
             * orderStatus : 3
             * orderType : 1
             * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,
             * "pageStr":"","totalPage":0,"totalResult":0}
             * params : null
             * payStatus : 1
             * payTime : 2019-12-27 18:41:15
             * payTimeString :
             * payType : null
             * phone : 17794559973
             * pledgePrice : 1270.0
             * remark :
             * searchValue :
             * startCreateTime : null
             * startTime : null
             * status : null
             * statusText :
             * supplier : JD
             * supplierId : 4
             * transactionId :
             * transactionPrice : 6350.0
             * type : 1
             * updateBy : 15
             * updateTime : 2019-12-30 19:53:17
             * updateTimeString :
             * userId : 15
             * userName : 痞子
             * username :
             */

            public String address;
            public int addressId;
            public boolean applyed;
            public int auctionDetailId;
            public int auctionId;
            public String buyerNamePhone;
            public Object carrierId;
            public String channelId;
            public boolean clicked;
            public String consignee;
            public String contractUrl;
            public double costPrice;
            public String createBy;
            public String createTime;
            public String createTimeString;
            public int deleted;
            public String deliverTime;
            public String deliverTimeString;
            public String desc;
            public String deviceCode;
            public String deviceType;
            public int displayArea;
            public Object endCreateTime;
            public String endDate;
            public Object endTime;
            public Object endTimes;
            public String fallReasons;
            public int goodsId;
            public String goodsName;
            public String goodsNameId;
            public Object id;
            public String logisticsCode;
            public String logisticsName;
            public String logisticsNo;
            public String logo;
            public String mobile;
            public Object money;
            public String orderField;
            public int orderId;
            public String orderNo;
            public double orderPrice;
            public int orderStatus;
            public int orderType;
            public PageBeanX page;
            public Object params;
            public int payStatus;
            public String payTime;
            public String payTimeString;
            public Object payType;
            public String phone;
            public double pledgePrice;
            public String remark;
            public String searchValue;
            public Object startCreateTime;
            public Object startTime;
            public Object status;
            public String statusText;
            public String supplier;
            public int supplierId;
            public String transactionId;
            public double transactionPrice;
            public int type;
            public String updateBy;
            public String updateTime;
            public String updateTimeString;
            public int userId;
            public String userName;
            public String username;

            public static class PageBeanX {
                /**
                 * currentResult : 0
                 * entityOrField : false
                 * pageNumber : 1
                 * pageSize : 10
                 * pageStr :
                 * totalPage : 0
                 * totalResult : 0
                 */

                public int currentResult;
                public boolean entityOrField;
                public int pageNumber;
                public int pageSize;
                public String pageStr;
                public int totalPage;
                public int totalResult;
            }
        }
    }
}
