package com.freedom.supercoin.mode;

public class UserInfoMode {

    /**
     * amount : 0.0
     * fanNums : 0
     * integralAmount : 0
     * invitationCode : R75083
     * nickname : 185***8679
     * phone : 18566398679
     */

    public double amount;
    public int fanNums;
    public int integralAmount;
    public String invitationCode;
    public String nickname;
    public String phone;
}
