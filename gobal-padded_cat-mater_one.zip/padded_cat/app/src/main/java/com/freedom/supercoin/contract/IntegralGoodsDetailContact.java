package com.freedom.supercoin.contract;


import com.freedom.supercoin.base_library.base.BasePresenter;
import com.freedom.supercoin.base_library.base.BaseView;
import com.freedom.supercoin.mode.IntegralGoodsDetailBean;
import com.freedom.supercoin.mode.IntegralOrderBean;


public class IntegralGoodsDetailContact {

    public interface View extends BaseView {

        void onLoadIntegralGoodsDetailSuccess(IntegralGoodsDetailBean bean);

        void onPerPaySuccess(IntegralOrderBean integralGoodsDetailBean);
    }


    public interface Presenter extends BasePresenter {
        void loadIntegralGoodsDetail(int goodId);
        void perPay(int goodId);
    }
}

