package com.freedom.supercoin.dialog;

import android.graphics.Color;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.Window;

import com.freedom.supercoin.R;
import com.freedom.supercoin.base_library.dialog.BaseDialog;
import com.freedom.supercoin.mode.StreetMode;
import com.zyyoona7.wheel.WheelView;

import java.util.ArrayList;
import java.util.List;

public class StreetDialog extends BaseDialog {

    private WheelView<StreetMode> streetWheel;
    private List<StreetMode> streetList = new ArrayList<>();

    @Override
    protected int setContentId() {
        return R.layout.dialog_street;
    }

    @Override
    protected void initView() {
        streetWheel = findView(R.id.wheel_street);
        streetWheel.setData(streetList);
        streetWheel.setTextSize(20f, true);
        streetWheel.setNormalItemTextColor(Color.parseColor("#666666"));
        streetWheel.setShowDivider(true);
        streetWheel.setDividerColor(Color.parseColor("#80999999"));
    }

    @Override
    protected void initData() {
        streetWheel.setOnItemSelectedListener((wheelView, data, position) -> {
            if (streetItemSelectInterface != null) {
                streetItemSelectInterface.onStreetSelect(position);
            }
        });
        findView(R.id.tv_confirm).setOnClickListener(v -> {
            if (streetItemSelectInterface != null) {
                streetItemSelectInterface.OnStreetConfirm();
            }
            dismiss();
        });
    }

    @Override
    public void onStart() {
        super.onStart();
        DisplayMetrics dm = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(dm);
        Window window = getDialog().getWindow();
        window.setLayout(dm.widthPixels, window.getAttributes().height);
        window.setGravity(Gravity.BOTTOM);
    }

    public void setData(List<StreetMode> streetList) {
        this.streetList.clear();
        this.streetList.addAll(streetList);
    }

    public interface StreetItemSelectInterface {
        void onStreetSelect(int index);

        void OnStreetConfirm();
    }

    public StreetItemSelectInterface streetItemSelectInterface;

    public void setStreetItemSelectInterface(StreetItemSelectInterface streetItemSelectInterface) {
        this.streetItemSelectInterface = streetItemSelectInterface;
    }
}
