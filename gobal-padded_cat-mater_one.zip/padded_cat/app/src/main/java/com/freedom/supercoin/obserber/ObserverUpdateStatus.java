package com.freedom.supercoin.obserber;

/**
 * 反馈更新状态
 */
public interface ObserverUpdateStatus {

    void notifyPayState(boolean status);

    void notifyChangedProgress(float v);
}
