package com.freedom.supercoin.adapter;

import android.databinding.DataBindingUtil;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.freedom.supercoin.R;
import com.freedom.supercoin.base_library.base.BaseEmptyAdapter;
import com.freedom.supercoin.base_library.utils.GlideUtils;
import com.freedom.supercoin.databinding.ItemAddressBinding;
import com.freedom.supercoin.databinding.ItemGoodsCategoryBinding;
import com.freedom.supercoin.mode.AddressListMode;
import com.freedom.supercoin.mode.GoodsCategoryMode;


public class GoodsCategoryAdapter extends BaseEmptyAdapter<GoodsCategoryMode, ItemGoodsCategoryBinding> {

    @Override
    protected ItemGoodsCategoryBinding createBinding(ViewGroup parent) {
        return DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()),
                R.layout.item_goods_category, parent, false);
    }

    @Override
    protected void onBindView(ItemGoodsCategoryBinding binding, GoodsCategoryMode bean, int position) {
        GlideUtils.loadImage(context,bean.pic,binding.ivImage);
        binding.tvName.setText(bean.name);
        binding.rlRoot.setOnClickListener(v -> {
            if (onItemClickListener!=null){
                onItemClickListener.onItemClick(position,bean);
            }
        });
    }

}
