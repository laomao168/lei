package com.freedom.supercoin.obserber;



/**
 * Created by xx on 2016/9/1.
 */
public interface ObserverWebSocket {

    void notifyWebMessage(String mes);


}
