package com.freedom.supercoin.activity;

import android.Manifest;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.View;

import com.freedom.supercoin.R;
import com.freedom.supercoin.base_library.AppConst;
import com.freedom.supercoin.base_library.utils.GlideUtils;
import com.freedom.supercoin.base_library.utils.PermissionUtils;
import com.freedom.supercoin.base_library.utils.SPUtils;
import com.freedom.supercoin.common.UiActivity;
import com.freedom.supercoin.contract.PersonalContact;
import com.freedom.supercoin.databinding.ActivityPersonalCenterBinding;
import com.freedom.supercoin.mode.ImageUploadMode;
import com.freedom.supercoin.mode.UpdateNikeNameMode;
import com.freedom.supercoin.persenter.PersonalPresenter;
import com.freedom.supercoin.utils.GlideLoader;
import com.lzy.imagepicker.ImagePicker;
import com.lzy.imagepicker.bean.ImageItem;
import com.lzy.imagepicker.ui.ImageGridActivity;
import com.lzy.imagepicker.view.CropImageView;

import java.io.File;
import java.util.ArrayList;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;

/**
 * @author : lijianping
 * @date : Created on 2019/7/11.
 * des:
 */
public class PersonalCenterActivity extends UiActivity<ActivityPersonalCenterBinding> implements PersonalContact.View {

    private PersonalPresenter presenter;
    private String inviteCode;
    private String imageUrl="";

    @Override
    protected int layoutResId() {
        return R.layout.activity_personal_center;
    }

    @Override
    protected void initData() {
        presenter = new PersonalPresenter(this);
        binding.titleBar.setTextColor("#ffffff");
        binding.titleBar.setTitle("个人资料");
        binding.titleBar.setLeftImage(R.mipmap.ic_back_white);
        binding.etNikeName.setText(SPUtils.getInstance().getString(AppConst.Keys.NICKNAME));
        inviteCode = SPUtils.getInstance().getString(AppConst.Keys.INVITATION_CODE, "");
        binding.tvPhone.setText(SPUtils.getInstance().getString(AppConst.Keys.PHONE));

        GlideUtils.loadRound(this, SPUtils.getInstance().getString(AppConst.Keys.AVATAR),
                binding.ivUserImage, 12);
        if (TextUtils.isEmpty(inviteCode)) {
            binding.tvInviteCode.setVisibility(View.GONE);
            binding.etCode.setVisibility(View.VISIBLE);
            binding.tvSaveInviteCode.setVisibility(View.VISIBLE);
        } else {
            binding.tvInviteCode.setText(inviteCode);
            binding.tvInviteCode.setVisibility(View.VISIBLE);
            binding.etCode.setVisibility(View.GONE);
            binding.tvSaveInviteCode.setVisibility(View.GONE);
        }
    }

    @Override
    protected void initEvent() {
        binding.setClick(v -> {
            switch (v.getId()) {
                case R.id.tv_save_invite_Code:
                    saveInviteCode();
                    break;
                case R.id.iv_user_image:
                    checkGranted();
                    break;
                case R.id.tv_save_image:
                    saveImage();
                    break;
            }
        });
    }

    private void saveImage() {
        presenter.updateNikeName(binding.etNikeName.getText().toString().trim(),imageUrl);
    }

    private void checkGranted() {
        ArrayList<String> list = new ArrayList<>();
        list.add(Manifest.permission.CAMERA);
        list.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        list.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        if (PermissionUtils.checkPermission(this, list)) {
            chooseImage();
        }
    }

    /**
     * 打开相册
     */
    private void chooseImage() {
        ImagePicker imagePicker = ImagePicker.getInstance();
        imagePicker.setImageLoader(new GlideLoader());   //设置图片加载器
        imagePicker.setShowCamera(true);  //显示拍照按钮
        imagePicker.setMultiMode(false);    //设置单选多选模式
        imagePicker.setCrop(true);        //允许裁剪（单选才有效）
        imagePicker.setSaveRectangle(true); //是否按矩形区域保存
        imagePicker.setSelectLimit(1);    //选中数量限制
        imagePicker.setStyle(CropImageView.Style.RECTANGLE);  //裁剪框的形状
        imagePicker.setFocusWidth(260);   //裁剪框的宽度。单位像素（圆形自动取宽高最小值）
        imagePicker.setFocusHeight(260);  //裁剪框的高度。单位像素（圆形自动取宽高最小值）
        imagePicker.setOutPutX(260);//保存文件的宽度。单位像素
        imagePicker.setOutPutY(260);//保存文件的高度。单位像素
        Intent intent = new Intent(this, ImageGridActivity.class);
        startActivityForResult(intent, 1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == ImagePicker.RESULT_CODE_ITEMS) {
            if (data != null && requestCode == 1) {
                ArrayList<ImageItem> images = (ArrayList<ImageItem>) data.getSerializableExtra(ImagePicker.EXTRA_RESULT_ITEMS);
                if (images!=null&&images.size()>0){
                    String imagePath = images.get(0).path;
                    GlideUtils.loadImage(this, imagePath,binding.ivUserImage);
                    uploadImage(imagePath);
                }

            }
        }
    }

    /**
     * 上传
     * @param imagePath
     */
    private void uploadImage(String imagePath) {

        // 获取文件路劲
        File  mFile = new File(imagePath);
        if (!mFile.exists())return;
        // 创建Retrofit对象

        // 上传普通参数
        MediaType mediaType = MediaType.parse("application/octet-stream");
        RequestBody requetBody = RequestBody.create(mediaType, "abc");

        // 上传文件参数
        RequestBody body = RequestBody.create(MediaType.parse("image/jpg"), mFile);
        MultipartBody.Part file = MultipartBody.Part.createFormData("file", mFile.getName(), body);
        presenter.uploadImage(requetBody,file);

    }

    private void saveInviteCode() {
        inviteCode = binding.etCode.getText().toString();
        if (TextUtils.isEmpty(inviteCode)) {
            showMessage("请输入邀请码");
            return;
        }
        presenter.saveInviteCode(inviteCode);
    }

    @Override
    public void onSuccess() {
        showMessage("保存成功");
        SPUtils.getInstance().put(AppConst.Keys.INVITATION_CODE, inviteCode);
        binding.tvInviteCode.setText(inviteCode);
        binding.tvInviteCode.setVisibility(View.VISIBLE);
        binding.etCode.setVisibility(View.GONE);
        binding.tvSaveInviteCode.setVisibility(View.GONE);
    }

    @Override
    public void onUploadImageSuccess(ImageUploadMode mode) {
        showMessage(mode.msg);
        imageUrl = mode.data;
    }

    @Override
    public void onUpdateNikeNameSuccess(UpdateNikeNameMode mode) {
       showMessage(mode.msg);
       if (mode.success){
           SPUtils.getInstance().put(AppConst.Keys.AVATAR,imageUrl);
       }
    }
}
