package com.freedom.supercoin.common;

import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.os.Bundle;
import android.view.ViewTreeObserver;
import android.view.WindowManager;

import com.freedom.supercoin.base_library.AppConst;
import com.freedom.supercoin.base_library.base.BaseActivity;
import com.freedom.supercoin.base_library.utils.Operation;
import com.freedom.supercoin.dialog.NetworkTipsDialog;
import com.gyf.barlibrary.ImmersionBar;
import com.hjq.toast.ToastUtils;
import com.trello.rxlifecycle.android.FragmentEvent;

import rx.Observable;

/**
 * Created by jianping on 2018/11/19.
 * 沉浸式状态栏 全局加载 view显示和隐藏
 */

public abstract class UiActivity<T extends ViewDataBinding> extends BaseActivity implements
        ViewTreeObserver.OnGlobalLayoutListener {

    public T binding;
    private ImmersionBar mImmersionBar;//状态栏沉浸
    private NetworkTipsDialog dialogTips;
    private Operation mBaseOperation;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // 在 super.onCreate(savedInstanceState) 之前调用该方法
        if (layoutResId() > 0) {
            binding = DataBindingUtil.setContentView(this, layoutResId());
    }
        super.onCreate(savedInstanceState);
    }

    @Override
    public void init() {
        //初始化沉浸式状态栏
        if (isStatusBarEnabled()) {
            statusBarConfig().init();
        }
        //设置标题栏
        if (getTitleBarId() > 0) {
            ImmersionBar.setTitleBar(this, findViewById(getTitleBarId()));
        }
        mBaseOperation = new Operation(this);
        super.init();
    }


    /**
     * 是否使用沉浸式状态栏
     */
    public boolean isStatusBarEnabled() {
        return true;
    }

    /**
     * 获取状态栏沉浸的配置对象
     */
    public ImmersionBar getStatusBarConfig() {
        return mImmersionBar;
    }

    /**
     * 初始化沉浸式状态栏
     */
    private ImmersionBar statusBarConfig() {
        //在BaseActivity里初始化
        mImmersionBar = ImmersionBar.with(this)
                .statusBarDarkFont(statusBarDarkFont())    //默认状态栏字体颜色为黑色
                .keyboardEnable(false, WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN
                        | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        //解决软键盘与底部输入框冲突问题，默认为false，还有一个重载方法，可以指定软键盘mode
        //必须设置View树布局变化监听，否则软键盘无法顶上去，还有模式必须是SOFT_INPUT_ADJUST_PAN
        getWindow().getDecorView().getViewTreeObserver().addOnGlobalLayoutListener(this);
        return mImmersionBar;
    }

    /**
     * {@link ViewTreeObserver.OnGlobalLayoutListener}
     */
    @Override
    public void onGlobalLayout() {
    }//不用写任何方法

    /**
     * 获取状态栏字体颜色
     */
    public boolean statusBarDarkFont() {
        //返回false表示白色字体
        return true;
    }
    /**
     * 获取共通操作机能
     */
    public Operation getOperation(){
        return this.mBaseOperation;
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mImmersionBar != null) mImmersionBar.destroy();
        getWindow().getDecorView().getViewTreeObserver().removeOnGlobalLayoutListener(this);


    }


    public void showProgress() {
        if (dialogTips == null) {
            dialogTips = new NetworkTipsDialog();
        }
        if (dialogTips.isAdded()) return;
        dialogTips.show(getSupportFragmentManager(), "");
    }


    public void hideProgress() {
        if (dialogTips==null)return;
        dialogTips.dismiss();
    }

    public void showMessage(String msg) {
        ToastUtils.show(msg);
    }

    /**
     * 延迟某个时间执行某个任务
     *
     * @param action      Runnable对象
     * @param delayMillis 延迟的时间
     */
    public boolean postDelayed(Runnable action, long delayMillis) {
        return getWindow().getDecorView().postDelayed(action, delayMillis);
    }

    //不可使用
    public <T> Observable.Transformer<T, T> bindUntilEvent(FragmentEvent event) {
        return null;
    }

    @Override
    protected void onResume() {
        super.onResume();
        AppConst.AddActivity(this);
    }

    public void  showToast(String content){
        ToastUtils.show(content);
    }
}
