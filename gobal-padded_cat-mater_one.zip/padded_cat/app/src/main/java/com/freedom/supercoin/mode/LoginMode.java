package com.freedom.supercoin.mode;

import java.util.List;

public class LoginMode {

    /**
     * accountDetailType : null
     * alipay :
     * amount : null
     * applyed : false
     * avatar : https://g.csdnimg.cn/static/user-reg-year/1x/12.png
     * backDeposit : null
     * beginTime :
     * birthday : null
     * blacklist : 0
     * cardNo :
     * channelId :
     * chargeMoney : null
     * clicked : false
     * createBy :
     * createIp :
     * createTime : 2019-12-29 15:50:41
     * deleted : 0
     * desc : desc
     * deviceCode :
     * deviceType :
     * directNum : null
     * endTime : null
     * failMoney : null
     * fanNums : null
     * gender : 0
     * indirectNum : null
     * inhibited : 0
     * integralAmount : null
     * integralDetailType : null
     * invitationCode : R75083
     * isEarnings : null
     * isSendMsg : null
     * lastLoginIp :
     * lastLoginTime : 2019-12-29 15:50:41
     * lockAmount : null
     * money : null
     * name :
     * newPeople : null
     * nickname : 185***8679
     * openid :
     * orderField :
     * orderMoney : null
     * outWithdraw : null
     * overTime :
     * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,"pageStr":"",
     * "totalPage":0,"totalResult":0}
     * params : null
     * parentId : 0
     * parentIdList : []
     * parentInvitationCode :
     * parentNickname :
     * parentTime : null
     * partnerIncome : null
     * password :
     * payPassword :
     * phone : 18566398679
     * positMoney : null
     * qrcodeUrl :
     * remark :
     * searchValue :
     * secondInviterId : null
     * sjnickname :
     * smsCode :
     * startTime : null
     * status : 0
     * token : 6zyl23TASE2XpuJFdcKHKpAotIOKD4tl3It73uIyQb1lrz40Ob50yAEyQE99n7sn
     * totalIncome : null
     * tradeType : null
     * type : 0
     * unionid :
     * updateBy :
     * updateInviteCode : 0
     * updateTime : null
     * userId : 1178
     * username : 185***8679
     * verifyCode :
     */

    public Object accountDetailType;
    public String alipay;
    public Object amount;
    public boolean applyed;
    public String avatar;
    public Object backDeposit;
    public String beginTime;
    public Object birthday;
    public int blacklist;
    public String cardNo;
    public String channelId;
    public Object chargeMoney;
    public boolean clicked;
    public String createBy;
    public String createIp;
    public String createTime;
    public int deleted;
    public String desc;
    public String deviceCode;
    public String deviceType;
    public Object directNum;
    public Object endTime;
    public Object failMoney;
    public Object fanNums;
    public int gender;
    public Object indirectNum;
    public int inhibited;
    public Object integralAmount;
    public Object integralDetailType;
    public String invitationCode;
    public Object isEarnings;
    public Object isSendMsg;
    public String lastLoginIp;
    public String lastLoginTime;
    public Object lockAmount;
    public Object money;
    public String name;
    public Object newPeople;
    public String nickname;
    public String openid;
    public String orderField;
    public Object orderMoney;
    public Object outWithdraw;
    public String overTime;
    public PageBean page;
    public Object params;
    public int parentId;
    public String parentInvitationCode;
    public String parentNickname;
    public Object parentTime;
    public Object partnerIncome;
    public String password;
    public String payPassword;
    public String phone;
    public Object positMoney;
    public String qrcodeUrl;
    public String remark;
    public String searchValue;
    public Object secondInviterId;
    public String sjnickname;
    public String smsCode;
    public Object startTime;
    public int status;
    public String token;
    public Object totalIncome;
    public Object tradeType;
    public int type;
    public String unionid;
    public String updateBy;
    public int updateInviteCode;
    public Object updateTime;
    public int userId;
    public String username;
    public String verifyCode;
    public List<?> parentIdList;

    public static class PageBean {
        /**
         * currentResult : 0
         * entityOrField : false
         * pageNumber : 1
         * pageSize : 10
         * pageStr :
         * totalPage : 0
         * totalResult : 0
         */

        public int currentResult;
        public boolean entityOrField;
        public int pageNumber;
        public int pageSize;
        public String pageStr;
        public int totalPage;
        public int totalResult;
    }
}
