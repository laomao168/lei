package com.freedom.supercoin.adapter;

import android.databinding.DataBindingUtil;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.freedom.supercoin.R;
import com.freedom.supercoin.base_library.base.BaseEmptyAdapter;
import com.freedom.supercoin.base_library.utils.StrUtils;
import com.freedom.supercoin.databinding.ItemBanlaceDetailBinding;
import com.freedom.supercoin.mode.BalanceListMode;

public class BalanceAdapter extends BaseEmptyAdapter<BalanceListMode.DataBeanX.DataBean,
        ItemBanlaceDetailBinding> {
    @Override
    protected ItemBanlaceDetailBinding createBinding(ViewGroup parent) {
        return DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()),
                R.layout.item_banlace_detail, parent, false);
    }

    @Override
    protected void onBindView(ItemBanlaceDetailBinding binding,
                              BalanceListMode.DataBeanX.DataBean bean, int position) {
        if (position == data.size() - 1) {
            binding.viewSplit.setVisibility(View.GONE);
        } else {
            binding.viewSplit.setVisibility(View.VISIBLE);
        }
        switch (bean.tradeType) {
            case 0:
                binding.tvIntegralTitle.setText("提现");
                break;
            case 1:
                binding.tvIntegralTitle.setText("保证金");
                break;
            case 2:
                binding.tvIntegralTitle.setText("订单");
                break;
            case 3:
                binding.tvIntegralTitle.setText("充值余额");
                break;
            case 4:
                binding.tvIntegralTitle.setText("退保证金");
                break;
            case 5:
                binding.tvIntegralTitle.setText("拍卖红包");
                break;
            case 6:
                binding.tvIntegralTitle.setText("好友成交红包");
                break;

            case 7:
                binding.tvIntegralTitle.setText("平台操作");
                break;

            case 8:
                binding.tvIntegralTitle.setText("寄拍收入");
                break;
            case 9:
                binding.tvIntegralTitle.setText("拍卖成交红包");
                break;

            case 10:
                binding.tvIntegralTitle.setText("拍卖收入");
                break;

            case 11:
                binding.tvIntegralTitle.setText("解冻提现");
                break;
            default:
                binding.tvIntegralTitle.setText("其他");
                break;
        }
//        收支类型 0 支出 1收入
        if (bean.type == 0) {
            binding.tvIntegralNum.setText("-" + StrUtils.getRemoveZreoNum(bean.amount));
        } else {
            binding.tvIntegralNum.setText("+" + StrUtils.getRemoveZreoNum(bean.amount));
        }
        binding.tvIntegralTime.setText(bean.createTime);
    }
}
