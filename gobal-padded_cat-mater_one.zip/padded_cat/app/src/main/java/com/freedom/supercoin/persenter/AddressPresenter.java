package com.freedom.supercoin.persenter;

import com.freedom.supercoin.contract.AddressContact;
import com.freedom.supercoin.mode.AddressListMode;
import com.freedom.supercoin.network.DataManager;
import com.freedom.supercoin.network.ResponseErrorFunc;
import com.freedom.supercoin.network.RxUtils;

import rx.Subscriber;


public class AddressPresenter implements AddressContact.Presenter {

    private final AddressContact.View view;

    public AddressPresenter(AddressContact.View view) {
        this.view = view;
    }

    @Override
    public void getAddress() {
        DataManager.getInstance()
                .getAddressList()
                .compose(RxUtils.applyIOSchedulers())
//                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<AddressListMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(AddressListMode mode) {
                        view.getAddressListSuccess(mode);
                        view.hideProgress();
                    }
                });

    }


}
