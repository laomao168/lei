package com.freedom.supercoin.contract;


import com.freedom.supercoin.base_library.base.BasePresenter;
import com.freedom.supercoin.base_library.base.BaseView;
import com.freedom.supercoin.mode.StreetMode;
import com.freedom.supercoin.mode.entity.AddressBean;

import java.util.List;


public class AddressDetailContact {

    public interface View extends BaseView {

        void onSuccess();

        void onLoadStreetModeSuccess(List<StreetMode> list, int type);
    }


    public interface Presenter extends BasePresenter {
        void addAddress(AddressBean bean);
        void editAddress(AddressBean bean);
        void getAllAddressList(int parentId,int type);
    }
}

