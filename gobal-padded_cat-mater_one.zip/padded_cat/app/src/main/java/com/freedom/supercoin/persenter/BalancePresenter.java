package com.freedom.supercoin.persenter;

import com.freedom.supercoin.contract.BalanceContact;
import com.freedom.supercoin.mode.BalanceDetailMode;
import com.freedom.supercoin.mode.CheckRealNameMode;
import com.freedom.supercoin.mode.TodayIncomeMode;
import com.freedom.supercoin.network.DataManager;
import com.freedom.supercoin.network.ResponseErrorFunc;
import com.freedom.supercoin.network.RxUtils;

import rx.Subscriber;


public class BalancePresenter implements BalanceContact.Presenter {

    private final BalanceContact.View view;

    public BalancePresenter(BalanceContact.View view) {
        this.view = view;
    }

    @Override
    public void getBalance() {
        DataManager.getInstance()
                .getBalance()
                .compose(RxUtils.applyIOSchedulers())
                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<BalanceDetailMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(BalanceDetailMode mode) {
                        view.getBalanceSuccess(mode);
                        view.hideProgress();
                    }
                });

    }

    @Override
    public void getTodayIncome() {
        DataManager.getInstance()
                .getTodayIncome()
                .compose(RxUtils.applyIOSchedulers())
//                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<TodayIncomeMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(TodayIncomeMode todayIncomeMode) {
                        view.hideProgress();
                        view.getTodayIncomeSuccess(todayIncomeMode);
                    }
                });

    }

    @Override
    public void checkRealName() {
        DataManager.getInstance()
                .checkRealName()
                .compose(RxUtils.applyIOSchedulers())
//                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<CheckRealNameMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(CheckRealNameMode mode) {
                        view.getRealNameSuccess(mode);
                        view.hideProgress();
                    }
                });

    }


}
