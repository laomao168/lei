package com.freedom.supercoin.fragment;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;

import com.freedom.supercoin.R;
import com.freedom.supercoin.activity.OrderDetailActivity;
import com.freedom.supercoin.adapter.OrderAdapter;
import com.freedom.supercoin.base_library.AppConst;
import com.freedom.supercoin.base_library.widget.spingview.DefaultFooter;
import com.freedom.supercoin.base_library.widget.spingview.SpringView;
import com.freedom.supercoin.base_library.widget.spingview.WheelHeader;
import com.freedom.supercoin.common.UILazyFragment;
import com.freedom.supercoin.contract.OrderContact;
import com.freedom.supercoin.databinding.FragmentOrderBinding;
import com.freedom.supercoin.mode.OrderMode;
import com.freedom.supercoin.mode.entity.Page;
import com.freedom.supercoin.persenter.OrderPresenter;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2019/7/18.
 */

public class OrderFragment extends UILazyFragment<FragmentOrderBinding> implements OrderContact.View {
    public static String INDEX = "INDEX";
    private OrderAdapter adapter;
    private OrderPresenter presenter;
    private int currentIndex;
    private int index;

    /**
     * @param index 0全部,1 代付款,2待发货,3 待收货,4已完成
     * @return
     */
    public static OrderFragment newInstance(int index) {
        OrderFragment fragment = new OrderFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(INDEX, index);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_order;
    }

    @Override
    protected boolean isLazyOrNot() {
        return false;
    }

    @Override
    protected void initEvent() {
        adapter.setOnItemClickListener(new OrderAdapter.OnItemClickListener() {
            @Override
            public void onItemDetailClick(int position, OrderMode.DataBeanX.DataBean bean) {
                getOperation().addParameter(AppConst.Keys.ORDER_ID, bean.orderId);
                getOperation().forward(OrderDetailActivity.class);
            }

            @Override
            public void onItemPayClick(int position, OrderMode.DataBeanX.DataBean bean) {
                //付款
                getOperation().addParameter(AppConst.Keys.ORDER_ID, bean.orderId);
                getOperation().forward(OrderDetailActivity.class);
            }
        });
    }

    @Override
    protected void initData() {
        initSpringView();
        index = getArguments().getInt(INDEX, 0);
        binding.recycleView.setLayoutManager(new LinearLayoutManager(mActivity));
        adapter = new OrderAdapter();
        binding.recycleView.setAdapter(adapter);
        presenter = new OrderPresenter(this);
        currentIndex = 1;
    }

    @Override
    public void onResume() {
        super.onResume();
        loadOrderList();
    }

    private void initSpringView() {
        binding.springView.setType(SpringView.Type.FOLLOW);
        binding.springView.setListener(new SpringView.OnFreshListener() {
            @Override
            public void onRefresh() {
                currentIndex = 1;
                loadOrderList();
            }

            @Override
            public void onLoadMore() {
                currentIndex++;
                loadOrderList();
            }
        });
//        binding.springView.setHeader(new WheelHeader(this));
        binding.springView.setFooter(new DefaultFooter(mActivity));
    }

    private void loadOrderList() {
        int type = index - 1;
        presenter.getOrderList(currentIndex, type);
    }

    @Override
    public void getOrderListSuccess(OrderMode mode) {
        binding.springView.onFinishFreshAndLoad();
        if (!mode.success && mode.data == null) return;
        if (currentIndex == 1) {
            adapter.setData(mode.data.data);
        } else {
            adapter.addDataList(mode.data.data);
        }
    }
}


