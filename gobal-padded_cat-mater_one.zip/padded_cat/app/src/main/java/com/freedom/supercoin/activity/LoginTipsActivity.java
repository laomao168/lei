package com.freedom.supercoin.activity;

import android.view.View;

import com.freedom.supercoin.R;
import com.freedom.supercoin.common.UiActivity;
import com.freedom.supercoin.databinding.ActivityABinding;
import com.freedom.supercoin.databinding.ActivityLoginTipsBinding;
import com.freedom.supercoin.mode.entity.HomeBus;

import org.greenrobot.eventbus.EventBus;

/**
 * @author : lijianping
 * @date : Created on 2019/7/11.
 * des:
 */
public class LoginTipsActivity extends UiActivity<ActivityLoginTipsBinding> {
    @Override
    protected int layoutResId() {
        return R.layout.activity_login_tips;
    }

    @Override
    protected void initData() {
    }

    @Override
    protected void initEvent() {
        binding.setClick(v -> {
            switch (v.getId()) {
                case R.id.tv_no_login://不登录
                    finish();
                    break;
                case R.id.tv_to_login://去登陆
                    getOperation().forward(LoginActivity.class);
                    finish();
                    break;
            }
        });
    }

}
