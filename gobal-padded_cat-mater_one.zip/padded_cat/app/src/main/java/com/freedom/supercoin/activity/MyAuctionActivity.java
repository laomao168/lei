package com.freedom.supercoin.activity;

import android.support.v7.widget.LinearLayoutManager;

import com.freedom.supercoin.R;
import com.freedom.supercoin.adapter.MyAuctionAdapter;
import com.freedom.supercoin.base_library.AppConst;
import com.freedom.supercoin.common.UiActivity;
import com.freedom.supercoin.contract.MyAuctionContact;
import com.freedom.supercoin.databinding.ActivityABinding;
import com.freedom.supercoin.databinding.ActivityMyAuctionBinding;
import com.freedom.supercoin.mode.MyAuctionMode;
import com.freedom.supercoin.persenter.MyAuctionPresenter;

/**
 * @author : lijianping
 * @date : Created on 2019/7/11.
 * des:
 */
public class MyAuctionActivity extends UiActivity<ActivityMyAuctionBinding> implements MyAuctionContact.View, MyAuctionAdapter.OnItemClickListener {

    private MyAuctionPresenter presenter;
    private MyAuctionAdapter adapter;

    @Override
    protected int layoutResId() {
        return R.layout.activity_my_auction;
    }

    @Override
    protected void initData() {
        binding.titleBar.setTextColor("#ffffff");
        binding.titleBar.setTitle("我的竞拍");
        binding.titleBar.setLeftImage(R.mipmap.ic_back_white);
        presenter = new MyAuctionPresenter(this);
        presenter.getMyAuctionList();
        binding.recycleView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MyAuctionAdapter();
        binding.recycleView.setAdapter(adapter);
        adapter.setOnItemListener(this);
    }

    @Override
    protected void initEvent() {

    }

    @Override
    public void onLoadMyAuctionSuccess(MyAuctionMode myAuctionMode) {
        if (myAuctionMode == null ||!myAuctionMode.success) return;
        if (myAuctionMode.data.data == null || myAuctionMode.data.data.size() == 0) return;
        adapter.setData(myAuctionMode.data.data);
    }

    @Override
    public void onItemClick(int position, MyAuctionMode.DataBeanX.DataBean bean) {
        getOperation().addParameter(AppConst.Keys.TITLE, bean.goodsName);
        getOperation().addParameter(AppConst.Keys.AUCTIONID, bean.auctionId);
        getOperation().addParameter("brokerage", bean.brokerage);
        getOperation().addParameter("markupPrice", bean.markupPrice);
        getOperation().addParameter("status",3);
        getOperation().addParameter("endTime", bean.endTimes);
        getOperation().addParameter("startPrice", bean.startPrice);
        getOperation().addParameter("type", 1);
        getOperation().forward(AuctionActivity.class);
    }
}
