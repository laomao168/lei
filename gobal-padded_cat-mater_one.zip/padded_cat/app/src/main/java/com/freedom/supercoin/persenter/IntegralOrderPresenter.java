package com.freedom.supercoin.persenter;

import com.freedom.supercoin.contract.IntegralOrderContact;
import com.freedom.supercoin.contract.OrderContact;
import com.freedom.supercoin.mode.IntegralOrderMode;
import com.freedom.supercoin.mode.OrderMode;
import com.freedom.supercoin.network.DataManager;
import com.freedom.supercoin.network.ResponseErrorFunc;
import com.freedom.supercoin.network.RxUtils;

import okhttp3.ResponseBody;
import rx.Subscriber;


public class IntegralOrderPresenter implements IntegralOrderContact.Presenter {

    private final IntegralOrderContact.View view;

    public IntegralOrderPresenter(IntegralOrderContact.View view) {
        this.view = view;
    }


    @Override
    public void getOrderList(int currentIndex, int index,int goodsType) {
        DataManager.getInstance()
                .getMallOrderList(currentIndex,index,goodsType)
                .compose(RxUtils.applyIOSchedulers())
//                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<IntegralOrderMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(IntegralOrderMode mode) {
                        view.hideProgress();
                        view.getOrderListSuccess(mode);
                    }
                });
    }



}
