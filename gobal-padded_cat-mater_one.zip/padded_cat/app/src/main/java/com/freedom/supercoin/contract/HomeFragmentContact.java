package com.freedom.supercoin.contract;


import com.freedom.supercoin.base_library.base.BasePresenter;
import com.freedom.supercoin.base_library.base.BaseView;
import com.freedom.supercoin.mode.GoodsCategoryMode;
import com.freedom.supercoin.mode.HomeBannerMode;
import com.freedom.supercoin.mode.entity.HomeAuctionReq;
import com.freedom.supercoin.mode.HomeAuctionRes;
import com.freedom.supercoin.mode.entity.Page;

import java.util.List;


public class HomeFragmentContact {

    public interface View extends BaseView {
        void getHomeBannerListSuccess(List<HomeBannerMode> list);

        void getTodayListSuccess(HomeAuctionRes list);

        void getPreviewList(HomeAuctionRes res);

        void onLoadGoodsCategorySuccess(List<GoodsCategoryMode> list);
        void  onLoadListError();
    }


    public interface Presenter extends BasePresenter {
        //banner
        void  getHomeBannerList();
        //今日列表
        void  getAuctionRecordInfoToday(Page page);
        //预展 列表
        void  getAuctionRecordInfoPreview(HomeAuctionReq homeAuctionReq);
        //商品分类列表
        void getGoodsCategoryList();
    }
}

