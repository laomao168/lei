package com.freedom.supercoin.persenter;

import com.freedom.supercoin.contract.RealNameContact;
import com.freedom.supercoin.mode.RealNameMode;
import com.freedom.supercoin.network.DataManager;
import com.freedom.supercoin.network.ResponseErrorFunc;
import com.freedom.supercoin.network.RxUtils;

import rx.Subscriber;


public class ResetPwdPresenter implements RealNameContact.Presenter {

    private final RealNameContact.View view;

    public ResetPwdPresenter(RealNameContact.View view) {
        this.view = view;
    }

    @Override
    public void toIdentity(String bankName, String bank, String bankCard, String userName, String alipay, String idCard) {
        DataManager.getInstance()
                .toIdentity(bankName, bank, bankCard, userName,alipay,idCard)
                .compose(RxUtils.applyIOSchedulers())
//                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<RealNameMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(RealNameMode mode) {
                        view.onSubSuccess(mode);
                        view.hideProgress();
                    }
                });

    }

}
