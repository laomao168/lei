package com.freedom.supercoin.activity;

import android.content.Intent;
import android.text.TextUtils;

import com.freedom.supercoin.R;
import com.freedom.supercoin.base_library.AppConst;
import com.freedom.supercoin.common.UiActivity;
import com.freedom.supercoin.contract.AddressDetailContact;
import com.freedom.supercoin.databinding.ActivityAddressDetailBinding;
import com.freedom.supercoin.dialog.AreaDialog;
import com.freedom.supercoin.dialog.StreetDialog;
import com.freedom.supercoin.mode.StreetMode;
import com.freedom.supercoin.mode.entity.AddressBean;
import com.freedom.supercoin.persenter.AddressDetailPresenter;
import com.hjq.toast.ToastUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : lijianping
 * @date : Created on 2019/7/11.
 * des:
 */
public class AddressDetailNewActivity extends UiActivity<ActivityAddressDetailBinding> implements AddressDetailContact.View, AreaDialog.AreaItemSelectInterface, StreetDialog.StreetItemSelectInterface {

    private AddressDetailPresenter presenter;
    private int tolerant;
    private boolean isEdit;
    private String street;
    public static final int TYPE_PROVINCE = 0;
    public static final int TYPE_CITY = 1;
    public static final int TYPE_AREA = 2;
    public static final int TYPE_STREET = 3;
    private List<StreetMode> proviceList = new ArrayList<>();
    private List<StreetMode> cityList = new ArrayList<>();
    private List<StreetMode> areaList = new ArrayList<>();
    private List<StreetMode> streetList = new ArrayList<>();
    private AreaDialog areaDialog;
    private int currentProvice;
    private int currentCity;
    private int currentArea;
    private boolean isFirst;
    private StreetDialog streetDialog;
    private int currentStreet;
    private int addressId;
    private int provinceId;
    private int cityId;
    private int districtId;
    private int streetTextId;

    @Override
    protected int layoutResId() {
        return R.layout.activity_address_detail;
    }

    @Override
    protected void initData() {
        binding.titleBar.setTextColor("#ffffff");
        binding.titleBar.setTitle("新增收货地址");
        binding.titleBar.setLeftImage(R.mipmap.ic_back_white);
        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        String phone = intent.getStringExtra(AppConst.Keys.PHONE);
        tolerant = intent.getIntExtra("tolerant", 0);
        String address = intent.getStringExtra("address");
        String province = intent.getStringExtra("province");
        String city = intent.getStringExtra("city");
        String district = intent.getStringExtra("district");
        String street = intent.getStringExtra("streetText");

        addressId = intent.getIntExtra("addressId", 0);
        binding.etName.setText(name);
        binding.etPhone.setText(phone);
        binding.ivSelectDefault.setSelected(tolerant == 0);
        presenter = new AddressDetailPresenter(this);
        if (addressId == 0) {
            isEdit = false;
            binding.tvConfirm.setText("保存");
        } else {
            isEdit = true;
            binding.tvConfirm.setText("修改地址");
        }
    }

    @Override
    protected void initEvent() {
        binding.setClick(v -> {
            switch (v.getId()) {
                case R.id.rl_area:
                    if (areaDialog == null) {
                        areaDialog = new AreaDialog();
                        areaDialog.setAreaItemSelectInterface(this);
                    }
                    areaDialog.show(getSupportFragmentManager(), "");
                    areaDialog.setData(proviceList, TYPE_PROVINCE);
                    if (isFirst) {
                        isFirst = false;
                        areaDialog.setData(cityList, TYPE_CITY);
                        areaDialog.setData(areaList, TYPE_AREA);
                    } else {
                        if (proviceList.size() != 0) {
                            presenter.getAllAddressList(proviceList.get(0).id, TYPE_CITY);
                        }
                    }
                    break;
                case R.id.rl_street:
                    if (streetList.size() == 0) {
                        showMessage("请先选择省市区");
                    } else {
                        if (streetDialog == null) {
                            streetDialog = new StreetDialog();
                            streetDialog.setStreetItemSelectInterface(this);
                        }
                        streetDialog.show(getSupportFragmentManager(), "");
                        streetDialog.setData(streetList);
                    }
                    break;
                case R.id.tv_confirm:
                    checkAndSub();
                    break;

                case R.id.iv_select_default:
                    binding.ivSelectDefault.setSelected(!binding.ivSelectDefault.isSelected());
                    break;
            }
        });
    }

    private void checkAndSub() {
        if (proviceList == null) {
            ToastUtils.show("请先选择省");
            return;
        }
        if (cityList == null) {
            ToastUtils.show("请先选择市");
            return;
        }
        if (areaList == null) {
            ToastUtils.show("请先选择地区");
            return;
        }
        if (streetList == null) {
            ToastUtils.show("请选择街道");
            return;
        }
        String address = binding.etDetail.getText().toString();
        if (TextUtils.isEmpty(address)) {
            ToastUtils.show("请输入地址");
            return;
        }
        AddressBean addressBean = new AddressBean();
        String name = binding.etName.getText().toString();
        String phone = binding.etPhone.getText().toString();
        addressBean.province = proviceList.get(currentProvice).id;
        addressBean.city = cityList.get(currentCity).id;
        addressBean.district = areaList.get(currentArea).id;
        addressBean.street = streetList.get(currentStreet).id;
        boolean checked = binding.ivSelectDefault.isSelected();
        addressBean.consignee = name;
        addressBean.mobile = phone;
        addressBean.address = address;
        addressBean.tolerant = checked ? 0 : 1;
        if (isEdit) {// 编辑
            addressBean.addressId = addressId;
            presenter.editAddress(addressBean);
        } else {
            presenter.addAddress(addressBean);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (isEdit) {// 编辑
            presenter.getAllAddressList(provinceId, TYPE_PROVINCE);
        } else {
            presenter.getAllAddressList(0, TYPE_PROVINCE);
        }
    }

    @Override
    public void onSuccess() {
        finish();
    }

    @Override
    public void onLoadStreetModeSuccess(List<StreetMode> list, int type) {
        switch (type) {
            //返回省
            case TYPE_PROVINCE:
                proviceList.clear();
                proviceList.addAll(list);
                if (areaDialog != null) {
                    areaDialog.setData(proviceList, TYPE_PROVINCE);
                }
                //请求第一个省的市区
                if (proviceList.size() != 0) {
                    presenter.getAllAddressList(proviceList.get(0).id, TYPE_CITY);
                }
                break;
            //返回市
            case TYPE_CITY:
                cityList.clear();
                cityList.addAll(list);
                if (areaDialog != null) {
                    areaDialog.setData(cityList, TYPE_CITY);
                }
                //请求第一个市的区
                if (cityList.size() != 0) {
                    presenter.getAllAddressList(cityList.get(0).id, TYPE_AREA);
                }
                break;
            //返回区
            case TYPE_AREA:
                areaList.clear();
                areaList.addAll(list);
                if (areaDialog != null) {
                    areaDialog.setData(areaList, TYPE_AREA);
                }
                break;
            //返回街道
            case TYPE_STREET:
                streetList.clear();
                streetList.addAll(list);
                break;
        }
    }

    @Override
    public void onProvinceSelect(int index) {
        currentProvice = index;
        try {
            presenter.getAllAddressList(proviceList.get(index).id, TYPE_CITY);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onCitySelect(int index) {
        currentCity = index;
        try {
            presenter.getAllAddressList(cityList.get(index).id, TYPE_AREA);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onAreaSelect(int index) {
        currentArea = index;
        try {
            presenter.getAllAddressList(areaList.get(index).id, TYPE_STREET);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onStreetSelect(int index) {
        currentStreet = index;
    }

    /**
     * 街道
     */
    @Override
    public void OnStreetConfirm() {
        try {
            street = streetList.get(currentStreet).areaname;
            binding.tvStreet.setText(street);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 地区
     */
    @Override
    public void OnConfirm() {
        try {
            binding.tvStreet.setText("请选择街道");
            currentStreet = 0;
            binding.tvArea.setText(proviceList.get(currentProvice).areaname + cityList.get(currentCity).areaname + areaList.get(currentArea).areaname);
            if (streetList.size() == 0) {
                presenter.getAllAddressList(areaList.get(currentStreet).id, TYPE_STREET);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
