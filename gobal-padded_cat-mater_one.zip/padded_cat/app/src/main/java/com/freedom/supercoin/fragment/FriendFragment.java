package com.freedom.supercoin.fragment;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.view.View;

import com.freedom.supercoin.R;
import com.freedom.supercoin.activity.InviteFriendActivity;
import com.freedom.supercoin.adapter.FriendAdapter;
import com.freedom.supercoin.base_library.widget.spingview.DefaultFooter;
import com.freedom.supercoin.base_library.widget.spingview.SpringView;
import com.freedom.supercoin.common.UILazyFragment;
import com.freedom.supercoin.contract.FriendContact;
import com.freedom.supercoin.databinding.FragmentFriendBinding;
import com.freedom.supercoin.mode.FriendMode;
import com.freedom.supercoin.mode.MyFansMode;
import com.freedom.supercoin.mode.MySuperiorMode;
import com.freedom.supercoin.mode.entity.HomeAuctionReq;
import com.freedom.supercoin.mode.entity.Page;
import com.freedom.supercoin.persenter.FriendPresenter;


/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2019/7/18.
 */

public class FriendFragment extends UILazyFragment<FragmentFriendBinding> implements FriendContact.View {
    public static String INDEX = "INDEX";
    private int index;
    private FriendPresenter presenter;
    private FriendAdapter adapter;
    private int currentPageNumber;

    /**
     * @param index 我的好友,1 全部朋友
     * @return
     */
    public static FriendFragment newInstance(int index) {
        FriendFragment fragment = new FriendFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(INDEX, index);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_friend;
    }


    @Override
    protected void initData() {
        presenter = new FriendPresenter(this);
        index = getArguments().getInt(INDEX, 0);
        binding.recycleView.setLayoutManager(new LinearLayoutManager(mActivity));
        adapter = new FriendAdapter();
        binding.recycleView.setAdapter(adapter);
        initSpringView();
        currentPageNumber = 1;
        if (index == 0) {
            presenter.getMyFriend(currentPageNumber);
        } else {
            presenter.getAllFriend(currentPageNumber);
        }
    }

    private void initSpringView() {
        binding.springView.setType(SpringView.Type.FOLLOW);
        binding.springView.setListener(new SpringView.OnFreshListener() {
            @Override
            public void onRefresh() {
            }

            @Override
            public void onLoadMore() {
                if (index == 0) {
                    currentPageNumber = currentPageNumber + 1;
                    presenter.getMyFriend(currentPageNumber);
                } else {
                    currentPageNumber = currentPageNumber + 1;
                    presenter.getAllFriend(currentPageNumber);
                }
            }

        });
        binding.springView.setFooter(new DefaultFooter(getActivity()));
    }

    @Override
    protected void initEvent() {
        binding.setClick(v -> {
            //邀请页面
            getOperation().forward(InviteFriendActivity.class);
        });
    }

    @Override
    public void loadFriendSuccess(FriendMode friendMode) {
        binding.springView.onFinishFreshAndLoad();
        if (friendMode == null || !friendMode.msg.contains("成功") || friendMode.data.data.size() == 0) {
            binding.recycleView.setVisibility(View.GONE);
            binding.rlEmpty.setVisibility(View.VISIBLE);
        } else {
            binding.recycleView.setVisibility(View.VISIBLE);
            binding.rlEmpty.setVisibility(View.GONE);
            if (currentPageNumber==1){
                adapter.setData(friendMode.data.data);
            }else {
                adapter.addDataList(friendMode.data.data);
            }
        }
    }

    @Override
    public void loadFriendError() {
        binding.springView.onFinishFreshAndLoad();
        binding.recycleView.setVisibility(View.GONE);
        binding.rlEmpty.setVisibility(View.VISIBLE);
    }

    @Override
    public void getMyFansSuccess(MyFansMode mode) {

    }

    @Override
    public void getMySuperiorSuccess(MySuperiorMode mode) {

    }
}
