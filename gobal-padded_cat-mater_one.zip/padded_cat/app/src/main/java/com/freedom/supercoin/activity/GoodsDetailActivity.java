package com.freedom.supercoin.activity;

import android.graphics.Color;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.LinearLayoutManager;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.freedom.supercoin.R;
import com.freedom.supercoin.adapter.DetailBannerAdapter;
import com.freedom.supercoin.adapter.GoodsRankAdapter;
import com.freedom.supercoin.adapter.HomeBannerAdapter;
import com.freedom.supercoin.base_library.AppConst;
import com.freedom.supercoin.base_library.utils.DimensUtils;
import com.freedom.supercoin.base_library.utils.GlideUtils;
import com.freedom.supercoin.base_library.utils.StrUtils;
import com.freedom.supercoin.base_library.utils.TimeUtil;
import com.freedom.supercoin.common.UiActivity;
import com.freedom.supercoin.contract.GoodsDetailsContact;
import com.freedom.supercoin.databinding.ActivityABinding;
import com.freedom.supercoin.databinding.ActivityGoodsDetailsBinding;
import com.freedom.supercoin.mode.GoodDetailsMode;
import com.freedom.supercoin.mode.GoodsRankListMode;
import com.freedom.supercoin.persenter.GoodsDetailsPresenter;
import com.zzhoujay.richtext.RichText;

import org.json.JSONArray;
import org.json.JSONException;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 * @author : lijianping
 * @date : Created on 2019/7/11.
 * des:
 */
public class GoodsDetailActivity extends UiActivity<ActivityGoodsDetailsBinding> implements GoodsDetailsContact.View {
    private int auctionId;
    private GoodsDetailsPresenter presenter;
    private boolean hasCalculationStart;
    private boolean hasCalculationEnd;
    private int currentTimeDiff;
    private int currentStatus;
    private DetailBannerAdapter bannerAdapter;
    private ArrayList<String> bannerList;
    private int currentIndex;
    private int maxIndex;
    private Timer timer;
    private TimerTask timerTask;
    private GoodsRankAdapter rankAdapter;
    private String goodsName;
    private double brokerage;
    private double markupPrice;
    private double cashDepositScale;
    private double startPrice;
    private long startTimes;
    private long endTimes;
    private Handler handler;

    /**
     * 计算倒计时
     *
     * @return
     */
    private String getTime() {
        if (currentTimeDiff >= 3600) {
            return currentTimeDiff / 3600 + "时" + currentTimeDiff / 60 % 60 + "分" + currentTimeDiff % 60 + "秒";
        } else if (currentTimeDiff >= 60) {
            return currentTimeDiff / 60 % 60 + "分" + currentTimeDiff % 60 + "秒";
        }
        return currentTimeDiff + "秒";
    }


    @Override
    protected int layoutResId() {
        return R.layout.activity_goods_details;
    }

    @Override
    protected void initData() {
        binding.titleBar.setTextColor("#ffffff");
        binding.titleBar.setLeftImage(R.mipmap.ic_back_white);
        binding.titleBar.setTitle("商品详情");
        auctionId = getIntent().getIntExtra(AppConst.Keys.AUCTIONID, 0);
        presenter = new GoodsDetailsPresenter(this);
        currentTimeDiff = 0;
        bannerAdapter = new DetailBannerAdapter(this, null);
        binding.vpBanner.setAdapter(bannerAdapter);
        rankAdapter = new GoodsRankAdapter();
        binding.offerRec.setLayoutManager(new LinearLayoutManager(this));
        binding.offerRec.setAdapter(rankAdapter);
    }

    private void initHandler() {
        handler = new Handler(msg -> {
            //即将开始
            if (msg.what == 2) {
                currentStatus = 2;
                if (!hasCalculationStart) {
                    currentTimeDiff = (int) (startTimes / 1000);
                    hasCalculationStart = true;
                }
                if (--currentTimeDiff >= 0) {
                    //计算时分秒
                    binding.tvRemainTime.setText(getTime());
                    handler.sendEmptyMessageDelayed(2, 1000);
                } else {
                    hasCalculationEnd = false;
                    presenter.getGoodDetails(auctionId);
                }
                //开始拍卖
            } else if (msg.what == 3) {
                currentStatus = 3;
                if (!hasCalculationEnd) {
//                    currentTimeDiff = TimeUtil.getCurrentTimeDiff(endTime);
                    currentTimeDiff = (int) (endTimes / 1000);
                    hasCalculationEnd = true;
                }
                if (--currentTimeDiff >= 0) {
                    //计算时分秒
                    binding.tvRemainTime.setText(getTime());
                    handler.sendEmptyMessageDelayed(3, 1000);
                } else {
                    presenter.getGoodDetails(auctionId);
                    presenter.getGoodRankList(auctionId);
                }
            } else if (msg.what > 3) {
                currentStatus = 4;
                binding.rlGoodsRemainTime.setVisibility(View.GONE);
                binding.tvGoodsStatusFinished.setVisibility(View.VISIBLE);
                binding.llStatusPrice.setBackgroundColor(Color.parseColor("#C9C9C9"));
                binding.tvStatusPriceTitle.setText("成交价");
                handler.removeCallbacksAndMessages(null);
                handler = null;

            }
            return false;
        });
    }


    @Override
    protected void onResume() {
        super.onResume();
        initHandler();
        presenter.getGoodDetails(auctionId);
    }
    @Override
    protected void onPause() {
        super.onPause();
        setTimeTask(false);
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
            handler = null;
        }
    }


    @Override
    protected void initEvent() {
        binding.setClick(v -> {
            switch (v.getId()) {
                case R.id.tv_to_bay:
                    getOperation().addParameter(AppConst.Keys.TITLE, goodsName);
                    getOperation().addParameter(AppConst.Keys.AUCTIONID, auctionId);
                    getOperation().addParameter("brokerage", brokerage);
                    getOperation().addParameter("markupPrice", markupPrice);
                    getOperation().addParameter("status", currentStatus);
                    getOperation().addParameter("endTime", endTimes);
                    getOperation().addParameter("startPrice", startPrice);
                    getOperation().addParameter("type", 1);
                    getOperation().forward(AuctionActivity.class);
                    break;
                case R.id.tv_show_more_notice://拍卖规则
                    getOperation().addParameter(AppConst.Keys.TITLE, "拍卖规则");
                    getOperation().addParameter(AppConst.Keys.WEB_URL,
                            AppConst.Values.AUCTION_RULES);
                    getOperation().forward(WebActivity.class);
                    break;
                case R.id.rl_offer_now:
                    getOperation().addParameter(AppConst.Keys.TITLE, goodsName);
                    getOperation().addParameter(AppConst.Keys.AUCTIONID, auctionId);
                    getOperation().addParameter("brokerage", brokerage);
                    getOperation().addParameter("markupPrice", markupPrice);
                    getOperation().addParameter("status", currentStatus);
                    getOperation().addParameter("startPrice", startPrice);
                    getOperation().addParameter("endTime", endTimes);
                    getOperation().addParameter("type", 2);
                    getOperation().forward(AuctionActivity.class);
                    break;
                case R.id.tv_share:
                    getOperation().forward(InviteFriendActivity.class);
                    break;
            }
        });
        binding.vpBanner.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {
            }

            @Override
            public void onPageSelected(int position) {
                currentIndex = position;
                for (int i = 0; i < binding.llDot.getChildCount(); i++) {
                    binding.llDot.getChildAt(i).setSelected(false);
                }
                binding.llDot.getChildAt(position).setSelected(true);
            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });
    }


    @Override
    public void getGoodsDetailSuccess(GoodDetailsMode mode) {
        //banner
        initBanner(mode.headImage);
        if (null != mode.goodsDetail) {
            //富文本显示
            binding.tvGoodDetails.setMovementMethod(LinkMovementMethod.getInstance());
            RichText.fromHtml(mode.goodsDetail).into(binding.tvGoodDetails);
        }
        brokerage = mode.brokerage;
        goodsName = mode.goodsName;
        startPrice = mode.startPrice;
        DecimalFormat df = new DecimalFormat("##.##");
        binding.tvStartPrice.setText("  ¥ " + df.format(mode.startPrice));
        markupPrice = mode.markupPrice;
        binding.tvRangePrice.setText("  ¥ " + df.format(markupPrice));
        binding.tvValuationPrice.setText("  ¥ " + df.format(mode.assessPrice));
        binding.tvCommissionPrice.setText("  ¥ " + df.format(mode.brokerage));
        binding.tvWatchNum.setText(mode.viewCount == null ? "0" : mode.viewCount + "人");
        binding.tvGoodsTitle.setText(mode.goodsName);
        startTimes = mode.startTimes;
        endTimes = mode.endTimes;
        cashDepositScale = mode.cashDepositScale;
        if (mode.status == 2) {
            binding.llStatusPrice.setBackgroundColor(Color.parseColor("#4A90E2"));
            binding.tvStatusPriceTitle.setText("起拍价 ");
            binding.tvStatusPricet.setText("¥" + df.format(mode.startPrice));
            binding.rlGoodsRemainTime.setVisibility(View.VISIBLE);
            binding.tvGoodsStatusFinished.setVisibility(View.GONE);
            binding.tvRemainTips.setText("距离开拍时间:");
            hasCalculationStart = false;
            handler.sendEmptyMessage(2);
            binding.rlOfferCount.setVisibility(View.GONE);
            binding.tvToBay.setVisibility(View.GONE);
            binding.tvBottomStatus.setText("即将开始");
            binding.tvBottomStatus.setVisibility(View.VISIBLE);
            binding.tvBottomStatus.setBackgroundColor(Color.GRAY);
            binding.rlOfferNow.setVisibility(View.GONE);
        } else if (mode.status == 3) {
            hasCalculationEnd = false;
            handler.sendEmptyMessage(3);
            binding.llStatusPrice.setBackgroundColor(Color.parseColor("#4A90E2"));
            binding.tvStatusPriceTitle.setText("当前出价 ");
            binding.tvStatusPricet.setText("¥" + df.format(mode.topPrice));
            binding.rlGoodsRemainTime.setVisibility(View.VISIBLE);
            binding.tvGoodsStatusFinished.setVisibility(View.GONE);
            binding.tvRemainTips.setText("距离结束还剩:");
            binding.tvToBay.setVisibility(View.VISIBLE);
            binding.rlOfferCount.setVisibility(View.GONE);
            binding.tvBottomStatus.setVisibility(View.GONE);
            binding.rlOfferNow.setVisibility(View.VISIBLE);
            double v = mode.topPrice + markupPrice;
            double v1 = v * cashDepositScale;
            binding.tvOfferNow.setText("我出价¥ " + df.format(v) + "(含保证金¥+" + df.format(v1) +
                    ")");
        } else if (mode.status > 3) {
            handler.sendEmptyMessage(5);
            binding.rlGoodsRemainTime.setVisibility(View.GONE);
            binding.tvGoodsStatusFinished.setVisibility(View.VISIBLE);
            binding.llStatusPrice.setBackgroundColor(Color.parseColor("#C9C9C9"));
            binding.tvStatusPriceTitle.setText("成交价");
            binding.tvStatusPricet.setText("¥" + mode.topPrice);
            presenter.getGoodRankList(auctionId);
            binding.rlOfferCount.setVisibility(View.VISIBLE);
            binding.tvToBay.setVisibility(View.VISIBLE);
            binding.tvBottomStatus.setText("已结束");
            binding.tvBottomStatus.setBackgroundColor(Color.GRAY);
            binding.rlOfferNow.setVisibility(View.GONE);
        }

    }

    @Override
    public void getGoodsRankListSuccess(List<GoodsRankListMode> list) {
        if (currentStatus > 3) {
            binding.rlOfferCount.setVisibility(View.VISIBLE);
            GlideUtils.loadImage(this, list.get(0).avatar, binding.ivUserImage,
                    R.mipmap.img_goodsdetails_head1);
            binding.tvNikeName.setText(list.get(0).userName);
            binding.tvOfferCenterProfit.setText(StrUtils.getRemoveZreoNum(list.get(0).totalPrice));
            binding.tvOfferCenterTime.setText(list.get(0).num + "");
            list.remove(0);
            rankAdapter.setData(list);
        } else {
            binding.rlOfferCount.setVisibility(View.GONE);
        }
    }

    private void initBanner(String headImage) {
        if (bannerList != null) return;
        try {
            JSONArray param = new JSONArray(headImage);
            bannerList = new ArrayList<>();
            for (int i = 0; i < param.length(); i++) {
                bannerList.add(param.get(i).toString());
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        if (bannerList != null) {
            bannerAdapter.setData(bannerList);
            for (int i = 0; i < bannerList.size(); i++) {
                // 设置相应下面小红点
                ImageView dotImage = new ImageView(this);
                dotImage.setImageResource(R.drawable.shape_dot_selector);
                // 设置原点的宽度和 间距
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(DimensUtils
                        .dp2px(this, 8), DimensUtils.dp2px(this, 8));
                params.leftMargin = DimensUtils.dp2px(this, 10);
                dotImage.setSelected(false);
                binding.llDot.addView(dotImage, params);
            }
            if (binding.llDot.getChildCount() > 0) {
                binding.llDot.getChildAt(0).setSelected(true);
                currentIndex = 0;
                maxIndex = binding.llDot.getChildCount();
            }
            setTimeTask(true);
        }
    }



    /**
     * banner 定时任务 轮播
     *
     * @param isVisibleToUser
     */
    private void setTimeTask(boolean isVisibleToUser) {
        if (maxIndex == 1) return;
        if (isVisibleToUser) {
            timer = new Timer();
            timerTask = new TimerTask() {
                @Override
                public void run() {
                    autoChangeBanner();
                }
            };
            //每隔两S发送一次网速
            timer.schedule(timerTask, 4000, 4000);
        } else {
            if (timer == null) return;
            timer.cancel();
        }
    }

    //自动轮播
    private void autoChangeBanner() {
        if (++currentIndex >= maxIndex) {
            currentIndex = 0;
        }
        runOnUiThread(() -> {
            binding.vpBanner.setCurrentItem(currentIndex);
        });
    }

}
