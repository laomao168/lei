package com.freedom.supercoin.mode;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2020/1/10.
 * @desc : 最新支付宝支付 用于网页跳转支付
 */
public class NewPayRes {

    /**
     * code : 0
     * count : null
     * data : {"order":"https://qr.alipay.com/bax01160kt7irm5v1v1r20f2"}
     * error : false
     * msg : 订单创建成功！
     * result : true
     * success : true
     */

    public String code;
    public Object count;
    public DataBean data;
    public boolean error;
    public String msg;
    public boolean result;
    public boolean success;

    public static class DataBean {
        /**
         * order : https://qr.alipay.com/bax01160kt7irm5v1v1r20f2
         */

        public String order;
    }
}
