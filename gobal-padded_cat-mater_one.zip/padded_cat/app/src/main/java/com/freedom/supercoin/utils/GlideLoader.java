package com.freedom.supercoin.utils;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;
import com.freedom.supercoin.base_library.utils.GlideUtils;
import com.lzy.imagepicker.loader.ImageLoader;

public class GlideLoader implements ImageLoader {

    @Override
    public void displayImage(Activity activity, String path, ImageView imageView, int width,
                             int height) {
        GlideUtils.loadImage(activity,path,imageView);
    }

    @Override
    public void displayImagePreview(Activity activity, String path, ImageView imageView,
                                    int width, int height) {
        GlideUtils.loadImage(activity,path,imageView);
    }

    @Override
    public void clearMemoryCache() {

    }
}
