package com.freedom.supercoin.mode;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2019/12/30.
 * @desc :
 */
public class CheckPwdMode {

    /**
     * code : 0
     * count : null
     * data : false
     * error : false
     * msg : 操作成功
     * result : true
     * success : true
     */

    public String code;
    public Object count;
    public boolean data;
    public boolean error;
    public String msg;
    public boolean result;
    public boolean success;
}
