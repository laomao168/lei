package com.freedom.supercoin.mode;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2019/12/30.
 * @desc :
 */
public class RealNameMode {

    /**
     * code :
     * count : null
     * data : 1
     * error : false
     * msg : 提交成功!
     * result : true
     * success : true
     */

    public String code;
    public Object count;
    public int data;
    public boolean error;
    public String msg;
    public boolean result;
    public boolean success;
}
