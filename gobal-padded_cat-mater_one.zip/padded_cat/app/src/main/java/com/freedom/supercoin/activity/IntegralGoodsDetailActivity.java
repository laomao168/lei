package com.freedom.supercoin.activity;

import android.support.v4.view.ViewPager;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.freedom.supercoin.R;
import com.freedom.supercoin.adapter.DetailBannerAdapter;
import com.freedom.supercoin.base_library.AppConst;
import com.freedom.supercoin.base_library.utils.DimensUtils;
import com.freedom.supercoin.common.UiActivity;
import com.freedom.supercoin.contract.IntegralGoodsDetailContact;
import com.freedom.supercoin.databinding.ActivityIntegralGoodsDetailsBinding;
import com.freedom.supercoin.mode.IntegralGoodsDetailBean;
import com.freedom.supercoin.mode.IntegralOrderBean;
import com.freedom.supercoin.persenter.IntegralGoodsDetailPresenter;
import com.zzhoujay.richtext.RichText;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2020/4/10.
 * @desc : 积分商品详情
 */
public class IntegralGoodsDetailActivity extends UiActivity<ActivityIntegralGoodsDetailsBinding> implements IntegralGoodsDetailContact.View {

    private IntegralGoodsDetailPresenter presenter;
    private int goodsId;
    private DetailBannerAdapter bannerAdapter;
    private ArrayList<String> bannerList;
    private int currentIndex;
    private int maxIndex;
    private Timer timer;
    private TimerTask timerTask;

    @Override
    protected int layoutResId() {
        return R.layout.activity_integral_goods_details;
    }

    @Override
    protected void initData() {
        binding.titleBar.setTextColor("#ffffff");
        binding.titleBar.setLeftImage(R.mipmap.ic_back_white);
        binding.titleBar.setTitle("商品详情");
        goodsId = getIntent().getIntExtra(AppConst.Keys.GOODS_ID, 0);
        presenter = new IntegralGoodsDetailPresenter(this);
        bannerAdapter = new DetailBannerAdapter(this, null);
        binding.vpBanner.setAdapter(bannerAdapter);

    }
    @Override
    protected void onStart() {
        super.onStart();
        presenter.loadIntegralGoodsDetail(goodsId);
    }
    @Override
    protected void initEvent() {
        binding.vpBanner.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {

            }

            @Override
            public void onPageSelected(int position) {
                currentIndex = position;
                for (int i = 0; i < binding.llDot.getChildCount(); i++) {
                    binding.llDot.getChildAt(i).setSelected(false);
                }
                binding.llDot.getChildAt(position).setSelected(true);
            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });
        binding.setClick(v -> {
            switch (v.getId()) {
                case R.id.tv_buy:
                    presenter.perPay(goodsId);
//                    getOperation().addParameter(AppConst.Keys.GOODS_ID, goodsId);
//        getOperation().forward(IntegralPayActivity.class);
                    break;

                case R.id.tv_share:
                    getOperation().forward(InviteFriendActivity.class);
                    break;

            }
        });
    }

    @Override
    public void onLoadIntegralGoodsDetailSuccess(IntegralGoodsDetailBean bean) {
        initBanner(bean.data.headImage);
        if (null != bean.data.goodsDetail) {
            //富文本显示
            binding.tvGoodDetails.setMovementMethod(LinkMovementMethod.getInstance());
            RichText.fromHtml(bean.data.goodsDetail).into(binding.tvGoodDetails);
        }
        binding.tvGoodsTitle.setText(bean.data.goodsName);
//        价格类型 1.积分 2.积分+金额，3.金额
//        4000 积分  +  ¥400
        if (bean.data.priceType == 1) {
            binding.tvPrice.setText(bean.data.integral + " 积分");
        } else if (bean.data.priceType == 2) {
            binding.tvPrice.setText(bean.data.integral + " 积分+" + " ¥" + bean.data.price);
        } else {
            binding.tvPrice.setText(" ¥" + bean.data.price);
        }
        //估值
        binding.tvValuationNum.setText(" ¥" + bean.data.assessPrice);
    }
    //预支付成功 跳转到支付页面
    @Override
    public void onPerPaySuccess(IntegralOrderBean bean) {
        getOperation().addParameter(AppConst.Keys.GOODS_ID, goodsId);
        getOperation().forward(IntegralPayActivity.class);
        finish();
    }

    private void initBanner(String headImage) {
        try {
            JSONArray param = new JSONArray(headImage);
            bannerList = new ArrayList<>();
            for (int i = 0; i < param.length(); i++) {
                bannerList.add(param.get(i).toString());
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        if (bannerList != null) {
            bannerAdapter.setData(bannerList);
            for (int i = 0; i < bannerList.size(); i++) {
                // 设置相应下面小红点
                ImageView dotImage = new ImageView(this);
                dotImage.setImageResource(R.drawable.shape_dot_selector);
                // 设置原点的宽度和 间距
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(DimensUtils
                        .dp2px(this, 8), DimensUtils.dp2px(this, 8));
                params.leftMargin = DimensUtils.dp2px(this, 10);
                dotImage.setSelected(false);
                binding.llDot.addView(dotImage, params);
            }
            if (binding.llDot.getChildCount() > 0) {
                binding.llDot.getChildAt(0).setSelected(true);
                currentIndex = 0;
                maxIndex = binding.llDot.getChildCount();
            }
            setTimeTask(true);
        }
    }

    /**
     * banner 定时任务 轮播
     *
     * @param isVisibleToUser
     */
    private void setTimeTask(boolean isVisibleToUser) {
        if (maxIndex == 1) return;
        if (isVisibleToUser) {
            timer = new Timer();
            timerTask = new TimerTask() {
                @Override
                public void run() {
                    autoChangeBanner();
                }
            };
            //每隔两S发送一次网速
            timer.schedule(timerTask, 4000, 4000);
        } else {
            if (timer == null) return;
            timer.cancel();
        }
    }

    //自动轮播
    private void autoChangeBanner() {
        if (++currentIndex >= maxIndex) {
            currentIndex = 0;
        }
        runOnUiThread(() -> {
            binding.vpBanner.setCurrentItem(currentIndex);
        });
    }
}
