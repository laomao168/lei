package com.freedom.supercoin.adapter;

import android.databinding.DataBindingUtil;
import android.graphics.Color;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.freedom.supercoin.R;
import com.freedom.supercoin.base_library.base.BaseEmptyAdapter;
import com.freedom.supercoin.base_library.utils.GlideUtils;
import com.freedom.supercoin.base_library.utils.StrUtils;
import com.freedom.supercoin.base_library.utils.TimeUtil;
import com.freedom.supercoin.databinding.ItemProductBinding;
import com.freedom.supercoin.mode.HomeAuctionRes;

public class ProductAdapter extends BaseEmptyAdapter<HomeAuctionRes.DataBeanX.DataBean,
        ItemProductBinding> {
    @Override
    protected ItemProductBinding createBinding(ViewGroup parent) {
        return DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()),
                R.layout.item_product, parent, false);
    }

    @Override
    protected void onBindView(ItemProductBinding binding,
                              HomeAuctionRes.DataBeanX.DataBean bean, int position) {
        GlideUtils.loadRound(context, bean.logo, binding.ivProduct, 10);
        binding.tvProductTitle.setText(bean.goodsName);
        if (bean.status == 2) {
            binding.tvProductPriceTitle.setText("起拍价");
            binding.tvProductPrice.setText("¥" + StrUtils.getRemoveZreoNum(bean.startPrice));
            binding.tvProductTimeTitle.setText("开拍时间");
            binding.tvProductTime.setText(bean.startTime.substring(11));
            binding.tvBidTimeTitle.setText("次围观");
            binding.tvPriceTime.setText(bean.viewCount + "");
            binding.tvPriceTime.setTextColor(Color.WHITE);
            binding.tvStatus.setText("即将开始");
            binding.tvStatus.setBackgroundResource(R.drawable.shape_home_rv_title_bg);
            binding.tvProductBid.setVisibility(View.GONE);
        } else if (bean.status == 3) {
            binding.tvProductPriceTitle.setText("当前价");
            binding.tvProductPrice.setText("¥" + StrUtils.getRemoveZreoNum(bean.topPrice));
            binding.tvProductTimeTitle.setText("结拍时间");
            binding.tvProductTime.setText(bean.endTime.substring(11));
            binding.tvStatus.setText("正在拍卖");
            binding.tvBidTimeTitle.setText("次出价");
            binding.tvPriceTime.setTextColor(Color.parseColor("#E51837"));
            binding.tvStatus.setBackgroundResource(R.drawable.shape_home_rv_title_autioning_bg);
            binding.tvPriceTime.setText(bean.markupNum + "");
        } else if (bean.status > 3) {
            binding.tvProductPriceTitle.setText("当前价");
            binding.tvProductPrice.setText("¥" + StrUtils.getRemoveZreoNum(bean.topPrice));
            binding.tvProductBid.setVisibility(View.GONE);
            binding.tvProductTimeTitle.setText("结拍时间");
            binding.tvProductTime.setText(bean.endTime.substring(11));
            binding.tvPriceTime.setText(bean.markupNum + "");
            binding.tvPriceTime.setTextColor(Color.WHITE);
            binding.tvStatus.setVisibility(View.GONE);
        }


        binding.root.setOnClickListener(v -> {
            if (onItemClickListener != null) {
                onItemClickListener.onItemClick(position, bean);
            }
        });
    }
}
