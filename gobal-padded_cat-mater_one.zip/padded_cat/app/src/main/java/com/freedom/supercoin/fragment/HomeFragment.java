package com.freedom.supercoin.fragment;

import android.graphics.Color;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.GridLayoutManager;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.freedom.supercoin.R;
import com.freedom.supercoin.activity.ChargeActivity;
import com.freedom.supercoin.activity.GoodsCategoryActivity;
import com.freedom.supercoin.activity.GoodsDetailActivity;
import com.freedom.supercoin.activity.LoginTipsActivity;
import com.freedom.supercoin.activity.WebActivity;
import com.freedom.supercoin.adapter.GoodsCategoryAdapter;
import com.freedom.supercoin.adapter.HomeBannerAdapter;
import com.freedom.supercoin.adapter.ProductAdapter;
import com.freedom.supercoin.base_library.AppConst;
import com.freedom.supercoin.base_library.base.BaseEmptyAdapter;
import com.freedom.supercoin.base_library.utils.DimensUtils;
import com.freedom.supercoin.common.UILazyFragment;
import com.freedom.supercoin.contract.HomeFragmentContact;
import com.freedom.supercoin.databinding.FragmentHomeBinding;
import com.freedom.supercoin.mode.GoodsCategoryMode;
import com.freedom.supercoin.mode.HomeAuctionRes;
import com.freedom.supercoin.mode.HomeBannerMode;
import com.freedom.supercoin.mode.entity.HomeAuctionReq;
import com.freedom.supercoin.mode.entity.Page;
import com.freedom.supercoin.persenter.HomeFragmentPresenter;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;


/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2019/7/18.
 */

public class HomeFragment extends UILazyFragment<FragmentHomeBinding> implements HomeFragmentContact.View, BaseEmptyAdapter.OnItemClickListener<GoodsCategoryMode> {

    private int currentIndex;
    private HomeBannerAdapter homeBannerAdapter;
    private int maxIndex;
    private Timer timer;
    private TimerTask timerTask;
    private ProductAdapter productAdapter;
    private HomeFragmentPresenter presenter;
    private List<HomeBannerMode> homeBannerList;
    private List<HomeAuctionRes.DataBeanX.DataBean> todayList;
    private List<HomeAuctionRes.DataBeanX.DataBean> previewList;
    private int pageNumberToday = 1;
    private int pageNumberPreview = 1;
    private int pageNumberAfterTom = 1;
    private int typeList = 1;
    private GoodsCategoryAdapter goodsCategoryAdapter;
    HomeAuctionReq homeAuctionReq = new HomeAuctionReq();
    @Override
    protected int getLayoutId() {
        return R.layout.fragment_home;
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        setTimeTask(isVisibleToUser);
    }

    @Override
    protected void initData() {
        presenter = new HomeFragmentPresenter(this);
        //轮播图
        homeBannerAdapter = new HomeBannerAdapter(mActivity, null);
        binding.vpBanner.setAdapter(homeBannerAdapter);

        //初始化 今日列表
        productAdapter = new ProductAdapter();
        binding.homeRecyclerView.setLayoutManager(new GridLayoutManager(mActivity, 2));
        binding.homeRecyclerView.setAdapter(productAdapter);
        //拍卖商品分类
        binding.homeRvItem.setLayoutManager(new GridLayoutManager(mActivity, 4));
        goodsCategoryAdapter = new GoodsCategoryAdapter();
        goodsCategoryAdapter.setOnItemClickListener(this);
        binding.homeRvItem.setAdapter(goodsCategoryAdapter);
        binding.homeRecyclerView.setNestedScrollingEnabled(false);
        presenter.getGoodsCategoryList();
    }


    @Override
    public void onStart() {
        super.onStart();
        if (presenter==null)return;
            presenter.getHomeBannerList();
        if (typeList == 1) {
            presenter.getAuctionRecordInfoToday(new Page());
        } else if (typeList == 2) {
            homeAuctionReq.type = 2;
            homeAuctionReq.pageNumber = 1;
            homeAuctionReq.pageSize = 10;
            presenter.getAuctionRecordInfoPreview(homeAuctionReq);
        } else {
            homeAuctionReq.type = 3;
            homeAuctionReq.pageNumber = 1;
            homeAuctionReq.pageSize = 10;
            presenter.getAuctionRecordInfoPreview(homeAuctionReq);
        }
    }

    /**
     * banner 定时任务 轮播
     *
     * @param isVisibleToUser
     */
    private void setTimeTask(boolean isVisibleToUser) {
        if (maxIndex == 1) return;
        if (isVisibleToUser) {
            timer = new Timer();
            timerTask = new TimerTask() {
                @Override
                public void run() {
                    autoChangeBanner();
                }
            };
            //每隔两S发送一次网速
            timer.schedule(timerTask, 4000, 4000);
        } else {
            if (timer == null) return;
            timer.cancel();
        }
    }

    //自动轮播
    private void autoChangeBanner() {
        if (++currentIndex >= maxIndex) {
            currentIndex = 0;
        }
        if (mActivity == null) return;
        mActivity.runOnUiThread(() -> {
            binding.vpBanner.setCurrentItem(currentIndex);
        });
    }

    @Override
    protected void initEvent() {
        //点击事件
        binding.setClick(v -> {
            switch (v.getId()) {
                //今天
                case R.id.ll_today:
                    typeList = 1;
                    presenter.getAuctionRecordInfoToday(new Page());
                    pageNumberToday = 1;

                    binding.tvToday.setTextColor(Color.parseColor("#4A90E2"));
                    binding.tvTodayTips.setTextColor(Color.WHITE);
                    binding.tvTodayTips.setBackgroundResource(R.drawable.shape_home_rv_title_bg);

                    binding.tvTom.setTextColor(Color.parseColor("#202020"));
                    binding.tvTomTips.setTextColor(Color.parseColor("#666666"));
                    binding.tvTomTips.setBackgroundColor(Color.TRANSPARENT);

                    binding.tvAfterTom.setTextColor(Color.parseColor("#202020"));
                    binding.tvAfterTomTips.setTextColor(Color.parseColor("#666666"));
                    binding.tvAfterTomTips.setBackgroundColor(Color.TRANSPARENT);

                    break;
                //明天
                case R.id.ll_tom:
                    typeList = 2;
                    homeAuctionReq.type = 2;
                    homeAuctionReq.pageNumber = 1;
                    presenter.getAuctionRecordInfoPreview(homeAuctionReq);
                    pageNumberPreview = 1;

                    binding.tvTom.setTextColor(Color.parseColor("#4A90E2"));
                    binding.tvTomTips.setTextColor(Color.WHITE);
                    binding.tvTomTips.setBackgroundResource(R.drawable.shape_home_rv_title_bg);

                    binding.tvToday.setTextColor(Color.parseColor("#202020"));
                    binding.tvTodayTips.setTextColor(Color.parseColor("#666666"));
                    binding.tvTodayTips.setBackgroundColor(Color.TRANSPARENT);

                    binding.tvAfterTom.setTextColor(Color.parseColor("#202020"));
                    binding.tvAfterTomTips.setTextColor(Color.parseColor("#666666"));
                    binding.tvAfterTomTips.setBackgroundColor(Color.TRANSPARENT);

                    break;
                //后天
                case R.id.ll_after_tom:
                    typeList = 3;
                    homeAuctionReq.type = 3;
                    homeAuctionReq.pageNumber = 1;
                    presenter.getAuctionRecordInfoPreview(homeAuctionReq);
                    pageNumberAfterTom = 1;

                    binding.tvAfterTom.setTextColor(Color.parseColor("#4A90E2"));
                    binding.tvAfterTomTips.setTextColor(Color.WHITE);
                    binding.tvAfterTomTips.setBackgroundResource(R.drawable.shape_home_rv_title_bg);

                    binding.tvTom.setTextColor(Color.parseColor("#202020"));
                    binding.tvTomTips.setTextColor(Color.parseColor("#666666"));
                    binding.tvTomTips.setBackgroundColor(Color.TRANSPARENT);

                    binding.tvToday.setTextColor(Color.parseColor("#202020"));
                    binding.tvTodayTips.setTextColor(Color.parseColor("#666666"));
                    binding.tvTodayTips.setBackgroundColor(Color.TRANSPARENT);
                    break;

            }
        });
        //轮播图 点击事件
        homeBannerAdapter.setOnItemClickListener(position -> {
//            type  ：
//            NBYM(1, "内部页面"),
//                    PMXQ(2, "拍卖详情"),
//                    PMFL(3, "拍卖分类"),
//                    BTZ(5, "不跳转"),
//                    H5(4, "h5页面");
            HomeBannerMode homeBannerMode = homeBannerList.get(position);
            switch (homeBannerMode.type) {
                case 1:
                    break;
                case 2:
                    getOperation().addParameter(AppConst.Keys.AUCTIONID, homeBannerMode.linkId);
                    getOperation().forward(GoodsDetailActivity.class);
                    break;
                case 3:
                    getOperation().addParameter("type", 1);
                    getOperation().addParameter("categoryId",homeBannerMode.linkId);
                    getOperation().addParameter(AppConst.Keys.TITLE, homeBannerMode.name);
                    getOperation().forward(GoodsCategoryActivity.class);
                    break;
                case 4:
                    break;

            }
        });

        binding.vpBanner.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {

            }

            @Override
            public void onPageSelected(int position) {
                currentIndex = position;
                for (int i = 0; i < binding.llDot.getChildCount(); i++) {
                    binding.llDot.getChildAt(i).setSelected(false);
                }
                binding.llDot.getChildAt(position).setSelected(true);
            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });
        binding.vpBanner.setOnTouchListener((v, event) -> {
            if (binding.vpBanner.getCurrentItem() != 0) {
                binding.vpBanner.requestDisallowInterceptTouchEvent(true);
            }
            return false;
        });

        //上拉加载



        binding.scrollView.setScrollViewListener((v, scrollX, scrollY, oldScrollX, oldScrollY) -> {
            //判断是否滑到的底部
            if (scrollY == (v.getChildAt(0).getMeasuredHeight() - v.getMeasuredHeight())) {
                if (typeList == 1) {
                    pageNumberToday++;
                    Page page = new Page();
                    page.pageNumber = pageNumberToday;
                    presenter.getAuctionRecordInfoToday(page);

                } else if (typeList == 2) {
                    pageNumberPreview++;
                    homeAuctionReq.type = 2;
                    homeAuctionReq.pageNumber = pageNumberPreview;
                    presenter.getAuctionRecordInfoPreview(homeAuctionReq);
                } else {
                    pageNumberAfterTom++;
                    homeAuctionReq.type = 3;
                    homeAuctionReq.pageNumber = pageNumberAfterTom;
                    presenter.getAuctionRecordInfoPreview(homeAuctionReq);
                }
            }
        });

        productAdapter.setOnItemClickListener((position, data) -> {
            if (AppConst.ISLOGIN){
                getOperation().addParameter(AppConst.Keys.AUCTIONID, data.auctionId);
                getOperation().forward(GoodsDetailActivity.class);
            }else {
                getOperation().forward(LoginTipsActivity.class);
            }

        });
        //下拉刷新
        binding.swipeRefresh.setOnRefreshListener(() -> {
            presenter.getHomeBannerList();
            presenter.getGoodsCategoryList();
            if (typeList == 1) {
                pageNumberToday=1;
                presenter.getAuctionRecordInfoToday(new Page());
            } else if (typeList == 2) {
                pageNumberPreview=1;
                homeAuctionReq.type = 2;
                homeAuctionReq.pageNumber = 1;
                presenter.getAuctionRecordInfoPreview(new HomeAuctionReq());
            } else {
                pageNumberAfterTom = 1;
                homeAuctionReq.type = 3;
                homeAuctionReq.pageNumber = 1;
                presenter.getAuctionRecordInfoPreview(homeAuctionReq);
            }
        });
    }

    @Override
    public void getHomeBannerListSuccess(List<HomeBannerMode> list) {
        if (list == null) return;
        this.homeBannerList = list;
        homeBannerAdapter.setData(homeBannerList);
        binding.llDot.removeAllViews();
        for (int i = 0; i < list.size(); i++) {
            // 设置相应下面小红点
            ImageView dotImage = new ImageView(mActivity);
            dotImage.setImageResource(R.drawable.shape_dot_selector);
            // 设置原点的宽度和 间距
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(DimensUtils
                    .dp2px(mActivity, 8), DimensUtils.dp2px(mActivity, 8));
            params.leftMargin = DimensUtils.dp2px(mActivity, 10);
            dotImage.setSelected(false);
            binding.llDot.addView(dotImage, params);
        }
        if (binding.llDot.getChildCount() > 0) {
            binding.llDot.getChildAt(0).setSelected(true);
            currentIndex = 0;
            maxIndex = binding.llDot.getChildCount();
        }
    }

    @Override
    public void getTodayListSuccess(HomeAuctionRes res) {
        binding.swipeRefresh.setRefreshing(false);
        if (res == null || !res.success || res.data.data.size() == 0){
            if (pageNumberToday==1){
                productAdapter.setData(new ArrayList<>());
            }
        }else {
            if (pageNumberToday == 1) { //新的
                productAdapter.setData(res.data.data);
            } else { //增加
                productAdapter.addDataList(res.data.data);
            }
        }

    }

    @Override
    public void getPreviewList(HomeAuctionRes res) {
        binding.swipeRefresh.setRefreshing(false);
        if (res == null || !res.success) {
                productAdapter.setData(new ArrayList<>());
        }else {
            if ((typeList == 2 && pageNumberPreview == 1) || (typeList == 3 && pageNumberAfterTom == 1)) {
                productAdapter.setData(res.data.data);
            } else {
                productAdapter.addDataList(res.data.data);
            }
        }
    }

    @Override
    public void onLoadGoodsCategorySuccess(List<GoodsCategoryMode> list) {
        if (list.size()==0){
            binding.homeRvItem.setVisibility(View.GONE);
        }else {
            binding.homeRvItem.setVisibility(View.VISIBLE);
            goodsCategoryAdapter.setData(list);
        }
    }

    @Override
    public void onLoadListError() {
        binding.swipeRefresh.setRefreshing(false);
        productAdapter.setData(new ArrayList<>());
    }

    @Override
    public void onItemClick(int position, GoodsCategoryMode data) {
        if (data.categoryId == 9999) {
            getOperation().addParameter(AppConst.Keys.TITLE, "拍卖规则");
            getOperation().addParameter(AppConst.Keys.WEB_URL,
                    AppConst.Values.AUCTION_RULES);
            getOperation().forward(WebActivity.class);
        } else if (data.categoryId == 8888) { //充值
            getOperation().forward(ChargeActivity.class);
        } else {
            getOperation().addParameter("categoryId", data.categoryId);
            getOperation().addParameter("type", 1);
            getOperation().addParameter(AppConst.Keys.TITLE, data.name);
            getOperation().forward(GoodsCategoryActivity.class);
        }
    }
}
