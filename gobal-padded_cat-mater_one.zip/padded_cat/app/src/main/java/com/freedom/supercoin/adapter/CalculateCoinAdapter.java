package com.freedom.supercoin.adapter;


public class CalculateCoinAdapter {
//        return DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()),
//                R.layout.item_calculate_coin, parent, false);
}
