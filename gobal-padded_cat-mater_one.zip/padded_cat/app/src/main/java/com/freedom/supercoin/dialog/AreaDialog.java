package com.freedom.supercoin.dialog;

import android.graphics.Color;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.Window;

import com.freedom.supercoin.R;
import com.freedom.supercoin.activity.AddressDetailNewActivity;
import com.freedom.supercoin.base_library.dialog.BaseDialog;
import com.freedom.supercoin.mode.StreetMode;
import com.zyyoona7.wheel.WheelView;

import java.util.ArrayList;
import java.util.List;

public class AreaDialog extends BaseDialog {

    private WheelView<StreetMode> province;
    private WheelView<StreetMode> city;
    private WheelView<StreetMode> area;
    private List<StreetMode> provinceList = new ArrayList<>();
    private List<StreetMode> cityList = new ArrayList<>();
    private List<StreetMode> areaList = new ArrayList<>();


    @Override
    protected int setContentId() {
        return R.layout.dialog_area;
    }

    @Override
    protected void initView() {
        province = findView(R.id.wheel_province);
        city = findView(R.id.wheel_city);
        area = findView(R.id.wheel_area);
        province.setData(provinceList);
        city.setData(cityList);
        area.setData(areaList);
        province.setTextSize(20f, true);
        area.setTextSize(20f, true);
        city.setTextSize(20f, true);
        province.setNormalItemTextColor(Color.parseColor("#666666"));
        province.setSelectedItemTextColor(Color.parseColor("#333333"));
        city.setNormalItemTextColor(Color.parseColor("#666666"));
        city.setSelectedItemTextColor(Color.parseColor("#333333"));
        area.setNormalItemTextColor(Color.parseColor("#666666"));
        area.setSelectedItemTextColor(Color.parseColor("#333333"));
        province.setShowDivider(true);
        province.setDividerColor(Color.parseColor("#80999999"));
        city.setShowDivider(true);
        city.setDividerColor(Color.parseColor("#80999999"));
        area.setShowDivider(true);
        area.setDividerColor(Color.parseColor("#80999999"));
    }

    @Override
    protected void initData() {
        initEvent();
    }

    private void initEvent() {
        province.setOnItemSelectedListener((wheelView, data, position) -> {
            if (areaItemSelectInterface != null) {
                areaItemSelectInterface.onProvinceSelect(position);
            }
        });

        city.setOnItemSelectedListener((wheelView, data, position) -> {
            if (areaItemSelectInterface != null) {
                areaItemSelectInterface.onCitySelect(position);
            }
        });

        area.setOnItemSelectedListener((wheelView, data, position) -> {
            if (areaItemSelectInterface != null) {
                areaItemSelectInterface.onAreaSelect(position);
            }
        });
        findView(R.id.tv_cancel).setOnClickListener(v -> {
            dismiss();
        });
        findView(R.id.tv_confirm).setOnClickListener(v -> {
            if (areaItemSelectInterface!=null){
                areaItemSelectInterface.OnConfirm();
            }
            dismiss();
        });
    }

    public void setData(List<StreetMode> list, int type) {
        if (type == AddressDetailNewActivity.TYPE_PROVINCE) {
            if (provinceList.isEmpty()) {
                provinceList.addAll(list);
            }
        } else if (type == AddressDetailNewActivity.TYPE_CITY) {
            cityList.clear();
            cityList.addAll(list);
            if (city != null) {
                city.setData(cityList);
            }
        } else {
            areaList.clear();
            areaList.addAll(list);
            if (area != null) {
                area.setData(areaList);
            }
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        DisplayMetrics dm = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(dm);
        Window window = getDialog().getWindow();
        window.setLayout(dm.widthPixels, window.getAttributes().height);
        window.setGravity(Gravity.BOTTOM);
    }


    public interface AreaItemSelectInterface {
        void onProvinceSelect(int index);

        void onCitySelect(int index);

        void onAreaSelect(int index);
        void OnConfirm();
    }

    public AreaItemSelectInterface areaItemSelectInterface;

    public void setAreaItemSelectInterface(AreaItemSelectInterface areaItemSelectInterface) {
        this.areaItemSelectInterface = areaItemSelectInterface;
    }
}
