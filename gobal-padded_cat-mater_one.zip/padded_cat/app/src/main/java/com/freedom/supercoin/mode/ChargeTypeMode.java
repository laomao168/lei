package com.freedom.supercoin.mode;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2020/1/5.
 * @desc :
 */
public class ChargeTypeMode {

    /**
     * code : 0
     * count : null
     * data : 1
     * error : false
     * msg : SUCCESS
     * result : true
     * success : true
     */

    public String code;
    public Object count;
    public String data;
    public boolean error;
    public String msg;
    public boolean result;
    public boolean success;
}
