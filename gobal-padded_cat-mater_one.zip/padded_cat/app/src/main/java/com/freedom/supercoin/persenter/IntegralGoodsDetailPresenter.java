package com.freedom.supercoin.persenter;

import com.freedom.supercoin.base_library.utils.GsonUtils;
import com.freedom.supercoin.base_library.utils.LogUtils;
import com.freedom.supercoin.contract.IntegralGoodsDetailContact;
import com.freedom.supercoin.mode.IntegralGoodsDetailBean;
import com.freedom.supercoin.mode.IntegralOrderBean;
import com.freedom.supercoin.mode.PayErrorRes;
import com.freedom.supercoin.network.DataManager;
import com.freedom.supercoin.network.ResponseErrorFunc;
import com.freedom.supercoin.network.RxUtils;

import okhttp3.ResponseBody;
import rx.Subscriber;


public class IntegralGoodsDetailPresenter implements IntegralGoodsDetailContact.Presenter {

    private final IntegralGoodsDetailContact.View view;

    public IntegralGoodsDetailPresenter(IntegralGoodsDetailContact.View view) {
        this.view = view;
    }


    @Override
    public void loadIntegralGoodsDetail(int goodId) {
        DataManager.getInstance()
                .getIntegralDetail(goodId)
                .compose(RxUtils.applyIOSchedulers())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(ResponseBody responseBody) {
                        view.hideProgress();
                        try {
                            String string = responseBody.string().trim();
                            LogUtils.ShowD("string", string);
                            if (string.contains("成功")) {
                                IntegralGoodsDetailBean integralGoodsDetailBean =
                                        GsonUtils.fromJson(string, IntegralGoodsDetailBean.class);
                                view.onLoadIntegralGoodsDetailSuccess(integralGoodsDetailBean);
                            } else {
                                PayErrorRes errorRes = GsonUtils.fromJson(string,
                                        PayErrorRes.class);
                                view.showMessage(errorRes.msg);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();

                        }
                    }
                });
    }

    @Override
    public void perPay(int goodId) {
        DataManager.getInstance()
                .prePayIntegralOrder(goodId)
                .compose(RxUtils.applyIOSchedulers())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(ResponseBody responseBody) {
                        view.hideProgress();
                        try {
                            String string = responseBody.string().trim();
                            LogUtils.ShowD("string", string);
                            if (string.contains("成功")) {
                                IntegralOrderBean orderBean =
                                        GsonUtils.fromJson(string, IntegralOrderBean.class);
                                view.onPerPaySuccess(orderBean);
                            } else {
                                PayErrorRes errorRes = GsonUtils.fromJson(string,
                                        PayErrorRes.class);
                                view.showMessage(errorRes.msg);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();

                        }
                    }
                });
    }
}
