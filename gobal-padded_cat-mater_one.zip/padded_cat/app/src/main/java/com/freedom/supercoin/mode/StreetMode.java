package com.freedom.supercoin.mode;

import com.zyyoona7.wheel.IWheelEntity;

import java.io.Serializable;

public class StreetMode implements IWheelEntity, Serializable {

    /**
     * areaname : 北京
     * id : 110000
     * parentid : 0
     * shortname : 北京
     */

    public String areaname;
    public int id;
    public int parentid;
    public String shortname;

    @Override
    public String getWheelText() {
        return areaname == null ? "" : areaname;
    }
}
