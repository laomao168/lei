package com.freedom.supercoin.contract;


import com.freedom.supercoin.base_library.base.BasePresenter;
import com.freedom.supercoin.base_library.base.BaseView;
import com.freedom.supercoin.mode.AddressListMode;
import com.freedom.supercoin.mode.BalanceDetailMode;
import com.freedom.supercoin.mode.ChargeTypeMode;
import com.freedom.supercoin.mode.IntegralGoodsDetailBean;
import com.freedom.supercoin.mode.OrderDetailMode;
import com.freedom.supercoin.mode.PayAlipayRes;
import com.freedom.supercoin.mode.PayReq;
import com.freedom.supercoin.mode.PayRes;


public class IntegralPayContact {

    public interface View extends BaseView {
        void onLoadChargeTypeSuccess(ChargeTypeMode mode);

        void onLoadPayResWechatSuccess(PayRes payRes, int payType);

        void getBalanceSuccess(BalanceDetailMode mode);

        void onLoadPayResAlipaySuccess(PayAlipayRes payAlipayRes, int payType);

        void getOrderDetailSuccess(OrderDetailMode mode);
        void getAddressListSuccess(AddressListMode mode);

        void onLoadPayResBalanceSuccess();

        void onLoadIntegralGoodsDetailSuccess(IntegralGoodsDetailBean bean);
    }


    public interface Presenter extends BasePresenter {
        void getBalance();

        void getOrderDetail(int orderId);

        void getPaytype();

        void getChargeType();

        void getPayInfo(PayReq payReq);
        void getAddress();
        void  loadIntegralGoodsDetail(int goodsId);
    }
}

