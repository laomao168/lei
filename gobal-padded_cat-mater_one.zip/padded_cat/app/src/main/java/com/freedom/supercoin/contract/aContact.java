package com.freedom.supercoin.contract;


import com.freedom.supercoin.base_library.base.BasePresenter;
import com.freedom.supercoin.base_library.base.BaseView;


public class aContact {

    public interface View extends BaseView {

    }


    public interface Presenter extends BasePresenter {
    }
}

