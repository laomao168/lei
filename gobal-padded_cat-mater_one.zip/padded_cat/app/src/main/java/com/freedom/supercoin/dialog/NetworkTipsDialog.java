package com.freedom.supercoin.dialog;


import com.freedom.supercoin.R;
import com.freedom.supercoin.base_library.dialog.BaseDialog;

/**
 * Created by jianping on 2018/10/29.
 */

public class NetworkTipsDialog extends BaseDialog {
    @Override
    protected int setContentId() {
        return R.layout.dialog_network_tips;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }

    @Override
    public void onResume() {
        super.onResume();
        this.setCancelable(false);
    }
}
