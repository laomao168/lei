package com.freedom.supercoin.mode;

import java.util.List;

public class GoodsRankListMode {

    /**
     * avatar : https://wx.qlogo
     * .cn/mmopen/vi_32
     * /ib3S4Yqib45FuFErT32fDXoaMUGatodGWsLAxgUHPricCQZiavw7BpuIxfopMzhsvmW5dunmJfvIQY9PC3nd31KLFQ/132
     * num : 3
     * totalPrice : 6.0
     * userName : 威武霸气你牛哥😘
     */

    public String avatar;
    public int num;
    public double totalPrice;
    public String userName;
}
