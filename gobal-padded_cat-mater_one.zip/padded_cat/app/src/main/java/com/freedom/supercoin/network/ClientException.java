package com.freedom.supercoin.network;

import android.support.annotation.Nullable;


public class ClientException extends RuntimeException {
    @Nullable
    private String forwardUrl;
    private String statusCode;
    public String message;


    public ClientException(Result result) {
        this(result.getErrCode(), result.getErrMsg());
    }


    public ClientException(String statusCode, String message) {
        super(message);
        this.message = message;
        this.statusCode = statusCode;
    }


    public ClientException(String statusCode, String message, @Nullable String forwardUrl) {
        super(message);
        this.message = message;
        this.statusCode = statusCode;
        this.forwardUrl = forwardUrl;
    }


    public String getStatusCode() {
        return this.statusCode;
    }


    @Nullable
    public String getForwardUrl() {
        return this.forwardUrl;
    }
}
