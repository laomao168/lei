package com.freedom.supercoin.activity;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.view.View;

import com.freedom.supercoin.R;
import com.freedom.supercoin.base_library.utils.StrUtils;
import com.freedom.supercoin.common.UiActivity;
import com.freedom.supercoin.contract.ChargeContact;
import com.freedom.supercoin.databinding.ActivityChargeBinding;
import com.freedom.supercoin.mode.BalanceDetailMode;
import com.freedom.supercoin.mode.ChargeTypeMode;
import com.freedom.supercoin.mode.NewPayRes;
import com.freedom.supercoin.mode.PayAlipayRes;
import com.freedom.supercoin.mode.PayReq;
import com.freedom.supercoin.mode.PayRes;
import com.freedom.supercoin.persenter.ChargePresenter;
import com.freedom.supercoin.utils.AliPayAPI;
import com.freedom.supercoin.utils.WXPayUtils;
import com.hjq.toast.ToastUtils;

/**
 * @author : lijianping
 * @date : Created on 2019/7/11.
 * des:重置
 */
public class ChargeActivity extends UiActivity<ActivityChargeBinding> implements ChargeContact.View, AliPayAPI.OnAliPayListener {

    private double balance;
    private ChargePresenter presenter;
    private int showType;
    private int paytype;

    @Override
    protected int layoutResId() {
        return R.layout.activity_charge;
    }

    @Override
    protected void initData() {
        binding.titleBar.setTextColor("#ffffff");
        binding.titleBar.setLeftImage(R.mipmap.ic_back_white);
        binding.titleBar.setTitle("账户充值");
        balance = getIntent().getDoubleExtra("balance", 0);
        binding.tvBalance.setText(StrUtils.getRemoveZreoNum(balance));
        presenter = new ChargePresenter(this);
        presenter.getChargeType();
    }

    @Override
    protected void onResume() {
        super.onResume();
        presenter.getBalance();
    }

    @Override
    protected void initEvent() {
        binding.setClick(v -> {
            switch (v.getId()) {
                //1余额2微信3支付宝4.积分
                case R.id.ll_alipay:
                    paytype = 3;
                    binding.ivCardStatus.setImageResource(R.mipmap.btn_pay_style_normal);
                    binding.ivWechatStatus.setImageResource(R.mipmap.btn_pay_style_normal);
                    binding.ivAlipayStatus.setImageResource(R.mipmap.btn_pay_style_select);
                    binding.tvToCharge.setVisibility(View.VISIBLE);
                    binding.rlChargeNum.setVisibility(View.VISIBLE);
                    binding.rlBank.setVisibility(View.GONE);
                    break;
                case R.id.ll_wechat:
                    paytype = 2;
                    binding.ivWechatStatus.setImageResource(R.mipmap.btn_pay_style_select);
                    binding.ivCardStatus.setImageResource(R.mipmap.btn_pay_style_normal);
                    binding.ivAlipayStatus.setImageResource(R.mipmap.btn_pay_style_normal);
                    binding.tvToCharge.setVisibility(View.VISIBLE);
                    binding.rlChargeNum.setVisibility(View.VISIBLE);
                    binding.rlBank.setVisibility(View.GONE);
                    break;
                case R.id.ll_card:
                    binding.ivCardStatus.setImageResource(R.mipmap.btn_pay_style_select);
                    binding.ivWechatStatus.setImageResource(R.mipmap.btn_pay_style_normal);
                    binding.ivAlipayStatus.setImageResource(R.mipmap.btn_pay_style_normal);
                    binding.tvToCharge.setVisibility(View.GONE);
                    binding.rlChargeNum.setVisibility(View.GONE);
                    binding.rlBank.setVisibility(View.VISIBLE);
                    break;
                case R.id.tv_to_charge: //去充值

                    getPayDetail();
                    break;
                case R.id.rl_to_charge_detail: //充值详情
                    getOperation().forward(ChargeDetailActivity.class);
                    break;
                case R.id.rl_bank:
                    ClipboardManager clipboardManager = (ClipboardManager) getSystemService(
                            Context.CLIPBOARD_SERVICE);
                    clipboardManager.setPrimaryClip(ClipData.newPlainText(null,
                            binding.tvContent.getText()));
                    ToastUtils.show("复制成功");
                    break;
            }
        });
    }

    private void getPayDetail() {
        PaySuccessActivity.type = 1;
        PayReq payReq = new PayReq();
        if (paytype == 0) {
            showMessage("请选择充值方式");
            return;
        }
        payReq.payType = paytype;
        payReq.orderType = 3;
        payReq.type = 2;
        String amount = binding.etChargeNum.getText().toString().trim();
        if (TextUtils.isEmpty(amount)) {
            showMessage("请输入充值金额");
            return;
        }
        payReq.amount = amount;
        if (showType != 8 || paytype != 3) {
            presenter.getPayInfo(payReq);
        } else {
            presenter.getPayInfoNew(payReq);
        }
    }

    @Override
    public void onLoadChargeTypeSuccess(ChargeTypeMode mode) {
        if (!mode.success) return;
        if (mode.data == null) return;
        try {
            //支付宝微信  显示充值
            binding.tvToCharge.setVisibility(View.VISIBLE);
            binding.rlChargeNum.setVisibility(View.VISIBLE);
            binding.rlBank.setVisibility(View.GONE);
            showType = Integer.parseInt(mode.data);
            //        1微信，2原生支付宝，3 第三方支付宝，4微信，原生支付宝5微信，第三方支付宝
            switch (showType) {
                case 1:
                    binding.llCard.setVisibility(View.GONE);
                    binding.llAlipay.setVisibility(View.GONE);
                    break;

                case 2:
                    binding.llCard.setVisibility(View.GONE);
                    binding.llWechat.setVisibility(View.GONE);
                    break;
                case 3:
                    binding.llAlipay.setVisibility(View.GONE);
                    binding.llWechat.setVisibility(View.GONE);
                    break;
                case 4:
                    binding.llCard.setVisibility(View.GONE);
                    break;
                case 5:
                    binding.llAlipay.setVisibility(View.GONE);
                    break;
                //返回8  三种充值方式 如果用支付宝充值使用新接口
                case 8:

                    break;

            }
        } catch (Exception e) {
            e.printStackTrace();
//            {"code":"0","count":null,"data":"9|招商银行xxx支行|xxx公司|61020101","error":false,
//            "msg":"SUCCESS","result":true,"success":true}
            // //8|银行卡：招行|卡号：123123 8返回数据类型
            //银行
            String[] split = mode.data.split("\\|");
            if (split != null) {
                String s = split[0];
                if (TextUtils.equals("8", s)) {
                    showType = 8;
                    binding.tvToCharge.setVisibility(View.VISIBLE);
                    binding.rlChargeNum.setVisibility(View.VISIBLE);
                    binding.rlBank.setVisibility(View.GONE);
                    binding.llWechat.setVisibility(View.VISIBLE);
                    binding.llAlipay.setVisibility(View.VISIBLE);
                    paytype = 2;
                    binding.ivWechatStatus.setImageResource(R.mipmap.btn_pay_style_select);

                } else {
                    showType = 9;
                    binding.tvToCharge.setVisibility(View.GONE);
                    binding.rlChargeNum.setVisibility(View.GONE);
                    binding.rlBank.setVisibility(View.VISIBLE);
                    binding.llWechat.setVisibility(View.GONE);
                    binding.llAlipay.setVisibility(View.GONE);
                }
            }

            String str = "";
            for (int i = 0; i < split.length; i++) {
                if (i != 0) {
                    str = str + split[i] + "\n";
                }
            }
            binding.tvContent.setText(str);
        }

    }

    @Override
    public void onLoadPayResWechatSuccess(PayRes payRes, int payType) {
        WXPayUtils.getInstance().toWXPay(this, payRes.data);
    }

    @Override
    public void getBalanceSuccess(BalanceDetailMode mode) {
        binding.tvBalance.setText(StrUtils.getRemoveZreoNum(mode.amount));
    }

    @Override
    public void onLoadPayResAlipaySuccess(PayAlipayRes payAlipayRes, int payType) {
        AliPayAPI.getInstance(this).startPay(this, payAlipayRes.data.order);
    }

    @Override
    public void onLoadNewAlipaySuccess(NewPayRes newPayRes) {
        Uri uri = Uri.parse(newPayRes.data.order);
        Intent it = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(it);
    }

    @Override
    public void onAliPaySuccess() {
        showMessage("充值成功");
        getOperation().forward(PaySuccessActivity.class);
        finish();
    }

    @Override
    public void onAliPayFailure() {
    }

    @Override
    public void onAliPayConfirming() {
    }
}
