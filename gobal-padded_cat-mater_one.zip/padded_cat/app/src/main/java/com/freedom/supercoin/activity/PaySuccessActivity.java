package com.freedom.supercoin.activity;

import android.view.View;

import com.freedom.supercoin.R;
import com.freedom.supercoin.common.UiActivity;
import com.freedom.supercoin.databinding.ActivityABinding;
import com.freedom.supercoin.databinding.ActivityPaySuccessBinding;

/**
 * @author : lijianping
 * @date : Created on 2019/7/11.
 * des:
 */
public class PaySuccessActivity extends UiActivity<ActivityPaySuccessBinding> {
    //0 订单  1 充值
    public static int type = 0;

    @Override
    protected int layoutResId() {
        return R.layout.activity_pay_success;
    }

    @Override
    protected void initData() {
        binding.titleBar.setTextColor("#ffffff");
        binding.titleBar.setLeftImage(R.mipmap.ic_back_white);
        if (type == 1) {
            binding.titleBar.setTitle("充值成功");
            binding.tvSuccess.setText("充值成功");
            binding.tvSuccessTips.setVisibility(View.GONE);
        } else {
            binding.titleBar.setTitle("购买成功");
        }

    }

    @Override
    protected void initEvent() {
        binding.tvFinished.setOnClickListener(v -> finish());
    }

}
