package com.freedom.supercoin.mode;

import java.util.List;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2020/1/11.
 * @desc :
 * @company: Fotile-智能厨电研究院
 * <p>
 * Copyright (c) 2019, FOTILE GROUP.
 * All rights reserved.
 * <p>
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * - Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * - Neither the name of the FOTILE GROUP nor the
 * names of its contributors may be used to endorse or promote products
 * derived from this software without specific prior written permission.
 * <p>
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL FOTILE GROUP BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
public class WithDrawListMode {

    /**
     * code :
     * count : null
     * data : {"data":[{"account":"18566398679","accountName":"剑平","alipay":"18566398679",
     * "amount":200,"applyTime":"2020-01-11 17:51:38","applyed":false,"auditMan":"",
     * "auditTime":null,"beginTime":"","channelId":"","clicked":false,"createBy":"剑平",
     * "createTime":"2020-01-11 17:51:38","deleted":0,"desc":"desc","deviceCode":"",
     * "deviceType":"","endTime":null,"id":3923,"orderField":"","overTime":"","page":{
     * "currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,"pageStr":"",
     * "totalPage":0,"totalResult":0},"params":null,"payPassword":"","remark":"",
     * "searchValue":"","serviceCharge":1.2,"startTime":null,"status":1,"thirdTradeNo":"",
     * "updateBy":"","updateTime":null,"userId":1601},{"account":"18566398679",
     * "accountName":"剑平","alipay":"18566398679","amount":1000,"applyTime":"2020-01-11 17:51:06",
     * "applyed":false,"auditMan":"","auditTime":null,"beginTime":"","channelId":"",
     * "clicked":false,"createBy":"剑平","createTime":"2020-01-11 17:51:06","deleted":0,
     * "desc":"desc","deviceCode":"","deviceType":"","endTime":null,"id":3922,"orderField":"",
     * "overTime":"","page":{"currentResult":0,"entityOrField":false,"pageNumber":1,
     * "pageSize":10,"pageStr":"","totalPage":0,"totalResult":0},"params":null,"payPassword":"",
     * "remark":"","searchValue":"","serviceCharge":6,"startTime":null,"status":1,
     * "thirdTradeNo":"","updateBy":"","updateTime":null,"userId":1601}],"page":{"currentResult
     * ":0,"entityOrField":false,"pageNumber":1,"pageSize":20,"pageStr":"","totalPage":1,
     * "totalResult":2}}
     * error : false
     * msg : 查询成功
     * result : true
     * success : true
     */

    public String code;
    public Object count;
    public DataBeanX data;
    public boolean error;
    public String msg;
    public boolean result;
    public boolean success;

    public static class DataBeanX {
        /**
         * data : [{"account":"18566398679","accountName":"剑平","alipay":"18566398679",
         * "amount":200,"applyTime":"2020-01-11 17:51:38","applyed":false,"auditMan":"",
         * "auditTime":null,"beginTime":"","channelId":"","clicked":false,"createBy":"剑平",
         * "createTime":"2020-01-11 17:51:38","deleted":0,"desc":"desc","deviceCode":"",
         * "deviceType":"","endTime":null,"id":3923,"orderField":"","overTime":"","page":{
         * "currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,"pageStr":"",
         * "totalPage":0,"totalResult":0},"params":null,"payPassword":"","remark":"",
         * "searchValue":"","serviceCharge":1.2,"startTime":null,"status":1,"thirdTradeNo":"",
         * "updateBy":"","updateTime":null,"userId":1601},{"account":"18566398679",
         * "accountName":"剑平","alipay":"18566398679","amount":1000,"applyTime":"2020-01-11
         * 17:51:06","applyed":false,"auditMan":"","auditTime":null,"beginTime":"",
         * "channelId":"","clicked":false,"createBy":"剑平","createTime":"2020-01-11 17:51:06",
         * "deleted":0,"desc":"desc","deviceCode":"","deviceType":"","endTime":null,"id":3922,
         * "orderField":"","overTime":"","page":{"currentResult":0,"entityOrField":false,
         * "pageNumber":1,"pageSize":10,"pageStr":"","totalPage":0,"totalResult":0},"params
         * ":null,"payPassword":"","remark":"","searchValue":"","serviceCharge":6,
         * "startTime":null,"status":1,"thirdTradeNo":"","updateBy":"","updateTime":null,
         * "userId":1601}]
         * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":20,
         * "pageStr":"","totalPage":1,"totalResult":2}
         */

        public PageBean page;
        public List<DataBean> data;

        public static class PageBean {
            /**
             * currentResult : 0
             * entityOrField : false
             * pageNumber : 1
             * pageSize : 20
             * pageStr :
             * totalPage : 1
             * totalResult : 2
             */

            public int currentResult;
            public boolean entityOrField;
            public int pageNumber;
            public int pageSize;
            public String pageStr;
            public int totalPage;
            public int totalResult;
        }

        public static class DataBean {
            /**
             * account : 18566398679
             * accountName : 剑平
             * alipay : 18566398679
             * amount : 200.0
             * applyTime : 2020-01-11 17:51:38
             * applyed : false
             * auditMan :
             * auditTime : null
             * beginTime :
             * channelId :
             * clicked : false
             * createBy : 剑平
             * createTime : 2020-01-11 17:51:38
             * deleted : 0
             * desc : desc
             * deviceCode :
             * deviceType :
             * endTime : null
             * id : 3923
             * orderField :
             * overTime :
             * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,
             * "pageStr":"","totalPage":0,"totalResult":0}
             * params : null
             * payPassword :
             * remark :
             * searchValue :
             * serviceCharge : 1.2
             * startTime : null
             * status : 1
             * thirdTradeNo :
             * updateBy :
             * updateTime : null
             * userId : 1601
             */

            public String account;
            public String accountName;
            public String alipay;
            public double amount;
            public String applyTime;
            public boolean applyed;
            public String auditMan;
            public Object auditTime;
            public String beginTime;
            public String channelId;
            public boolean clicked;
            public String createBy;
            public String createTime;
            public int deleted;
            public String desc;
            public String deviceCode;
            public String deviceType;
            public Object endTime;
            public int id;
            public String orderField;
            public String overTime;
            public PageBeanX page;
            public Object params;
            public String payPassword;
            public String remark;
            public String searchValue;
            public double serviceCharge;
            public Object startTime;
            public int status;
            public String thirdTradeNo;
            public String updateBy;
            public Object updateTime;
            public int userId;

            public static class PageBeanX {
                /**
                 * currentResult : 0
                 * entityOrField : false
                 * pageNumber : 1
                 * pageSize : 10
                 * pageStr :
                 * totalPage : 0
                 * totalResult : 0
                 */

                public int currentResult;
                public boolean entityOrField;
                public int pageNumber;
                public int pageSize;
                public String pageStr;
                public int totalPage;
                public int totalResult;
            }
        }
    }
}
