package com.freedom.supercoin.network;


import com.freedom.supercoin.base_library.base.BaseView;
import com.hjq.toast.ToastUtils;

import rx.Observable;
import rx.functions.Func1;

/**
 * 异常处理
 * @param <T>
 */
public class ResponseErrorFunc<T> implements Func1<Throwable, Observable<T>> {

	public ResponseErrorFunc() {

	}
	@Override
	public Observable<T> call(Throwable throwable) {
		return Observable.error(ExceptionEngine.handleException(throwable));
	}

	public static void showError(BaseView baseView, Exception e) {
		e.printStackTrace();
		if (e.getLocalizedMessage() != null) {
			ToastUtils.show(e.getMessage());
		}

	}
}