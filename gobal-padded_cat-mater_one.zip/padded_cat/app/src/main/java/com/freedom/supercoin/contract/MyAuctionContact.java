package com.freedom.supercoin.contract;


import com.freedom.supercoin.base_library.base.BasePresenter;
import com.freedom.supercoin.base_library.base.BaseView;
import com.freedom.supercoin.mode.MyAuctionMode;


public class MyAuctionContact {

    public interface View extends BaseView {

        void onLoadMyAuctionSuccess(MyAuctionMode myAuctionMode);
    }


    public interface Presenter extends BasePresenter {
        void  getMyAuctionList();
    }
}

