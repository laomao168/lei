package com.freedom.supercoin.activity;

import android.text.TextUtils;
import android.view.View;

import com.freedom.supercoin.R;
import com.freedom.supercoin.base_library.AppConst;
import com.freedom.supercoin.base_library.utils.Base64Utils;
import com.freedom.supercoin.base_library.utils.LogUtils;
import com.freedom.supercoin.base_library.utils.StrUtils;
import com.freedom.supercoin.common.UiActivity;
import com.freedom.supercoin.contract.RealNameContact;
import com.freedom.supercoin.contract.SetPwdContact;
import com.freedom.supercoin.databinding.ActivityResetPwdBinding;
import com.freedom.supercoin.databinding.ActivitySetPwdBinding;
import com.freedom.supercoin.mode.RealNameMode;
import com.freedom.supercoin.mode.entity.CodeReq;
import com.freedom.supercoin.persenter.ResetPwdPresenter;
import com.freedom.supercoin.persenter.SetPwdPresenter;
import com.freedom.supercoin.utils.RSAUtils;

/**
 * @author : lijianping
 * @date : Created on 2019/7/11.
 * des:
 */
public class SetPwdActivity extends UiActivity<ActivitySetPwdBinding> implements SetPwdContact.View {


    private SetPwdPresenter presenter;
    private boolean hasGetCode;
    private String phone;

    @Override
    protected int layoutResId() {
        return R.layout.activity_set_pwd;
    }

    @Override
    protected void initData() {
        binding.titleBar.setTextColor("#ffffff");
        binding.titleBar.setLeftImage(R.mipmap.ic_back_white);
        binding.titleBar.setTitle("重置密码");
        presenter = new SetPwdPresenter(this);
        phone = getIntent().getStringExtra(AppConst.Keys.PHONE);
        binding.tvPhoneNum.setText(phone);
    }

    @Override
    protected void initEvent() {
        binding.setClick(v -> {
            switch (v.getId()) {
                case R.id.tv_get_code:
                    checkAndGetCode();
                    break;
                case R.id.tv_sub:
                    checkAndSub();
                    break;
            }
        });
    }

    private void checkAndGetCode() {
        CodeReq codeReq = new CodeReq();
        codeReq.mobile = phone;
        codeReq.use = "password";
        presenter.getCode(codeReq);
    }

    private void checkAndSub() {
        String code = binding.etCode.getText().toString();
        String pwd = binding.etPwd.getText().toString();
        if (!hasGetCode) {
            showMessage("请先获取验证");
            return;
        }
        if (TextUtils.isEmpty(code)) {
            showMessage("请输入验证码");
            return;
        }

        if (TextUtils.isEmpty(pwd)) {
            showMessage("请输入6位数字支付密码");
            return;
        }
        presenter.setPwd(RSAUtils.publicEncrypt(pwd), code);
    }

    @Override
    public void onGetCodeSuccess() {
        hasGetCode = true;
        showMessage("获取验证码成功");
    }

    @Override
    public void onSetPwdSuccess() {
        showMessage("设置支付密码成功");
        finish();

    }
}
