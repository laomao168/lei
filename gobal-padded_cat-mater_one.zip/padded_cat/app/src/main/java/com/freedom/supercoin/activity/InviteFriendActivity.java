package com.freedom.supercoin.activity;

import android.Manifest;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.view.View;

import com.freedom.supercoin.R;
import com.freedom.supercoin.base_library.AppConst;
import com.freedom.supercoin.base_library.utils.GlideUtils;
import com.freedom.supercoin.base_library.utils.PermissionUtils;
import com.freedom.supercoin.base_library.utils.SPUtils;
import com.freedom.supercoin.common.UiActivity;
import com.freedom.supercoin.contract.InviteFriendContact;
import com.freedom.supercoin.databinding.ActivityABinding;
import com.freedom.supercoin.databinding.ActivityInviteFriendBinding;
import com.freedom.supercoin.mode.InviteFriendMode;
import com.freedom.supercoin.mode.entity.ShareInfo;
import com.freedom.supercoin.persenter.InviteFriendPresenter;
import com.freedom.supercoin.utils.WechatShareUtils;
import com.hjq.toast.ToastUtils;

import java.io.File;

/**
 * @author : lijianping
 * @date : Created on 2019/7/11.
 * des:
 */
public class InviteFriendActivity extends UiActivity<ActivityInviteFriendBinding> implements InviteFriendContact.View {

    private InviteFriendPresenter presenter;

    @Override
    protected int layoutResId() {
        return R.layout.activity_invite_friend;
    }

    @Override
    protected void initData() {
        binding.titleBar.setTitle("邀请好友");
        binding.titleBar.setTextColor("#ffffff");
        presenter = new InviteFriendPresenter(this);
        presenter.loadQrCode();
        binding.tvUserName.setText(SPUtils.getInstance().getString(AppConst.Keys.NICKNAME));
        binding.tvInviteCode.setText(SPUtils.getInstance().getString(AppConst.Keys.INVITATION_CODE));
        GlideUtils.loadRound(this, SPUtils.getInstance().getString(AppConst.Keys.AVATAR)
                , binding.ivUserImage, 15);
    }

    @Override
    protected void initEvent() {
        binding.setClick(v -> {
            switch (v.getId()) {
                case R.id.tv_share_wechat:
                    shareToWechat();
                    break;
                case R.id.tv_share_image:
                    saveImage();
                    break;

            }
        });
    }

    private void saveImage() {
        if (PermissionUtils.checkPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            binding.rlShareInfo.setDrawingCacheEnabled(true);
            binding.rlShareInfo.buildDrawingCache();
            Bitmap bitmap = Bitmap.createBitmap(binding.rlShareInfo.getDrawingCache());
            GlideUtils.saveImageToGallery(this, bitmap);
            showMessage("保存成功");
        }
    }

    private void shareToWechat() {
        binding.rlShareInfo.setDrawingCacheEnabled(true);
        binding.rlShareInfo.buildDrawingCache();
        Bitmap bitmap = Bitmap.createBitmap(binding.rlShareInfo.getDrawingCache());
        //保存本地图片
//        String path = GlideUtils.saveImageToLocal(bitmap);
        //分享
        WechatShareUtils.getInstance().shareImage(this,bitmap,WechatShareUtils.WEIXIN_SHARE_TYPE_TALK);
    }

    @Override
    public void onGetQrCodeSuccess(InviteFriendMode mode) {
        if (mode != null && mode.msg.contains("成功")) {
            GlideUtils.loadImage(this, mode.data, binding.ivQrCode);
        }
    }
}
