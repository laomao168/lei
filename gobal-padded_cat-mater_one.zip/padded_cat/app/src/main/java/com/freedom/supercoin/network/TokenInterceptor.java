package com.freedom.supercoin.network;


import com.freedom.supercoin.base_library.AppConst;
import com.freedom.supercoin.base_library.utils.LogUtils;
import com.freedom.supercoin.base_library.utils.SPUtils;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

public class TokenInterceptor implements Interceptor {

    @Override
    public Response intercept(Chain chain) throws IOException {
        Request request = chain.request();
            request = request.newBuilder()
                .addHeader("Authorization", SPUtils.getInstance().getString(AppConst.Keys.LOGIN_TOKEN, ""))
//                .addHeader("loginAccount",
//                    SPUtils.getInstance().getString(AppConst.Keys.LOGIN_ACCOUNT, ""))
//                .addHeader("userId",
//                    SPUtils.getInstance().getString(AppConst.Keys.USER_ID,""))
                .build();
        return chain.proceed(request);
    }
}
