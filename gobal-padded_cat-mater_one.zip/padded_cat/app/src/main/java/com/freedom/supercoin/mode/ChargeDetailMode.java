package com.freedom.supercoin.mode;

import java.util.List;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2020/1/10.
 * @desc :
 */
public class ChargeDetailMode {

    /**
     * code :
     * count : null
     * data : {"data":[{"applyed":false,"channelId":"","clicked":false,"createBy":"",
     * "createTime":"2020-01-10 16:14:46","deleted":0,"desc":"desc","deviceCode":"",
     * "deviceType":"","endTime":null,"id":2138403147,"money":10,"orderField":"",
     * "orderNo":"LPR200110161446723704","page":{"currentResult":0,"entityOrField":false,
     * "pageNumber":1,"pageSize":10,"pageStr":"","totalPage":0,"totalResult":0},"params":null,
     * "payTime":"2020-01-10 16:14:47","payType":2,"remark":"微信(剑平)","searchValue":"",
     * "startTime":null,"status":1,"transactionId":"4200000504202001109394447709","type":2,
     * "updateBy":"","updateTime":null,"userId":1601}],"page":{"currentResult":0,
     * "entityOrField":false,"pageNumber":1,"pageSize":10,"pageStr":"","totalPage":1,
     * "totalResult":1}}
     * error : false
     * msg : 查询成功
     * result : true
     * success : true
     */

    public String code;
    public Object count;
    public DataBeanX data;
    public boolean error;
    public String msg;
    public boolean result;
    public boolean success;

    public static class DataBeanX {
        /**
         * data : [{"applyed":false,"channelId":"","clicked":false,"createBy":"",
         * "createTime":"2020-01-10 16:14:46","deleted":0,"desc":"desc","deviceCode":"",
         * "deviceType":"","endTime":null,"id":2138403147,"money":10,"orderField":"",
         * "orderNo":"LPR200110161446723704","page":{"currentResult":0,"entityOrField":false,
         * "pageNumber":1,"pageSize":10,"pageStr":"","totalPage":0,"totalResult":0},"params
         * ":null,"payTime":"2020-01-10 16:14:47","payType":2,"remark":"微信(剑平)","searchValue":"",
         * "startTime":null,"status":1,"transactionId":"4200000504202001109394447709","type":2,
         * "updateBy":"","updateTime":null,"userId":1601}]
         * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,
         * "pageStr":"","totalPage":1,"totalResult":1}
         */

        public PageBean page;
        public List<DataBean> data;

        public static class PageBean {
            /**
             * currentResult : 0
             * entityOrField : false
             * pageNumber : 1
             * pageSize : 10
             * pageStr :
             * totalPage : 1
             * totalResult : 1
             */

            public int currentResult;
            public boolean entityOrField;
            public int pageNumber;
            public int pageSize;
            public String pageStr;
            public int totalPage;
            public int totalResult;
        }

        public static class DataBean {
            /**
             * applyed : false
             * channelId :
             * clicked : false
             * createBy :
             * createTime : 2020-01-10 16:14:46
             * deleted : 0
             * desc : desc
             * deviceCode :
             * deviceType :
             * endTime : null
             * id : 2138403147
             * money : 10.0
             * orderField :
             * orderNo : LPR200110161446723704
             * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,
             * "pageStr":"","totalPage":0,"totalResult":0}
             * params : null
             * payTime : 2020-01-10 16:14:47
             * payType : 2
             * remark : 微信(剑平)
             * searchValue :
             * startTime : null
             * status : 1
             * transactionId : 4200000504202001109394447709
             * type : 2
             * updateBy :
             * updateTime : null
             * userId : 1601
             */

            public boolean applyed;
            public String channelId;
            public boolean clicked;
            public String createBy;
            public String createTime;
            public int deleted;
            public String desc;
            public String deviceCode;
            public String deviceType;
            public Object endTime;
            public int id;
            public String money;
            public String orderField;
            public String orderNo;
            public PageBeanX page;
            public Object params;
            public String payTime;
            public int payType;
            public String remark;
            public String searchValue;
            public Object startTime;
            public int status;
            public String transactionId;
            public int type;
            public String updateBy;
            public Object updateTime;
            public int userId;

            public static class PageBeanX {
                /**
                 * currentResult : 0
                 * entityOrField : false
                 * pageNumber : 1
                 * pageSize : 10
                 * pageStr :
                 * totalPage : 0
                 * totalResult : 0
                 */

                public int currentResult;
                public boolean entityOrField;
                public int pageNumber;
                public int pageSize;
                public String pageStr;
                public int totalPage;
                public int totalResult;
            }
        }
    }
}
