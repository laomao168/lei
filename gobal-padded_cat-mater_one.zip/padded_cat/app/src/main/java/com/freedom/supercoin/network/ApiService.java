package com.freedom.supercoin.network;

import com.freedom.supercoin.base_library.utils.SPUtils;
import com.freedom.supercoin.mode.AddAddressMode;
import com.freedom.supercoin.mode.AddressListMode;
import com.freedom.supercoin.mode.AuctionAddMode;
import com.freedom.supercoin.mode.BalanceDetailMode;
import com.freedom.supercoin.mode.BalanceListMode;
import com.freedom.supercoin.mode.ChargeDetailMode;
import com.freedom.supercoin.mode.ChargeTypeMode;
import com.freedom.supercoin.mode.CheckPwdMode;
import com.freedom.supercoin.mode.CheckRealNameMode;
import com.freedom.supercoin.mode.CodeMode;
import com.freedom.supercoin.mode.FriendMode;
import com.freedom.supercoin.mode.GoodBidMode;
import com.freedom.supercoin.mode.GoodDetailsMode;
import com.freedom.supercoin.mode.GoodsCategoryMode;
import com.freedom.supercoin.mode.GoodsRankListMode;
import com.freedom.supercoin.mode.HomeBannerMode;
import com.freedom.supercoin.mode.HomeAuctionRes;
import com.freedom.supercoin.mode.ImageUploadMode;
import com.freedom.supercoin.mode.IntegralFragmentMode;
import com.freedom.supercoin.mode.IntegralMode;
import com.freedom.supercoin.mode.IntegralOrderMode;
import com.freedom.supercoin.mode.InviteFriendMode;
import com.freedom.supercoin.mode.LoginMode;
import com.freedom.supercoin.mode.MyAuctionMode;
import com.freedom.supercoin.mode.MyFansMode;
import com.freedom.supercoin.mode.MySuperiorMode;
import com.freedom.supercoin.mode.OrderDetailMode;
import com.freedom.supercoin.mode.OrderMode;
import com.freedom.supercoin.mode.OrderStatisticsMode;
import com.freedom.supercoin.mode.PersonalMode;
import com.freedom.supercoin.mode.RealNameMode;
import com.freedom.supercoin.mode.SetPwdMode;
import com.freedom.supercoin.mode.StreetMode;
import com.freedom.supercoin.mode.TodayIncomeMode;
import com.freedom.supercoin.mode.UpdateMode;
import com.freedom.supercoin.mode.UpdateNikeNameMode;
import com.freedom.supercoin.mode.UserInfoMode;
import com.freedom.supercoin.mode.WithDrawListMode;
import com.freedom.supercoin.mode.WithDrawMode;
import com.freedom.supercoin.mode.entity.CodeReq;
import com.freedom.supercoin.mode.entity.HomeAuctionReq;
import com.freedom.supercoin.mode.entity.LoginBean;
import com.freedom.supercoin.mode.entity.Page;

import java.util.List;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import rx.Observable;

/**
 * Created by zzq on 2018/4/3.
 */

public class ApiService {
    private NetService netService;


    public interface NetService {
        @FormUrlEncoded
        @POST("home/banner/list")
        Observable<Result<List<HomeBannerMode>>> getHomeBannerList(@Field("bannerType") int bannerType);

        @FormUrlEncoded
        @POST("mallGoodsInfo/list")
        Observable<IntegralFragmentMode> loadIntegralList(@Field("page.pageNumber") int pageNumber,
                                                          @Field("page.pageSize") int pageSize);

        @FormUrlEncoded
        @POST("mallGoodsInfo/list")
        Observable<IntegralFragmentMode> loadIntegralListByGoodstype(@Field("page.pageNumber") int pageNumber,
                                                                     @Field("page.pageSize") int pageSize,
                                                                     @Field("goodsType") int goodsType);

        @FormUrlEncoded
        @POST("auctionRecordInfo/listToday")
        Observable<HomeAuctionRes> getAuctionRecordInfoToday(@Field("page.pageNumber") int pageNumber, @Field("page.pageSize") int pageSize);

        @FormUrlEncoded
        @POST("auctionRecordInfo/listFatherCategory")
        Observable<HomeAuctionRes> getGoodsCategoryData(@Field("page.pageNumber") int pageNumber,
                                                        @Field("page.pageSize") int pageSize,
                                                        @Field("fatherCategoryId") int fatherCategoryId);

        @FormUrlEncoded
        @POST("auctionRecordInfo/listDate")
        Observable<HomeAuctionRes> getAuctionRecordInfoPreview(@Field("page.pageNumber") int pageNumber, @Field("type") int type, @Field("page.pageSize") int pageSize);

        @FormUrlEncoded
        @POST("auctionRecordInfo/auctionRecordInfo")
        Observable<Result<GoodDetailsMode>> getGoodDetails(@Field("auctionId") int auctionId);

        @FormUrlEncoded
        @POST("auctionRecordDetail/rankingList")
        Observable<Result<List<GoodsRankListMode>>> getGoodRankList(@Field("auctionId") int auctionId);

        @FormUrlEncoded
        @POST("auctionRecordDetail/listByAuctionId")
        Observable<GoodBidMode> getBidList(@Field("auctionId") int auctionId, @Field("page" +
                ".pageNumber") int pageNumber, @Field("page.pageSize") int pageSize);

        @FormUrlEncoded
        @POST("auctionRecordDetail/add")
        Observable<ResponseBody> getBidList(@Field("auctionId") int auctionId,
                                            @Field("payPrice") double payPrice);

        @FormUrlEncoded
        @POST("home/appLogin")
        Observable<Result<LoginMode>> login(@Field("phone") String phone,
                                            @Field("verifyCode") String verifyCode);

        @FormUrlEncoded
        @POST("home/sendSms")
        Observable<CodeMode> getCode(@Field("mobile") String mobile,
                                     @Field("use") String use);

        @POST("member/balanceAndIntegralAndFans")
        Observable<Result<UserInfoMode>> getUserInfo();

        @POST("order/statistics")
        Observable<Result<OrderStatisticsMode>> getOrderInfo();

        @FormUrlEncoded
        @POST("member/myIntegrate")
        Observable<IntegralMode> getIntegralList(@Field("page.pageNumber") int pageNumber,
                                                 @Field("page.pageSize") int pageSize);

        @FormUrlEncoded
        @POST("order/list")
        Observable<OrderMode> getOrderList(@Field("page.pageNumber") int pageNumber,
                                           @Field("page.pageSize") int pageSize, @Field(
                "orderStatus") int orderStatus);

        @FormUrlEncoded
        @POST("order/list")
        Observable<OrderMode> getOrderList(@Field("page.pageNumber") int pageNumber,
                                           @Field("page.pageSize") int pageSize);

        @FormUrlEncoded
        @POST("memberRealperson/realPerson")
        Observable<RealNameMode> toIdentity(@Field("userName") String userName,
                                            @Field("alipay") String alipay,
                                            @Field("idCard") String idCard,
                                            @Field("bankName") String bankName,
                                            @Field("bankBranch") String bank,
                                            @Field("bankCardNo") String bankCard);

        @FormUrlEncoded
        @POST("member/setPassword")
        Observable<SetPwdMode> setPwd(@Field("payPass") String payPass,
                                      @Field("verifyCode") String verifyCode);

        @FormUrlEncoded
        @POST("order/detail")
        Observable<Result<OrderDetailMode>> getOrderDetail(@Field("orderId") int orderId);

        @FormUrlEncoded
        @POST("order/receipt")
        Observable<Result<OrderDetailMode>> receiptOrder(@Field("orderId") int orderId);

        @FormUrlEncoded
        @POST("mallOrder/receipt")
        Observable<Result<OrderDetailMode>> receiptMallOrder(@Field("orderId") int orderId);

        @FormUrlEncoded
        @POST("order/cancelOrder")
        Observable<Result<OrderDetailMode>> cancelOrder(@Field("orderId") int orderId);

        @FormUrlEncoded
        @POST("mallOrder/closeOrder")
        Observable<Result<OrderDetailMode>> cancelMallOrder(@Field("orderId") int orderId);

        @FormUrlEncoded
        @POST("memberAddress/add")
        Observable<AddAddressMode> addAddress(@Field("address") String address,
                                              @Field("city") int city,
                                              @Field("consignee") String consignee,
                                              @Field("district") int district,
                                              @Field("mobile") String mobile,
                                              @Field("province") int province,
                                              @Field("tolerant") int tolerant,
                                              @Field("addressId") int addressId,
                                              @Field("street") int street);

        @FormUrlEncoded
        @POST("memberAddress/edit")
        Observable<AddAddressMode> editAddress(@Field("address") String address,
                                               @Field("city") int city,
                                               @Field("consignee") String consignee,
                                               @Field("district") int district,
                                               @Field("mobile") String mobile,
                                               @Field("province") int province,
                                               @Field("tolerant") int tolerant,
                                               @Field("addressId") int addressId,
                                               @Field("street") int street);


        @POST("account/detail")
        Observable<Result<BalanceDetailMode>> getBalance();

        @POST("account/todayincome")
        Observable<TodayIncomeMode> getTodayIncome();

        @FormUrlEncoded
        @POST("member/myAmountList")
        Observable<BalanceListMode> getBalanceDetail(@Field("page.pageNumber") int pageNumber,
                                                     @Field("page.pageSize") int pageSize);

        @POST("memberRealperson/checkRealPerson")
        Observable<CheckRealNameMode> checkRealName();

        @POST("member/isSetPassword")
        Observable<CheckPwdMode> checkPwd();

        @POST("auctionRecordInfo/myList")
        Observable<MyAuctionMode> getMyAuctionList();

        @POST("memberAddress/list")
        Observable<AddressListMode> getAddressList();

        @FormUrlEncoded
        @POST("memberAddress/allList")
        Observable<Result<List<StreetMode>>> getAllAddressList(@Field("parentId") int parentId);

        @FormUrlEncoded
        @POST("member/fans")
        Observable<FriendMode> getMyFriend(@Field("page.pageNumber") int pageNumber,
                                           @Field("page.pageSize") int pageSize);

        @FormUrlEncoded
        @POST("memberwithdraw/weixin")
        Observable<WithDrawMode> WithDraw(@Field("payPassword") String payPassword,
                                          @Field("amount") String amount);

        @FormUrlEncoded
        @POST("lepaiAppversion/getBySource")
        Observable<UpdateMode> CheckUpdate(@Field("source") String source);

        @FormUrlEncoded
        @POST("member/getAllMyFans")
        Observable<FriendMode> getAllFriend(@Field("page.pageNumber") int pageNumber,
                                            @Field("page.pageSize") int pageSize);

        @POST("member/getQRcodexcx")
        Observable<InviteFriendMode> loadQrCode();

        @FormUrlEncoded
        @POST("order/rechargeList")
        Observable<ChargeDetailMode> getChargeList(@Field("page.pageNumber") int pageNumber,
                                                   @Field("page.pageSize") int pageSize);

        @FormUrlEncoded
        @POST("memberwithdraw/list")
        Observable<WithDrawListMode> getWithDrawList(@Field("page.pageNumber") int pageNumber,
                                                     @Field("page.pageSize") int pageSize);

        @FormUrlEncoded
        @POST("config/key")
        Observable<ChargeTypeMode> getChargeType(@Field("sysConfigKey") String sys);

        @FormUrlEncoded
        @POST("account/unfreeze")
        Observable<ChargeTypeMode> cancelDraw(@Field("memberWithdrawId") String id);

        @FormUrlEncoded
        @POST("common/order")
        Observable<ResponseBody> getPayInfo(@Field("orderType") int orderType,
                                            @Field("type") int type,
                                            @Field("payType") int payType,
                                            @Field("amount") String amount);

        @FormUrlEncoded
        @POST("order/rechange")
        Observable<ResponseBody> getPayInfoNew(@Field("money") String amount);

        @FormUrlEncoded
        @POST("common/order")
        Observable<ResponseBody> payOrder(@Field("orderType") int orderType,
                                          @Field("type") int type,
                                          @Field("payType") int payType,
                                          @Field("payPassWord") String payPassWord,
                                          @Field("addressId") int addressId,
                                          @Field("orderId") int orderId,
                                          @Field("goodsId") int goodsId
        );

        @FormUrlEncoded
        @POST("common/order")
        Observable<ResponseBody> payOrder(@Field("orderType") int orderType,
                                          @Field("type") int type,
                                          @Field("payType") int payType,
                                          @Field("payPassWord") String payPassWord,
                                          @Field("addressId") int addressId,
                                          @Field("goodsId") int goodsId
        );

        @FormUrlEncoded
        @POST("mallGoodsInfo/detail")
        Observable<ResponseBody> getIntegralDetail(@Field("goodsId") int goodsId);

        @FormUrlEncoded
        @POST("member/inviteCode")
        Observable<PersonalMode> saveInviteCode(@Field("code") String code);

        @FormUrlEncoded
        @POST("mallOrder/prePayOrder")
        Observable<ResponseBody> prePayIntegralOrder(@Field("goodsId") int goodsId);

        @POST("member/superiorInfo")
        Observable<Result<MySuperiorMode>> getMySuperior();

        @POST("member/balanceAndIntegralAndFans")
        Observable<Result<MyFansMode>> getMyFans();

        @FormUrlEncoded
        @POST("goodsCategory/list")
        Observable<Result<List<GoodsCategoryMode>>> getGoodsCategoryList(@Field("isRecommend") int isRecommend);


        @FormUrlEncoded
        @POST("mallOrder/list")
        Observable<IntegralOrderMode> getMallOrderList(@Field("page.pageNumber") int pageNumber,
                                                       @Field("page.pageSize") int pageSize,
                                                       @Field("orderStatus") int orderStatus,
                                                       @Field("goodsType") int goodsType
        );

        @FormUrlEncoded
        @POST("mallOrder/list")
        Observable<IntegralOrderMode> getMallOrderList(@Field("page.pageNumber") int pageNumber,
                                                       @Field("page.pageSize") int pageSize,
                                                       @Field("goodsType") int goodsType);

        @FormUrlEncoded
        @POST("mallOrder/detail")
        Observable<Result<OrderDetailMode>> getMallOrderDetail(@Field("orderId") int orderId);

        @FormUrlEncoded
        @POST("member/updateNickname")
        Observable<UpdateNikeNameMode> updateNikeName(@Field("sjnickname") String nikeName, @Field("avatar")String avatar);

        @Multipart
        @POST("common/upload")
        Observable<ImageUploadMode> uploadImage(@Part("key")RequestBody requestBody, @Part MultipartBody.Part file);
    }


    public ApiService(String baseUrl) {
        this.netService = newNetService(baseUrl);
    }


    public NetService getNetService() {
        return netService;
    }


    private NetService newNetService(String baseUrl) {
        return new Retrofit.Builder()
                .baseUrl(baseUrl)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .client(HttpClientFactory.getInstance().getHttpClient())
                .build()
                .create(NetService.class);
    }
}
