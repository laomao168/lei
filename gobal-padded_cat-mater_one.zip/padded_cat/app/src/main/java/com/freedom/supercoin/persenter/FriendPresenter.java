package com.freedom.supercoin.persenter;

import com.freedom.supercoin.contract.FriendContact;
import com.freedom.supercoin.mode.FriendMode;
import com.freedom.supercoin.mode.MyFansMode;
import com.freedom.supercoin.mode.MySuperiorMode;
import com.freedom.supercoin.network.DataManager;
import com.freedom.supercoin.network.ResponseErrorFunc;
import com.freedom.supercoin.network.RxUtils;

import rx.Subscriber;


public class FriendPresenter implements FriendContact.Presenter {

    private final FriendContact.View view;

    public FriendPresenter(FriendContact.View view) {
        this.view = view;
    }

    @Override
    public void getMyFriend(int pageNumber) {
        DataManager.getInstance()
                .getMyFriend(pageNumber)
                .compose(RxUtils.applyIOSchedulers())
//                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<FriendMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                        view.loadFriendError();
                    }


                    @Override
                    public void onNext(FriendMode friendMode) {
                        view.hideProgress();
                        view.loadFriendSuccess(friendMode);
                    }
                });
    }

    @Override
    public void getAllFriend(int pageNumber) {
        DataManager.getInstance()
                .getAllFriend(pageNumber)
                .compose(RxUtils.applyIOSchedulers())
//                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<FriendMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                        view.loadFriendError();
                    }


                    @Override
                    public void onNext(FriendMode friendMode) {
                        view.loadFriendSuccess(friendMode);
                        view.hideProgress();
                    }
                });
    }

    @Override
    public void getMySuperior() {
        DataManager.getInstance()
                .getMySuperior()
                .compose(RxUtils.applyIOSchedulers())
                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<MySuperiorMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                        view.loadFriendError();
                    }


                    @Override
                    public void onNext(MySuperiorMode mode) {
                        view.getMySuperiorSuccess(mode);
                        view.hideProgress();
                    }
                });
    }

    @Override
    public void getMyFans() {
        DataManager.getInstance()
                .getMyFans()
                .compose(RxUtils.applyIOSchedulers())
                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<MyFansMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                        view.loadFriendError();
                    }


                    @Override
                    public void onNext(MyFansMode mode) {
                        view.getMyFansSuccess(mode);
                        view.hideProgress();
                    }
                });
    }


}
