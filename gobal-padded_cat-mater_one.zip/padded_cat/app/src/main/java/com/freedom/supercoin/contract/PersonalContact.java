package com.freedom.supercoin.contract;


import com.freedom.supercoin.base_library.base.BasePresenter;
import com.freedom.supercoin.base_library.base.BaseView;
import com.freedom.supercoin.mode.ImageUploadMode;
import com.freedom.supercoin.mode.UpdateNikeNameMode;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;


public class PersonalContact {

    public interface View extends BaseView {
        void onSuccess();

        void onUploadImageSuccess(ImageUploadMode mode);

        void onUpdateNikeNameSuccess(UpdateNikeNameMode mode);
    }


    public interface Presenter extends BasePresenter {
        void saveInviteCode(String inviteCode);
        void uploadImage(RequestBody requetBody, MultipartBody.Part file);
        void updateNikeName(String nikeName ,String avatar);
    }
}

