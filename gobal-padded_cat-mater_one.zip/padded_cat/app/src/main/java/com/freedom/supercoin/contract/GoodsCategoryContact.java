package com.freedom.supercoin.contract;


import com.freedom.supercoin.base_library.base.BasePresenter;
import com.freedom.supercoin.base_library.base.BaseView;
import com.freedom.supercoin.mode.HomeAuctionRes;
import com.freedom.supercoin.mode.IntegralFragmentMode;
import com.freedom.supercoin.mode.entity.Page;


public class GoodsCategoryContact {

    public interface View extends BaseView {

        void loadCategorySuccess(HomeAuctionRes res);

        void IntegralListSuccess(IntegralFragmentMode body);
    }


    public interface Presenter extends BasePresenter {
        void  getGoodsCategoryData(int fatherCategoryId,int pageNumber);
        void loadIntegralList(int fatherCategoryId,int pageNumber);
    }
}

