package com.freedom.supercoin.activity;

import android.support.v7.widget.LinearLayoutManager;

import com.freedom.supercoin.R;
import com.freedom.supercoin.adapter.WithDrawAdapter;
import com.freedom.supercoin.base_library.base.BaseEmptyAdapter;
import com.freedom.supercoin.base_library.widget.spingview.DefaultFooter;
import com.freedom.supercoin.base_library.widget.spingview.SpringView;
import com.freedom.supercoin.common.UiActivity;
import com.freedom.supercoin.contract.WithDrawContact;
import com.freedom.supercoin.databinding.ActivityChargeDetailBinding;
import com.freedom.supercoin.mode.BalanceDetailMode;
import com.freedom.supercoin.mode.WithDrawListMode;
import com.freedom.supercoin.mode.WithDrawMode;
import com.freedom.supercoin.mode.entity.Page;
import com.freedom.supercoin.persenter.WithDrawPresenter;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2020/1/10.
 * @desc :
 */
public class WithDrawDetailActivity extends UiActivity<ActivityChargeDetailBinding> implements WithDrawContact.View {

    private int currentIndex;
    private WithDrawAdapter adapter;
    private WithDrawPresenter presenter;

    @Override
    protected int layoutResId() {
        return R.layout.activity_charge_detail;
    }

    @Override
    protected void initData() {
        binding.tvTitle.setText("退金明细");
        initSpringView();
        binding.recycleView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new WithDrawAdapter();
        binding.recycleView.setAdapter(adapter);
        presenter = new WithDrawPresenter(this);
        currentIndex = 1;
        loadList();
    }

    @Override
    protected void initEvent() {
    adapter.setOnItemClickListener((position, data) -> {
        presenter.cancelDraw(data.id+"");
    });
    }

    private void initSpringView() {
        binding.springView.setType(SpringView.Type.FOLLOW);
        binding.springView.setListener(new SpringView.OnFreshListener() {
            @Override
            public void onRefresh() {
                currentIndex = 1;
                loadList();
            }

            @Override
            public void onLoadMore() {
                currentIndex++;
                loadList();
            }
        });
        binding.springView.setFooter(new DefaultFooter(this));
    }

    private void loadList() {
        Page page = new Page();
        page.pageNumber = currentIndex;
        page.pageSize = 20;
        presenter.getWithDrawList(page);
    }


    @Override
    public void getBalanceSuccess(BalanceDetailMode mode) {

    }

    @Override
    public void onLoadWithDrawSuccess(WithDrawMode mode) {

    }

    @Override
    public void onLoadWithDrawSuccessList(WithDrawListMode mode) {
        if (mode == null || !mode.msg.contains("成功")) return;
        if (currentIndex == 1) {
            adapter.setData(mode.data.data);
        } else {
            adapter.addDataList(mode.data.data);
        }
    }

    @Override
    public void onCancelDrawSuccess() {
        currentIndex=1;
        loadList();
    }
}
