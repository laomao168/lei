package com.freedom.supercoin.mode;

public class CodeMode {

    /**
     * code : 0
     * count : null
     * data : null
     * error : false
     * msg : 短信发送成功
     * result : true
     * success : true
     */

    public String code;
    public Object count;
    public Object data;
    public boolean error;
    public String msg;
    public boolean result;
    public boolean success;
}
