package com.freedom.supercoin.common;

import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.freedom.supercoin.base_library.base.BaseFragment;
import com.freedom.supercoin.base_library.utils.Operation;
import com.freedom.supercoin.dialog.NetworkTipsDialog;
import com.gyf.barlibrary.ImmersionBar;
import com.hjq.toast.ToastUtils;
import com.trello.rxlifecycle.android.ActivityEvent;

import rx.Observable;

/**
 * desc   : 支持沉浸式Fragment懒加载基类（默认不开启沉浸式）
 */
public abstract class UILazyFragment<T extends ViewDataBinding> extends BaseFragment {

    public T binding;
    private NetworkTipsDialog dialogTips;
    public ImmersionBar immersionBar;
    /**
     * 共通操作
     **/
    private Operation mBaseOperation = null;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle
            savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, getLayoutId(), container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mBaseOperation = new Operation(mActivity);
    }

    @Override
    public View getView() {
        if (binding == null) return null;
        return binding.getRoot();
    }

    /**
     * 初始化ImmersionBar
     */
    public void initImmersionBar(String color) {
        immersionBar = ImmersionBar.with(mActivity)
                .statusBarDarkFont(false)
                .navigationBarColor(color);
        immersionBar.init();
    }

    public void showProgress() {
        if (dialogTips == null) {
            dialogTips = new NetworkTipsDialog();
        }
        dialogTips.show(getFragmentManager(), "");
    }


    public void hideProgress() {
        if (dialogTips != null) {
            dialogTips.dismiss();
        }
    }

    public void showMessage(String msg) {
        ToastUtils.show(msg);
    }

    //不可使用
    public <T> Observable.Transformer<T, T> bindUntilEvent(ActivityEvent event) {
        return null;
    }

    /**
     * 获取共通操作机能
     */
    public Operation getOperation() {
        return this.mBaseOperation;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (immersionBar != null) {
            immersionBar.destroy();
        }

    }
}