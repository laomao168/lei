package com.freedom.supercoin.persenter;

import com.freedom.supercoin.contract.GoodsDetailsContact;
import com.freedom.supercoin.mode.GoodDetailsMode;
import com.freedom.supercoin.mode.GoodsRankListMode;
import com.freedom.supercoin.network.DataManager;
import com.freedom.supercoin.network.ResponseErrorFunc;
import com.freedom.supercoin.network.RxUtils;

import java.util.List;

import rx.Subscriber;


public class GoodsDetailsPresenter implements GoodsDetailsContact.Presenter {

    private final GoodsDetailsContact.View view;

    public GoodsDetailsPresenter(GoodsDetailsContact.View view) {
        this.view = view;
    }


    @Override
    public void getGoodDetails(int auctionId) {
        DataManager.getInstance()
                .getGoodDetails(auctionId)
                .compose(RxUtils.applyIOSchedulers())
                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<GoodDetailsMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(GoodDetailsMode mode) {
                        view.getGoodsDetailSuccess(mode);
                        view.hideProgress();
                    }
                });
    }

    @Override
    public void getGoodRankList(int auctionId) {
        DataManager.getInstance()
                .getGoodRankList(auctionId)
                .compose(RxUtils.applyIOSchedulers())
                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<List<GoodsRankListMode>>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(List<GoodsRankListMode> list) {
                        view.getGoodsRankListSuccess(list);
                        view.hideProgress();
                    }
                });
    }
}
