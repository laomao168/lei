package com.freedom.supercoin.adapter;

import android.databinding.DataBindingUtil;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.freedom.supercoin.R;
import com.freedom.supercoin.base_library.base.BaseEmptyAdapter;
import com.freedom.supercoin.base_library.utils.StrUtils;
import com.freedom.supercoin.databinding.ItemWithDrawBinding;
import com.freedom.supercoin.mode.WithDrawListMode;


public class WithDrawAdapter extends BaseEmptyAdapter<WithDrawListMode.DataBeanX.DataBean,
        ItemWithDrawBinding> {

    @Override
    protected ItemWithDrawBinding createBinding(ViewGroup parent) {
        return DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()),
                R.layout.item_with_draw, parent, false);
    }

    @Override
    protected void onBindView(ItemWithDrawBinding binding, WithDrawListMode.DataBeanX.DataBean bean,
                              int position) {
        binding.tvChargeAmount.setText("¥" + StrUtils.getRemoveZreoNum(bean.amount));
        binding.tvTime.setText(bean.applyTime);
        if (bean.status == 1) {
            binding.tvCancel.setVisibility(View.VISIBLE);
        } else {
            binding.tvCancel.setVisibility(View.GONE);
        }
        binding.tvCancel.setOnClickListener(v -> {
            if (onItemClickListener!=null){
                onItemClickListener.onItemClick(position,bean);
            }
        });
    }

}
