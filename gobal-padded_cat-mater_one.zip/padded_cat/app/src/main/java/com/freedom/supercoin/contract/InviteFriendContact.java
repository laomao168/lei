package com.freedom.supercoin.contract;


import com.freedom.supercoin.base_library.base.BasePresenter;
import com.freedom.supercoin.base_library.base.BaseView;
import com.freedom.supercoin.mode.InviteFriendMode;


public class InviteFriendContact {

    public interface View extends BaseView {

        void onGetQrCodeSuccess(InviteFriendMode mode);
    }


    public interface Presenter extends BasePresenter {
        void loadQrCode();

    }
}

