package com.freedom.supercoin.persenter;

import com.freedom.supercoin.contract.MainActivityContact;
import com.freedom.supercoin.mode.UpdateMode;
import com.freedom.supercoin.network.DataManager;
import com.freedom.supercoin.network.ResponseErrorFunc;
import com.freedom.supercoin.network.RxUtils;

import rx.Subscriber;


public class MainActivityPresenter implements MainActivityContact.Presenter {

    private final MainActivityContact.View view;

    public MainActivityPresenter(MainActivityContact.View view) {
        this.view = view;
    }

    public void CheckUpdate() {
        DataManager.getInstance()
                .CheckUpdate()
                .compose(RxUtils.applyIOSchedulers())
//                .map(RxUtils.checkResultToData())
                .onErrorResumeNext(new ResponseErrorFunc<>())
                .subscribe(new Subscriber<UpdateMode>() {
                    @Override
                    public void onCompleted() {

                    }


                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        view.hideProgress();
                    }


                    @Override
                    public void onNext(UpdateMode mode) {
                        view.hideProgress();
                        view.onLoadUpdateInfoSuccess(mode);
                    }
                });
    }



}
