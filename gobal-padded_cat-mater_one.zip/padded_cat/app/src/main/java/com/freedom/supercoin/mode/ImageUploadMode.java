package com.freedom.supercoin.mode;

public class ImageUploadMode {

    /**
     * code :
     * count : null
     * data : https://image.lepai988.cn/3c5da144ae0e41129e10388f47923819
     * error : false
     * msg : 上传成功
     * result : true
     * success : true
     */

    public String code;
    public Object count;
    public String data;
    public boolean error;
    public String msg;
    public boolean result;
    public boolean success;
}
