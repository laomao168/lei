package com.freedom.supercoin.activity;

import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;

import com.freedom.supercoin.R;
import com.freedom.supercoin.adapter.CategoryAdapter;
import com.freedom.supercoin.adapter.IntegralGoodsAdapter;
import com.freedom.supercoin.adapter.ProductAdapter;
import com.freedom.supercoin.base_library.AppConst;
import com.freedom.supercoin.base_library.base.BaseEmptyAdapter;
import com.freedom.supercoin.base_library.widget.spingview.DefaultFooter;
import com.freedom.supercoin.base_library.widget.spingview.SpringView;
import com.freedom.supercoin.common.UiActivity;
import com.freedom.supercoin.contract.GoodsCategoryContact;
import com.freedom.supercoin.databinding.ActivityABinding;
import com.freedom.supercoin.databinding.ActivityGoodsCategoryBinding;
import com.freedom.supercoin.mode.HomeAuctionRes;
import com.freedom.supercoin.mode.IntegralFragmentMode;
import com.freedom.supercoin.mode.entity.HomeAuctionReq;
import com.freedom.supercoin.mode.entity.Page;
import com.freedom.supercoin.persenter.GoodsCategoryPresenter;

/**
 * @author : lijianping
 * @date : Created on 2019/7/11.
 * des:
 */
public class GoodsCategoryActivity extends UiActivity<ActivityGoodsCategoryBinding> implements GoodsCategoryContact.View {

    private int type;
    private String title;
    private GoodsCategoryPresenter presenter;
    private int currentPageNumber;
    private CategoryAdapter adapter;
    private int categoryId;
    private IntegralGoodsAdapter integralAdapter;

    @Override
    protected int layoutResId() {
        return R.layout.activity_goods_category;
    }

    @Override
    protected void initData() {
        binding.titleBar.setTextColor("#ffffff");
        binding.titleBar.setLeftImage(R.mipmap.ic_back_white);
        categoryId = getIntent().getIntExtra("categoryId", 0);
        type = getIntent().getIntExtra("type", 0);
        title = getIntent().getStringExtra(AppConst.Keys.TITLE);
        binding.titleBar.setTitle(title);
        presenter = new GoodsCategoryPresenter(this);
        currentPageNumber = 1;
        if (type==1){
            binding.recycleView.setLayoutManager(new GridLayoutManager(this,2));
            presenter.getGoodsCategoryData(categoryId, currentPageNumber);
            adapter = new CategoryAdapter();
            binding.recycleView.setAdapter(adapter);
        }else {
            binding.recycleView.setLayoutManager(new GridLayoutManager(this,2));
            presenter.loadIntegralList(categoryId,currentPageNumber);
            integralAdapter = new IntegralGoodsAdapter();
            binding.recycleView.setAdapter(integralAdapter);
        }
    }

    @Override
    protected void initEvent() {
        binding.springView.setType(SpringView.Type.FOLLOW);
        binding.springView.setListener(new SpringView.OnFreshListener() {
            @Override
            public void onRefresh() {
            }

            @Override
            public void onLoadMore() {
                currentPageNumber++;
                if (type==1){
                    presenter.getGoodsCategoryData(categoryId, currentPageNumber);
                }else {
                    presenter.getGoodsCategoryData(categoryId,currentPageNumber);
                }
            }

        });
        binding.springView.setFooter(new DefaultFooter(this));
        if (type==1){
            adapter.setOnItemClickListener((position, data) -> {
                getOperation().addParameter(AppConst.Keys.AUCTIONID, data.auctionId);
                getOperation().forward(GoodsDetailActivity.class);
            });
        }else {
            integralAdapter.setOnItemClickListener((position, data) -> {
                //跳转商品详情
                getOperation().addParameter(AppConst.Keys.GOODS_ID, data.goodsId);
                getOperation().forward(IntegralGoodsDetailActivity.class);
            });
        }
    }

    @Override
    public void loadCategorySuccess(HomeAuctionRes res) {
        binding.springView.onFinishFreshAndLoad();
        if (res == null || !res.success || res.data.data.size() == 0) return;
        if (currentPageNumber == 1) { //新的
            adapter.setData(res.data.data);
        } else { //增加
            adapter.addDataList(res.data.data);
        }
    }

    @Override
    public void IntegralListSuccess(IntegralFragmentMode body) {
        if (currentPageNumber == 1) {
            integralAdapter.setData(body.data.data);
        } else {
            integralAdapter.addDataList(body.data.data);
        }
    }
}
