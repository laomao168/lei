package com.freedom.supercoin.activity;

import com.freedom.supercoin.R;
import com.freedom.supercoin.common.UiActivity;
import com.freedom.supercoin.databinding.ActivityABinding;

/**
 * @author : lijianping
 * @date : Created on 2019/7/11.
 * des:
 */
public class aActivity extends UiActivity <ActivityABinding>{
    @Override
    protected int layoutResId() {
        return R.layout.activity_a;
    }

    @Override
    protected void initData() {
        binding.titleBar.setTitle("大菠萝");
    }

    @Override
    protected void initEvent() {

    }

}
