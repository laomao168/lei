package com.freedom.supercoin.websocket.base.listener;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2019/11/29.
 */
public interface WebSocketMsgInterface {
    void onMessage(String msg);

    void onConnectSuc();
}
