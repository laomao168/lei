package com.freedom.supercoin.websocket.base;

import com.freedom.supercoin.base_library.utils.LogUtils;
import com.freedom.supercoin.websocket.base.listener.BaseWebSocketListener;
import com.freedom.supercoin.websocket.base.listener.IWebSocketListener;
import com.freedom.supercoin.websocket.base.listener.WebSocketMsgInterface;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okio.ByteString;

/**
 * @author
 * @date 创建时间：2018/12/14
 * @description 只用于订阅一个事件, 每次订阅一个新的的后重新创建  关闭页面就销毁 不需要心跳
 */
public class SimpleWebSocketManager implements WebSocketManagerListener {
    protected String TAG = "SimpleWebSocket";

    // 通过这个进行操作真正的WebSocket
    protected final IWebSocketListener mWebSocketListener;
    private String url;
    private OkHttpClient okHttpClient;
    private WebSocketMsgInterface listener;


    public SimpleWebSocketManager(String url, OkHttpClient okHttpClient,
                                  WebSocketMsgInterface listener) {
        this.url = url;
        this.okHttpClient = okHttpClient;
        this.listener = listener;
        mWebSocketListener = new BaseWebSocketListener(this);
    }

    /**
     * 订阅事件
     *
     * @param msg
     */
    public final void subscribe(String msg) {
        // 如果已经连接，则进行发送订阅消息，
        // 如果未连接，则将订阅消息先添加至 mWaitingEvent 集合，然后进行连接，等待连接成功后发送订阅
        if (mWebSocketListener.getCurState() == IWebSocketListener.CONNECTED) {
            // 发送信息
            mWebSocketListener.sendMsg(msg);
        } else {
            // 进行连接
            connect();
        }
    }


    /**
     * 进行WebSocket连接
     */
    public void connect() {
        if (mWebSocketListener.getCurState() == IWebSocketListener.NOT_CONNECTED) {
            LogUtils.ShowD(TAG,url+"==========开始连接");
            synchronized (this) {
                int curState = mWebSocketListener.getCurState();
                // 未连接
                if (curState == IWebSocketListener.NOT_CONNECTED) {
                    // 复位
                    mWebSocketListener.reset();
                    // 设置为连接中
                    mWebSocketListener.setCurState(IWebSocketListener.CONNECTING);
                    Request request = new Request
                            .Builder()
                            .url(url)
                            .build();
                    okHttpClient.newWebSocket(request, mWebSocketListener);
                } else {
                   LogUtils.ShowD(TAG, "WebSocket 已经处于连接状态，code：" + curState);
                }
            }

        }

    }

    @Override
    public void onConnectSuc() {
        // 连接成功
        LogUtils.ShowD(TAG,url+"==========连接成功");
        if (listener != null) {
            listener.onConnectSuc();
        }
    }

    /**
     * 正常关闭
     */
    public void close() {
        // 释放 WebSocket
        LogUtils.ShowD(TAG,url+"========== 释放 WebSocket");
        if (mWebSocketListener != null) {
            mWebSocketListener.release();
        }
    }

    /**
     * 连接失败
     *
     * @param reconnect 是否要重新连接
     */
    @Override
    public void onConnectFailure(boolean reconnect) {

        if (reconnect) { // 需要重连
           LogUtils.ShowD(TAG, url+"=============onConnectFailure: 进行重连");
            connect();
        } else {  //不需要进行重连，则直接中断
           LogUtils.ShowD(TAG, url+"=============onConnectFailure: 不进行重连");
        }

    }

    @Override
    public void onMessage(String msg) {
        LogUtils.ShowD(TAG, url+"========="+msg);
        if (listener != null) {
            listener.onMessage(msg);
        }
    }


    @Override
    public void onMessage(ByteString msg) {

    }


}
