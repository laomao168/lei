package com.freedom.supercoin.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;

import com.freedom.supercoin.R;
import com.freedom.supercoin.adapter.AddressAdapter;
import com.freedom.supercoin.base_library.AppConst;
import com.freedom.supercoin.base_library.base.BaseEmptyAdapter;
import com.freedom.supercoin.common.UiActivity;
import com.freedom.supercoin.contract.AddressContact;
import com.freedom.supercoin.databinding.ActivityAddressBinding;
import com.freedom.supercoin.mode.AddressListMode;
import com.freedom.supercoin.persenter.AddressPresenter;

/**
 * @author : lijianping
 * @date : Created on 2019/7/11.
 * des:
 */
public class AddressActivity extends UiActivity<ActivityAddressBinding> implements AddressContact.View, BaseEmptyAdapter.OnItemClickListener<AddressListMode.DataBeanX.DataBean> {

    private AddressPresenter presenter;
    private AddressAdapter adapter;
    private int orderId;

    @Override
    protected int layoutResId() {
        return R.layout.activity_address;
    }

    @Override
    protected void initData() {
        binding.titleBar.setTextColor("#ffffff");
        binding.titleBar.setLeftImage(R.mipmap.ic_back_white);
        binding.titleBar.setTitle("我的收货地址");
        binding.recycleView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new AddressAdapter();
        binding.recycleView.setAdapter(adapter);
        presenter = new AddressPresenter(this);
        adapter.setOnItemClickListener(this);
        orderId = getIntent().getIntExtra(AppConst.Keys.ORDER_ID, 0);
    }

    @Override
    protected void initEvent() {
        binding.setClick(v -> {
            getOperation().addParameter("name", "");
            getOperation().addParameter(AppConst.Keys.PHONE, "");
            getOperation().addParameter("area", "");
            getOperation().addParameter("address", "");
            getOperation().addParameter("default", 0);
            getOperation().addParameter("addressId", 0);
            getOperation().forward(AddressDetailNewActivity.class);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        presenter.getAddress();
    }

    @Override
    public void getAddressListSuccess(AddressListMode mode) {
        if (mode != null && mode.msg.contains("成功")) {
            adapter.setData(mode.data.data);
        }
    }

    @Override
    public void onItemClick(int position, AddressListMode.DataBeanX.DataBean data) {
        if (orderId == 0) {
            getOperation().addParameter("name", data.consignee);
            getOperation().addParameter(AppConst.Keys.PHONE, data.mobile);
            getOperation().addParameter("address", data.address);
            getOperation().addParameter("tolerant", data.tolerant);
            getOperation().addParameter("province", data.provinceText);
            getOperation().addParameter("city", data.cityText);
            getOperation().addParameter("district", data.districtText);
            getOperation().addParameter("streetText", data.streetText);

            getOperation().addParameter("provinceId", data.province);
            getOperation().addParameter("cityId", data.city);
            getOperation().addParameter("districtId", data.district);
            getOperation().addParameter("streetTextId", data.street);

            getOperation().addParameter("addressId", data.addressId);
            getOperation().forward(AddressDetailNewActivity.class);
        } else {
            Intent intent = getIntent();
            //这里使用bundle绷带来传输数据
            Bundle bundle = new Bundle();
            //传输的内容仍然是键值对的形式
            bundle.putString("address",
                    data.provinceText + data.cityText + data.districtText + data.streetText + data.address);
            bundle.putString("name", data.consignee);
            bundle.putString(AppConst.Keys.PHONE, data.mobile);
            bundle.putInt("addressId", data.addressId);
            intent.putExtras(bundle);
            setResult(AppConst.REQUESTCODE, intent);
            finish();
        }

    }
}
