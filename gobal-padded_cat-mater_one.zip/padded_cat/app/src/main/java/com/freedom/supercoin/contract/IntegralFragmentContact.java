package com.freedom.supercoin.contract;


import com.freedom.supercoin.base_library.base.BasePresenter;
import com.freedom.supercoin.base_library.base.BaseView;
import com.freedom.supercoin.mode.HomeBannerMode;
import com.freedom.supercoin.mode.IntegralFragmentMode;
import com.freedom.supercoin.mode.entity.Page;

import java.util.List;


public class IntegralFragmentContact {

    public interface View extends BaseView {
        void onLoadBannerSuccess(List<HomeBannerMode> list);

        void onLoadGoodsListSuccess(List<IntegralFragmentMode.DataBeanX.DataBean> data);
        void onLoadError();
    }


    public interface Presenter extends BasePresenter {
        void onLoadBanner();

        void loadIntegralList(Page page);

    }
}

