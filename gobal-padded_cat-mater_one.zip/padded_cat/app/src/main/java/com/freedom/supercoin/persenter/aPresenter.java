package com.freedom.supercoin.persenter;

import com.freedom.supercoin.contract.aContact;


public class aPresenter implements aContact.Presenter {

    private final aContact.View view;

    public aPresenter(aContact.View view) {
        this.view = view;
    }

     /* DataManager.getInstance()
              .submitAddPay(pay)
                .compose(RxUtils.applyIOSchedulers())
            .map(RxUtils.checkResultToData())
            .onErrorResumeNext(new ResponseErrorFunc<>())
            .subscribe(new Subscriber<String>() {
        @Override
        public void onCompleted() {

        }


        @Override
        public void onError(Throwable e) {
            e.printStackTrace();
            view.hideProgress();
        }


        @Override
        public void onNext(String s) {
            view.hideProgress();
        }
    });*/

}
