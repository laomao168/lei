package com.freedom.supercoin.activity;

import android.view.View;

import com.freedom.supercoin.R;
import com.freedom.supercoin.adapter.IntegralAdapter;
import com.freedom.supercoin.base_library.dialog.ComDialog;
import com.freedom.supercoin.base_library.utils.StrUtils;
import com.freedom.supercoin.common.UiActivity;
import com.freedom.supercoin.contract.BalanceContact;
import com.freedom.supercoin.databinding.ActivityBalanceBinding;
import com.freedom.supercoin.mode.BalanceDetailMode;
import com.freedom.supercoin.mode.CheckRealNameMode;
import com.freedom.supercoin.mode.TodayIncomeMode;
import com.freedom.supercoin.persenter.BalancePresenter;

/**
 * @author : lijianping
 * @date : Created on 2019/7/11.
 * des:余额
 */
public class BalanceActivity extends UiActivity<ActivityBalanceBinding> implements BalanceContact.View {

    private IntegralAdapter integralAdapter;
    private boolean isShowTips;
    private BalancePresenter presenter;
    private boolean isRealName;
    private double amount;

    @Override
    protected int layoutResId() {
        return R.layout.activity_balance;
    }

    @Override
    protected void initData() {
        isShowTips = false;
        integralAdapter = new IntegralAdapter();
        presenter = new BalancePresenter(this);
        presenter.getBalance();
        presenter.getTodayIncome();
        presenter.checkRealName();
    }

    @Override
    protected void initEvent() {
        binding.setClick(v -> {
            switch (v.getId()) {
                case R.id.tv_to_balance_detail: //余额明细
                    getOperation().forward(BalanceDetailActivity.class);
                    break;
                case R.id.rl_charge: //充值
                    getOperation().addParameter("balance", amount);
                    getOperation().forward(ChargeActivity.class);
                    break;
                case R.id.rl_withdraw: //提现
                    if (isRealName) {
                        getOperation().forward(WithDrawActivity.class);
                    } else { //
                        showRealNameDialog();
                    }
                    break;
            }
        });
    }

    /**
     * 提示实名
     */
    private void showRealNameDialog() {
        ComDialog comDialog = new ComDialog.Builder(this).setTitle("提示").setInfo
                ("为保证资金安全,请先实名认证").create();
        comDialog.setOnDialogClickListener(new ComDialog.OnDialogClickListener() {
            @Override
            public void onConfirmClick() {
                getOperation().forward(SecurityActivity.class);
            }

            @Override
            public void onCancelClick() {

            }
        });
        comDialog.show(getSupportFragmentManager(), "");
    }

    @Override
    public void getBalanceSuccess(BalanceDetailMode mode) {
        amount = mode.amount;
        binding.tvBalance.setText(StrUtils.getRemoveZreoNum(mode.amount));
        binding.tvFrozen.setText("冻结:"+StrUtils.getRemoveZreoNum(mode.lockAmount));
        binding.tvTodayMoney.setText(StrUtils.getRemoveZreoNum(mode.todayIncome));
        binding.tvTomMoney.setText(StrUtils.getRemoveZreoNum(mode.yesterdayProfit));
        binding.tvTotalMoney.setText(StrUtils.getRemoveZreoNum(mode.totalIncome));
    }

    @Override
    public void getRealNameSuccess(CheckRealNameMode mode) {
        if ( mode.success) {
            isRealName = true;
        } else {
            isRealName = false;
        }
    }

    @Override
    public void getTodayIncomeSuccess(TodayIncomeMode mode) {
        if (mode.success){
            binding.tvTodayMoney.setText(StrUtils.getRemoveZreoNum(mode.data));
        }
    }
}
