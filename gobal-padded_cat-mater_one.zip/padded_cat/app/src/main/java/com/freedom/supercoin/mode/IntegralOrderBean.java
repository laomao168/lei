package com.freedom.supercoin.mode;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2020/4/10.
 * @desc :
 */
public class IntegralOrderBean {

    /**
     * code : 0
     * count : null
     * data : {"memberAddress":{"address":"丹枫路","addressId":5,"applyed":false,"channelId":"",
     * "city":"330100","cityText":"杭州市","clicked":false,"consignee":"李剑平","createBy":"",
     * "createTime":"2020-04-10 13:48:37","deleted":0,"desc":"desc","deviceCode":"",
     * "deviceType":"","district":"330108","districtText":"滨江区","endTime":null,
     * "mobile":"18566398679","orderField":"","page":{"currentResult":0,"entityOrField":false,
     * "pageNumber":1,"pageSize":10,"pageStr":"","totalPage":0,"totalResult":0},"params":null,
     * "province":"330000","provinceText":"浙江省","remark":"","searchValue":"","startTime":null,
     * "street":"330108001","streetText":"西兴街道","tolerant":0,"updateBy":"","updateTime":null,
     * "userId":1760},"mallGoodsInfo":{"applyed":false,"assessPrice":720,"boutique":2,
     * "categoryId":4,"categoryName":"","channelId":"","clicked":false,"content":"",
     * "costPrice":240,"createBy":"admin","createTime":"2019-12-25 15:22:17","deleted":0,
     * "desc":"desc","description":"杜酱荷花酒贵州茅台镇53度香柔酱香型白酒500ml礼盒装 结婚宴喜事用酒 喜庆版整箱6瓶装",
     * "deviceCode":"","deviceType":"","eendTime":"","endTime":null,"goodsDetail":"",
     * "goodsId":180,"goodsName":"《限量10件》杜酱荷花酒贵州茅台镇53度香柔酱香型白酒500ml礼盒装整箱6瓶装","goodsSubType":null,
     * "goodsType":2,"headImage":"[\"https://images.oneauct
     * .com/1248840de97d4ff89667e6f479b3887e\",\"https://images.oneauct
     * .com/6b287c6cb0fd4eea92ce7ba95008d74b\"]","integral":998,"inventory":10,
     * "logo":"https://images.oneauct.com/6fe34f3785114a48aea64bc676761a1f","orderField":"",
     * "page":{"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,"pageStr":"",
     * "totalPage":0,"totalResult":0},"params":null,"price":null,"priceType":1,"remark":"",
     * "searchValue":"","soldNum":6,"sort":999,"sstartTime":"","startTime":null,"status":2,
     * "supplier":"ZM","supplierId":9,"updateBy":"cyz2019","updateTime":"2019-12-27 10:50:01",
     * "upperTime":null,"url5":"","url6":"","url7":"","url8":"","url9":""}}
     * error : false
     * msg : 查询成功
     * result : true
     * success : true
     */

    public String code;
    public Object count;
    public DataBean data;
    public boolean error;
    public String msg;
    public boolean result;
    public boolean success;

    public static class DataBean {
        /**
         * memberAddress : {"address":"丹枫路","addressId":5,"applyed":false,"channelId":"",
         * "city":"330100","cityText":"杭州市","clicked":false,"consignee":"李剑平","createBy":"",
         * "createTime":"2020-04-10 13:48:37","deleted":0,"desc":"desc","deviceCode":"",
         * "deviceType":"","district":"330108","districtText":"滨江区","endTime":null,
         * "mobile":"18566398679","orderField":"","page":{"currentResult":0,
         * "entityOrField":false,"pageNumber":1,"pageSize":10,"pageStr":"","totalPage":0,
         * "totalResult":0},"params":null,"province":"330000","provinceText":"浙江省","remark":"",
         * "searchValue":"","startTime":null,"street":"330108001","streetText":"西兴街道",
         * "tolerant":0,"updateBy":"","updateTime":null,"userId":1760}
         * mallGoodsInfo : {"applyed":false,"assessPrice":720,"boutique":2,"categoryId":4,
         * "categoryName":"","channelId":"","clicked":false,"content":"","costPrice":240,
         * "createBy":"admin","createTime":"2019-12-25 15:22:17","deleted":0,"desc":"desc",
         * "description":"杜酱荷花酒贵州茅台镇53度香柔酱香型白酒500ml礼盒装 结婚宴喜事用酒 喜庆版整箱6瓶装","deviceCode":"",
         * "deviceType":"","eendTime":"","endTime":null,"goodsDetail":"","goodsId":180,
         * "goodsName":"《限量10件》杜酱荷花酒贵州茅台镇53度香柔酱香型白酒500ml礼盒装整箱6瓶装","goodsSubType":null,
         * "goodsType":2,"headImage":"[\"https://images.oneauct
         * .com/1248840de97d4ff89667e6f479b3887e\",\"https://images.oneauct
         * .com/6b287c6cb0fd4eea92ce7ba95008d74b\"]","integral":998,"inventory":10,
         * "logo":"https://images.oneauct.com/6fe34f3785114a48aea64bc676761a1f","orderField":"",
         * "page":{"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,
         * "pageStr":"","totalPage":0,"totalResult":0},"params":null,"price":null,"priceType":1,
         * "remark":"","searchValue":"","soldNum":6,"sort":999,"sstartTime":"","startTime":null,
         * "status":2,"supplier":"ZM","supplierId":9,"updateBy":"cyz2019",
         * "updateTime":"2019-12-27 10:50:01","upperTime":null,"url5":"","url6":"","url7":"",
         * "url8":"","url9":""}
         */

        public MemberAddressBean memberAddress;
        public MallGoodsInfoBean mallGoodsInfo;

        public static class MemberAddressBean {
            /**
             * address : 丹枫路
             * addressId : 5
             * applyed : false
             * channelId :
             * city : 330100
             * cityText : 杭州市
             * clicked : false
             * consignee : 李剑平
             * createBy :
             * createTime : 2020-04-10 13:48:37
             * deleted : 0
             * desc : desc
             * deviceCode :
             * deviceType :
             * district : 330108
             * districtText : 滨江区
             * endTime : null
             * mobile : 18566398679
             * orderField :
             * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,
             * "pageStr":"","totalPage":0,"totalResult":0}
             * params : null
             * province : 330000
             * provinceText : 浙江省
             * remark :
             * searchValue :
             * startTime : null
             * street : 330108001
             * streetText : 西兴街道
             * tolerant : 0
             * updateBy :
             * updateTime : null
             * userId : 1760
             */

            public String address;
            public int addressId;
            public boolean applyed;
            public String channelId;
            public String city;
            public String cityText;
            public boolean clicked;
            public String consignee;
            public String createBy;
            public String createTime;
            public int deleted;
            public String desc;
            public String deviceCode;
            public String deviceType;
            public String district;
            public String districtText;
            public Object endTime;
            public String mobile;
            public String orderField;
            public PageBean page;
            public Object params;
            public String province;
            public String provinceText;
            public String remark;
            public String searchValue;
            public Object startTime;
            public String street;
            public String streetText;
            public int tolerant;
            public String updateBy;
            public Object updateTime;
            public int userId;

            public static class PageBean {
                /**
                 * currentResult : 0
                 * entityOrField : false
                 * pageNumber : 1
                 * pageSize : 10
                 * pageStr :
                 * totalPage : 0
                 * totalResult : 0
                 */

                public int currentResult;
                public boolean entityOrField;
                public int pageNumber;
                public int pageSize;
                public String pageStr;
                public int totalPage;
                public int totalResult;
            }
        }

        public static class MallGoodsInfoBean {
            /**
             * applyed : false
             * assessPrice : 720.0
             * boutique : 2
             * categoryId : 4
             * categoryName :
             * channelId :
             * clicked : false
             * content :
             * costPrice : 240.0
             * createBy : admin
             * createTime : 2019-12-25 15:22:17
             * deleted : 0
             * desc : desc
             * description : 杜酱荷花酒贵州茅台镇53度香柔酱香型白酒500ml礼盒装 结婚宴喜事用酒 喜庆版整箱6瓶装
             * deviceCode :
             * deviceType :
             * eendTime :
             * endTime : null
             * goodsDetail :
             * goodsId : 180
             * goodsName : 《限量10件》杜酱荷花酒贵州茅台镇53度香柔酱香型白酒500ml礼盒装整箱6瓶装
             * goodsSubType : null
             * goodsType : 2
             * headImage : ["https://images.oneauct.com/1248840de97d4ff89667e6f479b3887e",
             * "https://images.oneauct.com/6b287c6cb0fd4eea92ce7ba95008d74b"]
             * integral : 998.0
             * inventory : 10
             * logo : https://images.oneauct.com/6fe34f3785114a48aea64bc676761a1f
             * orderField :
             * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,
             * "pageStr":"","totalPage":0,"totalResult":0}
             * params : null
             * price : null
             * priceType : 1
             * remark :
             * searchValue :
             * soldNum : 6
             * sort : 999
             * sstartTime :
             * startTime : null
             * status : 2
             * supplier : ZM
             * supplierId : 9
             * updateBy : cyz2019
             * updateTime : 2019-12-27 10:50:01
             * upperTime : null
             * url5 :
             * url6 :
             * url7 :
             * url8 :
             * url9 :
             */

            public boolean applyed;
            public double assessPrice;
            public int boutique;
            public int categoryId;
            public String categoryName;
            public String channelId;
            public boolean clicked;
            public String content;
            public double costPrice;
            public String createBy;
            public String createTime;
            public int deleted;
            public String desc;
            public String description;
            public String deviceCode;
            public String deviceType;
            public String eendTime;
            public Object endTime;
            public String goodsDetail;
            public int goodsId;
            public String goodsName;
            public Object goodsSubType;
            public int goodsType;
            public String headImage;
            public double integral;
            public int inventory;
            public String logo;
            public String orderField;
            public PageBeanX page;
            public Object params;
            public Object price;
            public int priceType;
            public String remark;
            public String searchValue;
            public int soldNum;
            public int sort;
            public String sstartTime;
            public Object startTime;
            public int status;
            public String supplier;
            public int supplierId;
            public String updateBy;
            public String updateTime;
            public Object upperTime;
            public String url5;
            public String url6;
            public String url7;
            public String url8;
            public String url9;

            public static class PageBeanX {
                /**
                 * currentResult : 0
                 * entityOrField : false
                 * pageNumber : 1
                 * pageSize : 10
                 * pageStr :
                 * totalPage : 0
                 * totalResult : 0
                 */

                public int currentResult;
                public boolean entityOrField;
                public int pageNumber;
                public int pageSize;
                public String pageStr;
                public int totalPage;
                public int totalResult;
            }
        }
    }
}
