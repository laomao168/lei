package com.freedom.supercoin.activity;

import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;

import com.freedom.supercoin.R;
import com.freedom.supercoin.base_library.AppConst;
import com.freedom.supercoin.base_library.utils.AppUtil;
import com.freedom.supercoin.base_library.utils.SPUtils;
import com.freedom.supercoin.common.UiActivity;
import com.freedom.supercoin.contract.LoginContact;
import com.freedom.supercoin.databinding.ActivityABinding;
import com.freedom.supercoin.databinding.ActivityLoginBinding;
import com.freedom.supercoin.mode.entity.CodeReq;
import com.freedom.supercoin.mode.entity.LoginBean;
import com.freedom.supercoin.persenter.LoginPresenter;

/**
 * @author : lijianping
 * @date : Created on 2019/7/11.
 * des:
 */
public class LoginActivity extends UiActivity<ActivityLoginBinding> implements LoginContact.View {

    private LoginPresenter presenter;

    @Override
    protected int layoutResId() {
        return R.layout.activity_login;
    }

    @Override
    protected void initData() {
        presenter = new LoginPresenter(this);
        SPUtils.getInstance().put(AppConst.Keys.LOGIN_TOKEN, "");
        SPUtils.getInstance().put(AppConst.Keys.INVITATION_CODE,"");
        SPUtils.getInstance().put(AppConst.Keys.AVATAR,"");
        SPUtils.getInstance().put(AppConst.Keys.NICKNAME,"");
        SPUtils.getInstance().put(AppConst.Keys.PHONE,"");
        SPUtils.getInstance().put(AppConst.Keys.USER_ID,"");
    }

    @Override
    protected void initEvent() {
        binding.setClick(v -> {
            switch (v.getId()) {
                case R.id.tv_get_code:
                    getCode();
                    break;
                case R.id.tv_login:
                    checkAndRegister();
                    break;

            }
        });
    }

    private void checkAndRegister() {
        String phone = binding.etPhone.getText().toString().trim();
        String code = binding.etCode.getText().toString().trim();
        if (TextUtils.isEmpty(phone)) {
            showMessage("请输入手机号码");
            return;
        }
        if (phone.length() != 11) {
            showMessage("请输入正确的手机号码");
            return;
        }
        if (TextUtils.isEmpty(code)) {
            showMessage("请输入验证码");
            return;
        }
        LoginBean registerReq = new LoginBean();
        registerReq.verifyCode = code;
        registerReq.phone = phone;
        presenter.toLogin(registerReq);
    }

    private void getCode() {
        String s = binding.etPhone.getText().toString().trim();
        if (TextUtils.isEmpty(s)) {
            showMessage("请输入手机号码");
            return;
        }
        if (s.length() != 11) {
            showMessage("请输入正确的手机号码");
            return;
        }
        CodeReq codeReq = new CodeReq();
        codeReq.mobile = s;
        codeReq.use="register";
        presenter.getCode(codeReq);
    }

    @Override
    public void onLoginSuccess() {
        showMessage("登录成功");
        finish();
    }

    @Override
    public void onGetCodeSuccess() {
        showMessage("获取验证码成功");
    }
}
