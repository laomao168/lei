package com.freedom.supercoin.adapter;

import android.databinding.DataBindingUtil;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.freedom.supercoin.R;
import com.freedom.supercoin.base_library.base.BaseEmptyAdapter;
import com.freedom.supercoin.base_library.utils.GlideUtils;
import com.freedom.supercoin.databinding.ItemChargeBinding;
import com.freedom.supercoin.databinding.ItemFriendBinding;
import com.freedom.supercoin.mode.ChargeDetailMode;
import com.freedom.supercoin.mode.FriendMode;


public class ChargeAdapter extends BaseEmptyAdapter<ChargeDetailMode.DataBeanX.DataBean,
        ItemChargeBinding> {

    @Override
    protected ItemChargeBinding createBinding(ViewGroup parent) {
        return DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()),
                R.layout.item_charge, parent, false);
    }

    @Override
    protected void onBindView(ItemChargeBinding binding, ChargeDetailMode.DataBeanX.DataBean bean,
                              int position) {
        binding.tvChargeAmount.setText(bean.money);
        binding.tvTime.setText(bean.payTime);
    }

}
