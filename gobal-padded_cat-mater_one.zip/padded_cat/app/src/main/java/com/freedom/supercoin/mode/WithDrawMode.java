package com.freedom.supercoin.mode;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2020/1/11.
 */
public class WithDrawMode {

    /**
     * code : 1
     * count : null
     * data : null
     * error : true
     * msg : 提现金额不能超过5001元
     * result : false
     * success : false
     */

    public String code;
    public Object count;
    public Object data;
    public boolean error;
    public String msg;
    public boolean result;
    public boolean success;
}
