package com.freedom.supercoin.contract;


import com.freedom.supercoin.base_library.base.BasePresenter;
import com.freedom.supercoin.base_library.base.BaseView;
import com.freedom.supercoin.mode.BalanceDetailMode;
import com.freedom.supercoin.mode.CheckRealNameMode;
import com.freedom.supercoin.mode.TodayIncomeMode;


public class BalanceContact {

    public interface View extends BaseView {
        void getBalanceSuccess(BalanceDetailMode mode);

        void getRealNameSuccess(CheckRealNameMode mode);

        void getTodayIncomeSuccess(TodayIncomeMode s);
    }


    public interface Presenter extends BasePresenter {
        void getBalance();

        void getTodayIncome();

        void checkRealName();
    }
}

