package com.freedom.supercoin.mode.entity;


/**
 * Created by ljp on 2018/5/10.
 */

public class WeChatRequest {


    /**
     * appid : wx1d9979cc0239d1b3
     * noncestr : uz08rernzfoi7jtpz7kv
     * package : Sign=WXPay
     * prepayid : wx141313175800595ed27f11ab4264433349
     * partnerid : 1502595491
     * timestamp : 1526274797
     * sign : 3FC68224909A1201B498ED18109B44AC
     */

    public String appid;
    public String noncestr;
    public String prepayid;
    public String partnerid;
    public String timestamp;
    public String sign;

}
