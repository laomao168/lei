package com.freedom.supercoin.network;


public class ServerException extends RuntimeException {

    public String code;


    public ServerException(String message) {
        super(message);
    }



    public ServerException(String code, String message) {
        super();
        this.code = code;
    }
}
