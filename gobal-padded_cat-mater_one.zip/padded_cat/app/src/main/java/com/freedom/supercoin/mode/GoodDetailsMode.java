package com.freedom.supercoin.mode;

public class GoodDetailsMode {

    /**
     * assessPrice : 480.0
     * auctionId : 9484
     * brokerage : 5.0
     * cashDepositScale : 0.2
     * displayArea : 1
     * endTime : 2019-12-28 09:10:00
     * endTimes : 32831050
     * goodsDetail : <p><span><img src="https://images.oneauct
     * .com/13b62f5950bc4244b1b7f9480d22b52f"><img src="fhttps://images.oneauct
     * .com/39308e6ed63d4ecc8b320fb868a6ba58"><img src="https://images.oneauct
     * .com/5b9e2725fb204cc29fc1d158b6355131"><img src="https://images.oneauct
     * .com/2e3f677e993c45b79300a705346359ca"></span><br></p>
     * goodsName : 鲁花 食用油 5S物理压榨 压榨一级 花生油 6.18L（京东定制）
     * headImage : ["https://images.oneauct.com/929c0aa7f5eb435facfaad5376ef86d8","https://images
     * .oneauct.com/f69923e3dd264ac6ab6c89c266c68491","https://images.oneauct
     * .com/c1a692524ed544aaa03f9ac628107fbe"]
     * logo : https://images.oneauct.com/744a85b8ed694cd49eae8e5a58cb14ec
     * mailingUserId : null
     * markupNum : null
     * markupPrice : 50.0
     * nextCashDeposit : 34.0
     * startPrice : 120.0
     * startTime : 2019-12-28 09:00:00
     * startTimes : 32231050
     * status : 2
     * supplierId : 4
     * topPrice : 120.0
     * transactionPrice : null
     * viewCount : 104
     * vipUserId : null
     */

    public double assessPrice;
    public String auctionId;
    public double brokerage;
    public double cashDepositScale;
    public String displayArea;
    public String endTime;
    public long endTimes;
    public String goodsDetail;
    public String goodsName;
    public String headImage;
    public String logo;
    public Object mailingUserId;
    public Object markupNum;
    public double markupPrice;
    public String nextCashDeposit;
    public double startPrice;
    public String startTime;
    public long startTimes;
    public int status;
    public String supplierId;
    public double topPrice;
    public String transactionPrice;
    public String viewCount;
    public String vipUserId;

}
