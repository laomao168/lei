package com.freedom.supercoin.common;


import com.freedom.supercoin.base_library.AppConfig;
import com.freedom.supercoin.base_library.base.BaseApplication;
import com.freedom.supercoin.network.DataManager;

/**
 * Created by jianping on 2018/11/20.
 */

public class CommonApplication extends BaseApplication {
    @Override
    public void onCreate() {
        super.onCreate();
        DataManager.getInstance().init(this, new AppConfig() {
        });
    }
}
