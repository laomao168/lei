package com.freedom.supercoin.activity;

import android.text.TextUtils;
import android.view.View;

import com.freedom.supercoin.R;
import com.freedom.supercoin.common.UiActivity;
import com.freedom.supercoin.contract.RealNameContact;
import com.freedom.supercoin.databinding.ActivityABinding;
import com.freedom.supercoin.databinding.ActivityRealNameBinding;
import com.freedom.supercoin.mode.RealNameMode;
import com.freedom.supercoin.persenter.RealNamePresenter;

/**
 * @author : lijianping
 * @date : Created on 2019/7/11.
 * des:
 */
public class RealNameActivity extends UiActivity<ActivityRealNameBinding> implements RealNameContact.View {

    private RealNamePresenter presenter;

    @Override
    protected int layoutResId() {
        return R.layout.activity_real_name;
    }

    @Override
    protected void initData() {
        binding.titleBar.setTextColor("#ffffff");
        binding.titleBar.setTitle("实名认证");
        binding.titleBar.setLeftImage(R.mipmap.ic_back_white);
        presenter = new RealNamePresenter(this);

    }

    @Override
    protected void initEvent() {
        binding.tvSub.setOnClickListener(v -> {
            checkAndSub();
        });
    }

    private void checkAndSub() {
        String userName = binding.etName.getText().toString();
        String alipay = binding.etAilpay.getText().toString();
        String idCard = binding.etIdCard.getText().toString();
        String bank = binding.etBank.getText().toString();
        String bankName = binding.etBankName.getText().toString();
        String bankCard = binding.etBankCardNum.getText().toString();
        if (TextUtils.isEmpty(userName)) {
            showMessage("请输入姓名");
            return;
        }
        if (TextUtils.isEmpty(alipay)) {
            showMessage("请输入支付宝账户");
            return;
        }
        if (TextUtils.isEmpty(idCard)) {
            showMessage("请输入身份证号码");
            return;
        }
        if (TextUtils.isEmpty(bank)) {
            showMessage("请输入支行名称");
            return;
        }
        if (TextUtils.isEmpty(bankName)) {
            showMessage("请输入银行名称");
            return;
        }
        if (TextUtils.isEmpty(bankCard)) {
            showMessage("请输入银行卡号");
            return;
        }
        presenter.toIdentity(bankName, bank, bankCard, userName, alipay, idCard);
    }

    @Override
    public void onSubSuccess(RealNameMode mode) {
        if (mode == null) return;
        showMessage(mode.msg);
        if (mode.success) { //提交成功
            finish();
        }
    }
}
