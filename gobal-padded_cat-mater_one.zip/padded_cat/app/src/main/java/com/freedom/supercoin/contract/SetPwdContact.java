package com.freedom.supercoin.contract;


import com.freedom.supercoin.base_library.base.BasePresenter;
import com.freedom.supercoin.base_library.base.BaseView;
import com.freedom.supercoin.mode.entity.CodeReq;


public class SetPwdContact {

    public interface View extends BaseView {

        void onGetCodeSuccess();
        void  onSetPwdSuccess();
    }


    public interface Presenter extends BasePresenter {
        void  getCode(CodeReq codeReq);
        void setPwd(String payPass,String code);
    }
}

