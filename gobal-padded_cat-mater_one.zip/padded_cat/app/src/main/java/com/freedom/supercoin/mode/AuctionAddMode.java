package com.freedom.supercoin.mode;

public class AuctionAddMode {

    /**
     * applyed : false
     * auctionDetailId : 342229
     * auctionId : 12133
     * avatar : https://wx.qlogo
     * .cn/mmopen/vi_32
     * /ia2uqKQFHON9kDG2p7PUDmaWXYKEV9L8yIA2IZOYgotNaI7eWrJ7HibsQtqt8V3hI0FA5MvRYCmOZOenHicibJZIlQ/132
     * channelId :
     * clicked : false
     * createBy : 剑平
     * createTime : 2020-01-04 12:16:44
     * deleted : null
     * desc : desc
     * deviceCode :
     * deviceType :
     * endTime : null
     * guarantyPrice : 64.8
     * markupTime : 2020-01-04 12:16:44
     * orderField :
     * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,"pageStr":"",
     * "totalPage":0,"totalResult":0}
     * params : null
     * payPrice : 324.0
     * payType : 1
     * remark :
     * searchValue :
     * startTime : null
     * updateBy :
     * updateTime : null
     * userId : 1601
     * userName : 剑平
     * userType : 1
     */

    public boolean applyed;
    public int auctionDetailId;
    public int auctionId;
    public String avatar;
    public String channelId;
    public boolean clicked;
    public String createBy;
    public String createTime;
    public Object deleted;
    public String desc;
    public String deviceCode;
    public String deviceType;
    public Object endTime;
    public double guarantyPrice;
    public String markupTime;
    public String orderField;
    public PageBean page;
    public Object params;
    public double payPrice;
    public int payType;
    public String remark;
    public String searchValue;
    public Object startTime;
    public String updateBy;
    public Object updateTime;
    public int userId;
    public String userName;
    public int userType;
    public double nextCashDeposit;
    public double brokerage;
    public String markupTimeString;

    public static class PageBean {
        /**
         * currentResult : 0
         * entityOrField : false
         * pageNumber : 1
         * pageSize : 10
         * pageStr :
         * totalPage : 0
         * totalResult : 0
         */

        public int currentResult;
        public boolean entityOrField;
        public int pageNumber;
        public int pageSize;
        public String pageStr;
        public int totalPage;
        public int totalResult;
    }
}
