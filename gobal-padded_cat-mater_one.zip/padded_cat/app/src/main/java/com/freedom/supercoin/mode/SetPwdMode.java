package com.freedom.supercoin.mode;

import java.util.List;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2019/12/31.
 * @desc :
 */
public class SetPwdMode {

    /**
     * code : 0
     * count : null
     * data : {"accountDetailType":null,"alipay":"","amount":null,"applyed":false,"avatar":"",
     * "backDeposit":null,"beginTime":"","birthday":null,"blacklist":null,"cardNo":"",
     * "channelId":"","chargeMoney":null,"clicked":false,"createBy":"","createIp":"",
     * "createTime":null,"deleted":null,"desc":"desc","deviceCode":"","deviceType":"",
     * "directNum":null,"endTime":null,"failMoney":null,"fanNums":null,"gender":null,
     * "indirectNum":null,"inhibited":null,"integralAmount":null,"integralDetailType":null,
     * "invitationCode":"","isEarnings":null,"isSendMsg":null,"lastLoginIp":"",
     * "lastLoginTime":null,"lockAmount":null,"money":null,"name":"","newPeople":null,
     * "nickname":"","openid":"","orderField":"","orderMoney":null,"outWithdraw":null,
     * "overTime":"","page":{"currentResult":0,"entityOrField":false,"pageNumber":1,
     * "pageSize":10,"pageStr":"","totalPage":0,"totalResult":0},"params":null,"parentId":null,
     * "parentIdList":[],"parentInvitationCode":"","parentNickname":"","parentTime":null,
     * "partnerIncome":null,"password":"",
     * "payPassword":"97385ac31f75638f2c05b27116d844c2bb4b33f25382dd78","phone":"",
     * "positMoney":null,"qrcodeUrl":"","remark":"","searchValue":"","secondInviterId":null,
     * "sjnickname":"","smsCode":"","startTime":null,"status":null,"token":"","totalIncome":null,
     * "tradeType":null,"type":null,"unionid":"","updateBy":"1178","updateInviteCode":null,
     * "updateTime":null,"userId":1178,"username":"","verifyCode":""}
     * error : false
     * msg : 设置成功
     * result : true
     * success : true
     */

    public String code;
    public Object count;
    public DataBean data;
    public boolean error;
    public String msg;
    public boolean result;
    public boolean success;

    public static class DataBean {
        /**
         * accountDetailType : null
         * alipay :
         * amount : null
         * applyed : false
         * avatar :
         * backDeposit : null
         * beginTime :
         * birthday : null
         * blacklist : null
         * cardNo :
         * channelId :
         * chargeMoney : null
         * clicked : false
         * createBy :
         * createIp :
         * createTime : null
         * deleted : null
         * desc : desc
         * deviceCode :
         * deviceType :
         * directNum : null
         * endTime : null
         * failMoney : null
         * fanNums : null
         * gender : null
         * indirectNum : null
         * inhibited : null
         * integralAmount : null
         * integralDetailType : null
         * invitationCode :
         * isEarnings : null
         * isSendMsg : null
         * lastLoginIp :
         * lastLoginTime : null
         * lockAmount : null
         * money : null
         * name :
         * newPeople : null
         * nickname :
         * openid :
         * orderField :
         * orderMoney : null
         * outWithdraw : null
         * overTime :
         * page : {"currentResult":0,"entityOrField":false,"pageNumber":1,"pageSize":10,
         * "pageStr":"","totalPage":0,"totalResult":0}
         * params : null
         * parentId : null
         * parentIdList : []
         * parentInvitationCode :
         * parentNickname :
         * parentTime : null
         * partnerIncome : null
         * password :
         * payPassword : 97385ac31f75638f2c05b27116d844c2bb4b33f25382dd78
         * phone :
         * positMoney : null
         * qrcodeUrl :
         * remark :
         * searchValue :
         * secondInviterId : null
         * sjnickname :
         * smsCode :
         * startTime : null
         * status : null
         * token :
         * totalIncome : null
         * tradeType : null
         * type : null
         * unionid :
         * updateBy : 1178
         * updateInviteCode : null
         * updateTime : null
         * userId : 1178
         * username :
         * verifyCode :
         */

        public Object accountDetailType;
        public String alipay;
        public Object amount;
        public boolean applyed;
        public String avatar;
        public Object backDeposit;
        public String beginTime;
        public Object birthday;
        public Object blacklist;
        public String cardNo;
        public String channelId;
        public Object chargeMoney;
        public boolean clicked;
        public String createBy;
        public String createIp;
        public Object createTime;
        public Object deleted;
        public String desc;
        public String deviceCode;
        public String deviceType;
        public Object directNum;
        public Object endTime;
        public Object failMoney;
        public Object fanNums;
        public Object gender;
        public Object indirectNum;
        public Object inhibited;
        public Object integralAmount;
        public Object integralDetailType;
        public String invitationCode;
        public Object isEarnings;
        public Object isSendMsg;
        public String lastLoginIp;
        public Object lastLoginTime;
        public Object lockAmount;
        public Object money;
        public String name;
        public Object newPeople;
        public String nickname;
        public String openid;
        public String orderField;
        public Object orderMoney;
        public Object outWithdraw;
        public String overTime;
        public PageBean page;
        public Object params;
        public Object parentId;
        public String parentInvitationCode;
        public String parentNickname;
        public Object parentTime;
        public Object partnerIncome;
        public String password;
        public String payPassword;
        public String phone;
        public Object positMoney;
        public String qrcodeUrl;
        public String remark;
        public String searchValue;
        public Object secondInviterId;
        public String sjnickname;
        public String smsCode;
        public Object startTime;
        public Object status;
        public String token;
        public Object totalIncome;
        public Object tradeType;
        public Object type;
        public String unionid;
        public String updateBy;
        public Object updateInviteCode;
        public Object updateTime;
        public int userId;
        public String username;
        public String verifyCode;
        public List<?> parentIdList;

        public static class PageBean {
            /**
             * currentResult : 0
             * entityOrField : false
             * pageNumber : 1
             * pageSize : 10
             * pageStr :
             * totalPage : 0
             * totalResult : 0
             */

            public int currentResult;
            public boolean entityOrField;
            public int pageNumber;
            public int pageSize;
            public String pageStr;
            public int totalPage;
            public int totalResult;
        }
    }
}
