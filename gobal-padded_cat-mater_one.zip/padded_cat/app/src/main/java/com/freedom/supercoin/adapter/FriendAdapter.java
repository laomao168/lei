package com.freedom.supercoin.adapter;

import android.databinding.DataBindingUtil;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.freedom.supercoin.R;
import com.freedom.supercoin.base_library.base.BaseEmptyAdapter;
import com.freedom.supercoin.base_library.utils.GlideUtils;
import com.freedom.supercoin.databinding.ItemAddressBinding;
import com.freedom.supercoin.databinding.ItemFriendBinding;
import com.freedom.supercoin.mode.AddressListMode;
import com.freedom.supercoin.mode.FriendMode;


public class FriendAdapter extends BaseEmptyAdapter<FriendMode.DataBeanX.DataBean,
        ItemFriendBinding> {

    @Override
    protected ItemFriendBinding createBinding(ViewGroup parent) {
        return DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()),
                R.layout.item_friend, parent, false);
    }

    @Override
    protected void onBindView(ItemFriendBinding binding, FriendMode.DataBeanX.DataBean bean,
                              int position) {
        GlideUtils.loadImage(context,bean.avatar,binding.ivUserImage,R.mipmap.img_goodsdetails_head2);
        binding.tvName.setText(bean.nickname);
        binding.tvTime.setText(bean.createTime);
        binding.tvPerson.setText(bean.directNum+"");
    }

}
