package com.freedom.supercoin.fragment;

import android.support.v4.view.ViewPager;
import android.support.v7.widget.GridLayoutManager;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.freedom.supercoin.R;
import com.freedom.supercoin.activity.GoodsCategoryActivity;
import com.freedom.supercoin.activity.GoodsDetailActivity;
import com.freedom.supercoin.activity.IntegralGoodsDetailActivity;
import com.freedom.supercoin.activity.IntegralOrderActivity;
import com.freedom.supercoin.activity.LoginTipsActivity;
import com.freedom.supercoin.adapter.HomeBannerAdapter;
import com.freedom.supercoin.adapter.IntegralGoodsAdapter;
import com.freedom.supercoin.base_library.AppConst;
import com.freedom.supercoin.base_library.utils.DimensUtils;
import com.freedom.supercoin.common.UILazyFragment;
import com.freedom.supercoin.contract.IntegralFragmentContact;
import com.freedom.supercoin.databinding.FragmentIntegralBinding;
import com.freedom.supercoin.mode.HomeBannerMode;
import com.freedom.supercoin.mode.IntegralFragmentMode;
import com.freedom.supercoin.mode.entity.Page;
import com.freedom.supercoin.persenter.IntegralFragmentPresenter;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 * @author : lijianping
 * @e-mail :
 * @date : Created on 2019/7/18.
 */

public class IntegralFragment extends UILazyFragment<FragmentIntegralBinding> implements IntegralFragmentContact.View {

    private IntegralFragmentPresenter presenter;
    private List<HomeBannerMode> integralBannerList;
    private HomeBannerAdapter homeBannerAdapter;
    private int currentIndex;
    private int maxIndex;
    private Timer timer;
    private TimerTask timerTask;
    private IntegralGoodsAdapter adapter;
    private int currentPageNumber;

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_integral;
    }


    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        setTimeTask(isVisibleToUser);
        if (isVisibleToUser) {
            if (presenter != null) {
                loadPage();
                presenter.onLoadBanner();
            }
        }
    }

    @Override
    protected void initData() {
        homeBannerAdapter = new HomeBannerAdapter(mActivity, null);
        binding.vpBanner.setAdapter(homeBannerAdapter);
        presenter = new IntegralFragmentPresenter(this);
        binding.recycleViewItems.setLayoutManager(new GridLayoutManager(mActivity, 2));
        binding.recycleViewItems.setNestedScrollingEnabled(false);
        adapter = new IntegralGoodsAdapter();
        binding.recycleViewItems.setAdapter(adapter);
        currentPageNumber = 1;
    }

    private void loadPage() {
        Page page = new Page();
        page.pageNumber = currentPageNumber;
        page.pageSize = 10;
        presenter.loadIntegralList(page);
    }

    @Override
    protected void initEvent() {
        adapter.setOnItemClickListener((position, data) -> {
            //跳转商品详情
            if (AppConst.ISLOGIN){
                getOperation().addParameter(AppConst.Keys.GOODS_ID, data.goodsId);
                getOperation().forward(IntegralGoodsDetailActivity.class);
            }else {
                getOperation().forward(LoginTipsActivity.class);
            }

        });
        binding.scrollView.setScrollViewListener((v, scrollX, scrollY, oldScrollX, oldScrollY) -> {
            //判断是否滑到的底部
            if (scrollY == (v.getChildAt(0).getMeasuredHeight() - v.getMeasuredHeight())) {
                currentPageNumber++;
                binding.tvLoadingTips.setVisibility(View.VISIBLE);
                loadPage();
            }
        });
        homeBannerAdapter.setOnItemClickListener(position -> {
            //            type  ：
//            NBYM(1, "内部页面"),
//                    PMXQ(2, "拍卖详情"),
//                    PMFL(3, "拍卖分类"),
//                    BTZ(5, "不跳转"),
//                    H5(4, "h5页面");
            HomeBannerMode homeBannerMode = integralBannerList.get(position);
            switch (homeBannerMode.type) {
                case 1:
                    break;
                case 2:
                    getOperation().addParameter(AppConst.Keys.AUCTIONID, homeBannerMode.linkId);
                    getOperation().forward(GoodsDetailActivity.class);
                    break;
                case 3:
                    getOperation().addParameter("type", 1);
                    getOperation().addParameter("categoryId", homeBannerMode.linkId);
                    getOperation().addParameter(AppConst.Keys.TITLE, homeBannerMode.name);
                    getOperation().forward(GoodsCategoryActivity.class);
                    break;
                case 4:
                    break;

            }
        });
        binding.vpBanner.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {
            }

            @Override
            public void onPageSelected(int position) {
                currentIndex = position;
                for (int i = 0; i < binding.llDot.getChildCount(); i++) {
                    binding.llDot.getChildAt(i).setSelected(false);
                }
                binding.llDot.getChildAt(position).setSelected(true);
            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });
        binding.setClick(v -> {
            switch (v.getId()) {
                case R.id.ll_exchange://换购区
                    getOperation().addParameter("categoryId", 2);
                    getOperation().addParameter("type", 2);
                    getOperation().addParameter(AppConst.Keys.TITLE, "换购");
                    getOperation().forward(GoodsCategoryActivity.class);
                    break;

                case R.id.ll_mall: // 商城
                    getOperation().addParameter("categoryId", 1);
                    getOperation().addParameter("type", 2);
                    getOperation().addParameter(AppConst.Keys.TITLE, "寄拍");
                    getOperation().forward(GoodsCategoryActivity.class);
                    break;

                case R.id.ll_me_ex: //我的换购
                    getOperation().addParameter("goodsType", 2);
                    getOperation().forward(IntegralOrderActivity.class);
                    break;

                case R.id.ll_mall_order: //我的商城订单
                    getOperation().addParameter("goodsType", 1);
                    getOperation().forward(IntegralOrderActivity.class);
                    break;

            }
        });
        //下拉刷新
        binding.swipeRefresh.setOnRefreshListener(() -> {
            presenter.onLoadBanner();
            currentPageNumber = 1;
            loadPage();

        });
    }

    /**
     * banner 定时任务 轮播
     *
     * @param isVisibleToUser
     */
    private void setTimeTask(boolean isVisibleToUser) {
        if (maxIndex == 1) return;
        if (isVisibleToUser) {
            timer = new Timer();
            timerTask = new TimerTask() {
                @Override
                public void run() {
                    autoChangeBanner();
                }
            };
            //每隔两S发送一次网速
            timer.schedule(timerTask, 4000, 4000);
        } else {
            if (timer == null) return;
            timer.cancel();
        }
    }

    //自动轮播
    private void autoChangeBanner() {
        if (++currentIndex >= maxIndex) {
            currentIndex = 0;
        }
        if (mActivity == null) return;
        mActivity.runOnUiThread(() -> {
            binding.vpBanner.setCurrentItem(currentIndex);
        });
    }

    @Override
    public void onLoadBannerSuccess(List<HomeBannerMode> list) {
        binding.swipeRefresh.setRefreshing(false);
        if (list == null) return;
        this.integralBannerList = list;
        homeBannerAdapter.setData(integralBannerList);
        binding.llDot.removeAllViews();
        for (int i = 0; i < list.size(); i++) {
            // 设置相应下面小红点
            ImageView dotImage = new ImageView(mActivity);
            dotImage.setImageResource(R.drawable.shape_dot_selector);
            // 设置原点的宽度和 间距
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(DimensUtils
                    .dp2px(mActivity, 8), DimensUtils.dp2px(mActivity, 8));
            params.leftMargin = DimensUtils.dp2px(mActivity, 10);
            dotImage.setSelected(false);
            binding.llDot.addView(dotImage, params);
        }
        if (binding.llDot.getChildCount() > 0) {
            binding.llDot.getChildAt(0).setSelected(true);
            currentIndex = 0;
            maxIndex = binding.llDot.getChildCount();
        }
    }

    @Override
    public void onLoadGoodsListSuccess(List<IntegralFragmentMode.DataBeanX.DataBean> data) {
        binding.swipeRefresh.setRefreshing(false);
        binding.tvLoadingTips.setVisibility(View.GONE);
        if (currentPageNumber == 1) {
            adapter.setData(data);
        } else {
            adapter.addDataList(data);
        }
    }

    @Override
    public void onLoadError() {
        binding.swipeRefresh.setRefreshing(false);
    }
}
