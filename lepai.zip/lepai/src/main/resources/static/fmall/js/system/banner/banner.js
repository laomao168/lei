$(function(){
	var prefix = ctx + "system/banner";
	$.validator
	.setDefaults({
		ignore : "",
		/* 关闭键盘输入时的实时校验 */
		onkeyup : true,
		/* 重写校验元素获得焦点后的执行函数--增加[1.光标移入元素时的帮助提示,2.校验元素的高亮显示]两个功能点 */
		onfocusin : function(element) {
			this.lastActive = element;
			/* 2.校验元素的高亮显示 */
			$(element).addClass('highlight');

			// Hide error label and remove error class on focus if
			// enabled
			if (this.settings.focusCleanup) {
				if (this.settings.unhighlight) {
					this.settings.unhighlight.call(this, element,
							this.settings.errorClass,
							this.settings.validClass);
				}
				this.hideThese(this.errorsFor(element));
			}
		},
		errorPlacement:function(error,element) {  
			error.insertAfter(element);
	   },
		/* 重写校验元素焦点离开时的执行函数--移除[1.添加的帮助提示,2.校验元素的高亮显示] */
		onfocusout : function(element) {
			/* 2.校验元素高亮样式移除 */
			$(element).removeClass('highlight');
			/* 3.替换下面注释的原始代码，任何时候光标离开元素都触发校验功能 */
			// this.element( element );
			if (!this.checkable(element)
					&& (element.name in this.submitted || !this
							.optional(element))) {
				this.element(element);
			}
		}
	});
	
	
	$("#form-banner-add").validate(
			{
				rules : {
					url : {
						required : true,
					},
					state : {
						required : true,
					},
					sort : {
						required : true,
					},
					type : {
						required : true,
					},
					location : {
						digits:true
					},
					subSype : {
						required : true,
					}
				},
				submitHandler : function(form) {
					$.operate.save(prefix + "/save",
					$('#form-banner-add').serialize());
				}
			});
	
	$("#form-banner-edit").validate(
				{
					rules : {
						url : {
							required : true,
						},
						state : {
							required : true,
						},
						sort : {
							required : true,
						},
						type : {
							required : true,
						},
						location : {
							digits:true
						},
						subSype : {
							required : true,
						}
						
					},
					submitHandler : function(form) {
						$.operate.save(prefix + "/save",
						$('#form-banner-edit').serialize());
					}
				});

	
	createUploader("fileurlPicker", "fileurlList", "url");
	
	$(".banner-subType").click(function() {
		var value = $(this).val();
		if (value == 7) {//form-itemList  form-itemList7
			$("#form-itemList7").addClass("show");
			$("#form-itemList7").removeClass("hidden");
			$("#form-itemList").attr("disabled",false);
			
			$("#form-progressList6").addClass("hidden");
			$("#form-progressList6").removeClass("show");
			$("#form-progressList").attr("disabled",true);
			$("#form-recruitList3").addClass("hidden");
			$("#form-recruitList3").removeClass("show");
			$("#form-recruitList").attr("disabled",true);
			$("#form-liveList5").addClass("hidden");
			$("#form-liveList5").removeClass("show");
			$("#form-liveList").attr("disabled",true);
			$("#form-longVideoList2").addClass("hidden");
			$("#form-longVideoList2").removeClass("show");
			$("#form-longVideoList").attr("disabled",true);
			$("#form-visitList4").addClass("hidden");
			$("#form-visitList4").removeClass("show");
			$("#form-visitList").attr("disabled",true);
			$("#form-url").addClass("hidden");
			$("#form-url").removeClass("show");
			$("#form-url").attr("disabled",true);
			$("#form-topicList1").addClass("hidden");
			$("#form-topicList1").removeClass("show");
			$("#form-topicList").attr("disabled",true);
		}
		if (value == 6) {
			$("#form-itemList7").addClass("hidden");
			$("#form-itemList7").removeClass("show");
			$("#form-itemList").attr("disabled",true);
			$("#form-progressList6").addClass("show");
			$("#form-progressList6").removeClass("hidden");
			$("#form-progressList").attr("disabled",false);
			$("#form-recruitList3").addClass("hidden");
			$("#form-recruitList3").removeClass("show");
			$("#form-recruitList").attr("disabled",true);
			$("#form-liveList5").addClass("hidden");
			$("#form-liveList5").removeClass("show");
			$("#form-liveList").attr("disabled",true);
			$("#form-longVideoList2").addClass("hidden");
			$("#form-longVideoList2").removeClass("show");
			$("#form-longVideoList").attr("disabled",true);
			$("#form-visitList4").addClass("hidden");
			$("#form-visitList4").removeClass("show");
			$("#form-visitList").attr("disabled",true);
			$("#form-url").addClass("hidden");
			$("#form-url").removeClass("show");
			$("#form-url").attr("disabled",true);
			$("#form-topicList1").addClass("hidden");
			$("#form-topicList1").removeClass("show");
			$("#form-topicList").attr("disabled",true);
		}
		if (value == 5) {
			$("#form-itemList7").addClass("hidden");
			$("#form-itemList7").removeClass("show");
			$("#form-itemList").attr("disabled",true);
			$("#form-progressList6").addClass("hidden");
			$("#form-progressList6").removeClass("show");
			$("#form-progressList").attr("disabled",true);
			$("#form-recruitList3").addClass("show");
			$("#form-recruitList3").removeClass("hidden");
			$("#form-recruitList").attr("disabled",false);
			$("#form-liveList5").addClass("hidden");
			$("#form-liveList5").removeClass("show");
			$("#form-liveList").attr("disabled",true);
			$("#form-longVideoList2").addClass("hidden");
			$("#form-longVideoList2").removeClass("show");
			$("#form-longVideoList").attr("disabled",true);
			$("#form-visitList4").addClass("hidden");
			$("#form-visitList4").removeClass("show");
			$("#form-visitList").attr("disabled",true);
			$("#form-url").addClass("hidden");
			$("#form-url").removeClass("show");
			$("#form-url").attr("disabled",true);
			$("#form-topicList1").addClass("hidden");
			$("#form-topicList1").removeClass("show");
			$("#form-topicList").attr("disabled",true);
		}
		if (value == 4) {
			$("#form-itemList7").addClass("hidden");
			$("#form-itemList7").removeClass("show");
			$("#form-itemList").attr("disabled",true);
			$("#form-progressList6").addClass("hidden");
			$("#form-progressList6").removeClass("show");
			$("#form-progressList").attr("disabled",true);
			$("#form-visitList4").addClass("show");
			$("#form-visitList4").removeClass("hidden");
			$("#form-visitList").attr("disabled",false);
			$("#form-liveList5").addClass("hidden");
			$("#form-liveList5").removeClass("show");
			$("#form-liveList").attr("disabled",true);
			$("#form-longVideoList2").addClass("hidden");
			$("#form-longVideoList2").removeClass("show");
			$("#form-longVideoList").attr("disabled",true);
			$("#form-recruitList3").addClass("hidden");
			$("#form-recruitList3").removeClass("show");
			$("#form-recruitList").attr("disabled",true);
			$("#form-url").addClass("hidden");
			$("#form-url").removeClass("show");
			$("#form-url").attr("disabled",true);
			$("#form-topicList1").addClass("hidden");
			$("#form-topicList1").removeClass("show");
			$("#form-topicList").attr("disabled",true);
		}
		if (value == 3) {
			$("#form-itemList7").addClass("hidden");
			$("#form-itemList7").removeClass("show");
			$("#form-itemList").attr("disabled",true);
			$("#form-progressList6").addClass("hidden");
			$("#form-progressList6").removeClass("show");
			$("#form-progressList").attr("disabled",true);
			$("#form-longVideoList2").addClass("show");
			$("#form-longVideoList2").removeClass("hidden");
			$("#form-longVideoList").attr("disabled",false);
			$("#form-liveList").addClass("hidden");
			$("#form-liveList5").removeClass("show");
			$("#form-liveList5").attr("disabled",true);
			$("#form-visitList4").addClass("hidden");
			$("#form-visitList4").removeClass("show");
			$("#form-visitList").attr("disabled",true);
			$("#form-recruitList3").addClass("hidden");
			$("#form-recruitList3").removeClass("show");
			$("#form-recruitList").attr("disabled",true);
			$("#form-url").addClass("hidden");
			$("#form-url").removeClass("show");
			$("#form-url").attr("disabled",true);
			$("#form-topicList1").addClass("hidden");
			$("#form-topicList1").removeClass("show");
			$("#form-topicList").attr("disabled",true);
		}
		if (value == 0) {
			$("#form-itemList7").addClass("hidden");
			$("#form-itemList7").removeClass("show");
			$("#form-itemList").attr("disabled",true);
			$("#form-progressList6").addClass("hidden");
			$("#form-progressList6").removeClass("show");
			$("#form-progressList").attr("disabled",true);
			$("#form-url").addClass("show");
			$("#form-url").removeClass("hidden");
			$("#form-url").attr("disabled",false);
			$("#form-liveList5").addClass("hidden");
			$("#form-liveList5").removeClass("show");
			$("#form-liveList").attr("disabled",true);
			$("#form-visitList4").addClass("hidden");
			$("#form-visitList4").removeClass("show");
			$("#form-visitList").attr("disabled",true);
			$("#form-recruitList3").addClass("hidden");
			$("#form-recruitList3").removeClass("show");
			$("#form-recruitList").attr("disabled",true);
			$("#form-longVideoList2").addClass("hidden");
			$("#form-longVideoList2").removeClass("show");
			$("#form-longVideoList").attr("disabled",true);
			$("#form-topicList1").addClass("hidden");
			$("#form-topicList1").removeClass("show");
			$("#form-topicList").attr("disabled",true);
		}
		if (value == 1) {
			$("#form-itemList7").addClass("hidden");
			$("#form-itemList7").removeClass("show");
			$("#form-itemList").attr("disabled",true);
			$("#form-progressList6").addClass("hidden");
			$("#form-progressList6").removeClass("show");
			$("#form-progressList").attr("disabled",true);
			$("#form-liveList5").addClass("show");
			$("#form-liveList5").removeClass("hidden");
			$("#form-liveList").attr("disabled",false);
			$("#form-url").addClass("hidden");
			$("#form-url").removeClass("show");
			$("#form-url").attr("disabled",true);
			$("#form-visitList4").addClass("hidden");
			$("#form-visitList4").removeClass("show");
			$("#form-visitList").attr("disabled",true);
			$("#form-recruitList3").addClass("hidden");
			$("#form-recruitList3").removeClass("show");
			$("#form-recruitList").attr("disabled",true);
			$("#form-longVideoList2").addClass("hidden");
			$("#form-longVideoList2").removeClass("show");
			$("#form-longVideoList").attr("disabled",true);
			$("#form-topicList1").addClass("hidden");
			$("#form-topicList1").removeClass("show");
			$("#form-topicList").attr("disabled",true);
		}
		if (value == 2) {
			$("#form-itemList7").addClass("hidden");
			$("#form-itemList7").removeClass("show");
			$("#form-itemList").attr("disabled",true);
			$("#form-progressList6").addClass("hidden");
			$("#form-progressList6").removeClass("show");
			$("#form-progressList").attr("disabled",true);
			$("#form-topicList1").addClass("show");
			$("#form-topicList1").removeClass("hidden");
			$("#form-topicList").attr("disabled",false);
			$("#form-url").addClass("hidden");
			$("#form-url").removeClass("show");
			$("#form-url").attr("disabled",true);
			$("#form-visitList4").addClass("hidden");
			$("#form-visitList4").removeClass("show");
			$("#form-visitList").attr("disabled",true);
			$("#form-recruitList3").addClass("hidden");
			$("#form-recruitList3").removeClass("show");
			$("#form-recruitList").attr("disabled",true);
			$("#form-longVideoList2").addClass("hidden");
			$("#form-longVideoList2").removeClass("show");
			$("#form-longVideoList").attr("disabled",true);
			$("#form-liveList5").addClass("hidden");
			$("#form-liveList5").removeClass("show");
			$("#form-liveList").attr("disabled",true);
		}
		
	});
	
	$(".banner-type").click(function() {
		var value = $(this).val();
		if (value == 8) {//动态广告
			$("#form-bannerType1").addClass("show");
			$("#form-bannerType1").removeClass("hidden");
			$("#form-bannerType").attr("disabled",false);
			$("#form-labelId").attr("disabled",false);
		}else{
			$("#form-bannerType1").addClass("hidden");
			$("#form-bannerType1").removeClass("show");
			$("#form-bannerType").attr("disabled",true);
			$("#form-labelId").attr("disabled",true);
			}
	});
	
	
});