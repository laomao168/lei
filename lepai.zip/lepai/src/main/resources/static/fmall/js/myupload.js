	 function myFunction(ele) {
			//var second =  ele.duration;
			//console.log(Math.floor(ele.duration));
			//document.write("这段视频的时长为："+hour+"小时，"+minute+"分，"+second+"秒");
			var second = Math.ceil(ele.duration);
			$("#second").val(second);
	 }  
		
		
	 	//图片上传预览    IE是用了滤镜。
        function previewImage4(file)
        {
        	var video = file.files[0];  
		    var url = URL.createObjectURL(video);  
		    console.log(url);  
		    document.getElementById("aa").src = url;  
          var MAXWIDTH  = 90; 
          var MAXHEIGHT = 90;
          var div = document.getElementById('preview4');
          if (file.files && file.files[0])
          {
              var img = document.getElementById('imghead4');
              img.onload = function(){
                var rect = clacImgZoomParam(MAXWIDTH, MAXHEIGHT, img.offsetWidth, img.offsetHeight);
                img.width  =  rect.width;
                img.height =  rect.height;
			 // img.style.marginLeft = rect.left+'px';
                img.style.marginTop = rect.top+'px';
              }
              var reader = new FileReader();
              reader.onload = function(evt){img.src = evt.target.result;}
              reader.readAsDataURL(file.files[0]);
          }
          else //兼容IE
          {
            var sFilter='filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(sizingMethod=scale,src="';
            file.select();
            var src = document.selection.createRange().text;
            div.innerHTML = '<img id=imghead>';
            var img = document.getElementById('imghead4');
            img.filters.item('DXImageTransform.Microsoft.AlphaImageLoader').src = src;
            debugger;
            var rect = clacImgZoomParam(MAXWIDTH, MAXHEIGHT, img.offsetWidth, img.offsetHeight);
            status =('rect:'+rect.top+','+rect.left+','+rect.width+','+rect.height);
            div.innerHTML = "<div id=divhead style='width:"+rect.width+"px;height:"+rect.height+"px;margin-top:"+rect.top+"px;"+sFilter+src+"\"'></div>";
          }
        }
        function clacImgZoomParam( maxWidth, maxHeight, width, height ){
            var param = {top:0, left:0, width:width, height:height};
            if( width>maxWidth || height>maxHeight ){
                rateWidth = width / maxWidth;
                rateHeight = height / maxHeight;
                
                if( rateWidth > rateHeight ){
                    param.width =  maxWidth;
                    param.height = Math.round(height / rateWidth);
                }else{
                    param.width = Math.round(width / rateHeight);
                    param.height = maxHeight;
                }
            }
            param.left = Math.round((maxWidth - param.width) / 2);
            param.top = Math.round((maxHeight - param.height) / 2);
            return param;
        }
	

  $(document).ready(function(){
	  var Qiniu_UploadUrl = "http://up.qiniu.com";
  
      $('#previewImg4').change(function(){
//          var key=$(this).val();
//          var path1 = key.lastIndexOf("\\");
//          var key = key.substring(path1+1)+"1"+(new Date()).valueOf();
    	  var key = imgRandomUtil.imgRandomName("img");
          $('#key4').val(key);
		  
		   //普通上传
          var Qiniu_upload = function(f, token, key) {
            var xhr = new XMLHttpRequest();
            xhr.open('POST', Qiniu_UploadUrl, true);
            var formData, startDate;
            formData = new FormData();
            if (key !== null && key !== undefined) formData.append('key', key);
            formData.append('token', token);
            formData.append('file', f);
            var taking;
            xhr.upload.onprogress = function (evt) {
                if (evt.lengthComputable) {
                    var percentComplete = Math.round(evt.loaded * 100 / evt.total);
                    if (percentComplete==100) {
                        document.getElementById('progress').innerHTML = "上传进度完成！正在进行保存操作，提示上传成功之前，请不要关闭和刷新页面！";
                    } else {
                        document.getElementById('progress').innerHTML = "上传进度：" + percentComplete + "%";
                    }
                  
                }
            };
            xhr.upload.addEventListener("progress", function(evt) {
                if (evt.lengthComputable) {
                    var nowDate = new Date().getTime();
                    taking = nowDate - startDate;
                    var x = (evt.loaded) / 1024;
                    var y = taking / 1000;
                    var uploadSpeed = (x / y);
                    var formatSpeed;
                    if (uploadSpeed > 1024) {
                        formatSpeed = (uploadSpeed / 1024).toFixed(2) + "Mb\/s";
                    } else {
                        formatSpeed = uploadSpeed.toFixed(2) + "Kb\/s";
                    }
                   
                }
            }, false);
 
            xhr.onreadystatechange = function(response) {
                if (xhr.readyState == 4 && xhr.status == 200 && xhr.responseText != "") {
                    var blkRet = JSON.parse(xhr.responseText);                   
                   var link = $("#accessLink").val();
                   var url = link+"/"+blkRet.key
                   $("#addressUrl").val("");
                   $("#addressUrl").val(url);
//                   alert(url);
                   alert("上传成功!");
                } else if (xhr.status != 200 && xhr.responseText) {
 
                }
            };
            startDate = new Date().getTime();        
            xhr.send(formData);
        };
        var token = $("#token").val();
        if ($("#previewImg4")[0].files.length > 0 && token != "") {
            Qiniu_upload($("#previewImg4")[0].files[0], token, $("#key4").val());
        } else {
            console && console.log("form input error");
        }
        
      });
	  
  });