$(function(){
	
	var prefix = ctx + "system/onlineClass"
	$("#form-onlineClass-add").validate({
		rules:{
			xxxx:{
				required:true,
			},
		},
		submitHandler: function(form) {
			$.operate.save(prefix + "/save", $('#form-onlineClass-add').serialize());
		}
	});
	
	$("#form-onlineClass-edit").validate({
		rules:{
			xxxx:{
				required:true,
			},
		},
		submitHandler: function(form) {
			$.operate.save(prefix + "/save", $('#form-onlineClass-edit').serialize());
		}
	});
	
	createUploader("fileurlPicker1", "fileurlList1", "url");
	
});