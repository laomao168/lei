var imgRandomUtil = imgRandomUtil || {
	
	dateTimeToString : function() {
		var now = new Date();
		var nowYear = now.getFullYear();
		var nowMonth = now.getMonth();
		var nowDate = now.getDate();
		var nowHours = now.getHours(); // 获取当前小时数(0-23)
		var nowMin = now.getMinutes(); // 获取当前分钟数(0-59)
		var nowSecond = now.getSeconds(); // 获取当前秒数(0-59)
		var milliseconds = now.getMilliseconds()
		nowMonth = imgRandomUtil.doHandleZero(nowMonth + 1);
		nowDate = imgRandomUtil.doHandleZero(nowDate);
		nowHours = imgRandomUtil.doHandleZero(nowHours);
		nowMin = imgRandomUtil.doHandleZero(nowMin);
		nowSecond = imgRandomUtil.doHandleZero(nowSecond);
        milliseconds = imgRandomUtil.doHandleZero(milliseconds);
		
		return nowYear + nowMonth + nowDate + nowHours + nowMin + nowSecond + milliseconds;
	},
	
	imgRandomName : function(type) {
		    var imgName = "";
			var dateTime = imgRandomUtil.dateTimeToString();
			var random = imgRandomUtil.generateMixed(8);
			imgName+=type+"-";
			imgName+=dateTime+"-";
			imgName+=random;
  
		    return imgName;
	},
	
	generateMixed : function (n) {
		var chars = ['0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];
	     var res = "";
	     for(var i = 0; i < n ; i ++) {
	         var id = Math.ceil(Math.random()*35);
	         res += chars[id];
	     }
	     return res;
	},
	// 如果个位数补0
	doHandleZero : function(num) {
		if (num.toString().length == 1) {
			num = "0" + num;
		}
		return num;
	},

}