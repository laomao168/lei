$(function(){
	var ue = UE.getEditor('editor', {
		initialFrameHeight : 180,
		scaleEnabled : true,
	});
	ue.ready(function() {
		//ue.execCommand('forecolor', '#FF0000'); //设置字体颜色
		ue.execCommand('fontsize', '20px');
	});
	
	createUploader("fileImagePicker", "fileImageList", "image");
	
	createUploader("fileImagePicker1", "fileImageList1", "detailImage1");
	createUploader("fileImagePicker2", "fileImageList2", "detailImage2");
	createUploader("fileImagePicker3", "fileImageList3", "detailImage3");
});