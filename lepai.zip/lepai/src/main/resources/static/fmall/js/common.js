/**
 * 通用方法封装处理
 * Copyright (c) 2019 fmall 
 */

$(function(){
	
	
	// 复选框事件绑定
	if ($.fn.select2 !== undefined) {
		$("select.form-control:not(.noselect2)").each(function () {
			$(this).select2().on("change", function () {
				$(this).valid();
			})
		})
	}
	if ($(".i-checks").length > 0) {
	    $(".i-checks").iCheck({
	        checkboxClass: "icheckbox_square-green",
	        radioClass: "iradio_square-green",
	    })
	}
	if ($(".time").length > 0) {
		layui.use('laydate', function() {
		    var laydate = layui.laydate;
		    laydate.render({ elem: '#startTime', theme: 'molv' });
		    laydate.render({ elem: '#endTime', theme: 'molv' });
		});
	}
});

/** 创建选项卡 */
function createMenuItem(dataUrl, menuName) {
    dataIndex = $.common.random(1,100),
    flag = true;
    if (dataUrl == undefined || $.trim(dataUrl).length == 0) return false;
    var topWindow = $(window.parent.document);
    // 选项卡菜单已存在
    $('.menuTab', topWindow).each(function() {
        if ($(this).data('id') == dataUrl) {
            if (!$(this).hasClass('active')) {
                $(this).addClass('active').siblings('.menuTab').removeClass('active');
                $('.page-tabs-content').animate({ marginLeft: ""}, "fast");
                // 显示tab对应的内容区
                $('.mainContent .fMall_iframe', topWindow).each(function() {
                    if ($(this).data('id') == dataUrl) {
                        $(this).show().siblings('.fMall_iframe').hide();
                        return false;
                    }
                });
            }
            flag = false;
            return false;
        }
    });
    // 选项卡菜单不存在
    if (flag) {
        var str = '<a href="javascript:;" class="active menuTab" data-id="' + dataUrl + '">' + menuName + ' <i class="fa fa-times-circle"></i></a>';
        $('.menuTab', topWindow).removeClass('active');

        // 添加选项卡对应的iframe
        var str1 = '<iframe class="fMall_iframe" name="iframe' + dataIndex + '" width="100%" height="100%" src="' + dataUrl + '" frameborder="0" data-id="' + dataUrl + '" seamless></iframe>';
        $('.mainContent', topWindow).find('iframe.fMall_iframe').hide().parents('.mainContent').append(str1);

        // 添加选项卡
        $('.menuTabs .page-tabs-content', topWindow).append(str);
    }
    return false;
}

/** 设置全局ajax超时处理 */
$.ajaxSetup({
    complete: function(XMLHttpRequest, textStatus) {
        if (textStatus == "parsererror") {
        	$.modal.confirm("登陆超时！请重新登陆！", function() {
        		window.location.href = ctx + "login";
        	})
        }
    }
}); 

/**文件上传*/


function  createUploader(pickId,fileListId,urlId){
	// 初始化Web Uploader
	var uploader = WebUploader.create({
		auto : true,
		server : '/system/file/upload',
		pick : '#' + pickId,
		timeout: 10 * 60 * 1000,
		accept : {
			title : 'Images',
			extensions : 'gif,jpg,jpeg,bmp,png,mp4,flv,mpg,mpeg,avi,rm,rmvb,mov,wmv,mkv,asf',
			mimeTypes : 'image/*'
		},
		// 配置图片的压缩选项
		compress: {
			// 图片质量，只有type为`image/jpeg`的时候才有效。
			quality: 100,
			// 是否允许放大，如果想要生成小图的时候不失真，此选项应该设置为false.
			allowMagnify: false,
			// 是否允许裁剪。
			crop: false,
			// 是否保留头部meta信息。
			preserveHeaders: true,
			// 如果发现压缩后文件大小比原来还大，则使用原来图片
			// 此属性可能会影响图片自动纠正功能
			noCompressIfLarger: false,
			// 单位字节，如果图片大小小于此值，不会采用压缩。
			compressSize: 3 *1024 * 1024
		},
		// 禁掉全局的拖拽功能。这样不会出现图片拖进页面的时候，把图片打开。
		disableGlobalDnd: true,
		fileNumLimit: 100,  // 验证文件总数量
		fileSizeLimit: 300 * 1024 * 1024,    // 300 M  验证文件总大小
		fileSingleSizeLimit: 20 * 1024 * 1024    // 20 M  验证单个文件大小
	});
	var count = 0 ;
	// 当有文件添加进来的时候
	uploader.on( 'fileQueued', function( file ) {
		count++;
		console.log(count);
		var $list=$("#"+ fileListId);
		$list.empty();
	    var $li = $(
	            '<div id="' + file.id + '" class="file-item thumbnail">' +
	                '<img>' +
	                '<div class="info">' + file.name + '</div>' +
	            '</div>'
	            ),
	    $img = $li.find('img');
	    $list.append( $li );
	    uploader.makeThumb( file, function( error, src ) {
	        if ( error ) {
	            $img.replaceWith('<span>不能预览</span>');
	            return;
	        }

	        $img.attr( 'src', src );
	    }, 100, 100);
	});
	
	// 文件上传成功，给item添加成功class, 用样式标记上传成功。
	var someUrl = "";
	uploader.on('uploadSuccess', function(file,data) {
		if(fileListId == "fileurlList"){
			$('#' + urlId).val(data.data);
		}else{
			if(count >= 1 ){
				if(someUrl == ""){ 
					someUrl = data.data;
				}else{
					someUrl += ","+ data.data;
				}
				console.log(someUrl);
				$('#someurl').val(someUrl);
			}else{
				$('#' + urlId).val(data.data);
			}
		}
	});
	
	
	// 文件上传失败，显示上传出错。
	uploader.on('uploadError', function(file,data) {
		var $li = $('#' + file.id), $error = $li.find('div.error');
		// 避免重复创建
		if (!$error.length) {
			$error = $('<div class="error"></div>').appendTo($li);
		}
		$error.text('上传失败');
	});
	
	// 完成上传完了，成功或者失败，先删除进度条。
	uploader.on('uploadComplete', function(file) {
		$.modal.msg("上传成功", modal_status.SUCCESS);
		 $( '#'+file.id ).find('.progress').remove();
	});
	
	// 文件上传过程中创建进度条实时显示
    uploader.on( 'uploadProgress', function( file, percentage ) {
//    	//$("td.file-pro").text("");
//        $li.text((percentage * 100).toFixed(2) + '%');
//    	var $list=$("#"+ fileListId);
//    	$list.empty();
//    	 var $li = $(
// 	            '<div id="' + file.id + '" class="file-item thumbnail">' +
// 	                '<img>' +
// 	                '<div class="info">' + file.name + '</div>' +
// 	            '</div>'
// 	            ),
// 	           $span = $li.find('span');
//    	 alert((percentage * 100).toFixed(2) + '%');
//    	 $span.text((percentage * 100).toFixed(2) + '%');
    	 
//    	console.log("上传进度:"+(percentage * 100).toFixed(2) + '%');
         $("#progress").text("上传进度:"+(percentage * 100).toFixed(2) + '%');
    });
	
}










