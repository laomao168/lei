$(function(){
	var prefix = ctx + "system/shortVideo";
	
	
	$("#form-shortVideo-add").validate(
			{
				rules : {
					url : {
						required : true,
					},
					addressUrl : {
						required : true,
					},
					synopsis : {
						required : true,
					},
					state : {
						required : true,
					},
					sort : {
						required : true,
					},
					subType : {
						required : true,
					},
					type : {
						required : true,
					},
					urlHigh : {
						required : true,
						digits:true
					},
					fakeCount : {
						required : true,
						digits:true
					},
					urlWide : {
						required : true,
						digits:true
					},
					clickGoodCount:{
	        			required:true,
	        			min:1,
	                    remote: {
	                        url: prefix + "/checkclickGoodHotUnique",
	                        type: "post",
	                        dataType: "json",
	                        data: {
	                        	clickGoodCount:
	                        		function () {
	                                return $.trim($("#clickGoodCount").val());
	                            },
	                        	hot:function () {
	                                return $.trim($("#hot").val());
	                            }
	                            /* name: function () {
	                                return $.trim($("#clickGoodCount").val()+","+$("#hot").val());
	                            } */
	                        },
	                        dataFilter: function (data, type) {
	                        	if (data == '"0"') return  true;
	                            else return false;
	                        }
	                    }
	        		},
	        		hot:{
	        			required:true,
	        			min:1,
	        			remote: {
	        				url: prefix + "/checkclickGoodHotUnique",
	        				type: "post",
	        				dataType: "json",
	        				data: {
	                        	clickGoodCount: function () {
	                                return $.trim($("#clickGoodCount").val());
	                            },
	                        	hot: function () {
	                                return $.trim($("#hot").val());
	                            }
	        					/* name: function () {
	        						return $.trim($("#clickGoodCount").val()+","+$("#hot").val());
	        					} */
	        				},
	        				dataFilter: function (data, type) {
	        					if (data == '"0"') return  true;
	        					else return false;
	        				}
	        			}
	        		},
				},
				messages: {
	        		"clickGoodCount":{
	                	remote: "热度和点赞数的和已经存在请重新输入"
	        		},
	        		"hot":{
	        			remote: "热度和点赞数的和已经存在请重新输入"
	        		},
	            },
				submitHandler : function(form) {
					$.operate.save(prefix + "/save",
					$('#form-shortVideo-add').serialize());
				}
			});
	
	createUploader("fileurlPicker", "fileurlList", "url");
	createUploader("fileurlPicker1", "fileurlList1", "someurl");
	
});