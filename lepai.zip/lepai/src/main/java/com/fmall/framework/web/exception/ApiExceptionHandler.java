package com.fmall.framework.web.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.fmall.common.utils.JsonResult;
@RestControllerAdvice(basePackages={"com.fmall.project.api.controller"})
public class ApiExceptionHandler {
	
	private static final Logger log = LoggerFactory.getLogger(ApiExceptionHandler.class);
	
	
	@ExceptionHandler({ HttpRequestMethodNotSupportedException.class })
	public JsonResult<?> handleException(HttpRequestMethodNotSupportedException e) {
		log.error(e.getMessage(), e);
		JsonResult<Object> result = new JsonResult();
		result.setError("请求方式不支持", "405");
		return result;
	}

	
	@ExceptionHandler(RuntimeException.class)
	public JsonResult<?> notFount(RuntimeException e) {
		log.error("运行时异常:", e);
		JsonResult<Object> result = new JsonResult();
		result.setError("请求失败，请稍后再试", "400");
		return result;
	}

	
	@ExceptionHandler(Exception.class)
	public JsonResult<?> handleException(Exception e) {
		log.error(e.getMessage(), e);
		JsonResult<Object> result = new JsonResult();
		result.setError("服务器开小差,请稍后再试", "500");
		return result;
	}
	
	
	@ExceptionHandler(MissingServletRequestParameterException.class)
	public JsonResult<?> handleMissingServletRequestParameterException(Exception e) {
		log.error(e.getMessage(), e);
		JsonResult<Object> result = new JsonResult();
		result.setError(e.getMessage(), "400");
		return result;
	}

}
