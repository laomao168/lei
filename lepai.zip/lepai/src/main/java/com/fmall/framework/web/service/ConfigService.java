package com.fmall.framework.web.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fmall.project.system.config.service.IConfigService;


@Component
public class ConfigService
{
    @Autowired
    private IConfigService configService;

    
    public String selectConfigByKey(String configKey)
    {
        return configService.selectConfigByKey(configKey);
    }

}
