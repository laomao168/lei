package com.fmall.framework.config;

import com.alibaba.fastjson.serializer.ValueFilter;

public class BigDecimalValueFilter implements ValueFilter{

	@Override
	public Object process(Object object, String name, Object value) {






		return value;
	}
}
