package com.fmall.framework.web.page;

import java.io.Serializable;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.github.pagehelper.PageInfo;


public class TableDataInfo implements Serializable {
	
	private static  Logger logger = LoggerFactory.getLogger(TableDataInfo.class);
	
	 
	private static final long serialVersionUID = 1L;
	
	private long total;
	
    private int pageNum;
    
    private int pageSize;
    
    private int pages;
    
    private boolean isLastPage = false;
	
	
	private List<?> rows;

	
	public TableDataInfo() {
	}

	
	
	public int getPageNum() {
		return pageNum;
	}



	public void setPageNum(int pageNum) {
		this.pageNum = pageNum;
	}



	public int getPageSize() {
		return pageSize;
	}



	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}



	public int getPages() {
		return pages;
	}



	public void setPages(int pages) {
		this.pages = pages;
	}



	public boolean isLastPage() {
		return isLastPage;
	}



	public void setLastPage(boolean isLastPage) {
		this.isLastPage = isLastPage;
	}



	
	public TableDataInfo(List<?> list, int total) {
		this.rows = list;
		this.total = total;
	}

	public long getTotal() {
		return total;
	}

	public void setTotal(long total) {
		this.total = total;
	}

	public List<?> getRows() {
		return rows;
	}

	public void setRows(List<?> rows) {
		this.rows = rows;
	}
	
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static TableDataInfo getDataTable(List<?> list) {
		TableDataInfo rspData = new TableDataInfo();
		PageInfo info = new PageInfo<>(list);
		rspData.setRows(list);
		rspData.setTotal(info.getTotal());
		rspData.setLastPage(info.isIsLastPage());
		rspData.setPageNum(info.getPageNum());
		rspData.setPages(info.getPages());
		rspData.setPageSize(info.getPageSize());
		return rspData;
	}

}
