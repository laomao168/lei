package com.fmall.framework.redis;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.apache.shiro.util.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.connection.RedisStringCommands;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import com.fmall.common.utils.StringUtil;
import com.fmall.common.utils.StringUtils;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;

@Component
public class RedisUtil {


    private final static Logger logger = LoggerFactory.getLogger(RedisUtil.class);
    
    private static final String LOCK_PREFIX = "LOCK_PREFIX:";
    
    private static ThreadLocal<String> TOKEN_MAP = new ThreadLocal<>();

    
    private static final long FOREVER = Long.MAX_VALUE;

    private static final String METHOD_DESC = "Redis分布式锁";

    @Autowired
    RedisTemplate<String, Object> redisTemplate;

    
    private static String IP;

    static {
        try {
            IP = InetAddress.getLocalHost().getHostAddress();
        } catch (UnknownHostException e) {
            logger.error("分布式Redis锁，获取IP异常", e);
            IP = "UNKNOWN_HOST";
        }
    }

    
    public Boolean setnx(final String key, final String value) {
        return redisTemplate.execute(new RedisCallback<Boolean>() {
            @Override
            public Boolean doInRedis(RedisConnection redisConnection) throws DataAccessException {
                byte keys[] = redisTemplate.getStringSerializer().serialize(key);
                byte values[] = redisTemplate.getStringSerializer().serialize(value);
                return redisConnection.setNX(keys, values);
            }
        });
    }


    
    public boolean getLock(String lockKey, Object requestId, int expireTime) {
        Boolean success = redisTemplate.opsForValue().setIfAbsent(lockKey, requestId);
        if (success) {
            redisTemplate.expire(lockKey, expireTime, TimeUnit.SECONDS);
            return true;
        }
        return false;
    }


    
    public boolean releaseLock(String lockKey, Long requestId) {
        Object value = redisTemplate.opsForValue().get(lockKey);
        if (Objects.nonNull(value) && Long.valueOf(value.toString()).equals(requestId)) {
            redisTemplate.delete(lockKey);
            return true;
        }
        return false;
    }


    
    public Void setex(final String key, final Long timeout, final String value) {
        return redisTemplate.execute(new RedisCallback<Void>() {
            @Override
            public Void doInRedis(RedisConnection redisConnection) throws DataAccessException {
                byte keys[] = redisTemplate.getStringSerializer().serialize(key);
                byte values[] = redisTemplate.getStringSerializer().serialize(value);
                redisConnection.setEx(keys, timeout, values);
                return null;
            }
        });
    }

    

    
    public boolean expire(String key, long time) {
        try {
            if (time > 0) {
                redisTemplate.expire(key, time, TimeUnit.SECONDS);
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    
    public long getExpire(String key) {
        return redisTemplate.getExpire(key, TimeUnit.SECONDS);
    }

    
    public boolean hasKey(String key) {
        return redisTemplate.hasKey(key);
    }

    
    public void del(String... key) {
        if (key != null && key.length > 0) {
            if (key.length == 1) {
                redisTemplate.delete(key[0]);
            } else {
                redisTemplate.delete(CollectionUtils.asList(key));
            }
        }
    }

    

    
    public String get(String key) {
        return Objects.isNull(key) ? null : StringUtil.safeValueOf(redisTemplate.opsForValue().get(key));
    }

    
    public <T> T get(String key, Class<T> clazz) {
        return key == null ? null : (T) redisTemplate.opsForValue().get(key);
    }

    
    public void set(String key, Object value) {
        redisTemplate.opsForValue().set(key, value);

    }

    
    public void set(String key, Object value, long time) {
        if (time > 0) {
            redisTemplate.opsForValue().set(key, value, time, TimeUnit.SECONDS);
        } else {
            set(key, value);
        }
    }

    
    public long incr(String key, long delta) {
        if (delta < 0) {
            throw new RuntimeException("递增因子必须大于0");
        }
        return redisTemplate.opsForValue().increment(key, delta);
    }

    
    public long decr(String key, long delta) {
        if (delta < 0) {
            throw new RuntimeException("递减因子必须大于0");
        }
        return redisTemplate.opsForValue().increment(key, -delta);
    }

    

    
    public Object hget(String key, String item) {
        return redisTemplate.opsForHash().get(key, item);
    }

    
    public Map<Object, Object> hmget(String key) {
        return redisTemplate.opsForHash().entries(key);
    }

    
    public boolean hmset(String key, Map<String, Object> map) {
        try {
            redisTemplate.opsForHash().putAll(key, map);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    
    public boolean hmset(String key, Map<String, Object> map, long time) {
        try {
            redisTemplate.opsForHash().putAll(key, map);
            if (time > 0) {
                expire(key, time);
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    
    public boolean hset(String key, String item, Object value) {
        try {
            redisTemplate.opsForHash().put(key, item, value);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    
    public boolean hset(String key, String item, Object value, long time) {
        try {
            redisTemplate.opsForHash().put(key, item, value);
            if (time > 0) {
                expire(key, time);
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    
    public void hdel(String key, Object... item) {
        redisTemplate.opsForHash().delete(key, item);
    }

    
    public boolean hHasKey(String key, String item) {
        return redisTemplate.opsForHash().hasKey(key, item);
    }

    
    public double hincr(String key, String item, double by) {
        return redisTemplate.opsForHash().increment(key, item, by);
    }

    
    public double hdecr(String key, String item, double by) {
        return redisTemplate.opsForHash().increment(key, item, -by);
    }

    

    
    public Set<Object> sGet(String key) {
        try {
            return redisTemplate.opsForSet().members(key);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    
    public boolean sHasKey(String key, Object value) {
        try {
            return redisTemplate.opsForSet().isMember(key, value);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    
    public long sSet(String key, Object... values) {
        try {
            return redisTemplate.opsForSet().add(key, values);
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    
    public Boolean setbit(String key, long offset, boolean value) {
        try {
            return redisTemplate.opsForValue().setBit(key, offset, value);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    
    public Long bitOp(RedisStringCommands.BitOperation op, byte[] destination, byte[]... keys) {
        try {
            Long i = redisTemplate.execute((RedisCallback<Long>) con -> con.bitOp(op, destination, keys));
            return i;
        } catch (Exception e) {
            e.printStackTrace();
            return 0L;
        }
    }

    
    public Long bitCount(byte[] key) {
        try {
            return redisTemplate.execute((RedisCallback<Long>) con -> con.bitCount(key));
        } catch (Exception e) {
            e.printStackTrace();
            return 0L;
        }
    }

    
    public void convertAndSend(String key, Object values) {
        try {
            redisTemplate.convertAndSend(key, values);
        } catch (Exception e) {
            e.printStackTrace();

        }
    }

    
    public long sSetAndTime(String key, long time, Object... values) {
        try {
            Long count = redisTemplate.opsForSet().add(key, values);
            if (time > 0)
                expire(key, time);
            return count;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    
    public long sGetSetSize(String key) {
        try {
            return redisTemplate.opsForSet().size(key);
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }


    
    public long setRemove(String key, Object... values) {
        try {
            Long count = redisTemplate.opsForSet().remove(key, values);
            return count;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
    

    
    public <T> List<T> lGet(String key, long start, long end) {
        return (List<T>) redisTemplate.opsForList().range(key, start, end);
    }

    
    public <T> Page<T> lGetPageList(String key, int pageNum, int pageSize) {
        long total = lGetListSize(key);
        if (Objects.isNull(total) || total <= 0) {
            return null;
        }
        long start = (pageNum - 1) * pageSize;
        long end = start + pageSize - 1;
        if (end >= total) {
            end = total - 1;
        }
        Page page = new Page<>(pageNum, pageSize);
        page.setTotal(total);
        List<T> list = (List<T>) lGet(key, start, end);
        if (Objects.isNull(list) || list.isEmpty()) {
            return null;
        }
        page.addAll(list);
        return page;

    }

    
    public <T> List<T> lGetNewPageList(String key, int pageNum, int pageSize) {
        long total = lGetListSize(key);
        if (Objects.isNull(total) || total <= 0) {
            return null;
        }
        long start = (pageNum - 1) * pageSize;
        long end = start + pageSize - 1;
        if (end >= total) {
            end = total - 1;
        }
        List<T> list = (List<T>) lGet(key, start, end);
        return list;
    }

    
    public <T> Map<String, Object> lGetNewPage(String key, com.fmall.common.page.Page page) {
        Long total = lGetListSize(key);
        Map<String, Object> map = new HashMap<>();
        List<T> list = new ArrayList<>();
        if (Objects.isNull(total) || total <= 0) {
            map.put("page", page);
            map.put("data", list);
        }
        long start = (page.getPageNumber() - 1) * page.getPageSize();
        long end = start + page.getPageSize() - 1;
        if (end >= total) {
            end = total - 1;
        }
        page.setTotalResult(Integer.valueOf(total.toString()));
        list = lGetNewPageList(key, page.getPageNumber(), page.getPageSize());
        map.put("page", page);
        map.put("data", list);
        return map;
    }

    
    public <T> Page<T> lGetPageList(String key) {
        com.github.pagehelper.Page<?> page = PageHelper.getLocalPage();
        int pageNum = page.getPageNum();
        int pageSize = page.getPageSize();
        return lGetPageList(key, pageNum, pageSize);
    }

    
    public Long lGetListSize(String key) {
        return redisTemplate.opsForList().size(key);
    }

    
    public Object lGetIndex(String key, long index) {
        try {
            return redisTemplate.opsForList().index(key, index);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    
    public boolean lSet(String key, Object value) {
        try {
            redisTemplate.opsForList().rightPush(key, value);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    
    public boolean lleftPush(String key, Object value) {
        try {

            redisTemplate.opsForList().leftPush(key, value);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    
    

    
    public <T> boolean lSet(String key, List<T> value) {
        try {
            redisTemplate.opsForList().rightPushAll(key, value.toArray());
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    
    public <T> boolean lDelSet(String key, List<T> value) {
        try {
            redisTemplate.delete(key);
            redisTemplate.opsForList().rightPushAll(key, value.toArray());
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    
    public boolean lSet(String key, List<Object> value, long time) {
        try {
            redisTemplate.opsForList().rightPushAll(key, value.toArray());
            if (time > 0) {
                expire(key, time);
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    
    public boolean lUpdateIndex(String key, long index, Object value) {
        try {
            redisTemplate.opsForList().set(key, index, value);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    
    public long lRemove(String key, long count, Object value) {
        try {
            Long remove = redisTemplate.opsForList().remove(key, count, value);
            return remove;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    
    public boolean zsetAdd(String key, Object value, double score) {
        return redisTemplate.opsForZSet().add(key, value, score);
    }

    
    public <T> Set<T> zsetRange(String key, long start, long end) {
        return (Set<T>) redisTemplate.opsForZSet().range(key, start, end);

    }

    
    public <T> Set<T> zsetRange(String key) {
        return zsetRange(key, 0, -1);

    }

    
    public <T> List<T> zsetRangeToList(String key) {
        List<T> list = new ArrayList<>();
        list.addAll(zsetRange(key, 0, -1));
        return list;

    }

    
    public <T> Set<T> zsetPageRange(String key, Integer pageNum, Integer pageSize) {
        long total = redisTemplate.opsForZSet().zCard(key);
        if (Objects.isNull(total) || total <= 0) {
            return null;
        }
        long start = (pageNum - 1) * pageSize;
        long end = start + pageSize - 1;
        if (end >= total) {
            end = total - 1;
        }
        return (Set<T>) redisTemplate.opsForZSet().range(key, start, end);
    }

    
    public <T> Map<String, Object> zsetPageRange(String key, com.fmall.common.page.Page page) {
        Long total = redisTemplate.opsForZSet().zCard(key);
        Map<String, Object> map = new HashMap<>();
        List<T> list = new ArrayList<>();
        if (Objects.isNull(total) || total <= 0) {
            map.put("page", page);
            map.put("data", list);
        }
        long start = (page.getPageNumber() - 1) * page.getPageSize();
        long end = start + page.getPageSize() - 1;
        if (end >= total) {
            end = total - 1;
        }
        page.setTotalResult(Integer.valueOf(total.toString()));
        Set<T> sets = zsetPageRange(key, page.getPageNumber(), page.getPageSize());
        if (StringUtils.isNotEmpty(sets)) {
            list.addAll(sets);
        }
        map.put("page", page);
        map.put("data", list);
        return map;
    }

    public <T> Set<T> zsetRange(String key, int one, int two, int three, int four) {
        return (Set<T>) redisTemplate.opsForZSet().rangeByScore(key, one, two, three, four);

    }

    
    public Long zsetCount(String key) {
        return redisTemplate.opsForZSet().zCard(key);
    }

    
    public Long zsetCount2(String key) {
        return redisTemplate.opsForZSet().zCard(key);
    }

    
    public Long removeRangeByScore(String key, double min, double max) {
        return redisTemplate.opsForZSet().removeRangeByScore(key, min, max);
    }

    
    public Long removeRangeByScore(String key, double score) {
        return removeRangeByScore(key, score, score);
    }

    
    public Long removeRangeByScore(String key) {
        return redisTemplate.opsForZSet().removeRange(key, 0, -1);
    }

    public static String formatToken(String token) {
        return RedisKeyConstant.REDIS_TOKEN_PREFIX.concat(token);
    }


    
    public <T> T zrangeByScore(String key, double score) {
        Set<Object> sets = redisTemplate.opsForZSet().rangeByScore(key, score, score);
        List<Object> list = new ArrayList<>(sets);
        return list.size() > 0 ? (T) list.get(0) : null;
    }

    
    public <T> boolean rSet(String key, List<T> value) {
        try {
            redisTemplate.opsForList().leftPushAll(key, value.toArray());
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    public Set<String> keys(String countWxKey) {
        return redisTemplate.keys(countWxKey);
    }

    
    public void unlock(String key) {
        try {
            redisTemplate.opsForValue().getOperations().delete(key);
        } catch (Exception e) {
            logger.error("【redis分布式锁】解锁异常, {}", e);
        }
    }

    
    public boolean lock(String key, String value, Long expireTime) {
        
        if (redisTemplate.opsForValue().setIfAbsent(key, value, expireTime, TimeUnit.SECONDS)) {
            return true;
        }
        return false;
    }

    
    private boolean getLock(String key, long expireSecs) {
        
        
        return redisTemplate.opsForValue().setIfAbsent(keyOf(key), getToken(), expireSecs, TimeUnit.SECONDS);
        
    }

    
    private String getLockToken(String key) {
        return (String) redisTemplate.opsForValue().get(keyOf(key));
    }

    
    private void releaseLock(String key) {
        redisTemplate.opsForValue().getOperations().delete(keyOf(key));
    }

    
    private String keyOf(String key) {
        return LOCK_PREFIX + key;
    }

    private String getToken() {
        String threadToken = TOKEN_MAP.get();
        if (null == threadToken || threadToken.length() < 1) {
            TOKEN_MAP.set(threadToken = IP + "_" + UUID.randomUUID().toString().replaceAll("-", ""));
        }
        return threadToken;
    }

    private boolean tryLock(String key, long time, TimeUnit unit, long expireSecs) {
        if (tryLock(key, expireSecs)) {
            logger.debug(METHOD_DESC + ",直接tryLock成功|key={}|token={}", key, getToken());
            return true;
        }
        boolean held = false;
        long start = System.nanoTime();

        
        while (!held && (System.nanoTime() - start) < unit.toNanos(time)) {
            held = getLock(key, expireSecs);
        }
        if (!held) {
            logger.debug(METHOD_DESC + ",tryLock超时|key={}|token={}", key, getToken());
        } else {
            logger.debug(METHOD_DESC + ",自旋tryLock成功|key={}|token={}", key, getToken());
        }
        return held;
    }


    private boolean tryLock(String key, long expireSecs) {
        
        if (getLock(key, expireSecs)) {
            return true;
        }
        
        return getToken().equals(getLockToken(key));
    }

    public void reLock(String key, long expireSecs) {
        reLock(key,FOREVER,expireSecs);

    }

    public void reLock(String key, long time,long expireSecs) {
        tryLock(key, time, TimeUnit.SECONDS, expireSecs);
    }



    public void reUnLock(String key) {
        releaseLock(key);
        TOKEN_MAP.remove();
        logger.debug(METHOD_DESC + ",释放锁成功|key={}|token={}", key, getToken());
    }
}
