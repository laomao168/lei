package com.fmall.framework.web.exception;

import org.apache.shiro.authz.AuthorizationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.fmall.common.exception.DemoModeException;
import com.fmall.framework.web.domain.AjaxResult;


@RestControllerAdvice(basePackages={"com.fmall.project.common"
			,"com.fmall.project.monitor"
			,"com.fmall.project.system"
			,"com.fmall.project.tool"
})
public class DefaultExceptionHandler {
	private static final Logger log = LoggerFactory.getLogger(DefaultExceptionHandler.class);

	
	@ExceptionHandler(AuthorizationException.class)
	public AjaxResult handleAuthorizationException(AuthorizationException e) {
		log.error(e.getMessage(), e);
		return AjaxResult.error("您没有数据的权限，请联系管理员添加");
	}

	
	@ExceptionHandler({ HttpRequestMethodNotSupportedException.class })
	public AjaxResult handleException(HttpRequestMethodNotSupportedException e) {
		log.error(e.getMessage(), e);
		return AjaxResult.error("不支持' " + e.getMethod() + "'请求");
	}

	
	@ExceptionHandler(RuntimeException.class)
	public AjaxResult notFount(RuntimeException e) {
		log.error("运行时异常:", e);
		return AjaxResult.error("运行时异常:" + e.getMessage());
	}

	
	@ExceptionHandler(Exception.class)
	public AjaxResult handleException(Exception e) {
		log.error(e.getMessage(), e);
		return AjaxResult.error("服务器错误，请联系管理员");
	}

	
	@ExceptionHandler(DemoModeException.class)
	public AjaxResult demoModeException(DemoModeException e) {
		return AjaxResult.error("演示模式，不允许操作");
	}

}
