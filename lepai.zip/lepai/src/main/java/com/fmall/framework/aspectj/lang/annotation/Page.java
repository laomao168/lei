package com.fmall.framework.aspectj.lang.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface Page {
	
	int pageNum() default 1;
	int pageSize() default 10;
	String orderByColumn() default "createdate";
	String isAsc() default "desc";

}
