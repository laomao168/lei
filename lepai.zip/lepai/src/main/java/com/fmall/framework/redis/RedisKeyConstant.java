package com.fmall.framework.redis;


public class RedisKeyConstant {
	
	
		public final static String maohao = ":";
		public final static String USER_OBJ="user:id:";
		public final static String REDIS_TOKEN_PREFIX = "AUTHORIZATION:TOKEN:";
		
		public static final String SMS_PHONE_ = "SMS:PHONE:";
		
		public final static int DEFAULT_EXPIRED_TIME = 60;
		public final static int DAY = 86400;
		
		public final static int HOUR = 3600;

		public final static int MON = 2592000;
		
		public static String key = "lepai";
		
		public static final String USER_APP_TOKEN = "USER:TOKEN:";
		
		public static final String TASK_CONFIG_LIST = "TASK_CONFIG_LIST";
	
	
    public final static String DEFAULT_TOKEN_HEADER_NAME =  "Authorization";

    
    public final  static  String  SMS_UPPER_LIMIT = "sms_upper_limit:";

    
    public final  static  String  IS_NEW_PEOPLE = "sign:is_new_people:";

    
    public final static String BIZ_CODE_VALUE = "delayed:biz_code_value:";
    
    public final static String TRY_COUNT = "delayed:try_count:";
    
    public final static String LOCK = "delayed:lock:";

    
    public final  static  String  XCX_QRCODE_URL = "xcx_qrcode_url:";

    
    public final static String MEMBER = "member:info:";
    
    public final static String MEMBER_BLACKLIST = "member:blacklist:";
    
    public final static String MEMBER_INHIBITED = "member:inhibited:";

    
    public final static String MEMBER_ACCOUNT = "member:account:";
    
    public final static String GOODS_AUTO_OPEN = "goods:auto:open:";
    
    public final static String GOODS_AUTO_CLOSE = "goods:auto:close:";
    
    public final static String ORDER_AUTO_CLOSE = "order:auto:close:";
    
    public final static String ORDER_AUTO_SMS = "order:auto:sms:";

    
    public final static String MEMBER_WITHDRAW_NOT_COMPLETE = "member:withdraw:not:complete:";

    
    public final static String  MEMBER_REALPERSON = "member:realPerson:";
    
    public final static String  MEMBER_REALPERSON_LOCK = "member:realPerson:lock:";
    
    public final static String  MEMBER_REALPERSON_TIMES = "member:realPerson:times:";

    
    public final static String MEMBER_INTEGRAL_CHANGE_LOCK = "member:integral:change:lock:";
    
    public final static String MEMBER_WITHDRAW_ADD_LOCK = "member:withdraw:add:lock:";
    
    public final static String MEMBER_WITHDRAW_AUDIT_LOCK = "member:withdraw:audit:lock:";

    
    public final static String PARTNER_WITHDRAW_ADD_LOCK = "partner:withdraw:add:lock:";
    
    public final static String PARTNER_WITHDRAW_AUDIT_LOCK = "partner:withdraw:audit:lock:";

    
    public final static String PARTNER_WITHDRAW_SUM = "partner:withdraw:sum:";
    
    public final static String MEMBER_WITHDRAW_SUM = "member:withdraw:sum:";
    
    public final static String GOODS_MARKUP_RULE = "goods:markupRule:";
    
    public final static String AUCTION_SCHEDULED = "auction:scheduled:";
    
    public final static String MEMBER_AMOUNT_CHANGE_LOCK = "member:amount:change:lock:";
    
    public final static String MEMBER_ROBOT_LIST = "member:robot:list";

    
    public final static String MEMBER_PARTNER = "member:partner:";

    
    
    public final static String AUCTION_INFO_LOCK = "auction:info:lock:";

    
    public final static String AUCTION_INFO_LOCK_ROBOT = "auction:info:lock:robot:";

    
    public final static String AUCTION_INFO_INFO = "auction:info:info:";
    
    public final static String AUCTION_HOURTIME_AUCTIONLIST = "auction:hourTime:auctionList:";
    
    public final static String AUCTION_INFO_WX = "auction:info:wx:";

    
    public final static String AUCTION_MARKUP_COUNT = "auction:markup:count:";

    
    public final static String AUCTION_MARKUP_DETAIL = "auction:markup:detail:";

    
    public final static String AUCTION_MARKUP_DETAIL_LIST = "auction:markup:detailList:";

    
    public final static String AUCTION_MEMBER_DETAIL_LIST = "auction:member:detailList:";

    
    public final static String AUCTION_MARKUP_TOP = "auction:markup:top:";
    
    public final static String AUCTION_ROBOT_MARKUP = "auction:robot:markup:";
    public final static String TEST_AUCTION_ROBOT_MARKUP = "test:auction:robot:markup:";
    
    public final static String AUCTION_SUCCESS_USER = "auction:success:user:";
    
    public final static String GOODS_LOCK_KEY = "goods:lock:key";

    
    public final static String AUCTION_MARKUP_PAY= "auction:markup:pay:";
    
    
    public final static String AUCTION_INFO_VIEWCOUNT = "auction:info:viewCount:";

    


    
    public final static String WEBSOCKET_SESSION = "websocket_session";


    
    public final static String AUCTION_ADD_PRICE= "auction:add:price:";
    
    public final static String AUCTION_ADD_NEXT_PRICE= "auction:add:next:price:";

    
    public final static String CATEGORY_ALL_LIST= "category:all:list:";
    
    public final static String CATEGORY_ID= "category:id:";
    
    public final static String BANNER_POSITION_LIST= "banner:position:list:";

    

    
    public final static String COUNT_BIDSNUM = "count:bidsnum";

    
    public final static String COUNT_SCENENUM = "count:scenenum";

    
    public final static String COUNT_REALTIME = "count:realtime";
    
    
    public final static String MALL_CONTRACTNO_ORDER = "mall:contractNo:order:";

    
    public final static String  MEMBER_REALPERSON_INFO = "member:realPerson:info:";
    
    
    
    public final static String repor_today_visitor= "repor:today:visitor:";
    public final static String todayDayCount= "todayDayCount";
    public final static String yesterdayDayCount= "yesterdayDayCount";
    public final static String sevenDayCount= "sevenDayCount";

}
