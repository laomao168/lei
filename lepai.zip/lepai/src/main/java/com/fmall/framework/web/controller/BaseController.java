package com.fmall.framework.web.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;

import com.fmall.common.utils.StringUtils;
import com.fmall.common.utils.security.ShiroUtils;
import com.fmall.framework.web.domain.AjaxResult;
import com.fmall.framework.web.page.PageDomain;
import com.fmall.framework.web.page.TableDataInfo;
import com.fmall.framework.web.page.TableSupport;
import com.fmall.project.system.user.domain.User;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;


public class BaseController {
	
	 public Logger logger = LoggerFactory.getLogger(getClass());
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		dateFormat.setLenient(false);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}

	
	protected void startPage() {
		PageDomain pageDomain = TableSupport.buildPageRequest();
		Integer pageNum = pageDomain.getPageNum();
		Integer pageSize = pageDomain.getPageSize();
		if (StringUtils.isNotNull(pageNum) && StringUtils.isNotNull(pageSize)) {
			String orderBy = pageDomain.getOrderBy();
			PageHelper.startPage(pageNum, pageSize, orderBy);
		}
	}

	
	@SuppressWarnings({ "rawtypes" })
	protected TableDataInfo getDataTable(List<?> list) {
		TableDataInfo rspData = new TableDataInfo();
		PageInfo info = new PageInfo<>(list);
		rspData.setRows(list);
		rspData.setTotal(info.getTotal());
		rspData.setLastPage(info.isIsLastPage());
		rspData.setPageNum(info.getPageNum());
		rspData.setPages(info.getPages());
		rspData.setPageSize(info.getPageSize());
		return rspData;
	}

	
	public AjaxResult success() {
		return AjaxResult.success();
	}

	
	public AjaxResult error() {
		return AjaxResult.error();
	}

	
	public AjaxResult success(String message) {
		return AjaxResult.success(message);
	}

	
	public AjaxResult error(String message) {
		return AjaxResult.error(message);
	}

	
	public AjaxResult error(int code, String message) {
		return AjaxResult.error(code, message);
	}

	
	public String redirect(String url) {
		return StringUtils.format("redirect:{}", url);
	}

	public User getUser() {
		return ShiroUtils.getUser();
	}

	public void setUser(User user) {
		ShiroUtils.setUser(user);
	}

	public Long getUserId() {
		return getUser().getUserId();
	}

	public String getLoginName() {
		return getUser().getLoginName();
	}
}
