package com.fmall.framework.config;

import java.io.UnsupportedEncodingException;
import java.util.Objects;

import com.alibaba.fastjson.serializer.ValueFilter;
import com.fmall.common.utils.EmojiUtils;

public class EmojiValueFilter implements ValueFilter{

	@Override
	public Object process(Object object, String name, Object value) {
		if(value instanceof String && name.equals("content")){
			if(Objects.nonNull(value)){
				try {
					value = EmojiUtils.utfemojiRecovery(value.toString());
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				}
			}
		}
		return value;
	}
}
