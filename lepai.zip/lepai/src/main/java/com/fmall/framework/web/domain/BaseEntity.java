package com.fmall.framework.web.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fmall.common.page.Page;
import io.swagger.annotations.ApiModelProperty;


public class BaseEntity<T> implements Serializable {
	private static final long serialVersionUID = 1L;

	
	@ApiModelProperty(value = "搜索值 ",hidden = true)
	private String searchValue;

	
	@ApiModelProperty(value = "创建者",hidden = true)
	private String createBy;

	
	@ApiModelProperty(value = "创建时间",hidden = true)
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createTime;

	
	@ApiModelProperty(value = "更新者",hidden = true)
	private String updateBy;

	
	@ApiModelProperty(value = "更新时间",hidden = true)
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date updateTime;
	
	
	@ApiModelProperty(value = "是否删除",hidden = true)
	private Integer deleted;
	@ApiModelProperty(value = "startTime",hidden = true)
	private Date startTime ;
	@ApiModelProperty(value = "endTime",hidden = true)
	private Date endTime;
	
	@ApiModelProperty(value = "备注",hidden = true)
	private String remark;
	@ApiModelProperty(value = "orderField",hidden = true)
	private String orderField="";
	@ApiModelProperty(value = "desc",hidden = true)
	private String desc="desc";
	@ApiModelProperty(value = "设备",notes = "设备：android  ios",hidden = true)
	private String deviceType;   
	@ApiModelProperty(value = "设备号",notes = "设备号",hidden = true)
	private String deviceCode;   
	@ApiModelProperty(value = "orderField",hidden = true)
	private String channelId;

	@ApiModelProperty(value = "orderField",hidden = true)
	private boolean clicked;
	@ApiModelProperty(value = "orderField",hidden = true)
	private boolean applyed;

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	private Page page = new Page(1, 10);
	
	
	
	
	

	public boolean isApplyed() {
		return applyed;
	}

	public void setApplyed(boolean applyed) {
		this.applyed = applyed;
	}

	public boolean isClicked() {
		return clicked;
	}

	public void setClicked(boolean clicked) {
		this.clicked = clicked;
	}

	public String getOrderField() {
		return orderField;
	}

	public void setOrderField(String orderField) {
		this.orderField = orderField;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public Page getPage() {
		return  page;
	}

	public void setPage(Page page) {
		this.page = page;
	}

	
	@ApiModelProperty(value = "请求参数",hidden = true)
	private Map<String, Object> params;

	public String getSearchValue() {
		return searchValue;
	}

	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;
	}

	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Map<String, Object> getParams() {
		return params;
	}

	public void setParams(Map<String, Object> params) {
		this.params = params;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public String getDeviceCode() {
		return deviceCode;
	}

	public void setDeviceCode(String deviceCode) {
		this.deviceCode = deviceCode;
	}

	public String getChannelId() {
		return channelId;
	}

	public Integer getDeleted() {
		return deleted;
	}

	public void setDeleted(Integer deleted) {
		this.deleted = deleted;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

}
