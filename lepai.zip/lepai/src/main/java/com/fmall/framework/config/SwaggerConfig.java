package com.fmall.framework.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;


@Configuration
@EnableSwagger2
public class SwaggerConfig
{
    
    @Autowired
    private FMallConfig fMallConfig;

    
    @Bean
    public Docket createRestApi()
    {
        return new Docket(DocumentationType.SWAGGER_2)
                
                .apiInfo(apiInfo())
                .select()
                
                .apis(RequestHandlerSelectors.basePackage("com.fmall.project.api.controller"))
                
                .paths(PathSelectors.any())
                .build();
    }

    
    private ApiInfo apiInfo()
    {
        
        return new ApiInfoBuilder()
                .title("标题：接口文档")
                .description("描述：接口文档")
                .contact(new Contact(fMallConfig.getName(), null, null))
                .version("版本号:" + fMallConfig.getVersion())
                .build();
    }
}
