package com.fmall.framework.web.page;

import com.fmall.common.constant.Constants;
import com.fmall.common.utils.ServletUtils;
import com.fmall.common.utils.StringUtils;
import com.github.pagehelper.PageHelper;


public class TableSupport {
	
	public static PageDomain getPageDomain() {
		PageDomain pageDomain = new PageDomain();
		pageDomain.setPageNum(ServletUtils.getParameterToInt(Constants.PAGENUM));
		pageDomain.setPageSize(ServletUtils.getParameterToInt(Constants.PAGESIZE));
		pageDomain.setOrderByColumn(ServletUtils.getParameter(Constants.ORDERBYCOLUMN));
		pageDomain.setIsAsc(ServletUtils.getParameter(Constants.ISASC));
		return pageDomain;
	}

	public static PageDomain buildPageRequest() {
		return getPageDomain();
	}
	

}
