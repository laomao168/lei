package com.fmall.framework.config;

import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.alibaba.fastjson.serializer.SerializerFeature;
import com.alibaba.fastjson.support.config.FastJsonConfig;
import com.alibaba.fastjson.support.spring.FastJsonHttpMessageConverter;

@Configuration
@ConditionalOnClass({FastJsonHttpMessageConverter.class}) 
@ConditionalOnProperty(
        name = {"spring.http.converters.preferred-json-mapper"},
        havingValue = "fastjson", 
        matchIfMissing = true
)
public class FastJson2HttpMessageConverterConfiguration {

	@Bean
	public  FastJsonHttpMessageConverter  fastJsonHttpMessageConverter() {
		
		FastJsonHttpMessageConverter converter = new FastJsonHttpMessageConverter();
		FastJsonConfig  config = converter.getFastJsonConfig();
	    config.setSerializerFeatures(SerializerFeature.WriteBigDecimalAsPlain,SerializerFeature.WriteMapNullValue,SerializerFeature.WriteNullListAsEmpty,SerializerFeature.WriteNullStringAsEmpty);
		config.setSerializeFilters(new BigDecimalValueFilter());
		
		config.setDateFormat("yyyy-MM-dd HH:mm:ss");
		converter.setFastJsonConfig(config);
		return converter;
	}
}
