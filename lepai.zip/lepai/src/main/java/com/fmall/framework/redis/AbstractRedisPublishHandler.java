package com.fmall.framework.redis;

import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;


@Component
public abstract  class AbstractRedisPublishHandler<T> implements  RedisPublishHandler<T>{

    private Logger logger = LoggerFactory.getLogger(getClass());

    @Resource
    private RedisTemplate<String, Object> redisTemplate;

    @Autowired
    private RedisUtil redisUtil;


    @Override
    public void handler(String key) {
        if (support(key)) {
            doHandler(key);
        }
    }

    
    protected void doHandler(String key){
        
        
        
        if(!redisUtil.lock(RedisKeyConstant.LOCK.concat(key).concat(key),key,3L) ){
            logger.info("已经进行了处理，并发不做处理");
            return;
        }
       
        redisTemplate.delete(RedisKeyConstant.LOCK.concat(key));
        System.out.print(RedisKeyConstant.BIZ_CODE_VALUE.concat(key));
        T t = (T) redisTemplate.opsForValue().get(RedisKeyConstant.BIZ_CODE_VALUE.concat(key));
        logger.info("获取业务数据为：{}", JSON.toJSONString(t));
        int tryCount = (int) redisTemplate.opsForValue().get(RedisKeyConstant.TRY_COUNT.concat(key));
        logger.info("尝试第{}次执行",tryCount);
        if(tryCount > 3){
            logHandler(t);
            redisUtil.unlock(RedisKeyConstant.LOCK.concat(key).concat(key));
            return ;
        }
        boolean flag = bizHandler(t);
        delRedisKey(flag,key);
        redisUtil.unlock(RedisKeyConstant.LOCK.concat(key).concat(key));
        this.endHandler(flag,t);
    }

    
    protected abstract boolean bizHandler(T t);

    
    protected abstract void logHandler(T t);


    
    protected abstract void endHandler(boolean flag,T t);

    protected  void delRedisKey(Boolean flag, String key){
        if(flag){
            redisTemplate.delete(RedisKeyConstant.TRY_COUNT.concat(key));
            redisTemplate.delete(RedisKeyConstant.BIZ_CODE_VALUE.concat(key));
        }else{
            redisTemplate.opsForValue().set(key,key,1, TimeUnit.SECONDS);
            redisTemplate.opsForValue().set(RedisKeyConstant.LOCK.concat(key), 0,2000,TimeUnit.SECONDS);
            redisTemplate.opsForValue().increment(RedisKeyConstant.TRY_COUNT.concat(key));
        }

    }

}
