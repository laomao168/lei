package com.fmall.framework.config;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.Filter;

import org.apache.shiro.cache.ehcache.EhCacheManager;
import org.apache.shiro.codec.Base64;
import org.apache.shiro.mgt.SecurityManager;
import org.apache.shiro.spring.security.interceptor.AuthorizationAttributeSourceAdvisor;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.mgt.CookieRememberMeManager;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.apache.shiro.web.servlet.SimpleCookie;
import org.springframework.aop.framework.autoproxy.DefaultAdvisorAutoProxyCreator;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.fmall.common.utils.StringUtils;
import com.fmall.framework.shiro.realm.UserRealm;
import com.fmall.framework.shiro.session.OnlineSessionDAO;
import com.fmall.framework.shiro.session.OnlineSessionFactory;
import com.fmall.framework.shiro.web.filter.LogoutFilter;
import com.fmall.framework.shiro.web.filter.captcha.CaptchaValidateFilter;
import com.fmall.framework.shiro.web.filter.online.OnlineSessionFilter;
import com.fmall.framework.shiro.web.filter.sync.SyncOnlineSessionFilter;
import com.fmall.framework.shiro.web.session.OnlineWebSessionManager;
import com.fmall.framework.shiro.web.session.SpringSessionValidationScheduler;

import at.pollux.thymeleaf.shiro.dialect.ShiroDialect;
import net.sf.ehcache.CacheManager;


@Configuration
public class ShiroConfig
{
    public static final String PREMISSION_STRING = "perms[\"{0}\"]";

    
    @Value("${shiro.session.expireTime}")
    private int expireTime;

    
    @Value("${shiro.session.validationInterval}")
    private int validationInterval;

    
    @Value("${shiro.user.captchaEbabled}")
    private boolean captchaEbabled;

    
    @Value("${shiro.user.captchaType}")
    private String captchaType;

    
    @Value("${shiro.cookie.domain}")
    private String domain;

    
    @Value("${shiro.cookie.path}")
    private String path;

    
    @Value("${shiro.cookie.httpOnly}")
    private boolean httpOnly;

    
    @Value("${shiro.cookie.maxAge}")
    private int maxAge;

    
    @Value("${shiro.user.loginUrl}")
    private String loginUrl;

    
    @Value("${shiro.user.unauthorizedUrl}")
    private String unauthorizedUrl;
    
    private static final int time = 30 * 60 *1000;

    
    @Bean
    public EhCacheManager getEhCacheManager()
    {
        CacheManager cacheManager = CacheManager.getCacheManager("fmall");
        EhCacheManager em = new EhCacheManager();
        if (StringUtils.isNull(cacheManager))
        {
            em.setCacheManagerConfigFile("classpath:ehcache/ehcache-shiro.xml");
            return em;
        }
        else
        {
            em.setCacheManager(cacheManager);
            return em;
        }
    }

    
    @Bean
    public UserRealm userRealm(EhCacheManager cacheManager)
    {
        UserRealm userRealm = new UserRealm();
        userRealm.setCacheManager(cacheManager);
        return userRealm;
    }

    
    @Bean
    public OnlineSessionDAO sessionDAO()
    {
        OnlineSessionDAO sessionDAO = new OnlineSessionDAO();
        return sessionDAO;
    }

    
    @Bean
    public OnlineSessionFactory sessionFactory()
    {
        OnlineSessionFactory sessionFactory = new OnlineSessionFactory();
        return sessionFactory;
    }

    
    @Bean
    public SpringSessionValidationScheduler sessionValidationScheduler()
    {
        SpringSessionValidationScheduler sessionValidationScheduler = new SpringSessionValidationScheduler();
        
        sessionValidationScheduler.setSessionValidationInterval(time);
        
        sessionValidationScheduler.setSessionManager(sessionValidationManager());
        return sessionValidationScheduler;
    }

    
    @Bean
    public OnlineWebSessionManager sessionValidationManager()
    {
        OnlineWebSessionManager manager = new OnlineWebSessionManager();
        
        manager.setCacheManager(getEhCacheManager());
        
        manager.setDeleteInvalidSessions(true);
        
        manager.setGlobalSessionTimeout(time);
        
        manager.setSessionIdUrlRewritingEnabled(false);
        
        manager.setSessionValidationSchedulerEnabled(true);
        
        manager.setSessionDAO(sessionDAO());
        
        manager.setSessionFactory(sessionFactory());
        return manager;
    }

    
    @Bean
    public OnlineWebSessionManager sessionManager()
    {
        OnlineWebSessionManager manager = new OnlineWebSessionManager();
        
        manager.setCacheManager(getEhCacheManager());
        
        manager.setDeleteInvalidSessions(true);
        
        manager.setGlobalSessionTimeout(time);
        
        manager.setSessionIdUrlRewritingEnabled(false);
        
        manager.setSessionValidationScheduler(sessionValidationScheduler());
        
        manager.setSessionValidationSchedulerEnabled(true);
        
        manager.setSessionDAO(sessionDAO());
        
        manager.setSessionFactory(sessionFactory());
        return manager;
    }

    
    @Bean
    public SecurityManager securityManager(UserRealm userRealm)
    {
        DefaultWebSecurityManager securityManager = new DefaultWebSecurityManager();
        
        securityManager.setRealm(userRealm);
        
        securityManager.setRememberMeManager(rememberMeManager());
        
        securityManager.setCacheManager(getEhCacheManager());
        
        securityManager.setSessionManager(sessionManager());
        return securityManager;
    }

    
    public LogoutFilter logoutFilter()
    {
        LogoutFilter logoutFilter = new LogoutFilter();
        logoutFilter.setLoginUrl(loginUrl);
        return logoutFilter;
    }

    
    @Bean
    public ShiroFilterFactoryBean shiroFilterFactoryBean(SecurityManager securityManager)
    {
        ShiroFilterFactoryBean shiroFilterFactoryBean = new ShiroFilterFactoryBean();
        
        shiroFilterFactoryBean.setSecurityManager(securityManager);
        
        shiroFilterFactoryBean.setLoginUrl(loginUrl);
        
        shiroFilterFactoryBean.setUnauthorizedUrl(unauthorizedUrl);
        
        LinkedHashMap<String, String> filterChainDefinitionMap = new LinkedHashMap<>();
        
        filterChainDefinitionMap.put("/favicon.ico**", "anon");
        return shiroFilterFactoryBean;
    }
    @Bean
    public OnlineSessionFilter onlineSessionFilter()
    {
        OnlineSessionFilter onlineSessionFilter = new OnlineSessionFilter();
        onlineSessionFilter.setLoginUrl(loginUrl);
        return onlineSessionFilter;
    }

    
    @Bean
    public SyncOnlineSessionFilter syncOnlineSessionFilter()
    {
        SyncOnlineSessionFilter syncOnlineSessionFilter = new SyncOnlineSessionFilter();
        return syncOnlineSessionFilter;
    }

    
    @Bean
    public CaptchaValidateFilter captchaValidateFilter()
    {
        CaptchaValidateFilter captchaValidateFilter = new CaptchaValidateFilter();
        captchaValidateFilter.setCaptchaEbabled(captchaEbabled);
        captchaValidateFilter.setCaptchaType(captchaType);
        return captchaValidateFilter;
    }

    
    public SimpleCookie rememberMeCookie()
    {
        SimpleCookie cookie = new SimpleCookie("rememberMe");
        cookie.setDomain(domain);
        cookie.setPath(path);
        cookie.setHttpOnly(httpOnly);
        cookie.setMaxAge(maxAge * 24 * 60 * 60);
        return cookie;
    }

    
    public CookieRememberMeManager rememberMeManager()
    {
        CookieRememberMeManager cookieRememberMeManager = new CookieRememberMeManager();
        cookieRememberMeManager.setCookie(rememberMeCookie());
        cookieRememberMeManager.setCipherKey(Base64.decode("fCq+/xW488hMTCD+cmJ3aQ=="));
        return cookieRememberMeManager;
    }

    
    @Bean
    public DefaultAdvisorAutoProxyCreator defaultAdvisorAutoProxyCreator()
    {
        DefaultAdvisorAutoProxyCreator proxyCreator = new DefaultAdvisorAutoProxyCreator();
        proxyCreator.setProxyTargetClass(true);
        return proxyCreator;
    }

    
    @Bean
    public ShiroDialect shiroDialect()
    {
        return new ShiroDialect();
    }

    
    @Bean
    public AuthorizationAttributeSourceAdvisor authorizationAttributeSourceAdvisor(
            @Qualifier("securityManager") SecurityManager securityManager)
    {
        AuthorizationAttributeSourceAdvisor authorizationAttributeSourceAdvisor = new AuthorizationAttributeSourceAdvisor();
        authorizationAttributeSourceAdvisor.setSecurityManager(securityManager);
        return authorizationAttributeSourceAdvisor;
    }
}
