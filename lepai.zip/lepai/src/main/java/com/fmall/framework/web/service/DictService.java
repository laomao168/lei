package com.fmall.framework.web.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fmall.project.system.dict.domain.DictData;
import com.fmall.project.system.dict.service.IDictDataService;


@Component
public class DictService
{
    @Autowired
    private IDictDataService dictDataService;

    
    public List<DictData> selectDictData(String dictType)
    {
        return dictDataService.selectDictDataByType(dictType);
    }
}
