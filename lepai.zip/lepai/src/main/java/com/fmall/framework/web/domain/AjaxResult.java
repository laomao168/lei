package com.fmall.framework.web.domain;

import java.io.Serializable;
import java.util.HashMap;


public class AjaxResult extends HashMap<String, Object> implements Serializable
{
    private static final long serialVersionUID = 1L;

    
    public AjaxResult()
    {
    }

    
    public static AjaxResult error()
    {
        return error(1, "操作失败");
    }



    
    public static AjaxResult error(String msg)
    {
        return error(500, msg);
    }

    
    public static AjaxResult error(int code, String msg)
    {
        AjaxResult json = new AjaxResult();
        json.put("code", code);
        json.put("msg", msg);
        return json;
    }
    
    public static AjaxResult error(int code, String msg,Object data)
    {
        AjaxResult json = new AjaxResult();
        json.put("code", code);
        json.put("msg", msg);
        json.put("data", data);
        return json;
    }
    
    public static AjaxResult success(int code , String msg,Object data)
    {
        AjaxResult json = new AjaxResult();
        json.put("msg", msg);
        json.put("code", code);
        json.put("data", data);
        return json;
    }
    
    public static AjaxResult success(String msg)
    {
        AjaxResult json = new AjaxResult();
        json.put("msg", msg);
        json.put("code", 0);
        return json;
    }
    
    
    public static AjaxResult success()
    {
        return AjaxResult.success("操作成功");
    }

    
    @Override
    public AjaxResult put(String key, Object value)
    {
        super.put(key, value);
        return this;
    }
}
