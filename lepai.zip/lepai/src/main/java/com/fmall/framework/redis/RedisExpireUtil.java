package com.fmall.framework.redis;

import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;


@Service
public class RedisExpireUtil {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Resource
    private RedisTemplate<String, Object> redisTemplate;

    
    public void setRedisExpire(String redisKey,String title,Object obj, Long expireSecond){




        redisTemplate.opsForValue().set(redisKey,title,expireSecond, TimeUnit.SECONDS);
        redisTemplate.opsForValue().set(RedisKeyConstant.BIZ_CODE_VALUE.concat(redisKey), obj,expireSecond+60, TimeUnit.SECONDS);
        redisTemplate.opsForValue().set(RedisKeyConstant.TRY_COUNT.concat(redisKey), 0,expireSecond+60,TimeUnit.SECONDS);
        redisTemplate.opsForValue().set(RedisKeyConstant.LOCK.concat(redisKey), 0,expireSecond+60,TimeUnit.SECONDS);
    }

    
    public void delRedisExpire(String redisKey){
        redisTemplate.delete(redisKey);
        redisTemplate.delete(RedisKeyConstant.BIZ_CODE_VALUE.concat(redisKey));
        redisTemplate.delete(RedisKeyConstant.TRY_COUNT.concat(redisKey));
        redisTemplate.delete(RedisKeyConstant.LOCK.concat(redisKey));
    }



}
