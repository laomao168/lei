package com.fmall.framework.redis;


public interface RedisPublishHandler<T> {


    
     boolean support(String key);

    
    void handler(String key);
}
